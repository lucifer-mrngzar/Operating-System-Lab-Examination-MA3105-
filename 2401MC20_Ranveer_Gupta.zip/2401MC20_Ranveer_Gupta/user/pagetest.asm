
user/_pagetest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	1000                	addi	s0,sp,32
  char *p;
  int pid;

  printf("\n===== PAGE TABLE INSPECTION TEST =====\n");
   8:	00001517          	auipc	a0,0x1
   c:	9d850513          	addi	a0,a0,-1576 # 9e0 <malloc+0xfe>
  10:	017000ef          	jal	826 <printf>

  p = sbrk(4096);
  14:	6505                	lui	a0,0x1
  16:	35e000ef          	jal	374 <sbrk>
  if(p == (char*)-1){
  1a:	57fd                	li	a5,-1
  1c:	08f50363          	beq	a0,a5,a2 <main+0xa2>
  20:	e426                	sd	s1,8(sp)
  22:	84aa                	mv	s1,a0
    printf("Memory allocation failed\n");
    exit(1);
  }

  p[0] = 'A';
  24:	04100793          	li	a5,65
  28:	00f50023          	sb	a5,0(a0) # 1000 <freep>

  printf("\nBefore removing write permission:\n");
  2c:	00001517          	auipc	a0,0x1
  30:	a0450513          	addi	a0,a0,-1532 # a30 <malloc+0x14e>
  34:	7f2000ef          	jal	826 <printf>
  pageinfo((uint64)p);
  38:	8526                	mv	a0,s1
  3a:	426000ef          	jal	460 <pageinfo>

  printf("\nSetting page to read-only...\n");
  3e:	00001517          	auipc	a0,0x1
  42:	a1a50513          	addi	a0,a0,-1510 # a58 <malloc+0x176>
  46:	7e0000ef          	jal	826 <printf>
  if(setreadonly((uint64)p) < 0){
  4a:	8526                	mv	a0,s1
  4c:	41c000ef          	jal	468 <setreadonly>
  50:	06054363          	bltz	a0,b6 <main+0xb6>
    printf("setreadonly failed\n");
    exit(1);
  }

  printf("\nAfter removing write permission:\n");
  54:	00001517          	auipc	a0,0x1
  58:	a3c50513          	addi	a0,a0,-1476 # a90 <malloc+0x1ae>
  5c:	7ca000ef          	jal	826 <printf>
  pageinfo((uint64)p);
  60:	8526                	mv	a0,s1
  62:	3fe000ef          	jal	460 <pageinfo>

  printf("\n===== WRITE PROTECTION TEST =====\n");
  66:	00001517          	auipc	a0,0x1
  6a:	a5250513          	addi	a0,a0,-1454 # ab8 <malloc+0x1d6>
  6e:	7b8000ef          	jal	826 <printf>

  pid = fork();
  72:	32e000ef          	jal	3a0 <fork>
  if(pid < 0){
  76:	04054963          	bltz	a0,c8 <main+0xc8>
    printf("Fork failed\n");
    exit(1);
  }

  if(pid == 0){
  7a:	e125                	bnez	a0,da <main+0xda>
    printf("Child attempting to write to read-only page...\n");
  7c:	00001517          	auipc	a0,0x1
  80:	a7450513          	addi	a0,a0,-1420 # af0 <malloc+0x20e>
  84:	7a2000ef          	jal	826 <printf>
    p[0] = 'B';
  88:	04200793          	li	a5,66
  8c:	00f48023          	sb	a5,0(s1)
    printf("ERROR: Write unexpectedly succeeded!\n");
  90:	00001517          	auipc	a0,0x1
  94:	a9050513          	addi	a0,a0,-1392 # b20 <malloc+0x23e>
  98:	78e000ef          	jal	826 <printf>
    exit(1);
  9c:	4505                	li	a0,1
  9e:	30a000ef          	jal	3a8 <exit>
  a2:	e426                	sd	s1,8(sp)
    printf("Memory allocation failed\n");
  a4:	00001517          	auipc	a0,0x1
  a8:	96c50513          	addi	a0,a0,-1684 # a10 <malloc+0x12e>
  ac:	77a000ef          	jal	826 <printf>
    exit(1);
  b0:	4505                	li	a0,1
  b2:	2f6000ef          	jal	3a8 <exit>
    printf("setreadonly failed\n");
  b6:	00001517          	auipc	a0,0x1
  ba:	9c250513          	addi	a0,a0,-1598 # a78 <malloc+0x196>
  be:	768000ef          	jal	826 <printf>
    exit(1);
  c2:	4505                	li	a0,1
  c4:	2e4000ef          	jal	3a8 <exit>
    printf("Fork failed\n");
  c8:	00001517          	auipc	a0,0x1
  cc:	a1850513          	addi	a0,a0,-1512 # ae0 <malloc+0x1fe>
  d0:	756000ef          	jal	826 <printf>
    exit(1);
  d4:	4505                	li	a0,1
  d6:	2d2000ef          	jal	3a8 <exit>
  }

  wait(0);
  da:	4501                	li	a0,0
  dc:	2d4000ef          	jal	3b0 <wait>
  printf("Parent survived the child's expected page fault.\n");
  e0:	00001517          	auipc	a0,0x1
  e4:	a6850513          	addi	a0,a0,-1432 # b48 <malloc+0x266>
  e8:	73e000ef          	jal	826 <printf>

  exit(0);
  ec:	4501                	li	a0,0
  ee:	2ba000ef          	jal	3a8 <exit>

00000000000000f2 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  f2:	1141                	addi	sp,sp,-16
  f4:	e406                	sd	ra,8(sp)
  f6:	e022                	sd	s0,0(sp)
  f8:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  fa:	f07ff0ef          	jal	0 <main>
  exit(r);
  fe:	2aa000ef          	jal	3a8 <exit>

0000000000000102 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 102:	1141                	addi	sp,sp,-16
 104:	e406                	sd	ra,8(sp)
 106:	e022                	sd	s0,0(sp)
 108:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 10a:	87aa                	mv	a5,a0
 10c:	0585                	addi	a1,a1,1
 10e:	0785                	addi	a5,a5,1
 110:	fff5c703          	lbu	a4,-1(a1)
 114:	fee78fa3          	sb	a4,-1(a5)
 118:	fb75                	bnez	a4,10c <strcpy+0xa>
    ;
  return os;
}
 11a:	60a2                	ld	ra,8(sp)
 11c:	6402                	ld	s0,0(sp)
 11e:	0141                	addi	sp,sp,16
 120:	8082                	ret

0000000000000122 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 122:	1141                	addi	sp,sp,-16
 124:	e406                	sd	ra,8(sp)
 126:	e022                	sd	s0,0(sp)
 128:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 12a:	00054783          	lbu	a5,0(a0)
 12e:	cb91                	beqz	a5,142 <strcmp+0x20>
 130:	0005c703          	lbu	a4,0(a1)
 134:	00f71763          	bne	a4,a5,142 <strcmp+0x20>
    p++, q++;
 138:	0505                	addi	a0,a0,1
 13a:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 13c:	00054783          	lbu	a5,0(a0)
 140:	fbe5                	bnez	a5,130 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 142:	0005c503          	lbu	a0,0(a1)
}
 146:	40a7853b          	subw	a0,a5,a0
 14a:	60a2                	ld	ra,8(sp)
 14c:	6402                	ld	s0,0(sp)
 14e:	0141                	addi	sp,sp,16
 150:	8082                	ret

0000000000000152 <strlen>:

uint
strlen(const char *s)
{
 152:	1141                	addi	sp,sp,-16
 154:	e406                	sd	ra,8(sp)
 156:	e022                	sd	s0,0(sp)
 158:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 15a:	00054783          	lbu	a5,0(a0)
 15e:	cf91                	beqz	a5,17a <strlen+0x28>
 160:	00150793          	addi	a5,a0,1
 164:	86be                	mv	a3,a5
 166:	0785                	addi	a5,a5,1
 168:	fff7c703          	lbu	a4,-1(a5)
 16c:	ff65                	bnez	a4,164 <strlen+0x12>
 16e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 172:	60a2                	ld	ra,8(sp)
 174:	6402                	ld	s0,0(sp)
 176:	0141                	addi	sp,sp,16
 178:	8082                	ret
  for (n = 0; s[n]; n++)
 17a:	4501                	li	a0,0
 17c:	bfdd                	j	172 <strlen+0x20>

000000000000017e <memset>:

void *
memset(void *dst, int c, uint n)
{
 17e:	1141                	addi	sp,sp,-16
 180:	e406                	sd	ra,8(sp)
 182:	e022                	sd	s0,0(sp)
 184:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 186:	ca19                	beqz	a2,19c <memset+0x1e>
 188:	87aa                	mv	a5,a0
 18a:	1602                	slli	a2,a2,0x20
 18c:	9201                	srli	a2,a2,0x20
 18e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 192:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 196:	0785                	addi	a5,a5,1
 198:	fee79de3          	bne	a5,a4,192 <memset+0x14>
  }
  return dst;
}
 19c:	60a2                	ld	ra,8(sp)
 19e:	6402                	ld	s0,0(sp)
 1a0:	0141                	addi	sp,sp,16
 1a2:	8082                	ret

00000000000001a4 <strchr>:

char *
strchr(const char *s, char c)
{
 1a4:	1141                	addi	sp,sp,-16
 1a6:	e406                	sd	ra,8(sp)
 1a8:	e022                	sd	s0,0(sp)
 1aa:	0800                	addi	s0,sp,16
  for (; *s; s++)
 1ac:	00054783          	lbu	a5,0(a0)
 1b0:	c799                	beqz	a5,1be <strchr+0x1a>
    if (*s == c)
 1b2:	00f58763          	beq	a1,a5,1c0 <strchr+0x1c>
  for (; *s; s++)
 1b6:	0505                	addi	a0,a0,1
 1b8:	00054783          	lbu	a5,0(a0)
 1bc:	fbfd                	bnez	a5,1b2 <strchr+0xe>
      return (char *)s;
  return 0;
 1be:	4501                	li	a0,0
}
 1c0:	60a2                	ld	ra,8(sp)
 1c2:	6402                	ld	s0,0(sp)
 1c4:	0141                	addi	sp,sp,16
 1c6:	8082                	ret

00000000000001c8 <gets>:

char *
gets(char *buf, int max)
{
 1c8:	711d                	addi	sp,sp,-96
 1ca:	ec86                	sd	ra,88(sp)
 1cc:	e8a2                	sd	s0,80(sp)
 1ce:	e4a6                	sd	s1,72(sp)
 1d0:	e0ca                	sd	s2,64(sp)
 1d2:	fc4e                	sd	s3,56(sp)
 1d4:	f852                	sd	s4,48(sp)
 1d6:	f456                	sd	s5,40(sp)
 1d8:	f05a                	sd	s6,32(sp)
 1da:	ec5e                	sd	s7,24(sp)
 1dc:	e862                	sd	s8,16(sp)
 1de:	1080                	addi	s0,sp,96
 1e0:	8baa                	mv	s7,a0
 1e2:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 1e4:	892a                	mv	s2,a0
 1e6:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1e8:	faf40b13          	addi	s6,s0,-81
 1ec:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 1ee:	8c26                	mv	s8,s1
 1f0:	0014899b          	addiw	s3,s1,1
 1f4:	84ce                	mv	s1,s3
 1f6:	0349d863          	bge	s3,s4,226 <gets+0x5e>
    cc = read(0, &c, 1);
 1fa:	8656                	mv	a2,s5
 1fc:	85da                	mv	a1,s6
 1fe:	4501                	li	a0,0
 200:	1c0000ef          	jal	3c0 <read>
    if (cc < 1)
 204:	02a05163          	blez	a0,226 <gets+0x5e>
      break;
    buf[i++] = c;
 208:	faf44783          	lbu	a5,-81(s0)
 20c:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 210:	0905                	addi	s2,s2,1
 212:	ff678713          	addi	a4,a5,-10
 216:	00173713          	seqz	a4,a4
 21a:	17cd                	addi	a5,a5,-13
 21c:	0017b793          	seqz	a5,a5
 220:	8fd9                	or	a5,a5,a4
 222:	d7f1                	beqz	a5,1ee <gets+0x26>
    buf[i++] = c;
 224:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 226:	9c5e                	add	s8,s8,s7
 228:	000c0023          	sb	zero,0(s8)
  return buf;
}
 22c:	855e                	mv	a0,s7
 22e:	60e6                	ld	ra,88(sp)
 230:	6446                	ld	s0,80(sp)
 232:	64a6                	ld	s1,72(sp)
 234:	6906                	ld	s2,64(sp)
 236:	79e2                	ld	s3,56(sp)
 238:	7a42                	ld	s4,48(sp)
 23a:	7aa2                	ld	s5,40(sp)
 23c:	7b02                	ld	s6,32(sp)
 23e:	6be2                	ld	s7,24(sp)
 240:	6c42                	ld	s8,16(sp)
 242:	6125                	addi	sp,sp,96
 244:	8082                	ret

0000000000000246 <stat>:

int
stat(const char *n, struct stat *st)
{
 246:	1101                	addi	sp,sp,-32
 248:	ec06                	sd	ra,24(sp)
 24a:	e822                	sd	s0,16(sp)
 24c:	e04a                	sd	s2,0(sp)
 24e:	1000                	addi	s0,sp,32
 250:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 252:	4581                	li	a1,0
 254:	194000ef          	jal	3e8 <open>
  if (fd < 0)
 258:	02054263          	bltz	a0,27c <stat+0x36>
 25c:	e426                	sd	s1,8(sp)
 25e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 260:	85ca                	mv	a1,s2
 262:	19e000ef          	jal	400 <fstat>
 266:	892a                	mv	s2,a0
  close(fd);
 268:	8526                	mv	a0,s1
 26a:	166000ef          	jal	3d0 <close>
  return r;
 26e:	64a2                	ld	s1,8(sp)
}
 270:	854a                	mv	a0,s2
 272:	60e2                	ld	ra,24(sp)
 274:	6442                	ld	s0,16(sp)
 276:	6902                	ld	s2,0(sp)
 278:	6105                	addi	sp,sp,32
 27a:	8082                	ret
    return -1;
 27c:	57fd                	li	a5,-1
 27e:	893e                	mv	s2,a5
 280:	bfc5                	j	270 <stat+0x2a>

0000000000000282 <atoi>:

int
atoi(const char *s)
{
 282:	1141                	addi	sp,sp,-16
 284:	e406                	sd	ra,8(sp)
 286:	e022                	sd	s0,0(sp)
 288:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 28a:	00054683          	lbu	a3,0(a0)
 28e:	fd06879b          	addiw	a5,a3,-48
 292:	0ff7f793          	zext.b	a5,a5
 296:	4625                	li	a2,9
 298:	02f66963          	bltu	a2,a5,2ca <atoi+0x48>
 29c:	872a                	mv	a4,a0
  n = 0;
 29e:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 2a0:	0705                	addi	a4,a4,1
 2a2:	0025179b          	slliw	a5,a0,0x2
 2a6:	9fa9                	addw	a5,a5,a0
 2a8:	0017979b          	slliw	a5,a5,0x1
 2ac:	9fb5                	addw	a5,a5,a3
 2ae:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 2b2:	00074683          	lbu	a3,0(a4)
 2b6:	fd06879b          	addiw	a5,a3,-48
 2ba:	0ff7f793          	zext.b	a5,a5
 2be:	fef671e3          	bgeu	a2,a5,2a0 <atoi+0x1e>
  return n;
}
 2c2:	60a2                	ld	ra,8(sp)
 2c4:	6402                	ld	s0,0(sp)
 2c6:	0141                	addi	sp,sp,16
 2c8:	8082                	ret
  n = 0;
 2ca:	4501                	li	a0,0
 2cc:	bfdd                	j	2c2 <atoi+0x40>

00000000000002ce <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 2ce:	1141                	addi	sp,sp,-16
 2d0:	e406                	sd	ra,8(sp)
 2d2:	e022                	sd	s0,0(sp)
 2d4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2d6:	02b57563          	bgeu	a0,a1,300 <memmove+0x32>
    while (n-- > 0)
 2da:	00c05f63          	blez	a2,2f8 <memmove+0x2a>
 2de:	1602                	slli	a2,a2,0x20
 2e0:	9201                	srli	a2,a2,0x20
 2e2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2e6:	872a                	mv	a4,a0
      *dst++ = *src++;
 2e8:	0585                	addi	a1,a1,1
 2ea:	0705                	addi	a4,a4,1
 2ec:	fff5c683          	lbu	a3,-1(a1)
 2f0:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 2f4:	fee79ae3          	bne	a5,a4,2e8 <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2f8:	60a2                	ld	ra,8(sp)
 2fa:	6402                	ld	s0,0(sp)
 2fc:	0141                	addi	sp,sp,16
 2fe:	8082                	ret
    while (n-- > 0)
 300:	fec05ce3          	blez	a2,2f8 <memmove+0x2a>
    dst += n;
 304:	00c50733          	add	a4,a0,a2
    src += n;
 308:	95b2                	add	a1,a1,a2
 30a:	fff6079b          	addiw	a5,a2,-1
 30e:	1782                	slli	a5,a5,0x20
 310:	9381                	srli	a5,a5,0x20
 312:	fff7c793          	not	a5,a5
 316:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 318:	15fd                	addi	a1,a1,-1
 31a:	177d                	addi	a4,a4,-1
 31c:	0005c683          	lbu	a3,0(a1)
 320:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 324:	fef71ae3          	bne	a4,a5,318 <memmove+0x4a>
 328:	bfc1                	j	2f8 <memmove+0x2a>

000000000000032a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 32a:	1141                	addi	sp,sp,-16
 32c:	e406                	sd	ra,8(sp)
 32e:	e022                	sd	s0,0(sp)
 330:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 332:	ce19                	beqz	a2,350 <memcmp+0x26>
 334:	1602                	slli	a2,a2,0x20
 336:	9201                	srli	a2,a2,0x20
 338:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 33c:	00054783          	lbu	a5,0(a0)
 340:	0005c703          	lbu	a4,0(a1)
 344:	00e79b63          	bne	a5,a4,35a <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 348:	0505                	addi	a0,a0,1
    p2++;
 34a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 34c:	fed518e3          	bne	a0,a3,33c <memcmp+0x12>
  }
  return 0;
 350:	4501                	li	a0,0
}
 352:	60a2                	ld	ra,8(sp)
 354:	6402                	ld	s0,0(sp)
 356:	0141                	addi	sp,sp,16
 358:	8082                	ret
      return *p1 - *p2;
 35a:	40e7853b          	subw	a0,a5,a4
 35e:	bfd5                	j	352 <memcmp+0x28>

0000000000000360 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 360:	1141                	addi	sp,sp,-16
 362:	e406                	sd	ra,8(sp)
 364:	e022                	sd	s0,0(sp)
 366:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 368:	f67ff0ef          	jal	2ce <memmove>
}
 36c:	60a2                	ld	ra,8(sp)
 36e:	6402                	ld	s0,0(sp)
 370:	0141                	addi	sp,sp,16
 372:	8082                	ret

0000000000000374 <sbrk>:

char *
sbrk(int n)
{
 374:	1141                	addi	sp,sp,-16
 376:	e406                	sd	ra,8(sp)
 378:	e022                	sd	s0,0(sp)
 37a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 37c:	4585                	li	a1,1
 37e:	0b2000ef          	jal	430 <sys_sbrk>
}
 382:	60a2                	ld	ra,8(sp)
 384:	6402                	ld	s0,0(sp)
 386:	0141                	addi	sp,sp,16
 388:	8082                	ret

000000000000038a <sbrklazy>:

char *
sbrklazy(int n)
{
 38a:	1141                	addi	sp,sp,-16
 38c:	e406                	sd	ra,8(sp)
 38e:	e022                	sd	s0,0(sp)
 390:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 392:	4589                	li	a1,2
 394:	09c000ef          	jal	430 <sys_sbrk>
}
 398:	60a2                	ld	ra,8(sp)
 39a:	6402                	ld	s0,0(sp)
 39c:	0141                	addi	sp,sp,16
 39e:	8082                	ret

00000000000003a0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3a0:	4885                	li	a7,1
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <exit>:
.global exit
exit:
 li a7, SYS_exit
 3a8:	4889                	li	a7,2
 ecall
 3aa:	00000073          	ecall
 ret
 3ae:	8082                	ret

00000000000003b0 <wait>:
.global wait
wait:
 li a7, SYS_wait
 3b0:	488d                	li	a7,3
 ecall
 3b2:	00000073          	ecall
 ret
 3b6:	8082                	ret

00000000000003b8 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3b8:	4891                	li	a7,4
 ecall
 3ba:	00000073          	ecall
 ret
 3be:	8082                	ret

00000000000003c0 <read>:
.global read
read:
 li a7, SYS_read
 3c0:	4895                	li	a7,5
 ecall
 3c2:	00000073          	ecall
 ret
 3c6:	8082                	ret

00000000000003c8 <write>:
.global write
write:
 li a7, SYS_write
 3c8:	48c1                	li	a7,16
 ecall
 3ca:	00000073          	ecall
 ret
 3ce:	8082                	ret

00000000000003d0 <close>:
.global close
close:
 li a7, SYS_close
 3d0:	48d5                	li	a7,21
 ecall
 3d2:	00000073          	ecall
 ret
 3d6:	8082                	ret

00000000000003d8 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3d8:	4899                	li	a7,6
 ecall
 3da:	00000073          	ecall
 ret
 3de:	8082                	ret

00000000000003e0 <exec>:
.global exec
exec:
 li a7, SYS_exec
 3e0:	489d                	li	a7,7
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <open>:
.global open
open:
 li a7, SYS_open
 3e8:	48bd                	li	a7,15
 ecall
 3ea:	00000073          	ecall
 ret
 3ee:	8082                	ret

00000000000003f0 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3f0:	48c5                	li	a7,17
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3f8:	48c9                	li	a7,18
 ecall
 3fa:	00000073          	ecall
 ret
 3fe:	8082                	ret

0000000000000400 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 400:	48a1                	li	a7,8
 ecall
 402:	00000073          	ecall
 ret
 406:	8082                	ret

0000000000000408 <link>:
.global link
link:
 li a7, SYS_link
 408:	48cd                	li	a7,19
 ecall
 40a:	00000073          	ecall
 ret
 40e:	8082                	ret

0000000000000410 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 410:	48d1                	li	a7,20
 ecall
 412:	00000073          	ecall
 ret
 416:	8082                	ret

0000000000000418 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 418:	48a5                	li	a7,9
 ecall
 41a:	00000073          	ecall
 ret
 41e:	8082                	ret

0000000000000420 <dup>:
.global dup
dup:
 li a7, SYS_dup
 420:	48a9                	li	a7,10
 ecall
 422:	00000073          	ecall
 ret
 426:	8082                	ret

0000000000000428 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 428:	48ad                	li	a7,11
 ecall
 42a:	00000073          	ecall
 ret
 42e:	8082                	ret

0000000000000430 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 430:	48b1                	li	a7,12
 ecall
 432:	00000073          	ecall
 ret
 436:	8082                	ret

0000000000000438 <pause>:
.global pause
pause:
 li a7, SYS_pause
 438:	48b5                	li	a7,13
 ecall
 43a:	00000073          	ecall
 ret
 43e:	8082                	ret

0000000000000440 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 440:	48b9                	li	a7,14
 ecall
 442:	00000073          	ecall
 ret
 446:	8082                	ret

0000000000000448 <sync>:
.global sync
sync:
 li a7, SYS_sync
 448:	48d9                	li	a7,22
 ecall
 44a:	00000073          	ecall
 ret
 44e:	8082                	ret

0000000000000450 <memstats>:
.global memstats
memstats:
 li a7, SYS_memstats
 450:	48dd                	li	a7,23
 ecall
 452:	00000073          	ecall
 ret
 456:	8082                	ret

0000000000000458 <vtop>:
.global vtop
vtop:
 li a7, SYS_vtop
 458:	48e1                	li	a7,24
 ecall
 45a:	00000073          	ecall
 ret
 45e:	8082                	ret

0000000000000460 <pageinfo>:
.global pageinfo
pageinfo:
 li a7, SYS_pageinfo
 460:	48e5                	li	a7,25
 ecall
 462:	00000073          	ecall
 ret
 466:	8082                	ret

0000000000000468 <setreadonly>:
.global setreadonly
setreadonly:
 li a7, SYS_setreadonly
 468:	48e9                	li	a7,26
 ecall
 46a:	00000073          	ecall
 ret
 46e:	8082                	ret

0000000000000470 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 470:	1101                	addi	sp,sp,-32
 472:	ec06                	sd	ra,24(sp)
 474:	e822                	sd	s0,16(sp)
 476:	1000                	addi	s0,sp,32
 478:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 47c:	4605                	li	a2,1
 47e:	fef40593          	addi	a1,s0,-17
 482:	f47ff0ef          	jal	3c8 <write>
}
 486:	60e2                	ld	ra,24(sp)
 488:	6442                	ld	s0,16(sp)
 48a:	6105                	addi	sp,sp,32
 48c:	8082                	ret

000000000000048e <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 48e:	715d                	addi	sp,sp,-80
 490:	e486                	sd	ra,72(sp)
 492:	e0a2                	sd	s0,64(sp)
 494:	f84a                	sd	s2,48(sp)
 496:	f44e                	sd	s3,40(sp)
 498:	0880                	addi	s0,sp,80
 49a:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 49c:	00d036b3          	snez	a3,a3
 4a0:	03f5d793          	srli	a5,a1,0x3f
 4a4:	8efd                	and	a3,a3,a5
  neg = 0;
 4a6:	4301                	li	t1,0
  if (sgn && xx < 0) {
 4a8:	c681                	beqz	a3,4b0 <printint+0x22>
    neg = 1;
    x = -xx;
 4aa:	40b005b3          	neg	a1,a1
    neg = 1;
 4ae:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 4b0:	fb840993          	addi	s3,s0,-72
  neg = 0;
 4b4:	86ce                	mv	a3,s3
  i = 0;
 4b6:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 4b8:	00000817          	auipc	a6,0x0
 4bc:	6d080813          	addi	a6,a6,1744 # b88 <digits>
 4c0:	88ba                	mv	a7,a4
 4c2:	0017051b          	addiw	a0,a4,1
 4c6:	872a                	mv	a4,a0
 4c8:	02c5f7b3          	remu	a5,a1,a2
 4cc:	97c2                	add	a5,a5,a6
 4ce:	0007c783          	lbu	a5,0(a5)
 4d2:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 4d6:	87ae                	mv	a5,a1
 4d8:	02c5d5b3          	divu	a1,a1,a2
 4dc:	0685                	addi	a3,a3,1
 4de:	fec7f1e3          	bgeu	a5,a2,4c0 <printint+0x32>
  if (neg)
 4e2:	00030b63          	beqz	t1,4f8 <printint+0x6a>
    buf[i++] = '-';
 4e6:	fd040793          	addi	a5,s0,-48
 4ea:	953e                	add	a0,a0,a5
 4ec:	02d00793          	li	a5,45
 4f0:	fef50423          	sb	a5,-24(a0)
 4f4:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 4f8:	02e05563          	blez	a4,522 <printint+0x94>
 4fc:	fc26                	sd	s1,56(sp)
 4fe:	377d                	addiw	a4,a4,-1
 500:	00e984b3          	add	s1,s3,a4
 504:	19fd                	addi	s3,s3,-1
 506:	99ba                	add	s3,s3,a4
 508:	1702                	slli	a4,a4,0x20
 50a:	9301                	srli	a4,a4,0x20
 50c:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 510:	0004c583          	lbu	a1,0(s1)
 514:	854a                	mv	a0,s2
 516:	f5bff0ef          	jal	470 <putc>
  while (--i >= 0)
 51a:	14fd                	addi	s1,s1,-1
 51c:	ff349ae3          	bne	s1,s3,510 <printint+0x82>
 520:	74e2                	ld	s1,56(sp)
}
 522:	60a6                	ld	ra,72(sp)
 524:	6406                	ld	s0,64(sp)
 526:	7942                	ld	s2,48(sp)
 528:	79a2                	ld	s3,40(sp)
 52a:	6161                	addi	sp,sp,80
 52c:	8082                	ret

000000000000052e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 52e:	711d                	addi	sp,sp,-96
 530:	ec86                	sd	ra,88(sp)
 532:	e8a2                	sd	s0,80(sp)
 534:	e4a6                	sd	s1,72(sp)
 536:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 538:	0005c483          	lbu	s1,0(a1)
 53c:	2a048063          	beqz	s1,7dc <vprintf+0x2ae>
 540:	e0ca                	sd	s2,64(sp)
 542:	fc4e                	sd	s3,56(sp)
 544:	f852                	sd	s4,48(sp)
 546:	f456                	sd	s5,40(sp)
 548:	f05a                	sd	s6,32(sp)
 54a:	ec5e                	sd	s7,24(sp)
 54c:	e862                	sd	s8,16(sp)
 54e:	8b2a                	mv	s6,a0
 550:	8a2e                	mv	s4,a1
 552:	8bb2                	mv	s7,a2
  state = 0;
 554:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 556:	4901                	li	s2,0
 558:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 55a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 55e:	06400c13          	li	s8,100
 562:	a00d                	j	584 <vprintf+0x56>
        putc(fd, c0);
 564:	85a6                	mv	a1,s1
 566:	855a                	mv	a0,s6
 568:	f09ff0ef          	jal	470 <putc>
 56c:	a019                	j	572 <vprintf+0x44>
    } else if (state == '%') {
 56e:	03598363          	beq	s3,s5,594 <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 572:	0019079b          	addiw	a5,s2,1
 576:	893e                	mv	s2,a5
 578:	873e                	mv	a4,a5
 57a:	97d2                	add	a5,a5,s4
 57c:	0007c483          	lbu	s1,0(a5)
 580:	24048763          	beqz	s1,7ce <vprintf+0x2a0>
    c0 = fmt[i] & 0xff;
 584:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 588:	fe0993e3          	bnez	s3,56e <vprintf+0x40>
      if (c0 == '%') {
 58c:	fd579ce3          	bne	a5,s5,564 <vprintf+0x36>
        state = '%';
 590:	89be                	mv	s3,a5
 592:	b7c5                	j	572 <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 594:	00ea06b3          	add	a3,s4,a4
 598:	0016c603          	lbu	a2,1(a3)
      if (c1)
 59c:	24060563          	beqz	a2,7e6 <vprintf+0x2b8>
      if (c0 == 'd') {
 5a0:	0b878763          	beq	a5,s8,64e <vprintf+0x120>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 5a4:	f9478693          	addi	a3,a5,-108
 5a8:	0016b693          	seqz	a3,a3
 5ac:	f9c60593          	addi	a1,a2,-100
 5b0:	0015b593          	seqz	a1,a1
 5b4:	8df5                	and	a1,a1,a3
 5b6:	e9c5                	bnez	a1,666 <vprintf+0x138>
        c2 = fmt[i + 2] & 0xff;
 5b8:	9752                	add	a4,a4,s4
 5ba:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 5be:	f9460713          	addi	a4,a2,-108
 5c2:	00173713          	seqz	a4,a4
 5c6:	8f75                	and	a4,a4,a3
 5c8:	f9c50593          	addi	a1,a0,-100
 5cc:	0015b593          	seqz	a1,a1
 5d0:	8df9                	and	a1,a1,a4
 5d2:	e5dd                	bnez	a1,680 <vprintf+0x152>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 5d4:	07500593          	li	a1,117
 5d8:	0cb78163          	beq	a5,a1,69a <vprintf+0x16c>
        printint(fd, va_arg(ap, uint32), 10, 0);
      } else if (c0 == 'l' && c1 == 'u') {
 5dc:	f8b60593          	addi	a1,a2,-117
 5e0:	0015b593          	seqz	a1,a1
 5e4:	8df5                	and	a1,a1,a3
 5e6:	e5f1                	bnez	a1,6b2 <vprintf+0x184>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 5e8:	f8b50593          	addi	a1,a0,-117
 5ec:	0015b593          	seqz	a1,a1
 5f0:	8df9                	and	a1,a1,a4
 5f2:	ede9                	bnez	a1,6cc <vprintf+0x19e>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 5f4:	07800593          	li	a1,120
 5f8:	0eb78763          	beq	a5,a1,6e6 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint32), 16, 0);
      } else if (c0 == 'l' && c1 == 'x') {
 5fc:	f8860613          	addi	a2,a2,-120
 600:	00163613          	seqz	a2,a2
 604:	8ef1                	and	a3,a3,a2
 606:	0e069c63          	bnez	a3,6fe <vprintf+0x1d0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 60a:	f8850513          	addi	a0,a0,-120
 60e:	00153513          	seqz	a0,a0
 612:	8f69                	and	a4,a4,a0
 614:	10071263          	bnez	a4,718 <vprintf+0x1ea>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 618:	07000713          	li	a4,112
 61c:	10e78a63          	beq	a5,a4,730 <vprintf+0x202>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 620:	06300713          	li	a4,99
 624:	14e78a63          	beq	a5,a4,778 <vprintf+0x24a>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 628:	07300713          	li	a4,115
 62c:	16e78063          	beq	a5,a4,78c <vprintf+0x25e>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 630:	02500713          	li	a4,37
 634:	18e78863          	beq	a5,a4,7c4 <vprintf+0x296>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 638:	02500593          	li	a1,37
 63c:	855a                	mv	a0,s6
 63e:	e33ff0ef          	jal	470 <putc>
        putc(fd, c0);
 642:	85a6                	mv	a1,s1
 644:	855a                	mv	a0,s6
 646:	e2bff0ef          	jal	470 <putc>
      }

      state = 0;
 64a:	4981                	li	s3,0
 64c:	b71d                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 64e:	008b8493          	addi	s1,s7,8
 652:	4685                	li	a3,1
 654:	4629                	li	a2,10
 656:	000ba583          	lw	a1,0(s7)
 65a:	855a                	mv	a0,s6
 65c:	e33ff0ef          	jal	48e <printint>
 660:	8ba6                	mv	s7,s1
      state = 0;
 662:	4981                	li	s3,0
 664:	b739                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 666:	008b8493          	addi	s1,s7,8
 66a:	4685                	li	a3,1
 66c:	4629                	li	a2,10
 66e:	000bb583          	ld	a1,0(s7)
 672:	855a                	mv	a0,s6
 674:	e1bff0ef          	jal	48e <printint>
        i += 1;
 678:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 67a:	8ba6                	mv	s7,s1
      state = 0;
 67c:	4981                	li	s3,0
 67e:	bdd5                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 680:	008b8493          	addi	s1,s7,8
 684:	4685                	li	a3,1
 686:	4629                	li	a2,10
 688:	000bb583          	ld	a1,0(s7)
 68c:	855a                	mv	a0,s6
 68e:	e01ff0ef          	jal	48e <printint>
        i += 2;
 692:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 694:	8ba6                	mv	s7,s1
      state = 0;
 696:	4981                	li	s3,0
        i += 2;
 698:	bde9                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 69a:	008b8493          	addi	s1,s7,8
 69e:	4681                	li	a3,0
 6a0:	4629                	li	a2,10
 6a2:	000be583          	lwu	a1,0(s7)
 6a6:	855a                	mv	a0,s6
 6a8:	de7ff0ef          	jal	48e <printint>
 6ac:	8ba6                	mv	s7,s1
      state = 0;
 6ae:	4981                	li	s3,0
 6b0:	b5c9                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6b2:	008b8493          	addi	s1,s7,8
 6b6:	4681                	li	a3,0
 6b8:	4629                	li	a2,10
 6ba:	000bb583          	ld	a1,0(s7)
 6be:	855a                	mv	a0,s6
 6c0:	dcfff0ef          	jal	48e <printint>
        i += 1;
 6c4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 6c6:	8ba6                	mv	s7,s1
      state = 0;
 6c8:	4981                	li	s3,0
 6ca:	b565                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6cc:	008b8493          	addi	s1,s7,8
 6d0:	4681                	li	a3,0
 6d2:	4629                	li	a2,10
 6d4:	000bb583          	ld	a1,0(s7)
 6d8:	855a                	mv	a0,s6
 6da:	db5ff0ef          	jal	48e <printint>
        i += 2;
 6de:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6e0:	8ba6                	mv	s7,s1
      state = 0;
 6e2:	4981                	li	s3,0
        i += 2;
 6e4:	b579                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6e6:	008b8493          	addi	s1,s7,8
 6ea:	4681                	li	a3,0
 6ec:	4641                	li	a2,16
 6ee:	000be583          	lwu	a1,0(s7)
 6f2:	855a                	mv	a0,s6
 6f4:	d9bff0ef          	jal	48e <printint>
 6f8:	8ba6                	mv	s7,s1
      state = 0;
 6fa:	4981                	li	s3,0
 6fc:	bd9d                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6fe:	008b8493          	addi	s1,s7,8
 702:	4681                	li	a3,0
 704:	4641                	li	a2,16
 706:	000bb583          	ld	a1,0(s7)
 70a:	855a                	mv	a0,s6
 70c:	d83ff0ef          	jal	48e <printint>
        i += 1;
 710:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 712:	8ba6                	mv	s7,s1
      state = 0;
 714:	4981                	li	s3,0
 716:	bdb1                	j	572 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 718:	008b8493          	addi	s1,s7,8
 71c:	4641                	li	a2,16
 71e:	000bb583          	ld	a1,0(s7)
 722:	855a                	mv	a0,s6
 724:	d6bff0ef          	jal	48e <printint>
        i += 2;
 728:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 72a:	8ba6                	mv	s7,s1
      state = 0;
 72c:	4981                	li	s3,0
        i += 2;
 72e:	b591                	j	572 <vprintf+0x44>
 730:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 732:	008b8793          	addi	a5,s7,8
 736:	8cbe                	mv	s9,a5
 738:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 73c:	03000593          	li	a1,48
 740:	855a                	mv	a0,s6
 742:	d2fff0ef          	jal	470 <putc>
  putc(fd, 'x');
 746:	07800593          	li	a1,120
 74a:	855a                	mv	a0,s6
 74c:	d25ff0ef          	jal	470 <putc>
 750:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 752:	00000b97          	auipc	s7,0x0
 756:	436b8b93          	addi	s7,s7,1078 # b88 <digits>
 75a:	03c9d793          	srli	a5,s3,0x3c
 75e:	97de                	add	a5,a5,s7
 760:	0007c583          	lbu	a1,0(a5)
 764:	855a                	mv	a0,s6
 766:	d0bff0ef          	jal	470 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 76a:	0992                	slli	s3,s3,0x4
 76c:	34fd                	addiw	s1,s1,-1
 76e:	f4f5                	bnez	s1,75a <vprintf+0x22c>
        printptr(fd, va_arg(ap, uint64));
 770:	8be6                	mv	s7,s9
      state = 0;
 772:	4981                	li	s3,0
 774:	6ca2                	ld	s9,8(sp)
 776:	bbf5                	j	572 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 778:	008b8493          	addi	s1,s7,8
 77c:	000bc583          	lbu	a1,0(s7)
 780:	855a                	mv	a0,s6
 782:	cefff0ef          	jal	470 <putc>
 786:	8ba6                	mv	s7,s1
      state = 0;
 788:	4981                	li	s3,0
 78a:	b3e5                	j	572 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 78c:	008b8993          	addi	s3,s7,8
 790:	000bb483          	ld	s1,0(s7)
 794:	cc91                	beqz	s1,7b0 <vprintf+0x282>
        for (; *s; s++)
 796:	0004c583          	lbu	a1,0(s1)
 79a:	c195                	beqz	a1,7be <vprintf+0x290>
          putc(fd, *s);
 79c:	855a                	mv	a0,s6
 79e:	cd3ff0ef          	jal	470 <putc>
        for (; *s; s++)
 7a2:	0485                	addi	s1,s1,1
 7a4:	0004c583          	lbu	a1,0(s1)
 7a8:	f9f5                	bnez	a1,79c <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 7aa:	8bce                	mv	s7,s3
      state = 0;
 7ac:	4981                	li	s3,0
 7ae:	b3d1                	j	572 <vprintf+0x44>
          s = "(null)";
 7b0:	00000497          	auipc	s1,0x0
 7b4:	3d048493          	addi	s1,s1,976 # b80 <malloc+0x29e>
        for (; *s; s++)
 7b8:	02800593          	li	a1,40
 7bc:	b7c5                	j	79c <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 7be:	8bce                	mv	s7,s3
      state = 0;
 7c0:	4981                	li	s3,0
 7c2:	bb45                	j	572 <vprintf+0x44>
        putc(fd, '%');
 7c4:	85be                	mv	a1,a5
 7c6:	855a                	mv	a0,s6
 7c8:	ca9ff0ef          	jal	470 <putc>
 7cc:	bdbd                	j	64a <vprintf+0x11c>
 7ce:	6906                	ld	s2,64(sp)
 7d0:	79e2                	ld	s3,56(sp)
 7d2:	7a42                	ld	s4,48(sp)
 7d4:	7aa2                	ld	s5,40(sp)
 7d6:	7b02                	ld	s6,32(sp)
 7d8:	6be2                	ld	s7,24(sp)
 7da:	6c42                	ld	s8,16(sp)
    }
  }
}
 7dc:	60e6                	ld	ra,88(sp)
 7de:	6446                	ld	s0,80(sp)
 7e0:	64a6                	ld	s1,72(sp)
 7e2:	6125                	addi	sp,sp,96
 7e4:	8082                	ret
      if (c0 == 'd') {
 7e6:	06400713          	li	a4,100
 7ea:	e6e782e3          	beq	a5,a4,64e <vprintf+0x120>
      } else if (c0 == 'l' && c1 == 'd') {
 7ee:	f9478693          	addi	a3,a5,-108
 7f2:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 7f6:	8532                	mv	a0,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 7f8:	4701                	li	a4,0
 7fa:	bbe9                	j	5d4 <vprintf+0xa6>

00000000000007fc <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7fc:	715d                	addi	sp,sp,-80
 7fe:	ec06                	sd	ra,24(sp)
 800:	e822                	sd	s0,16(sp)
 802:	1000                	addi	s0,sp,32
 804:	e010                	sd	a2,0(s0)
 806:	e414                	sd	a3,8(s0)
 808:	e818                	sd	a4,16(s0)
 80a:	ec1c                	sd	a5,24(s0)
 80c:	03043023          	sd	a6,32(s0)
 810:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 814:	8622                	mv	a2,s0
 816:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 81a:	d15ff0ef          	jal	52e <vprintf>
}
 81e:	60e2                	ld	ra,24(sp)
 820:	6442                	ld	s0,16(sp)
 822:	6161                	addi	sp,sp,80
 824:	8082                	ret

0000000000000826 <printf>:

void
printf(const char *fmt, ...)
{
 826:	711d                	addi	sp,sp,-96
 828:	ec06                	sd	ra,24(sp)
 82a:	e822                	sd	s0,16(sp)
 82c:	1000                	addi	s0,sp,32
 82e:	e40c                	sd	a1,8(s0)
 830:	e810                	sd	a2,16(s0)
 832:	ec14                	sd	a3,24(s0)
 834:	f018                	sd	a4,32(s0)
 836:	f41c                	sd	a5,40(s0)
 838:	03043823          	sd	a6,48(s0)
 83c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 840:	00840613          	addi	a2,s0,8
 844:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 848:	85aa                	mv	a1,a0
 84a:	4505                	li	a0,1
 84c:	ce3ff0ef          	jal	52e <vprintf>
}
 850:	60e2                	ld	ra,24(sp)
 852:	6442                	ld	s0,16(sp)
 854:	6125                	addi	sp,sp,96
 856:	8082                	ret

0000000000000858 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 858:	1141                	addi	sp,sp,-16
 85a:	e406                	sd	ra,8(sp)
 85c:	e022                	sd	s0,0(sp)
 85e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 860:	ff050713          	addi	a4,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 864:	00000797          	auipc	a5,0x0
 868:	79c7b783          	ld	a5,1948(a5) # 1000 <freep>
 86c:	a095                	j	8d0 <free+0x78>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
 86e:	ff852583          	lw	a1,-8(a0)
 872:	6390                	ld	a2,0(a5)
 874:	02059813          	slli	a6,a1,0x20
 878:	01c85693          	srli	a3,a6,0x1c
 87c:	96ba                	add	a3,a3,a4
 87e:	02d60563          	beq	a2,a3,8a8 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 882:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 886:	4790                	lw	a2,8(a5)
 888:	02061593          	slli	a1,a2,0x20
 88c:	01c5d693          	srli	a3,a1,0x1c
 890:	96be                	add	a3,a3,a5
 892:	02d70263          	beq	a4,a3,8b6 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 896:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 898:	00000717          	auipc	a4,0x0
 89c:	76f73423          	sd	a5,1896(a4) # 1000 <freep>
}
 8a0:	60a2                	ld	ra,8(sp)
 8a2:	6402                	ld	s0,0(sp)
 8a4:	0141                	addi	sp,sp,16
 8a6:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 8a8:	4614                	lw	a3,8(a2)
 8aa:	9ead                	addw	a3,a3,a1
 8ac:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8b0:	6394                	ld	a3,0(a5)
 8b2:	6290                	ld	a2,0(a3)
 8b4:	b7f9                	j	882 <free+0x2a>
    p->s.size += bp->s.size;
 8b6:	ff852703          	lw	a4,-8(a0)
 8ba:	9f31                	addw	a4,a4,a2
 8bc:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8be:	ff053703          	ld	a4,-16(a0)
 8c2:	bfd1                	j	896 <free+0x3e>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8c4:	6394                	ld	a3,0(a5)
 8c6:	00d7e463          	bltu	a5,a3,8ce <free+0x76>
 8ca:	fad762e3          	bltu	a4,a3,86e <free+0x16>
 8ce:	87b6                	mv	a5,a3
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8d0:	fee7fae3          	bgeu	a5,a4,8c4 <free+0x6c>
 8d4:	6394                	ld	a3,0(a5)
 8d6:	f8d76ce3          	bltu	a4,a3,86e <free+0x16>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8da:	f8d7fae3          	bgeu	a5,a3,86e <free+0x16>
 8de:	87b6                	mv	a5,a3
 8e0:	bfc5                	j	8d0 <free+0x78>

00000000000008e2 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 8e2:	7139                	addi	sp,sp,-64
 8e4:	fc06                	sd	ra,56(sp)
 8e6:	f822                	sd	s0,48(sp)
 8e8:	f04a                	sd	s2,32(sp)
 8ea:	ec4e                	sd	s3,24(sp)
 8ec:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 8ee:	02051993          	slli	s3,a0,0x20
 8f2:	0209d993          	srli	s3,s3,0x20
 8f6:	09bd                	addi	s3,s3,15
 8f8:	0049d993          	srli	s3,s3,0x4
 8fc:	2985                	addiw	s3,s3,1
 8fe:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 900:	00000517          	auipc	a0,0x0
 904:	70053503          	ld	a0,1792(a0) # 1000 <freep>
 908:	c905                	beqz	a0,938 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 90a:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 90c:	4798                	lw	a4,8(a5)
 90e:	09377663          	bgeu	a4,s3,99a <malloc+0xb8>
 912:	f426                	sd	s1,40(sp)
 914:	e852                	sd	s4,16(sp)
 916:	e456                	sd	s5,8(sp)
 918:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 91a:	8a4e                	mv	s4,s3
 91c:	6705                	lui	a4,0x1
 91e:	00e9f363          	bgeu	s3,a4,924 <malloc+0x42>
 922:	6a05                	lui	s4,0x1
 924:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 928:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 92c:	00000497          	auipc	s1,0x0
 930:	6d448493          	addi	s1,s1,1748 # 1000 <freep>
  if (p == SBRK_ERROR)
 934:	5afd                	li	s5,-1
 936:	a83d                	j	974 <malloc+0x92>
 938:	f426                	sd	s1,40(sp)
 93a:	e852                	sd	s4,16(sp)
 93c:	e456                	sd	s5,8(sp)
 93e:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 940:	00000797          	auipc	a5,0x0
 944:	6d078793          	addi	a5,a5,1744 # 1010 <base>
 948:	00000717          	auipc	a4,0x0
 94c:	6af73c23          	sd	a5,1720(a4) # 1000 <freep>
 950:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 952:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 956:	b7d1                	j	91a <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 958:	6398                	ld	a4,0(a5)
 95a:	e118                	sd	a4,0(a0)
 95c:	a899                	j	9b2 <malloc+0xd0>
  hp->s.size = nu;
 95e:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 962:	0541                	addi	a0,a0,16
 964:	ef5ff0ef          	jal	858 <free>
  return freep;
 968:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 96a:	c125                	beqz	a0,9ca <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 96c:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 96e:	4798                	lw	a4,8(a5)
 970:	03277163          	bgeu	a4,s2,992 <malloc+0xb0>
    if (p == freep)
 974:	6098                	ld	a4,0(s1)
 976:	853e                	mv	a0,a5
 978:	fef71ae3          	bne	a4,a5,96c <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 97c:	8552                	mv	a0,s4
 97e:	9f7ff0ef          	jal	374 <sbrk>
  if (p == SBRK_ERROR)
 982:	fd551ee3          	bne	a0,s5,95e <malloc+0x7c>
        return 0;
 986:	4501                	li	a0,0
 988:	74a2                	ld	s1,40(sp)
 98a:	6a42                	ld	s4,16(sp)
 98c:	6aa2                	ld	s5,8(sp)
 98e:	6b02                	ld	s6,0(sp)
 990:	a03d                	j	9be <malloc+0xdc>
 992:	74a2                	ld	s1,40(sp)
 994:	6a42                	ld	s4,16(sp)
 996:	6aa2                	ld	s5,8(sp)
 998:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 99a:	fae90fe3          	beq	s2,a4,958 <malloc+0x76>
        p->s.size -= nunits;
 99e:	4137073b          	subw	a4,a4,s3
 9a2:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9a4:	02071693          	slli	a3,a4,0x20
 9a8:	01c6d713          	srli	a4,a3,0x1c
 9ac:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9ae:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9b2:	00000717          	auipc	a4,0x0
 9b6:	64a73723          	sd	a0,1614(a4) # 1000 <freep>
      return (void *)(p + 1);
 9ba:	01078513          	addi	a0,a5,16
  }
}
 9be:	70e2                	ld	ra,56(sp)
 9c0:	7442                	ld	s0,48(sp)
 9c2:	7902                	ld	s2,32(sp)
 9c4:	69e2                	ld	s3,24(sp)
 9c6:	6121                	addi	sp,sp,64
 9c8:	8082                	ret
 9ca:	74a2                	ld	s1,40(sp)
 9cc:	6a42                	ld	s4,16(sp)
 9ce:	6aa2                	ld	s5,8(sp)
 9d0:	6b02                	ld	s6,0(sp)
 9d2:	b7f5                	j	9be <malloc+0xdc>
