
user/_vttest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	1000                	addi	s0,sp,32
  char *p;
  uint64 pa;
  uint64 invalid = 0x40000000;

  printf("\n===== VIRTUAL TO PHYSICAL ADDRESS TEST =====\n");
   8:	00001517          	auipc	a0,0x1
   c:	9a850513          	addi	a0,a0,-1624 # 9b0 <malloc+0x100>
  10:	7e4000ef          	jal	7f4 <printf>

  p = sbrk(4096);
  14:	6505                	lui	a0,0x1
  16:	32c000ef          	jal	342 <sbrk>
  if(p == (char*)-1){
  1a:	57fd                	li	a5,-1
  1c:	06f50a63          	beq	a0,a5,90 <main+0x90>
  20:	e426                	sd	s1,8(sp)
  22:	84aa                	mv	s1,a0
    printf("Memory allocation failed\n");
    exit(1);
  }

  p[0] = 'A';
  24:	04100793          	li	a5,65
  28:	00f50023          	sb	a5,0(a0) # 1000 <freep>

  printf("Allocated virtual address: %p\n", (void*)p);
  2c:	85aa                	mv	a1,a0
  2e:	00001517          	auipc	a0,0x1
  32:	9da50513          	addi	a0,a0,-1574 # a08 <malloc+0x158>
  36:	7be000ef          	jal	7f4 <printf>

  pa = vtop((uint64)p);
  3a:	8526                	mv	a0,s1
  3c:	3ea000ef          	jal	426 <vtop>
  40:	85aa                	mv	a1,a0
  if(pa != 0)
  42:	c12d                	beqz	a0,a4 <main+0xa4>
    printf("Translated physical address: %p\n", (void*)pa);
  44:	00001517          	auipc	a0,0x1
  48:	9e450513          	addi	a0,a0,-1564 # a28 <malloc+0x178>
  4c:	7a8000ef          	jal	7f4 <printf>
  else
    printf("Translation failed\n");

  pa = vtop((uint64)p + 100);
  50:	06448513          	addi	a0,s1,100
  54:	3d2000ef          	jal	426 <vtop>
  58:	85aa                	mv	a1,a0
  printf("Address with offset 100: %p\n", (void*)pa);
  5a:	00001517          	auipc	a0,0x1
  5e:	a0e50513          	addi	a0,a0,-1522 # a68 <malloc+0x1b8>
  62:	792000ef          	jal	7f4 <printf>

  printf("\n===== INVALID ADDRESS TEST =====\n");
  66:	00001517          	auipc	a0,0x1
  6a:	a2250513          	addi	a0,a0,-1502 # a88 <malloc+0x1d8>
  6e:	786000ef          	jal	7f4 <printf>
  pa = vtop(invalid);
  72:	40000537          	lui	a0,0x40000
  76:	3b0000ef          	jal	426 <vtop>
  7a:	85aa                	mv	a1,a0

  if(pa == 0)
  7c:	e91d                	bnez	a0,b2 <main+0xb2>
    printf("Invalid/unmapped address correctly rejected.\n");
  7e:	00001517          	auipc	a0,0x1
  82:	a3250513          	addi	a0,a0,-1486 # ab0 <malloc+0x200>
  86:	76e000ef          	jal	7f4 <printf>
  else
    printf("Unexpected physical address: %p\n", (void*)pa);

  exit(0);
  8a:	4501                	li	a0,0
  8c:	2ea000ef          	jal	376 <exit>
  90:	e426                	sd	s1,8(sp)
    printf("Memory allocation failed\n");
  92:	00001517          	auipc	a0,0x1
  96:	95650513          	addi	a0,a0,-1706 # 9e8 <malloc+0x138>
  9a:	75a000ef          	jal	7f4 <printf>
    exit(1);
  9e:	4505                	li	a0,1
  a0:	2d6000ef          	jal	376 <exit>
    printf("Translation failed\n");
  a4:	00001517          	auipc	a0,0x1
  a8:	9ac50513          	addi	a0,a0,-1620 # a50 <malloc+0x1a0>
  ac:	748000ef          	jal	7f4 <printf>
  b0:	b745                	j	50 <main+0x50>
    printf("Unexpected physical address: %p\n", (void*)pa);
  b2:	00001517          	auipc	a0,0x1
  b6:	a2e50513          	addi	a0,a0,-1490 # ae0 <malloc+0x230>
  ba:	73a000ef          	jal	7f4 <printf>
  be:	b7f1                	j	8a <main+0x8a>

00000000000000c0 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  c0:	1141                	addi	sp,sp,-16
  c2:	e406                	sd	ra,8(sp)
  c4:	e022                	sd	s0,0(sp)
  c6:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  c8:	f39ff0ef          	jal	0 <main>
  exit(r);
  cc:	2aa000ef          	jal	376 <exit>

00000000000000d0 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
  d0:	1141                	addi	sp,sp,-16
  d2:	e406                	sd	ra,8(sp)
  d4:	e022                	sd	s0,0(sp)
  d6:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
  d8:	87aa                	mv	a5,a0
  da:	0585                	addi	a1,a1,1
  dc:	0785                	addi	a5,a5,1
  de:	fff5c703          	lbu	a4,-1(a1)
  e2:	fee78fa3          	sb	a4,-1(a5)
  e6:	fb75                	bnez	a4,da <strcpy+0xa>
    ;
  return os;
}
  e8:	60a2                	ld	ra,8(sp)
  ea:	6402                	ld	s0,0(sp)
  ec:	0141                	addi	sp,sp,16
  ee:	8082                	ret

00000000000000f0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  f0:	1141                	addi	sp,sp,-16
  f2:	e406                	sd	ra,8(sp)
  f4:	e022                	sd	s0,0(sp)
  f6:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
  f8:	00054783          	lbu	a5,0(a0)
  fc:	cb91                	beqz	a5,110 <strcmp+0x20>
  fe:	0005c703          	lbu	a4,0(a1)
 102:	00f71763          	bne	a4,a5,110 <strcmp+0x20>
    p++, q++;
 106:	0505                	addi	a0,a0,1
 108:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 10a:	00054783          	lbu	a5,0(a0)
 10e:	fbe5                	bnez	a5,fe <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 110:	0005c503          	lbu	a0,0(a1)
}
 114:	40a7853b          	subw	a0,a5,a0
 118:	60a2                	ld	ra,8(sp)
 11a:	6402                	ld	s0,0(sp)
 11c:	0141                	addi	sp,sp,16
 11e:	8082                	ret

0000000000000120 <strlen>:

uint
strlen(const char *s)
{
 120:	1141                	addi	sp,sp,-16
 122:	e406                	sd	ra,8(sp)
 124:	e022                	sd	s0,0(sp)
 126:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 128:	00054783          	lbu	a5,0(a0)
 12c:	cf91                	beqz	a5,148 <strlen+0x28>
 12e:	00150793          	addi	a5,a0,1
 132:	86be                	mv	a3,a5
 134:	0785                	addi	a5,a5,1
 136:	fff7c703          	lbu	a4,-1(a5)
 13a:	ff65                	bnez	a4,132 <strlen+0x12>
 13c:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 140:	60a2                	ld	ra,8(sp)
 142:	6402                	ld	s0,0(sp)
 144:	0141                	addi	sp,sp,16
 146:	8082                	ret
  for (n = 0; s[n]; n++)
 148:	4501                	li	a0,0
 14a:	bfdd                	j	140 <strlen+0x20>

000000000000014c <memset>:

void *
memset(void *dst, int c, uint n)
{
 14c:	1141                	addi	sp,sp,-16
 14e:	e406                	sd	ra,8(sp)
 150:	e022                	sd	s0,0(sp)
 152:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 154:	ca19                	beqz	a2,16a <memset+0x1e>
 156:	87aa                	mv	a5,a0
 158:	1602                	slli	a2,a2,0x20
 15a:	9201                	srli	a2,a2,0x20
 15c:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 160:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 164:	0785                	addi	a5,a5,1
 166:	fee79de3          	bne	a5,a4,160 <memset+0x14>
  }
  return dst;
}
 16a:	60a2                	ld	ra,8(sp)
 16c:	6402                	ld	s0,0(sp)
 16e:	0141                	addi	sp,sp,16
 170:	8082                	ret

0000000000000172 <strchr>:

char *
strchr(const char *s, char c)
{
 172:	1141                	addi	sp,sp,-16
 174:	e406                	sd	ra,8(sp)
 176:	e022                	sd	s0,0(sp)
 178:	0800                	addi	s0,sp,16
  for (; *s; s++)
 17a:	00054783          	lbu	a5,0(a0)
 17e:	c799                	beqz	a5,18c <strchr+0x1a>
    if (*s == c)
 180:	00f58763          	beq	a1,a5,18e <strchr+0x1c>
  for (; *s; s++)
 184:	0505                	addi	a0,a0,1
 186:	00054783          	lbu	a5,0(a0)
 18a:	fbfd                	bnez	a5,180 <strchr+0xe>
      return (char *)s;
  return 0;
 18c:	4501                	li	a0,0
}
 18e:	60a2                	ld	ra,8(sp)
 190:	6402                	ld	s0,0(sp)
 192:	0141                	addi	sp,sp,16
 194:	8082                	ret

0000000000000196 <gets>:

char *
gets(char *buf, int max)
{
 196:	711d                	addi	sp,sp,-96
 198:	ec86                	sd	ra,88(sp)
 19a:	e8a2                	sd	s0,80(sp)
 19c:	e4a6                	sd	s1,72(sp)
 19e:	e0ca                	sd	s2,64(sp)
 1a0:	fc4e                	sd	s3,56(sp)
 1a2:	f852                	sd	s4,48(sp)
 1a4:	f456                	sd	s5,40(sp)
 1a6:	f05a                	sd	s6,32(sp)
 1a8:	ec5e                	sd	s7,24(sp)
 1aa:	e862                	sd	s8,16(sp)
 1ac:	1080                	addi	s0,sp,96
 1ae:	8baa                	mv	s7,a0
 1b0:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 1b2:	892a                	mv	s2,a0
 1b4:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1b6:	faf40b13          	addi	s6,s0,-81
 1ba:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 1bc:	8c26                	mv	s8,s1
 1be:	0014899b          	addiw	s3,s1,1
 1c2:	84ce                	mv	s1,s3
 1c4:	0349d863          	bge	s3,s4,1f4 <gets+0x5e>
    cc = read(0, &c, 1);
 1c8:	8656                	mv	a2,s5
 1ca:	85da                	mv	a1,s6
 1cc:	4501                	li	a0,0
 1ce:	1c0000ef          	jal	38e <read>
    if (cc < 1)
 1d2:	02a05163          	blez	a0,1f4 <gets+0x5e>
      break;
    buf[i++] = c;
 1d6:	faf44783          	lbu	a5,-81(s0)
 1da:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 1de:	0905                	addi	s2,s2,1
 1e0:	ff678713          	addi	a4,a5,-10
 1e4:	00173713          	seqz	a4,a4
 1e8:	17cd                	addi	a5,a5,-13
 1ea:	0017b793          	seqz	a5,a5
 1ee:	8fd9                	or	a5,a5,a4
 1f0:	d7f1                	beqz	a5,1bc <gets+0x26>
    buf[i++] = c;
 1f2:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1f4:	9c5e                	add	s8,s8,s7
 1f6:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1fa:	855e                	mv	a0,s7
 1fc:	60e6                	ld	ra,88(sp)
 1fe:	6446                	ld	s0,80(sp)
 200:	64a6                	ld	s1,72(sp)
 202:	6906                	ld	s2,64(sp)
 204:	79e2                	ld	s3,56(sp)
 206:	7a42                	ld	s4,48(sp)
 208:	7aa2                	ld	s5,40(sp)
 20a:	7b02                	ld	s6,32(sp)
 20c:	6be2                	ld	s7,24(sp)
 20e:	6c42                	ld	s8,16(sp)
 210:	6125                	addi	sp,sp,96
 212:	8082                	ret

0000000000000214 <stat>:

int
stat(const char *n, struct stat *st)
{
 214:	1101                	addi	sp,sp,-32
 216:	ec06                	sd	ra,24(sp)
 218:	e822                	sd	s0,16(sp)
 21a:	e04a                	sd	s2,0(sp)
 21c:	1000                	addi	s0,sp,32
 21e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 220:	4581                	li	a1,0
 222:	194000ef          	jal	3b6 <open>
  if (fd < 0)
 226:	02054263          	bltz	a0,24a <stat+0x36>
 22a:	e426                	sd	s1,8(sp)
 22c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 22e:	85ca                	mv	a1,s2
 230:	19e000ef          	jal	3ce <fstat>
 234:	892a                	mv	s2,a0
  close(fd);
 236:	8526                	mv	a0,s1
 238:	166000ef          	jal	39e <close>
  return r;
 23c:	64a2                	ld	s1,8(sp)
}
 23e:	854a                	mv	a0,s2
 240:	60e2                	ld	ra,24(sp)
 242:	6442                	ld	s0,16(sp)
 244:	6902                	ld	s2,0(sp)
 246:	6105                	addi	sp,sp,32
 248:	8082                	ret
    return -1;
 24a:	57fd                	li	a5,-1
 24c:	893e                	mv	s2,a5
 24e:	bfc5                	j	23e <stat+0x2a>

0000000000000250 <atoi>:

int
atoi(const char *s)
{
 250:	1141                	addi	sp,sp,-16
 252:	e406                	sd	ra,8(sp)
 254:	e022                	sd	s0,0(sp)
 256:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 258:	00054683          	lbu	a3,0(a0)
 25c:	fd06879b          	addiw	a5,a3,-48
 260:	0ff7f793          	zext.b	a5,a5
 264:	4625                	li	a2,9
 266:	02f66963          	bltu	a2,a5,298 <atoi+0x48>
 26a:	872a                	mv	a4,a0
  n = 0;
 26c:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 26e:	0705                	addi	a4,a4,1
 270:	0025179b          	slliw	a5,a0,0x2
 274:	9fa9                	addw	a5,a5,a0
 276:	0017979b          	slliw	a5,a5,0x1
 27a:	9fb5                	addw	a5,a5,a3
 27c:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 280:	00074683          	lbu	a3,0(a4)
 284:	fd06879b          	addiw	a5,a3,-48
 288:	0ff7f793          	zext.b	a5,a5
 28c:	fef671e3          	bgeu	a2,a5,26e <atoi+0x1e>
  return n;
}
 290:	60a2                	ld	ra,8(sp)
 292:	6402                	ld	s0,0(sp)
 294:	0141                	addi	sp,sp,16
 296:	8082                	ret
  n = 0;
 298:	4501                	li	a0,0
 29a:	bfdd                	j	290 <atoi+0x40>

000000000000029c <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 29c:	1141                	addi	sp,sp,-16
 29e:	e406                	sd	ra,8(sp)
 2a0:	e022                	sd	s0,0(sp)
 2a2:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2a4:	02b57563          	bgeu	a0,a1,2ce <memmove+0x32>
    while (n-- > 0)
 2a8:	00c05f63          	blez	a2,2c6 <memmove+0x2a>
 2ac:	1602                	slli	a2,a2,0x20
 2ae:	9201                	srli	a2,a2,0x20
 2b0:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2b4:	872a                	mv	a4,a0
      *dst++ = *src++;
 2b6:	0585                	addi	a1,a1,1
 2b8:	0705                	addi	a4,a4,1
 2ba:	fff5c683          	lbu	a3,-1(a1)
 2be:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 2c2:	fee79ae3          	bne	a5,a4,2b6 <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2c6:	60a2                	ld	ra,8(sp)
 2c8:	6402                	ld	s0,0(sp)
 2ca:	0141                	addi	sp,sp,16
 2cc:	8082                	ret
    while (n-- > 0)
 2ce:	fec05ce3          	blez	a2,2c6 <memmove+0x2a>
    dst += n;
 2d2:	00c50733          	add	a4,a0,a2
    src += n;
 2d6:	95b2                	add	a1,a1,a2
 2d8:	fff6079b          	addiw	a5,a2,-1
 2dc:	1782                	slli	a5,a5,0x20
 2de:	9381                	srli	a5,a5,0x20
 2e0:	fff7c793          	not	a5,a5
 2e4:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2e6:	15fd                	addi	a1,a1,-1
 2e8:	177d                	addi	a4,a4,-1
 2ea:	0005c683          	lbu	a3,0(a1)
 2ee:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 2f2:	fef71ae3          	bne	a4,a5,2e6 <memmove+0x4a>
 2f6:	bfc1                	j	2c6 <memmove+0x2a>

00000000000002f8 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2f8:	1141                	addi	sp,sp,-16
 2fa:	e406                	sd	ra,8(sp)
 2fc:	e022                	sd	s0,0(sp)
 2fe:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 300:	ce19                	beqz	a2,31e <memcmp+0x26>
 302:	1602                	slli	a2,a2,0x20
 304:	9201                	srli	a2,a2,0x20
 306:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 30a:	00054783          	lbu	a5,0(a0)
 30e:	0005c703          	lbu	a4,0(a1)
 312:	00e79b63          	bne	a5,a4,328 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 316:	0505                	addi	a0,a0,1
    p2++;
 318:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 31a:	fed518e3          	bne	a0,a3,30a <memcmp+0x12>
  }
  return 0;
 31e:	4501                	li	a0,0
}
 320:	60a2                	ld	ra,8(sp)
 322:	6402                	ld	s0,0(sp)
 324:	0141                	addi	sp,sp,16
 326:	8082                	ret
      return *p1 - *p2;
 328:	40e7853b          	subw	a0,a5,a4
 32c:	bfd5                	j	320 <memcmp+0x28>

000000000000032e <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 32e:	1141                	addi	sp,sp,-16
 330:	e406                	sd	ra,8(sp)
 332:	e022                	sd	s0,0(sp)
 334:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 336:	f67ff0ef          	jal	29c <memmove>
}
 33a:	60a2                	ld	ra,8(sp)
 33c:	6402                	ld	s0,0(sp)
 33e:	0141                	addi	sp,sp,16
 340:	8082                	ret

0000000000000342 <sbrk>:

char *
sbrk(int n)
{
 342:	1141                	addi	sp,sp,-16
 344:	e406                	sd	ra,8(sp)
 346:	e022                	sd	s0,0(sp)
 348:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 34a:	4585                	li	a1,1
 34c:	0b2000ef          	jal	3fe <sys_sbrk>
}
 350:	60a2                	ld	ra,8(sp)
 352:	6402                	ld	s0,0(sp)
 354:	0141                	addi	sp,sp,16
 356:	8082                	ret

0000000000000358 <sbrklazy>:

char *
sbrklazy(int n)
{
 358:	1141                	addi	sp,sp,-16
 35a:	e406                	sd	ra,8(sp)
 35c:	e022                	sd	s0,0(sp)
 35e:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 360:	4589                	li	a1,2
 362:	09c000ef          	jal	3fe <sys_sbrk>
}
 366:	60a2                	ld	ra,8(sp)
 368:	6402                	ld	s0,0(sp)
 36a:	0141                	addi	sp,sp,16
 36c:	8082                	ret

000000000000036e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 36e:	4885                	li	a7,1
 ecall
 370:	00000073          	ecall
 ret
 374:	8082                	ret

0000000000000376 <exit>:
.global exit
exit:
 li a7, SYS_exit
 376:	4889                	li	a7,2
 ecall
 378:	00000073          	ecall
 ret
 37c:	8082                	ret

000000000000037e <wait>:
.global wait
wait:
 li a7, SYS_wait
 37e:	488d                	li	a7,3
 ecall
 380:	00000073          	ecall
 ret
 384:	8082                	ret

0000000000000386 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 386:	4891                	li	a7,4
 ecall
 388:	00000073          	ecall
 ret
 38c:	8082                	ret

000000000000038e <read>:
.global read
read:
 li a7, SYS_read
 38e:	4895                	li	a7,5
 ecall
 390:	00000073          	ecall
 ret
 394:	8082                	ret

0000000000000396 <write>:
.global write
write:
 li a7, SYS_write
 396:	48c1                	li	a7,16
 ecall
 398:	00000073          	ecall
 ret
 39c:	8082                	ret

000000000000039e <close>:
.global close
close:
 li a7, SYS_close
 39e:	48d5                	li	a7,21
 ecall
 3a0:	00000073          	ecall
 ret
 3a4:	8082                	ret

00000000000003a6 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3a6:	4899                	li	a7,6
 ecall
 3a8:	00000073          	ecall
 ret
 3ac:	8082                	ret

00000000000003ae <exec>:
.global exec
exec:
 li a7, SYS_exec
 3ae:	489d                	li	a7,7
 ecall
 3b0:	00000073          	ecall
 ret
 3b4:	8082                	ret

00000000000003b6 <open>:
.global open
open:
 li a7, SYS_open
 3b6:	48bd                	li	a7,15
 ecall
 3b8:	00000073          	ecall
 ret
 3bc:	8082                	ret

00000000000003be <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3be:	48c5                	li	a7,17
 ecall
 3c0:	00000073          	ecall
 ret
 3c4:	8082                	ret

00000000000003c6 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3c6:	48c9                	li	a7,18
 ecall
 3c8:	00000073          	ecall
 ret
 3cc:	8082                	ret

00000000000003ce <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3ce:	48a1                	li	a7,8
 ecall
 3d0:	00000073          	ecall
 ret
 3d4:	8082                	ret

00000000000003d6 <link>:
.global link
link:
 li a7, SYS_link
 3d6:	48cd                	li	a7,19
 ecall
 3d8:	00000073          	ecall
 ret
 3dc:	8082                	ret

00000000000003de <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3de:	48d1                	li	a7,20
 ecall
 3e0:	00000073          	ecall
 ret
 3e4:	8082                	ret

00000000000003e6 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3e6:	48a5                	li	a7,9
 ecall
 3e8:	00000073          	ecall
 ret
 3ec:	8082                	ret

00000000000003ee <dup>:
.global dup
dup:
 li a7, SYS_dup
 3ee:	48a9                	li	a7,10
 ecall
 3f0:	00000073          	ecall
 ret
 3f4:	8082                	ret

00000000000003f6 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3f6:	48ad                	li	a7,11
 ecall
 3f8:	00000073          	ecall
 ret
 3fc:	8082                	ret

00000000000003fe <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 3fe:	48b1                	li	a7,12
 ecall
 400:	00000073          	ecall
 ret
 404:	8082                	ret

0000000000000406 <pause>:
.global pause
pause:
 li a7, SYS_pause
 406:	48b5                	li	a7,13
 ecall
 408:	00000073          	ecall
 ret
 40c:	8082                	ret

000000000000040e <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 40e:	48b9                	li	a7,14
 ecall
 410:	00000073          	ecall
 ret
 414:	8082                	ret

0000000000000416 <sync>:
.global sync
sync:
 li a7, SYS_sync
 416:	48d9                	li	a7,22
 ecall
 418:	00000073          	ecall
 ret
 41c:	8082                	ret

000000000000041e <memstats>:
.global memstats
memstats:
 li a7, SYS_memstats
 41e:	48dd                	li	a7,23
 ecall
 420:	00000073          	ecall
 ret
 424:	8082                	ret

0000000000000426 <vtop>:
.global vtop
vtop:
 li a7, SYS_vtop
 426:	48e1                	li	a7,24
 ecall
 428:	00000073          	ecall
 ret
 42c:	8082                	ret

000000000000042e <pageinfo>:
.global pageinfo
pageinfo:
 li a7, SYS_pageinfo
 42e:	48e5                	li	a7,25
 ecall
 430:	00000073          	ecall
 ret
 434:	8082                	ret

0000000000000436 <setreadonly>:
.global setreadonly
setreadonly:
 li a7, SYS_setreadonly
 436:	48e9                	li	a7,26
 ecall
 438:	00000073          	ecall
 ret
 43c:	8082                	ret

000000000000043e <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 43e:	1101                	addi	sp,sp,-32
 440:	ec06                	sd	ra,24(sp)
 442:	e822                	sd	s0,16(sp)
 444:	1000                	addi	s0,sp,32
 446:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 44a:	4605                	li	a2,1
 44c:	fef40593          	addi	a1,s0,-17
 450:	f47ff0ef          	jal	396 <write>
}
 454:	60e2                	ld	ra,24(sp)
 456:	6442                	ld	s0,16(sp)
 458:	6105                	addi	sp,sp,32
 45a:	8082                	ret

000000000000045c <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 45c:	715d                	addi	sp,sp,-80
 45e:	e486                	sd	ra,72(sp)
 460:	e0a2                	sd	s0,64(sp)
 462:	f84a                	sd	s2,48(sp)
 464:	f44e                	sd	s3,40(sp)
 466:	0880                	addi	s0,sp,80
 468:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 46a:	00d036b3          	snez	a3,a3
 46e:	03f5d793          	srli	a5,a1,0x3f
 472:	8efd                	and	a3,a3,a5
  neg = 0;
 474:	4301                	li	t1,0
  if (sgn && xx < 0) {
 476:	c681                	beqz	a3,47e <printint+0x22>
    neg = 1;
    x = -xx;
 478:	40b005b3          	neg	a1,a1
    neg = 1;
 47c:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 47e:	fb840993          	addi	s3,s0,-72
  neg = 0;
 482:	86ce                	mv	a3,s3
  i = 0;
 484:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 486:	00000817          	auipc	a6,0x0
 48a:	68a80813          	addi	a6,a6,1674 # b10 <digits>
 48e:	88ba                	mv	a7,a4
 490:	0017051b          	addiw	a0,a4,1
 494:	872a                	mv	a4,a0
 496:	02c5f7b3          	remu	a5,a1,a2
 49a:	97c2                	add	a5,a5,a6
 49c:	0007c783          	lbu	a5,0(a5)
 4a0:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 4a4:	87ae                	mv	a5,a1
 4a6:	02c5d5b3          	divu	a1,a1,a2
 4aa:	0685                	addi	a3,a3,1
 4ac:	fec7f1e3          	bgeu	a5,a2,48e <printint+0x32>
  if (neg)
 4b0:	00030b63          	beqz	t1,4c6 <printint+0x6a>
    buf[i++] = '-';
 4b4:	fd040793          	addi	a5,s0,-48
 4b8:	953e                	add	a0,a0,a5
 4ba:	02d00793          	li	a5,45
 4be:	fef50423          	sb	a5,-24(a0)
 4c2:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 4c6:	02e05563          	blez	a4,4f0 <printint+0x94>
 4ca:	fc26                	sd	s1,56(sp)
 4cc:	377d                	addiw	a4,a4,-1
 4ce:	00e984b3          	add	s1,s3,a4
 4d2:	19fd                	addi	s3,s3,-1
 4d4:	99ba                	add	s3,s3,a4
 4d6:	1702                	slli	a4,a4,0x20
 4d8:	9301                	srli	a4,a4,0x20
 4da:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 4de:	0004c583          	lbu	a1,0(s1)
 4e2:	854a                	mv	a0,s2
 4e4:	f5bff0ef          	jal	43e <putc>
  while (--i >= 0)
 4e8:	14fd                	addi	s1,s1,-1
 4ea:	ff349ae3          	bne	s1,s3,4de <printint+0x82>
 4ee:	74e2                	ld	s1,56(sp)
}
 4f0:	60a6                	ld	ra,72(sp)
 4f2:	6406                	ld	s0,64(sp)
 4f4:	7942                	ld	s2,48(sp)
 4f6:	79a2                	ld	s3,40(sp)
 4f8:	6161                	addi	sp,sp,80
 4fa:	8082                	ret

00000000000004fc <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4fc:	711d                	addi	sp,sp,-96
 4fe:	ec86                	sd	ra,88(sp)
 500:	e8a2                	sd	s0,80(sp)
 502:	e4a6                	sd	s1,72(sp)
 504:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 506:	0005c483          	lbu	s1,0(a1)
 50a:	2a048063          	beqz	s1,7aa <vprintf+0x2ae>
 50e:	e0ca                	sd	s2,64(sp)
 510:	fc4e                	sd	s3,56(sp)
 512:	f852                	sd	s4,48(sp)
 514:	f456                	sd	s5,40(sp)
 516:	f05a                	sd	s6,32(sp)
 518:	ec5e                	sd	s7,24(sp)
 51a:	e862                	sd	s8,16(sp)
 51c:	8b2a                	mv	s6,a0
 51e:	8a2e                	mv	s4,a1
 520:	8bb2                	mv	s7,a2
  state = 0;
 522:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 524:	4901                	li	s2,0
 526:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 528:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 52c:	06400c13          	li	s8,100
 530:	a00d                	j	552 <vprintf+0x56>
        putc(fd, c0);
 532:	85a6                	mv	a1,s1
 534:	855a                	mv	a0,s6
 536:	f09ff0ef          	jal	43e <putc>
 53a:	a019                	j	540 <vprintf+0x44>
    } else if (state == '%') {
 53c:	03598363          	beq	s3,s5,562 <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 540:	0019079b          	addiw	a5,s2,1
 544:	893e                	mv	s2,a5
 546:	873e                	mv	a4,a5
 548:	97d2                	add	a5,a5,s4
 54a:	0007c483          	lbu	s1,0(a5)
 54e:	24048763          	beqz	s1,79c <vprintf+0x2a0>
    c0 = fmt[i] & 0xff;
 552:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 556:	fe0993e3          	bnez	s3,53c <vprintf+0x40>
      if (c0 == '%') {
 55a:	fd579ce3          	bne	a5,s5,532 <vprintf+0x36>
        state = '%';
 55e:	89be                	mv	s3,a5
 560:	b7c5                	j	540 <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 562:	00ea06b3          	add	a3,s4,a4
 566:	0016c603          	lbu	a2,1(a3)
      if (c1)
 56a:	24060563          	beqz	a2,7b4 <vprintf+0x2b8>
      if (c0 == 'd') {
 56e:	0b878763          	beq	a5,s8,61c <vprintf+0x120>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 572:	f9478693          	addi	a3,a5,-108
 576:	0016b693          	seqz	a3,a3
 57a:	f9c60593          	addi	a1,a2,-100
 57e:	0015b593          	seqz	a1,a1
 582:	8df5                	and	a1,a1,a3
 584:	e9c5                	bnez	a1,634 <vprintf+0x138>
        c2 = fmt[i + 2] & 0xff;
 586:	9752                	add	a4,a4,s4
 588:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 58c:	f9460713          	addi	a4,a2,-108
 590:	00173713          	seqz	a4,a4
 594:	8f75                	and	a4,a4,a3
 596:	f9c50593          	addi	a1,a0,-100
 59a:	0015b593          	seqz	a1,a1
 59e:	8df9                	and	a1,a1,a4
 5a0:	e5dd                	bnez	a1,64e <vprintf+0x152>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 5a2:	07500593          	li	a1,117
 5a6:	0cb78163          	beq	a5,a1,668 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint32), 10, 0);
      } else if (c0 == 'l' && c1 == 'u') {
 5aa:	f8b60593          	addi	a1,a2,-117
 5ae:	0015b593          	seqz	a1,a1
 5b2:	8df5                	and	a1,a1,a3
 5b4:	e5f1                	bnez	a1,680 <vprintf+0x184>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 5b6:	f8b50593          	addi	a1,a0,-117
 5ba:	0015b593          	seqz	a1,a1
 5be:	8df9                	and	a1,a1,a4
 5c0:	ede9                	bnez	a1,69a <vprintf+0x19e>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 5c2:	07800593          	li	a1,120
 5c6:	0eb78763          	beq	a5,a1,6b4 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint32), 16, 0);
      } else if (c0 == 'l' && c1 == 'x') {
 5ca:	f8860613          	addi	a2,a2,-120
 5ce:	00163613          	seqz	a2,a2
 5d2:	8ef1                	and	a3,a3,a2
 5d4:	0e069c63          	bnez	a3,6cc <vprintf+0x1d0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 5d8:	f8850513          	addi	a0,a0,-120
 5dc:	00153513          	seqz	a0,a0
 5e0:	8f69                	and	a4,a4,a0
 5e2:	10071263          	bnez	a4,6e6 <vprintf+0x1ea>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 5e6:	07000713          	li	a4,112
 5ea:	10e78a63          	beq	a5,a4,6fe <vprintf+0x202>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 5ee:	06300713          	li	a4,99
 5f2:	14e78a63          	beq	a5,a4,746 <vprintf+0x24a>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 5f6:	07300713          	li	a4,115
 5fa:	16e78063          	beq	a5,a4,75a <vprintf+0x25e>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 5fe:	02500713          	li	a4,37
 602:	18e78863          	beq	a5,a4,792 <vprintf+0x296>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 606:	02500593          	li	a1,37
 60a:	855a                	mv	a0,s6
 60c:	e33ff0ef          	jal	43e <putc>
        putc(fd, c0);
 610:	85a6                	mv	a1,s1
 612:	855a                	mv	a0,s6
 614:	e2bff0ef          	jal	43e <putc>
      }

      state = 0;
 618:	4981                	li	s3,0
 61a:	b71d                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 61c:	008b8493          	addi	s1,s7,8
 620:	4685                	li	a3,1
 622:	4629                	li	a2,10
 624:	000ba583          	lw	a1,0(s7)
 628:	855a                	mv	a0,s6
 62a:	e33ff0ef          	jal	45c <printint>
 62e:	8ba6                	mv	s7,s1
      state = 0;
 630:	4981                	li	s3,0
 632:	b739                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 634:	008b8493          	addi	s1,s7,8
 638:	4685                	li	a3,1
 63a:	4629                	li	a2,10
 63c:	000bb583          	ld	a1,0(s7)
 640:	855a                	mv	a0,s6
 642:	e1bff0ef          	jal	45c <printint>
        i += 1;
 646:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 648:	8ba6                	mv	s7,s1
      state = 0;
 64a:	4981                	li	s3,0
 64c:	bdd5                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 64e:	008b8493          	addi	s1,s7,8
 652:	4685                	li	a3,1
 654:	4629                	li	a2,10
 656:	000bb583          	ld	a1,0(s7)
 65a:	855a                	mv	a0,s6
 65c:	e01ff0ef          	jal	45c <printint>
        i += 2;
 660:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 662:	8ba6                	mv	s7,s1
      state = 0;
 664:	4981                	li	s3,0
        i += 2;
 666:	bde9                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 668:	008b8493          	addi	s1,s7,8
 66c:	4681                	li	a3,0
 66e:	4629                	li	a2,10
 670:	000be583          	lwu	a1,0(s7)
 674:	855a                	mv	a0,s6
 676:	de7ff0ef          	jal	45c <printint>
 67a:	8ba6                	mv	s7,s1
      state = 0;
 67c:	4981                	li	s3,0
 67e:	b5c9                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 680:	008b8493          	addi	s1,s7,8
 684:	4681                	li	a3,0
 686:	4629                	li	a2,10
 688:	000bb583          	ld	a1,0(s7)
 68c:	855a                	mv	a0,s6
 68e:	dcfff0ef          	jal	45c <printint>
        i += 1;
 692:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 694:	8ba6                	mv	s7,s1
      state = 0;
 696:	4981                	li	s3,0
 698:	b565                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 69a:	008b8493          	addi	s1,s7,8
 69e:	4681                	li	a3,0
 6a0:	4629                	li	a2,10
 6a2:	000bb583          	ld	a1,0(s7)
 6a6:	855a                	mv	a0,s6
 6a8:	db5ff0ef          	jal	45c <printint>
        i += 2;
 6ac:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6ae:	8ba6                	mv	s7,s1
      state = 0;
 6b0:	4981                	li	s3,0
        i += 2;
 6b2:	b579                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6b4:	008b8493          	addi	s1,s7,8
 6b8:	4681                	li	a3,0
 6ba:	4641                	li	a2,16
 6bc:	000be583          	lwu	a1,0(s7)
 6c0:	855a                	mv	a0,s6
 6c2:	d9bff0ef          	jal	45c <printint>
 6c6:	8ba6                	mv	s7,s1
      state = 0;
 6c8:	4981                	li	s3,0
 6ca:	bd9d                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6cc:	008b8493          	addi	s1,s7,8
 6d0:	4681                	li	a3,0
 6d2:	4641                	li	a2,16
 6d4:	000bb583          	ld	a1,0(s7)
 6d8:	855a                	mv	a0,s6
 6da:	d83ff0ef          	jal	45c <printint>
        i += 1;
 6de:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6e0:	8ba6                	mv	s7,s1
      state = 0;
 6e2:	4981                	li	s3,0
 6e4:	bdb1                	j	540 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6e6:	008b8493          	addi	s1,s7,8
 6ea:	4641                	li	a2,16
 6ec:	000bb583          	ld	a1,0(s7)
 6f0:	855a                	mv	a0,s6
 6f2:	d6bff0ef          	jal	45c <printint>
        i += 2;
 6f6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6f8:	8ba6                	mv	s7,s1
      state = 0;
 6fa:	4981                	li	s3,0
        i += 2;
 6fc:	b591                	j	540 <vprintf+0x44>
 6fe:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 700:	008b8793          	addi	a5,s7,8
 704:	8cbe                	mv	s9,a5
 706:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 70a:	03000593          	li	a1,48
 70e:	855a                	mv	a0,s6
 710:	d2fff0ef          	jal	43e <putc>
  putc(fd, 'x');
 714:	07800593          	li	a1,120
 718:	855a                	mv	a0,s6
 71a:	d25ff0ef          	jal	43e <putc>
 71e:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 720:	00000b97          	auipc	s7,0x0
 724:	3f0b8b93          	addi	s7,s7,1008 # b10 <digits>
 728:	03c9d793          	srli	a5,s3,0x3c
 72c:	97de                	add	a5,a5,s7
 72e:	0007c583          	lbu	a1,0(a5)
 732:	855a                	mv	a0,s6
 734:	d0bff0ef          	jal	43e <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 738:	0992                	slli	s3,s3,0x4
 73a:	34fd                	addiw	s1,s1,-1
 73c:	f4f5                	bnez	s1,728 <vprintf+0x22c>
        printptr(fd, va_arg(ap, uint64));
 73e:	8be6                	mv	s7,s9
      state = 0;
 740:	4981                	li	s3,0
 742:	6ca2                	ld	s9,8(sp)
 744:	bbf5                	j	540 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 746:	008b8493          	addi	s1,s7,8
 74a:	000bc583          	lbu	a1,0(s7)
 74e:	855a                	mv	a0,s6
 750:	cefff0ef          	jal	43e <putc>
 754:	8ba6                	mv	s7,s1
      state = 0;
 756:	4981                	li	s3,0
 758:	b3e5                	j	540 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 75a:	008b8993          	addi	s3,s7,8
 75e:	000bb483          	ld	s1,0(s7)
 762:	cc91                	beqz	s1,77e <vprintf+0x282>
        for (; *s; s++)
 764:	0004c583          	lbu	a1,0(s1)
 768:	c195                	beqz	a1,78c <vprintf+0x290>
          putc(fd, *s);
 76a:	855a                	mv	a0,s6
 76c:	cd3ff0ef          	jal	43e <putc>
        for (; *s; s++)
 770:	0485                	addi	s1,s1,1
 772:	0004c583          	lbu	a1,0(s1)
 776:	f9f5                	bnez	a1,76a <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 778:	8bce                	mv	s7,s3
      state = 0;
 77a:	4981                	li	s3,0
 77c:	b3d1                	j	540 <vprintf+0x44>
          s = "(null)";
 77e:	00000497          	auipc	s1,0x0
 782:	38a48493          	addi	s1,s1,906 # b08 <malloc+0x258>
        for (; *s; s++)
 786:	02800593          	li	a1,40
 78a:	b7c5                	j	76a <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 78c:	8bce                	mv	s7,s3
      state = 0;
 78e:	4981                	li	s3,0
 790:	bb45                	j	540 <vprintf+0x44>
        putc(fd, '%');
 792:	85be                	mv	a1,a5
 794:	855a                	mv	a0,s6
 796:	ca9ff0ef          	jal	43e <putc>
 79a:	bdbd                	j	618 <vprintf+0x11c>
 79c:	6906                	ld	s2,64(sp)
 79e:	79e2                	ld	s3,56(sp)
 7a0:	7a42                	ld	s4,48(sp)
 7a2:	7aa2                	ld	s5,40(sp)
 7a4:	7b02                	ld	s6,32(sp)
 7a6:	6be2                	ld	s7,24(sp)
 7a8:	6c42                	ld	s8,16(sp)
    }
  }
}
 7aa:	60e6                	ld	ra,88(sp)
 7ac:	6446                	ld	s0,80(sp)
 7ae:	64a6                	ld	s1,72(sp)
 7b0:	6125                	addi	sp,sp,96
 7b2:	8082                	ret
      if (c0 == 'd') {
 7b4:	06400713          	li	a4,100
 7b8:	e6e782e3          	beq	a5,a4,61c <vprintf+0x120>
      } else if (c0 == 'l' && c1 == 'd') {
 7bc:	f9478693          	addi	a3,a5,-108
 7c0:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 7c4:	8532                	mv	a0,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 7c6:	4701                	li	a4,0
 7c8:	bbe9                	j	5a2 <vprintf+0xa6>

00000000000007ca <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7ca:	715d                	addi	sp,sp,-80
 7cc:	ec06                	sd	ra,24(sp)
 7ce:	e822                	sd	s0,16(sp)
 7d0:	1000                	addi	s0,sp,32
 7d2:	e010                	sd	a2,0(s0)
 7d4:	e414                	sd	a3,8(s0)
 7d6:	e818                	sd	a4,16(s0)
 7d8:	ec1c                	sd	a5,24(s0)
 7da:	03043023          	sd	a6,32(s0)
 7de:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7e2:	8622                	mv	a2,s0
 7e4:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7e8:	d15ff0ef          	jal	4fc <vprintf>
}
 7ec:	60e2                	ld	ra,24(sp)
 7ee:	6442                	ld	s0,16(sp)
 7f0:	6161                	addi	sp,sp,80
 7f2:	8082                	ret

00000000000007f4 <printf>:

void
printf(const char *fmt, ...)
{
 7f4:	711d                	addi	sp,sp,-96
 7f6:	ec06                	sd	ra,24(sp)
 7f8:	e822                	sd	s0,16(sp)
 7fa:	1000                	addi	s0,sp,32
 7fc:	e40c                	sd	a1,8(s0)
 7fe:	e810                	sd	a2,16(s0)
 800:	ec14                	sd	a3,24(s0)
 802:	f018                	sd	a4,32(s0)
 804:	f41c                	sd	a5,40(s0)
 806:	03043823          	sd	a6,48(s0)
 80a:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 80e:	00840613          	addi	a2,s0,8
 812:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 816:	85aa                	mv	a1,a0
 818:	4505                	li	a0,1
 81a:	ce3ff0ef          	jal	4fc <vprintf>
}
 81e:	60e2                	ld	ra,24(sp)
 820:	6442                	ld	s0,16(sp)
 822:	6125                	addi	sp,sp,96
 824:	8082                	ret

0000000000000826 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 826:	1141                	addi	sp,sp,-16
 828:	e406                	sd	ra,8(sp)
 82a:	e022                	sd	s0,0(sp)
 82c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 82e:	ff050713          	addi	a4,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 832:	00000797          	auipc	a5,0x0
 836:	7ce7b783          	ld	a5,1998(a5) # 1000 <freep>
 83a:	a095                	j	89e <free+0x78>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
 83c:	ff852583          	lw	a1,-8(a0)
 840:	6390                	ld	a2,0(a5)
 842:	02059813          	slli	a6,a1,0x20
 846:	01c85693          	srli	a3,a6,0x1c
 84a:	96ba                	add	a3,a3,a4
 84c:	02d60563          	beq	a2,a3,876 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 850:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 854:	4790                	lw	a2,8(a5)
 856:	02061593          	slli	a1,a2,0x20
 85a:	01c5d693          	srli	a3,a1,0x1c
 85e:	96be                	add	a3,a3,a5
 860:	02d70263          	beq	a4,a3,884 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 864:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 866:	00000717          	auipc	a4,0x0
 86a:	78f73d23          	sd	a5,1946(a4) # 1000 <freep>
}
 86e:	60a2                	ld	ra,8(sp)
 870:	6402                	ld	s0,0(sp)
 872:	0141                	addi	sp,sp,16
 874:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 876:	4614                	lw	a3,8(a2)
 878:	9ead                	addw	a3,a3,a1
 87a:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 87e:	6394                	ld	a3,0(a5)
 880:	6290                	ld	a2,0(a3)
 882:	b7f9                	j	850 <free+0x2a>
    p->s.size += bp->s.size;
 884:	ff852703          	lw	a4,-8(a0)
 888:	9f31                	addw	a4,a4,a2
 88a:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 88c:	ff053703          	ld	a4,-16(a0)
 890:	bfd1                	j	864 <free+0x3e>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 892:	6394                	ld	a3,0(a5)
 894:	00d7e463          	bltu	a5,a3,89c <free+0x76>
 898:	fad762e3          	bltu	a4,a3,83c <free+0x16>
 89c:	87b6                	mv	a5,a3
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 89e:	fee7fae3          	bgeu	a5,a4,892 <free+0x6c>
 8a2:	6394                	ld	a3,0(a5)
 8a4:	f8d76ce3          	bltu	a4,a3,83c <free+0x16>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8a8:	f8d7fae3          	bgeu	a5,a3,83c <free+0x16>
 8ac:	87b6                	mv	a5,a3
 8ae:	bfc5                	j	89e <free+0x78>

00000000000008b0 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 8b0:	7139                	addi	sp,sp,-64
 8b2:	fc06                	sd	ra,56(sp)
 8b4:	f822                	sd	s0,48(sp)
 8b6:	f04a                	sd	s2,32(sp)
 8b8:	ec4e                	sd	s3,24(sp)
 8ba:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 8bc:	02051993          	slli	s3,a0,0x20
 8c0:	0209d993          	srli	s3,s3,0x20
 8c4:	09bd                	addi	s3,s3,15
 8c6:	0049d993          	srli	s3,s3,0x4
 8ca:	2985                	addiw	s3,s3,1
 8cc:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 8ce:	00000517          	auipc	a0,0x0
 8d2:	73253503          	ld	a0,1842(a0) # 1000 <freep>
 8d6:	c905                	beqz	a0,906 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 8d8:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 8da:	4798                	lw	a4,8(a5)
 8dc:	09377663          	bgeu	a4,s3,968 <malloc+0xb8>
 8e0:	f426                	sd	s1,40(sp)
 8e2:	e852                	sd	s4,16(sp)
 8e4:	e456                	sd	s5,8(sp)
 8e6:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 8e8:	8a4e                	mv	s4,s3
 8ea:	6705                	lui	a4,0x1
 8ec:	00e9f363          	bgeu	s3,a4,8f2 <malloc+0x42>
 8f0:	6a05                	lui	s4,0x1
 8f2:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8f6:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 8fa:	00000497          	auipc	s1,0x0
 8fe:	70648493          	addi	s1,s1,1798 # 1000 <freep>
  if (p == SBRK_ERROR)
 902:	5afd                	li	s5,-1
 904:	a83d                	j	942 <malloc+0x92>
 906:	f426                	sd	s1,40(sp)
 908:	e852                	sd	s4,16(sp)
 90a:	e456                	sd	s5,8(sp)
 90c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 90e:	00000797          	auipc	a5,0x0
 912:	70278793          	addi	a5,a5,1794 # 1010 <base>
 916:	00000717          	auipc	a4,0x0
 91a:	6ef73523          	sd	a5,1770(a4) # 1000 <freep>
 91e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 920:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 924:	b7d1                	j	8e8 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 926:	6398                	ld	a4,0(a5)
 928:	e118                	sd	a4,0(a0)
 92a:	a899                	j	980 <malloc+0xd0>
  hp->s.size = nu;
 92c:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 930:	0541                	addi	a0,a0,16
 932:	ef5ff0ef          	jal	826 <free>
  return freep;
 936:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 938:	c125                	beqz	a0,998 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 93a:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 93c:	4798                	lw	a4,8(a5)
 93e:	03277163          	bgeu	a4,s2,960 <malloc+0xb0>
    if (p == freep)
 942:	6098                	ld	a4,0(s1)
 944:	853e                	mv	a0,a5
 946:	fef71ae3          	bne	a4,a5,93a <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 94a:	8552                	mv	a0,s4
 94c:	9f7ff0ef          	jal	342 <sbrk>
  if (p == SBRK_ERROR)
 950:	fd551ee3          	bne	a0,s5,92c <malloc+0x7c>
        return 0;
 954:	4501                	li	a0,0
 956:	74a2                	ld	s1,40(sp)
 958:	6a42                	ld	s4,16(sp)
 95a:	6aa2                	ld	s5,8(sp)
 95c:	6b02                	ld	s6,0(sp)
 95e:	a03d                	j	98c <malloc+0xdc>
 960:	74a2                	ld	s1,40(sp)
 962:	6a42                	ld	s4,16(sp)
 964:	6aa2                	ld	s5,8(sp)
 966:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 968:	fae90fe3          	beq	s2,a4,926 <malloc+0x76>
        p->s.size -= nunits;
 96c:	4137073b          	subw	a4,a4,s3
 970:	c798                	sw	a4,8(a5)
        p += p->s.size;
 972:	02071693          	slli	a3,a4,0x20
 976:	01c6d713          	srli	a4,a3,0x1c
 97a:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 97c:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 980:	00000717          	auipc	a4,0x0
 984:	68a73023          	sd	a0,1664(a4) # 1000 <freep>
      return (void *)(p + 1);
 988:	01078513          	addi	a0,a5,16
  }
}
 98c:	70e2                	ld	ra,56(sp)
 98e:	7442                	ld	s0,48(sp)
 990:	7902                	ld	s2,32(sp)
 992:	69e2                	ld	s3,24(sp)
 994:	6121                	addi	sp,sp,64
 996:	8082                	ret
 998:	74a2                	ld	s1,40(sp)
 99a:	6a42                	ld	s4,16(sp)
 99c:	6aa2                	ld	s5,8(sp)
 99e:	6b02                	ld	s6,0(sp)
 9a0:	b7f5                	j	98c <malloc+0xdc>
