#include "types.h"
#include "stat.h"
#include "user.h"

// Simple delay function to simulate staggered process arrivals
void delay(int count) {
  volatile int i, j;
  for(i = 0; i < count; i++) {
    for(j = 0; j < 1000000; j++);
  }
}

int main(int argc, char *argv[]) {
  printf(1, "--- Starting SRTF Test ---\n");

  // 1. Fork Process 1 (Long Burst)
  int pid1 = fork();
  if(pid1 == 0) {
    int my_pid = getpid();
    set_burst(my_pid, 20);
    printf(1, "P1 (PID %d, Long Job, burst=20) started.\n", my_pid);
    
    // Perform heavy CPU work
    for(volatile double i = 0; i < 50000000.0; i += 1.0);
    
    printf(1, "P1 (PID %d, Long Job) COMPLETED.\n", my_pid);
    exit();
  }

  delay(200); // Wait briefly before spawning P2

  // 2. Fork Process 2 (Medium Burst)
  int pid2 = fork();
  if(pid2 == 0) {
    int my_pid = getpid();
    set_burst(my_pid, 10);
    printf(1, "P2 (PID %d, Medium Job, burst=10) arrived.\n", my_pid);
    
    for(volatile double i = 0; i < 25000000.0; i += 1.0);
    
    printf(1, "P2 (PID %d, Medium Job) COMPLETED.\n", my_pid);
    exit();
  }

  delay(100); // Wait briefly before spawning P3

  // 3. Fork Process 3 (Short Burst - Should preempt longer running process)
  int pid3 = fork();
  if(pid3 == 0) {
    int my_pid = getpid();
    set_burst(my_pid, 2);
    printf(1, "P3 (PID %d, Short Job, burst=2) arrived -> PREEMPTING!\n", my_pid);
    
    for(volatile double i = 0; i < 5000000.0; i += 1.0);
    
    printf(1, "P3 (PID %d, Short Job) COMPLETED.\n", my_pid);
    exit();
  }

  // Parent waits for all 3 child processes to finish
  wait();
  wait();
  wait();

  printf(1, "--- SRTF Test Complete ---\n");
  exit();
}