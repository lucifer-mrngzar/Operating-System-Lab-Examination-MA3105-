
user/_memtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  char *p;

  printf("\n===== INITIAL MEMORY STATISTICS =====\n");
   8:	00001517          	auipc	a0,0x1
   c:	97850513          	addi	a0,a0,-1672 # 980 <malloc+0xf6>
  10:	7be000ef          	jal	7ce <printf>
  memstats();
  14:	3e4000ef          	jal	3f8 <memstats>

  printf("\nAllocating 3 pages using sbrk()...\n");
  18:	00001517          	auipc	a0,0x1
  1c:	99050513          	addi	a0,a0,-1648 # 9a8 <malloc+0x11e>
  20:	7ae000ef          	jal	7ce <printf>
  p = sbrk(3 * 4096);
  24:	650d                	lui	a0,0x3
  26:	2f6000ef          	jal	31c <sbrk>

  if(p == (char*)-1){
  2a:	57fd                	li	a5,-1
  2c:	04f50e63          	beq	a0,a5,88 <main+0x88>
    printf("Memory allocation failed\n");
    exit(1);
  }

  p[0] = 'A';
  30:	04100793          	li	a5,65
  34:	00f50023          	sb	a5,0(a0) # 3000 <base+0x1ff0>
  p[4096] = 'B';
  38:	6785                	lui	a5,0x1
  3a:	97aa                	add	a5,a5,a0
  3c:	04200713          	li	a4,66
  40:	00e78023          	sb	a4,0(a5) # 1000 <freep>
  p[8192] = 'C';
  44:	6789                	lui	a5,0x2
  46:	953e                	add	a0,a0,a5
  48:	04300793          	li	a5,67
  4c:	00f50023          	sb	a5,0(a0)

  printf("\n===== AFTER ALLOCATION =====\n");
  50:	00001517          	auipc	a0,0x1
  54:	9a850513          	addi	a0,a0,-1624 # 9f8 <malloc+0x16e>
  58:	776000ef          	jal	7ce <printf>
  memstats();
  5c:	39c000ef          	jal	3f8 <memstats>

  printf("\nReleasing 3 pages using sbrk()...\n");
  60:	00001517          	auipc	a0,0x1
  64:	9b850513          	addi	a0,a0,-1608 # a18 <malloc+0x18e>
  68:	766000ef          	jal	7ce <printf>
  sbrk(-3 * 4096);
  6c:	7575                	lui	a0,0xffffd
  6e:	2ae000ef          	jal	31c <sbrk>

  printf("\n===== AFTER DEALLOCATION =====\n");
  72:	00001517          	auipc	a0,0x1
  76:	9ce50513          	addi	a0,a0,-1586 # a40 <malloc+0x1b6>
  7a:	754000ef          	jal	7ce <printf>
  memstats();
  7e:	37a000ef          	jal	3f8 <memstats>

  exit(0);
  82:	4501                	li	a0,0
  84:	2cc000ef          	jal	350 <exit>
    printf("Memory allocation failed\n");
  88:	00001517          	auipc	a0,0x1
  8c:	95050513          	addi	a0,a0,-1712 # 9d8 <malloc+0x14e>
  90:	73e000ef          	jal	7ce <printf>
    exit(1);
  94:	4505                	li	a0,1
  96:	2ba000ef          	jal	350 <exit>

000000000000009a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  9a:	1141                	addi	sp,sp,-16
  9c:	e406                	sd	ra,8(sp)
  9e:	e022                	sd	s0,0(sp)
  a0:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  a2:	f5fff0ef          	jal	0 <main>
  exit(r);
  a6:	2aa000ef          	jal	350 <exit>

00000000000000aa <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
  aa:	1141                	addi	sp,sp,-16
  ac:	e406                	sd	ra,8(sp)
  ae:	e022                	sd	s0,0(sp)
  b0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
  b2:	87aa                	mv	a5,a0
  b4:	0585                	addi	a1,a1,1
  b6:	0785                	addi	a5,a5,1 # 2001 <base+0xff1>
  b8:	fff5c703          	lbu	a4,-1(a1)
  bc:	fee78fa3          	sb	a4,-1(a5)
  c0:	fb75                	bnez	a4,b4 <strcpy+0xa>
    ;
  return os;
}
  c2:	60a2                	ld	ra,8(sp)
  c4:	6402                	ld	s0,0(sp)
  c6:	0141                	addi	sp,sp,16
  c8:	8082                	ret

00000000000000ca <strcmp>:

int
strcmp(const char *p, const char *q)
{
  ca:	1141                	addi	sp,sp,-16
  cc:	e406                	sd	ra,8(sp)
  ce:	e022                	sd	s0,0(sp)
  d0:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
  d2:	00054783          	lbu	a5,0(a0)
  d6:	cb91                	beqz	a5,ea <strcmp+0x20>
  d8:	0005c703          	lbu	a4,0(a1)
  dc:	00f71763          	bne	a4,a5,ea <strcmp+0x20>
    p++, q++;
  e0:	0505                	addi	a0,a0,1
  e2:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
  e4:	00054783          	lbu	a5,0(a0)
  e8:	fbe5                	bnez	a5,d8 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  ea:	0005c503          	lbu	a0,0(a1)
}
  ee:	40a7853b          	subw	a0,a5,a0
  f2:	60a2                	ld	ra,8(sp)
  f4:	6402                	ld	s0,0(sp)
  f6:	0141                	addi	sp,sp,16
  f8:	8082                	ret

00000000000000fa <strlen>:

uint
strlen(const char *s)
{
  fa:	1141                	addi	sp,sp,-16
  fc:	e406                	sd	ra,8(sp)
  fe:	e022                	sd	s0,0(sp)
 100:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 102:	00054783          	lbu	a5,0(a0)
 106:	cf91                	beqz	a5,122 <strlen+0x28>
 108:	00150793          	addi	a5,a0,1
 10c:	86be                	mv	a3,a5
 10e:	0785                	addi	a5,a5,1
 110:	fff7c703          	lbu	a4,-1(a5)
 114:	ff65                	bnez	a4,10c <strlen+0x12>
 116:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 11a:	60a2                	ld	ra,8(sp)
 11c:	6402                	ld	s0,0(sp)
 11e:	0141                	addi	sp,sp,16
 120:	8082                	ret
  for (n = 0; s[n]; n++)
 122:	4501                	li	a0,0
 124:	bfdd                	j	11a <strlen+0x20>

0000000000000126 <memset>:

void *
memset(void *dst, int c, uint n)
{
 126:	1141                	addi	sp,sp,-16
 128:	e406                	sd	ra,8(sp)
 12a:	e022                	sd	s0,0(sp)
 12c:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 12e:	ca19                	beqz	a2,144 <memset+0x1e>
 130:	87aa                	mv	a5,a0
 132:	1602                	slli	a2,a2,0x20
 134:	9201                	srli	a2,a2,0x20
 136:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 13a:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 13e:	0785                	addi	a5,a5,1
 140:	fee79de3          	bne	a5,a4,13a <memset+0x14>
  }
  return dst;
}
 144:	60a2                	ld	ra,8(sp)
 146:	6402                	ld	s0,0(sp)
 148:	0141                	addi	sp,sp,16
 14a:	8082                	ret

000000000000014c <strchr>:

char *
strchr(const char *s, char c)
{
 14c:	1141                	addi	sp,sp,-16
 14e:	e406                	sd	ra,8(sp)
 150:	e022                	sd	s0,0(sp)
 152:	0800                	addi	s0,sp,16
  for (; *s; s++)
 154:	00054783          	lbu	a5,0(a0)
 158:	c799                	beqz	a5,166 <strchr+0x1a>
    if (*s == c)
 15a:	00f58763          	beq	a1,a5,168 <strchr+0x1c>
  for (; *s; s++)
 15e:	0505                	addi	a0,a0,1
 160:	00054783          	lbu	a5,0(a0)
 164:	fbfd                	bnez	a5,15a <strchr+0xe>
      return (char *)s;
  return 0;
 166:	4501                	li	a0,0
}
 168:	60a2                	ld	ra,8(sp)
 16a:	6402                	ld	s0,0(sp)
 16c:	0141                	addi	sp,sp,16
 16e:	8082                	ret

0000000000000170 <gets>:

char *
gets(char *buf, int max)
{
 170:	711d                	addi	sp,sp,-96
 172:	ec86                	sd	ra,88(sp)
 174:	e8a2                	sd	s0,80(sp)
 176:	e4a6                	sd	s1,72(sp)
 178:	e0ca                	sd	s2,64(sp)
 17a:	fc4e                	sd	s3,56(sp)
 17c:	f852                	sd	s4,48(sp)
 17e:	f456                	sd	s5,40(sp)
 180:	f05a                	sd	s6,32(sp)
 182:	ec5e                	sd	s7,24(sp)
 184:	e862                	sd	s8,16(sp)
 186:	1080                	addi	s0,sp,96
 188:	8baa                	mv	s7,a0
 18a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 18c:	892a                	mv	s2,a0
 18e:	4481                	li	s1,0
    cc = read(0, &c, 1);
 190:	faf40b13          	addi	s6,s0,-81
 194:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 196:	8c26                	mv	s8,s1
 198:	0014899b          	addiw	s3,s1,1
 19c:	84ce                	mv	s1,s3
 19e:	0349d863          	bge	s3,s4,1ce <gets+0x5e>
    cc = read(0, &c, 1);
 1a2:	8656                	mv	a2,s5
 1a4:	85da                	mv	a1,s6
 1a6:	4501                	li	a0,0
 1a8:	1c0000ef          	jal	368 <read>
    if (cc < 1)
 1ac:	02a05163          	blez	a0,1ce <gets+0x5e>
      break;
    buf[i++] = c;
 1b0:	faf44783          	lbu	a5,-81(s0)
 1b4:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 1b8:	0905                	addi	s2,s2,1
 1ba:	ff678713          	addi	a4,a5,-10
 1be:	00173713          	seqz	a4,a4
 1c2:	17cd                	addi	a5,a5,-13
 1c4:	0017b793          	seqz	a5,a5
 1c8:	8fd9                	or	a5,a5,a4
 1ca:	d7f1                	beqz	a5,196 <gets+0x26>
    buf[i++] = c;
 1cc:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1ce:	9c5e                	add	s8,s8,s7
 1d0:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1d4:	855e                	mv	a0,s7
 1d6:	60e6                	ld	ra,88(sp)
 1d8:	6446                	ld	s0,80(sp)
 1da:	64a6                	ld	s1,72(sp)
 1dc:	6906                	ld	s2,64(sp)
 1de:	79e2                	ld	s3,56(sp)
 1e0:	7a42                	ld	s4,48(sp)
 1e2:	7aa2                	ld	s5,40(sp)
 1e4:	7b02                	ld	s6,32(sp)
 1e6:	6be2                	ld	s7,24(sp)
 1e8:	6c42                	ld	s8,16(sp)
 1ea:	6125                	addi	sp,sp,96
 1ec:	8082                	ret

00000000000001ee <stat>:

int
stat(const char *n, struct stat *st)
{
 1ee:	1101                	addi	sp,sp,-32
 1f0:	ec06                	sd	ra,24(sp)
 1f2:	e822                	sd	s0,16(sp)
 1f4:	e04a                	sd	s2,0(sp)
 1f6:	1000                	addi	s0,sp,32
 1f8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1fa:	4581                	li	a1,0
 1fc:	194000ef          	jal	390 <open>
  if (fd < 0)
 200:	02054263          	bltz	a0,224 <stat+0x36>
 204:	e426                	sd	s1,8(sp)
 206:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 208:	85ca                	mv	a1,s2
 20a:	19e000ef          	jal	3a8 <fstat>
 20e:	892a                	mv	s2,a0
  close(fd);
 210:	8526                	mv	a0,s1
 212:	166000ef          	jal	378 <close>
  return r;
 216:	64a2                	ld	s1,8(sp)
}
 218:	854a                	mv	a0,s2
 21a:	60e2                	ld	ra,24(sp)
 21c:	6442                	ld	s0,16(sp)
 21e:	6902                	ld	s2,0(sp)
 220:	6105                	addi	sp,sp,32
 222:	8082                	ret
    return -1;
 224:	57fd                	li	a5,-1
 226:	893e                	mv	s2,a5
 228:	bfc5                	j	218 <stat+0x2a>

000000000000022a <atoi>:

int
atoi(const char *s)
{
 22a:	1141                	addi	sp,sp,-16
 22c:	e406                	sd	ra,8(sp)
 22e:	e022                	sd	s0,0(sp)
 230:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 232:	00054683          	lbu	a3,0(a0)
 236:	fd06879b          	addiw	a5,a3,-48
 23a:	0ff7f793          	zext.b	a5,a5
 23e:	4625                	li	a2,9
 240:	02f66963          	bltu	a2,a5,272 <atoi+0x48>
 244:	872a                	mv	a4,a0
  n = 0;
 246:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 248:	0705                	addi	a4,a4,1
 24a:	0025179b          	slliw	a5,a0,0x2
 24e:	9fa9                	addw	a5,a5,a0
 250:	0017979b          	slliw	a5,a5,0x1
 254:	9fb5                	addw	a5,a5,a3
 256:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 25a:	00074683          	lbu	a3,0(a4)
 25e:	fd06879b          	addiw	a5,a3,-48
 262:	0ff7f793          	zext.b	a5,a5
 266:	fef671e3          	bgeu	a2,a5,248 <atoi+0x1e>
  return n;
}
 26a:	60a2                	ld	ra,8(sp)
 26c:	6402                	ld	s0,0(sp)
 26e:	0141                	addi	sp,sp,16
 270:	8082                	ret
  n = 0;
 272:	4501                	li	a0,0
 274:	bfdd                	j	26a <atoi+0x40>

0000000000000276 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 276:	1141                	addi	sp,sp,-16
 278:	e406                	sd	ra,8(sp)
 27a:	e022                	sd	s0,0(sp)
 27c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 27e:	02b57563          	bgeu	a0,a1,2a8 <memmove+0x32>
    while (n-- > 0)
 282:	00c05f63          	blez	a2,2a0 <memmove+0x2a>
 286:	1602                	slli	a2,a2,0x20
 288:	9201                	srli	a2,a2,0x20
 28a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 28e:	872a                	mv	a4,a0
      *dst++ = *src++;
 290:	0585                	addi	a1,a1,1
 292:	0705                	addi	a4,a4,1
 294:	fff5c683          	lbu	a3,-1(a1)
 298:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 29c:	fee79ae3          	bne	a5,a4,290 <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2a0:	60a2                	ld	ra,8(sp)
 2a2:	6402                	ld	s0,0(sp)
 2a4:	0141                	addi	sp,sp,16
 2a6:	8082                	ret
    while (n-- > 0)
 2a8:	fec05ce3          	blez	a2,2a0 <memmove+0x2a>
    dst += n;
 2ac:	00c50733          	add	a4,a0,a2
    src += n;
 2b0:	95b2                	add	a1,a1,a2
 2b2:	fff6079b          	addiw	a5,a2,-1
 2b6:	1782                	slli	a5,a5,0x20
 2b8:	9381                	srli	a5,a5,0x20
 2ba:	fff7c793          	not	a5,a5
 2be:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2c0:	15fd                	addi	a1,a1,-1
 2c2:	177d                	addi	a4,a4,-1
 2c4:	0005c683          	lbu	a3,0(a1)
 2c8:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 2cc:	fef71ae3          	bne	a4,a5,2c0 <memmove+0x4a>
 2d0:	bfc1                	j	2a0 <memmove+0x2a>

00000000000002d2 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2d2:	1141                	addi	sp,sp,-16
 2d4:	e406                	sd	ra,8(sp)
 2d6:	e022                	sd	s0,0(sp)
 2d8:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2da:	ce19                	beqz	a2,2f8 <memcmp+0x26>
 2dc:	1602                	slli	a2,a2,0x20
 2de:	9201                	srli	a2,a2,0x20
 2e0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 2e4:	00054783          	lbu	a5,0(a0)
 2e8:	0005c703          	lbu	a4,0(a1)
 2ec:	00e79b63          	bne	a5,a4,302 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 2f0:	0505                	addi	a0,a0,1
    p2++;
 2f2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 2f4:	fed518e3          	bne	a0,a3,2e4 <memcmp+0x12>
  }
  return 0;
 2f8:	4501                	li	a0,0
}
 2fa:	60a2                	ld	ra,8(sp)
 2fc:	6402                	ld	s0,0(sp)
 2fe:	0141                	addi	sp,sp,16
 300:	8082                	ret
      return *p1 - *p2;
 302:	40e7853b          	subw	a0,a5,a4
 306:	bfd5                	j	2fa <memcmp+0x28>

0000000000000308 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 308:	1141                	addi	sp,sp,-16
 30a:	e406                	sd	ra,8(sp)
 30c:	e022                	sd	s0,0(sp)
 30e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 310:	f67ff0ef          	jal	276 <memmove>
}
 314:	60a2                	ld	ra,8(sp)
 316:	6402                	ld	s0,0(sp)
 318:	0141                	addi	sp,sp,16
 31a:	8082                	ret

000000000000031c <sbrk>:

char *
sbrk(int n)
{
 31c:	1141                	addi	sp,sp,-16
 31e:	e406                	sd	ra,8(sp)
 320:	e022                	sd	s0,0(sp)
 322:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 324:	4585                	li	a1,1
 326:	0b2000ef          	jal	3d8 <sys_sbrk>
}
 32a:	60a2                	ld	ra,8(sp)
 32c:	6402                	ld	s0,0(sp)
 32e:	0141                	addi	sp,sp,16
 330:	8082                	ret

0000000000000332 <sbrklazy>:

char *
sbrklazy(int n)
{
 332:	1141                	addi	sp,sp,-16
 334:	e406                	sd	ra,8(sp)
 336:	e022                	sd	s0,0(sp)
 338:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 33a:	4589                	li	a1,2
 33c:	09c000ef          	jal	3d8 <sys_sbrk>
}
 340:	60a2                	ld	ra,8(sp)
 342:	6402                	ld	s0,0(sp)
 344:	0141                	addi	sp,sp,16
 346:	8082                	ret

0000000000000348 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 348:	4885                	li	a7,1
 ecall
 34a:	00000073          	ecall
 ret
 34e:	8082                	ret

0000000000000350 <exit>:
.global exit
exit:
 li a7, SYS_exit
 350:	4889                	li	a7,2
 ecall
 352:	00000073          	ecall
 ret
 356:	8082                	ret

0000000000000358 <wait>:
.global wait
wait:
 li a7, SYS_wait
 358:	488d                	li	a7,3
 ecall
 35a:	00000073          	ecall
 ret
 35e:	8082                	ret

0000000000000360 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 360:	4891                	li	a7,4
 ecall
 362:	00000073          	ecall
 ret
 366:	8082                	ret

0000000000000368 <read>:
.global read
read:
 li a7, SYS_read
 368:	4895                	li	a7,5
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <write>:
.global write
write:
 li a7, SYS_write
 370:	48c1                	li	a7,16
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <close>:
.global close
close:
 li a7, SYS_close
 378:	48d5                	li	a7,21
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <kill>:
.global kill
kill:
 li a7, SYS_kill
 380:	4899                	li	a7,6
 ecall
 382:	00000073          	ecall
 ret
 386:	8082                	ret

0000000000000388 <exec>:
.global exec
exec:
 li a7, SYS_exec
 388:	489d                	li	a7,7
 ecall
 38a:	00000073          	ecall
 ret
 38e:	8082                	ret

0000000000000390 <open>:
.global open
open:
 li a7, SYS_open
 390:	48bd                	li	a7,15
 ecall
 392:	00000073          	ecall
 ret
 396:	8082                	ret

0000000000000398 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 398:	48c5                	li	a7,17
 ecall
 39a:	00000073          	ecall
 ret
 39e:	8082                	ret

00000000000003a0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3a0:	48c9                	li	a7,18
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3a8:	48a1                	li	a7,8
 ecall
 3aa:	00000073          	ecall
 ret
 3ae:	8082                	ret

00000000000003b0 <link>:
.global link
link:
 li a7, SYS_link
 3b0:	48cd                	li	a7,19
 ecall
 3b2:	00000073          	ecall
 ret
 3b6:	8082                	ret

00000000000003b8 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3b8:	48d1                	li	a7,20
 ecall
 3ba:	00000073          	ecall
 ret
 3be:	8082                	ret

00000000000003c0 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3c0:	48a5                	li	a7,9
 ecall
 3c2:	00000073          	ecall
 ret
 3c6:	8082                	ret

00000000000003c8 <dup>:
.global dup
dup:
 li a7, SYS_dup
 3c8:	48a9                	li	a7,10
 ecall
 3ca:	00000073          	ecall
 ret
 3ce:	8082                	ret

00000000000003d0 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3d0:	48ad                	li	a7,11
 ecall
 3d2:	00000073          	ecall
 ret
 3d6:	8082                	ret

00000000000003d8 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 3d8:	48b1                	li	a7,12
 ecall
 3da:	00000073          	ecall
 ret
 3de:	8082                	ret

00000000000003e0 <pause>:
.global pause
pause:
 li a7, SYS_pause
 3e0:	48b5                	li	a7,13
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 3e8:	48b9                	li	a7,14
 ecall
 3ea:	00000073          	ecall
 ret
 3ee:	8082                	ret

00000000000003f0 <sync>:
.global sync
sync:
 li a7, SYS_sync
 3f0:	48d9                	li	a7,22
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <memstats>:
.global memstats
memstats:
 li a7, SYS_memstats
 3f8:	48dd                	li	a7,23
 ecall
 3fa:	00000073          	ecall
 ret
 3fe:	8082                	ret

0000000000000400 <vtop>:
.global vtop
vtop:
 li a7, SYS_vtop
 400:	48e1                	li	a7,24
 ecall
 402:	00000073          	ecall
 ret
 406:	8082                	ret

0000000000000408 <pageinfo>:
.global pageinfo
pageinfo:
 li a7, SYS_pageinfo
 408:	48e5                	li	a7,25
 ecall
 40a:	00000073          	ecall
 ret
 40e:	8082                	ret

0000000000000410 <setreadonly>:
.global setreadonly
setreadonly:
 li a7, SYS_setreadonly
 410:	48e9                	li	a7,26
 ecall
 412:	00000073          	ecall
 ret
 416:	8082                	ret

0000000000000418 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 418:	1101                	addi	sp,sp,-32
 41a:	ec06                	sd	ra,24(sp)
 41c:	e822                	sd	s0,16(sp)
 41e:	1000                	addi	s0,sp,32
 420:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 424:	4605                	li	a2,1
 426:	fef40593          	addi	a1,s0,-17
 42a:	f47ff0ef          	jal	370 <write>
}
 42e:	60e2                	ld	ra,24(sp)
 430:	6442                	ld	s0,16(sp)
 432:	6105                	addi	sp,sp,32
 434:	8082                	ret

0000000000000436 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 436:	715d                	addi	sp,sp,-80
 438:	e486                	sd	ra,72(sp)
 43a:	e0a2                	sd	s0,64(sp)
 43c:	f84a                	sd	s2,48(sp)
 43e:	f44e                	sd	s3,40(sp)
 440:	0880                	addi	s0,sp,80
 442:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 444:	00d036b3          	snez	a3,a3
 448:	03f5d793          	srli	a5,a1,0x3f
 44c:	8efd                	and	a3,a3,a5
  neg = 0;
 44e:	4301                	li	t1,0
  if (sgn && xx < 0) {
 450:	c681                	beqz	a3,458 <printint+0x22>
    neg = 1;
    x = -xx;
 452:	40b005b3          	neg	a1,a1
    neg = 1;
 456:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 458:	fb840993          	addi	s3,s0,-72
  neg = 0;
 45c:	86ce                	mv	a3,s3
  i = 0;
 45e:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 460:	00000817          	auipc	a6,0x0
 464:	61080813          	addi	a6,a6,1552 # a70 <digits>
 468:	88ba                	mv	a7,a4
 46a:	0017051b          	addiw	a0,a4,1
 46e:	872a                	mv	a4,a0
 470:	02c5f7b3          	remu	a5,a1,a2
 474:	97c2                	add	a5,a5,a6
 476:	0007c783          	lbu	a5,0(a5)
 47a:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 47e:	87ae                	mv	a5,a1
 480:	02c5d5b3          	divu	a1,a1,a2
 484:	0685                	addi	a3,a3,1
 486:	fec7f1e3          	bgeu	a5,a2,468 <printint+0x32>
  if (neg)
 48a:	00030b63          	beqz	t1,4a0 <printint+0x6a>
    buf[i++] = '-';
 48e:	fd040793          	addi	a5,s0,-48
 492:	953e                	add	a0,a0,a5
 494:	02d00793          	li	a5,45
 498:	fef50423          	sb	a5,-24(a0)
 49c:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 4a0:	02e05563          	blez	a4,4ca <printint+0x94>
 4a4:	fc26                	sd	s1,56(sp)
 4a6:	377d                	addiw	a4,a4,-1
 4a8:	00e984b3          	add	s1,s3,a4
 4ac:	19fd                	addi	s3,s3,-1
 4ae:	99ba                	add	s3,s3,a4
 4b0:	1702                	slli	a4,a4,0x20
 4b2:	9301                	srli	a4,a4,0x20
 4b4:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 4b8:	0004c583          	lbu	a1,0(s1)
 4bc:	854a                	mv	a0,s2
 4be:	f5bff0ef          	jal	418 <putc>
  while (--i >= 0)
 4c2:	14fd                	addi	s1,s1,-1
 4c4:	ff349ae3          	bne	s1,s3,4b8 <printint+0x82>
 4c8:	74e2                	ld	s1,56(sp)
}
 4ca:	60a6                	ld	ra,72(sp)
 4cc:	6406                	ld	s0,64(sp)
 4ce:	7942                	ld	s2,48(sp)
 4d0:	79a2                	ld	s3,40(sp)
 4d2:	6161                	addi	sp,sp,80
 4d4:	8082                	ret

00000000000004d6 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4d6:	711d                	addi	sp,sp,-96
 4d8:	ec86                	sd	ra,88(sp)
 4da:	e8a2                	sd	s0,80(sp)
 4dc:	e4a6                	sd	s1,72(sp)
 4de:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 4e0:	0005c483          	lbu	s1,0(a1)
 4e4:	2a048063          	beqz	s1,784 <vprintf+0x2ae>
 4e8:	e0ca                	sd	s2,64(sp)
 4ea:	fc4e                	sd	s3,56(sp)
 4ec:	f852                	sd	s4,48(sp)
 4ee:	f456                	sd	s5,40(sp)
 4f0:	f05a                	sd	s6,32(sp)
 4f2:	ec5e                	sd	s7,24(sp)
 4f4:	e862                	sd	s8,16(sp)
 4f6:	8b2a                	mv	s6,a0
 4f8:	8a2e                	mv	s4,a1
 4fa:	8bb2                	mv	s7,a2
  state = 0;
 4fc:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 4fe:	4901                	li	s2,0
 500:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 502:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 506:	06400c13          	li	s8,100
 50a:	a00d                	j	52c <vprintf+0x56>
        putc(fd, c0);
 50c:	85a6                	mv	a1,s1
 50e:	855a                	mv	a0,s6
 510:	f09ff0ef          	jal	418 <putc>
 514:	a019                	j	51a <vprintf+0x44>
    } else if (state == '%') {
 516:	03598363          	beq	s3,s5,53c <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 51a:	0019079b          	addiw	a5,s2,1
 51e:	893e                	mv	s2,a5
 520:	873e                	mv	a4,a5
 522:	97d2                	add	a5,a5,s4
 524:	0007c483          	lbu	s1,0(a5)
 528:	24048763          	beqz	s1,776 <vprintf+0x2a0>
    c0 = fmt[i] & 0xff;
 52c:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 530:	fe0993e3          	bnez	s3,516 <vprintf+0x40>
      if (c0 == '%') {
 534:	fd579ce3          	bne	a5,s5,50c <vprintf+0x36>
        state = '%';
 538:	89be                	mv	s3,a5
 53a:	b7c5                	j	51a <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 53c:	00ea06b3          	add	a3,s4,a4
 540:	0016c603          	lbu	a2,1(a3)
      if (c1)
 544:	24060563          	beqz	a2,78e <vprintf+0x2b8>
      if (c0 == 'd') {
 548:	0b878763          	beq	a5,s8,5f6 <vprintf+0x120>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 54c:	f9478693          	addi	a3,a5,-108
 550:	0016b693          	seqz	a3,a3
 554:	f9c60593          	addi	a1,a2,-100
 558:	0015b593          	seqz	a1,a1
 55c:	8df5                	and	a1,a1,a3
 55e:	e9c5                	bnez	a1,60e <vprintf+0x138>
        c2 = fmt[i + 2] & 0xff;
 560:	9752                	add	a4,a4,s4
 562:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 566:	f9460713          	addi	a4,a2,-108
 56a:	00173713          	seqz	a4,a4
 56e:	8f75                	and	a4,a4,a3
 570:	f9c50593          	addi	a1,a0,-100
 574:	0015b593          	seqz	a1,a1
 578:	8df9                	and	a1,a1,a4
 57a:	e5dd                	bnez	a1,628 <vprintf+0x152>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 57c:	07500593          	li	a1,117
 580:	0cb78163          	beq	a5,a1,642 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint32), 10, 0);
      } else if (c0 == 'l' && c1 == 'u') {
 584:	f8b60593          	addi	a1,a2,-117
 588:	0015b593          	seqz	a1,a1
 58c:	8df5                	and	a1,a1,a3
 58e:	e5f1                	bnez	a1,65a <vprintf+0x184>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 590:	f8b50593          	addi	a1,a0,-117
 594:	0015b593          	seqz	a1,a1
 598:	8df9                	and	a1,a1,a4
 59a:	ede9                	bnez	a1,674 <vprintf+0x19e>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 59c:	07800593          	li	a1,120
 5a0:	0eb78763          	beq	a5,a1,68e <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint32), 16, 0);
      } else if (c0 == 'l' && c1 == 'x') {
 5a4:	f8860613          	addi	a2,a2,-120
 5a8:	00163613          	seqz	a2,a2
 5ac:	8ef1                	and	a3,a3,a2
 5ae:	0e069c63          	bnez	a3,6a6 <vprintf+0x1d0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 5b2:	f8850513          	addi	a0,a0,-120
 5b6:	00153513          	seqz	a0,a0
 5ba:	8f69                	and	a4,a4,a0
 5bc:	10071263          	bnez	a4,6c0 <vprintf+0x1ea>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 5c0:	07000713          	li	a4,112
 5c4:	10e78a63          	beq	a5,a4,6d8 <vprintf+0x202>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 5c8:	06300713          	li	a4,99
 5cc:	14e78a63          	beq	a5,a4,720 <vprintf+0x24a>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 5d0:	07300713          	li	a4,115
 5d4:	16e78063          	beq	a5,a4,734 <vprintf+0x25e>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 5d8:	02500713          	li	a4,37
 5dc:	18e78863          	beq	a5,a4,76c <vprintf+0x296>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5e0:	02500593          	li	a1,37
 5e4:	855a                	mv	a0,s6
 5e6:	e33ff0ef          	jal	418 <putc>
        putc(fd, c0);
 5ea:	85a6                	mv	a1,s1
 5ec:	855a                	mv	a0,s6
 5ee:	e2bff0ef          	jal	418 <putc>
      }

      state = 0;
 5f2:	4981                	li	s3,0
 5f4:	b71d                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5f6:	008b8493          	addi	s1,s7,8
 5fa:	4685                	li	a3,1
 5fc:	4629                	li	a2,10
 5fe:	000ba583          	lw	a1,0(s7)
 602:	855a                	mv	a0,s6
 604:	e33ff0ef          	jal	436 <printint>
 608:	8ba6                	mv	s7,s1
      state = 0;
 60a:	4981                	li	s3,0
 60c:	b739                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 60e:	008b8493          	addi	s1,s7,8
 612:	4685                	li	a3,1
 614:	4629                	li	a2,10
 616:	000bb583          	ld	a1,0(s7)
 61a:	855a                	mv	a0,s6
 61c:	e1bff0ef          	jal	436 <printint>
        i += 1;
 620:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 622:	8ba6                	mv	s7,s1
      state = 0;
 624:	4981                	li	s3,0
 626:	bdd5                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 628:	008b8493          	addi	s1,s7,8
 62c:	4685                	li	a3,1
 62e:	4629                	li	a2,10
 630:	000bb583          	ld	a1,0(s7)
 634:	855a                	mv	a0,s6
 636:	e01ff0ef          	jal	436 <printint>
        i += 2;
 63a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 63c:	8ba6                	mv	s7,s1
      state = 0;
 63e:	4981                	li	s3,0
        i += 2;
 640:	bde9                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 642:	008b8493          	addi	s1,s7,8
 646:	4681                	li	a3,0
 648:	4629                	li	a2,10
 64a:	000be583          	lwu	a1,0(s7)
 64e:	855a                	mv	a0,s6
 650:	de7ff0ef          	jal	436 <printint>
 654:	8ba6                	mv	s7,s1
      state = 0;
 656:	4981                	li	s3,0
 658:	b5c9                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 65a:	008b8493          	addi	s1,s7,8
 65e:	4681                	li	a3,0
 660:	4629                	li	a2,10
 662:	000bb583          	ld	a1,0(s7)
 666:	855a                	mv	a0,s6
 668:	dcfff0ef          	jal	436 <printint>
        i += 1;
 66c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 66e:	8ba6                	mv	s7,s1
      state = 0;
 670:	4981                	li	s3,0
 672:	b565                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 674:	008b8493          	addi	s1,s7,8
 678:	4681                	li	a3,0
 67a:	4629                	li	a2,10
 67c:	000bb583          	ld	a1,0(s7)
 680:	855a                	mv	a0,s6
 682:	db5ff0ef          	jal	436 <printint>
        i += 2;
 686:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 688:	8ba6                	mv	s7,s1
      state = 0;
 68a:	4981                	li	s3,0
        i += 2;
 68c:	b579                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 68e:	008b8493          	addi	s1,s7,8
 692:	4681                	li	a3,0
 694:	4641                	li	a2,16
 696:	000be583          	lwu	a1,0(s7)
 69a:	855a                	mv	a0,s6
 69c:	d9bff0ef          	jal	436 <printint>
 6a0:	8ba6                	mv	s7,s1
      state = 0;
 6a2:	4981                	li	s3,0
 6a4:	bd9d                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6a6:	008b8493          	addi	s1,s7,8
 6aa:	4681                	li	a3,0
 6ac:	4641                	li	a2,16
 6ae:	000bb583          	ld	a1,0(s7)
 6b2:	855a                	mv	a0,s6
 6b4:	d83ff0ef          	jal	436 <printint>
        i += 1;
 6b8:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ba:	8ba6                	mv	s7,s1
      state = 0;
 6bc:	4981                	li	s3,0
 6be:	bdb1                	j	51a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6c0:	008b8493          	addi	s1,s7,8
 6c4:	4641                	li	a2,16
 6c6:	000bb583          	ld	a1,0(s7)
 6ca:	855a                	mv	a0,s6
 6cc:	d6bff0ef          	jal	436 <printint>
        i += 2;
 6d0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6d2:	8ba6                	mv	s7,s1
      state = 0;
 6d4:	4981                	li	s3,0
        i += 2;
 6d6:	b591                	j	51a <vprintf+0x44>
 6d8:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6da:	008b8793          	addi	a5,s7,8
 6de:	8cbe                	mv	s9,a5
 6e0:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6e4:	03000593          	li	a1,48
 6e8:	855a                	mv	a0,s6
 6ea:	d2fff0ef          	jal	418 <putc>
  putc(fd, 'x');
 6ee:	07800593          	li	a1,120
 6f2:	855a                	mv	a0,s6
 6f4:	d25ff0ef          	jal	418 <putc>
 6f8:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6fa:	00000b97          	auipc	s7,0x0
 6fe:	376b8b93          	addi	s7,s7,886 # a70 <digits>
 702:	03c9d793          	srli	a5,s3,0x3c
 706:	97de                	add	a5,a5,s7
 708:	0007c583          	lbu	a1,0(a5)
 70c:	855a                	mv	a0,s6
 70e:	d0bff0ef          	jal	418 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 712:	0992                	slli	s3,s3,0x4
 714:	34fd                	addiw	s1,s1,-1
 716:	f4f5                	bnez	s1,702 <vprintf+0x22c>
        printptr(fd, va_arg(ap, uint64));
 718:	8be6                	mv	s7,s9
      state = 0;
 71a:	4981                	li	s3,0
 71c:	6ca2                	ld	s9,8(sp)
 71e:	bbf5                	j	51a <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 720:	008b8493          	addi	s1,s7,8
 724:	000bc583          	lbu	a1,0(s7)
 728:	855a                	mv	a0,s6
 72a:	cefff0ef          	jal	418 <putc>
 72e:	8ba6                	mv	s7,s1
      state = 0;
 730:	4981                	li	s3,0
 732:	b3e5                	j	51a <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 734:	008b8993          	addi	s3,s7,8
 738:	000bb483          	ld	s1,0(s7)
 73c:	cc91                	beqz	s1,758 <vprintf+0x282>
        for (; *s; s++)
 73e:	0004c583          	lbu	a1,0(s1)
 742:	c195                	beqz	a1,766 <vprintf+0x290>
          putc(fd, *s);
 744:	855a                	mv	a0,s6
 746:	cd3ff0ef          	jal	418 <putc>
        for (; *s; s++)
 74a:	0485                	addi	s1,s1,1
 74c:	0004c583          	lbu	a1,0(s1)
 750:	f9f5                	bnez	a1,744 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 752:	8bce                	mv	s7,s3
      state = 0;
 754:	4981                	li	s3,0
 756:	b3d1                	j	51a <vprintf+0x44>
          s = "(null)";
 758:	00000497          	auipc	s1,0x0
 75c:	31048493          	addi	s1,s1,784 # a68 <malloc+0x1de>
        for (; *s; s++)
 760:	02800593          	li	a1,40
 764:	b7c5                	j	744 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 766:	8bce                	mv	s7,s3
      state = 0;
 768:	4981                	li	s3,0
 76a:	bb45                	j	51a <vprintf+0x44>
        putc(fd, '%');
 76c:	85be                	mv	a1,a5
 76e:	855a                	mv	a0,s6
 770:	ca9ff0ef          	jal	418 <putc>
 774:	bdbd                	j	5f2 <vprintf+0x11c>
 776:	6906                	ld	s2,64(sp)
 778:	79e2                	ld	s3,56(sp)
 77a:	7a42                	ld	s4,48(sp)
 77c:	7aa2                	ld	s5,40(sp)
 77e:	7b02                	ld	s6,32(sp)
 780:	6be2                	ld	s7,24(sp)
 782:	6c42                	ld	s8,16(sp)
    }
  }
}
 784:	60e6                	ld	ra,88(sp)
 786:	6446                	ld	s0,80(sp)
 788:	64a6                	ld	s1,72(sp)
 78a:	6125                	addi	sp,sp,96
 78c:	8082                	ret
      if (c0 == 'd') {
 78e:	06400713          	li	a4,100
 792:	e6e782e3          	beq	a5,a4,5f6 <vprintf+0x120>
      } else if (c0 == 'l' && c1 == 'd') {
 796:	f9478693          	addi	a3,a5,-108
 79a:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 79e:	8532                	mv	a0,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 7a0:	4701                	li	a4,0
 7a2:	bbe9                	j	57c <vprintf+0xa6>

00000000000007a4 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7a4:	715d                	addi	sp,sp,-80
 7a6:	ec06                	sd	ra,24(sp)
 7a8:	e822                	sd	s0,16(sp)
 7aa:	1000                	addi	s0,sp,32
 7ac:	e010                	sd	a2,0(s0)
 7ae:	e414                	sd	a3,8(s0)
 7b0:	e818                	sd	a4,16(s0)
 7b2:	ec1c                	sd	a5,24(s0)
 7b4:	03043023          	sd	a6,32(s0)
 7b8:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7bc:	8622                	mv	a2,s0
 7be:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7c2:	d15ff0ef          	jal	4d6 <vprintf>
}
 7c6:	60e2                	ld	ra,24(sp)
 7c8:	6442                	ld	s0,16(sp)
 7ca:	6161                	addi	sp,sp,80
 7cc:	8082                	ret

00000000000007ce <printf>:

void
printf(const char *fmt, ...)
{
 7ce:	711d                	addi	sp,sp,-96
 7d0:	ec06                	sd	ra,24(sp)
 7d2:	e822                	sd	s0,16(sp)
 7d4:	1000                	addi	s0,sp,32
 7d6:	e40c                	sd	a1,8(s0)
 7d8:	e810                	sd	a2,16(s0)
 7da:	ec14                	sd	a3,24(s0)
 7dc:	f018                	sd	a4,32(s0)
 7de:	f41c                	sd	a5,40(s0)
 7e0:	03043823          	sd	a6,48(s0)
 7e4:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7e8:	00840613          	addi	a2,s0,8
 7ec:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7f0:	85aa                	mv	a1,a0
 7f2:	4505                	li	a0,1
 7f4:	ce3ff0ef          	jal	4d6 <vprintf>
}
 7f8:	60e2                	ld	ra,24(sp)
 7fa:	6442                	ld	s0,16(sp)
 7fc:	6125                	addi	sp,sp,96
 7fe:	8082                	ret

0000000000000800 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 800:	1141                	addi	sp,sp,-16
 802:	e406                	sd	ra,8(sp)
 804:	e022                	sd	s0,0(sp)
 806:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 808:	ff050713          	addi	a4,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 80c:	00000797          	auipc	a5,0x0
 810:	7f47b783          	ld	a5,2036(a5) # 1000 <freep>
 814:	a095                	j	878 <free+0x78>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
 816:	ff852583          	lw	a1,-8(a0)
 81a:	6390                	ld	a2,0(a5)
 81c:	02059813          	slli	a6,a1,0x20
 820:	01c85693          	srli	a3,a6,0x1c
 824:	96ba                	add	a3,a3,a4
 826:	02d60563          	beq	a2,a3,850 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 82a:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 82e:	4790                	lw	a2,8(a5)
 830:	02061593          	slli	a1,a2,0x20
 834:	01c5d693          	srli	a3,a1,0x1c
 838:	96be                	add	a3,a3,a5
 83a:	02d70263          	beq	a4,a3,85e <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 83e:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 840:	00000717          	auipc	a4,0x0
 844:	7cf73023          	sd	a5,1984(a4) # 1000 <freep>
}
 848:	60a2                	ld	ra,8(sp)
 84a:	6402                	ld	s0,0(sp)
 84c:	0141                	addi	sp,sp,16
 84e:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 850:	4614                	lw	a3,8(a2)
 852:	9ead                	addw	a3,a3,a1
 854:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 858:	6394                	ld	a3,0(a5)
 85a:	6290                	ld	a2,0(a3)
 85c:	b7f9                	j	82a <free+0x2a>
    p->s.size += bp->s.size;
 85e:	ff852703          	lw	a4,-8(a0)
 862:	9f31                	addw	a4,a4,a2
 864:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 866:	ff053703          	ld	a4,-16(a0)
 86a:	bfd1                	j	83e <free+0x3e>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 86c:	6394                	ld	a3,0(a5)
 86e:	00d7e463          	bltu	a5,a3,876 <free+0x76>
 872:	fad762e3          	bltu	a4,a3,816 <free+0x16>
 876:	87b6                	mv	a5,a3
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 878:	fee7fae3          	bgeu	a5,a4,86c <free+0x6c>
 87c:	6394                	ld	a3,0(a5)
 87e:	f8d76ce3          	bltu	a4,a3,816 <free+0x16>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 882:	f8d7fae3          	bgeu	a5,a3,816 <free+0x16>
 886:	87b6                	mv	a5,a3
 888:	bfc5                	j	878 <free+0x78>

000000000000088a <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 88a:	7139                	addi	sp,sp,-64
 88c:	fc06                	sd	ra,56(sp)
 88e:	f822                	sd	s0,48(sp)
 890:	f04a                	sd	s2,32(sp)
 892:	ec4e                	sd	s3,24(sp)
 894:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 896:	02051993          	slli	s3,a0,0x20
 89a:	0209d993          	srli	s3,s3,0x20
 89e:	09bd                	addi	s3,s3,15
 8a0:	0049d993          	srli	s3,s3,0x4
 8a4:	2985                	addiw	s3,s3,1
 8a6:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 8a8:	00000517          	auipc	a0,0x0
 8ac:	75853503          	ld	a0,1880(a0) # 1000 <freep>
 8b0:	c905                	beqz	a0,8e0 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 8b2:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 8b4:	4798                	lw	a4,8(a5)
 8b6:	09377663          	bgeu	a4,s3,942 <malloc+0xb8>
 8ba:	f426                	sd	s1,40(sp)
 8bc:	e852                	sd	s4,16(sp)
 8be:	e456                	sd	s5,8(sp)
 8c0:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 8c2:	8a4e                	mv	s4,s3
 8c4:	6705                	lui	a4,0x1
 8c6:	00e9f363          	bgeu	s3,a4,8cc <malloc+0x42>
 8ca:	6a05                	lui	s4,0x1
 8cc:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8d0:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 8d4:	00000497          	auipc	s1,0x0
 8d8:	72c48493          	addi	s1,s1,1836 # 1000 <freep>
  if (p == SBRK_ERROR)
 8dc:	5afd                	li	s5,-1
 8de:	a83d                	j	91c <malloc+0x92>
 8e0:	f426                	sd	s1,40(sp)
 8e2:	e852                	sd	s4,16(sp)
 8e4:	e456                	sd	s5,8(sp)
 8e6:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8e8:	00000797          	auipc	a5,0x0
 8ec:	72878793          	addi	a5,a5,1832 # 1010 <base>
 8f0:	00000717          	auipc	a4,0x0
 8f4:	70f73823          	sd	a5,1808(a4) # 1000 <freep>
 8f8:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8fa:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 8fe:	b7d1                	j	8c2 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 900:	6398                	ld	a4,0(a5)
 902:	e118                	sd	a4,0(a0)
 904:	a899                	j	95a <malloc+0xd0>
  hp->s.size = nu;
 906:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 90a:	0541                	addi	a0,a0,16
 90c:	ef5ff0ef          	jal	800 <free>
  return freep;
 910:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 912:	c125                	beqz	a0,972 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 914:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 916:	4798                	lw	a4,8(a5)
 918:	03277163          	bgeu	a4,s2,93a <malloc+0xb0>
    if (p == freep)
 91c:	6098                	ld	a4,0(s1)
 91e:	853e                	mv	a0,a5
 920:	fef71ae3          	bne	a4,a5,914 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 924:	8552                	mv	a0,s4
 926:	9f7ff0ef          	jal	31c <sbrk>
  if (p == SBRK_ERROR)
 92a:	fd551ee3          	bne	a0,s5,906 <malloc+0x7c>
        return 0;
 92e:	4501                	li	a0,0
 930:	74a2                	ld	s1,40(sp)
 932:	6a42                	ld	s4,16(sp)
 934:	6aa2                	ld	s5,8(sp)
 936:	6b02                	ld	s6,0(sp)
 938:	a03d                	j	966 <malloc+0xdc>
 93a:	74a2                	ld	s1,40(sp)
 93c:	6a42                	ld	s4,16(sp)
 93e:	6aa2                	ld	s5,8(sp)
 940:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 942:	fae90fe3          	beq	s2,a4,900 <malloc+0x76>
        p->s.size -= nunits;
 946:	4137073b          	subw	a4,a4,s3
 94a:	c798                	sw	a4,8(a5)
        p += p->s.size;
 94c:	02071693          	slli	a3,a4,0x20
 950:	01c6d713          	srli	a4,a3,0x1c
 954:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 956:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 95a:	00000717          	auipc	a4,0x0
 95e:	6aa73323          	sd	a0,1702(a4) # 1000 <freep>
      return (void *)(p + 1);
 962:	01078513          	addi	a0,a5,16
  }
}
 966:	70e2                	ld	ra,56(sp)
 968:	7442                	ld	s0,48(sp)
 96a:	7902                	ld	s2,32(sp)
 96c:	69e2                	ld	s3,24(sp)
 96e:	6121                	addi	sp,sp,64
 970:	8082                	ret
 972:	74a2                	ld	s1,40(sp)
 974:	6a42                	ld	s4,16(sp)
 976:	6aa2                	ld	s5,8(sp)
 978:	6b02                	ld	s6,0(sp)
 97a:	b7f5                	j	966 <malloc+0xdc>
