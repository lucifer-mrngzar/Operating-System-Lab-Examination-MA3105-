#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
work(int n)
{
    volatile int x = 0;

    for(int i = 0; i < n; i++)
        x = x + i;
}

int
main(void)
{
    int pid;

    for(int i = 0; i < 3; i++)
    {
        if(i > 0)
        {
            // Small delay before creating the next process.
            for(volatile int j = 0; j < 1000000; j++)
                ;
        }

        pid = fork();

        if(pid < 0)
        {
            printf("fork failed\n");
            exit(1);
        }

        if(pid == 0)
        {
            printf("PID %d started\n", getpid());

            // CPU-bound work
            work(5000000);

            printf("PID %d completed\n", getpid());
            exit(0);
        }
    }

    // Parent waits for all three children.
    for(int i = 0; i < 3; i++)
        wait(0);

    printf("All processes completed\n");

    exit(0);
}
