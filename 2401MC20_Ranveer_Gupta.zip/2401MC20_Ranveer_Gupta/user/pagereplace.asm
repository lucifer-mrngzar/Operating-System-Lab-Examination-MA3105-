
user/_pagereplace:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <simulate>:

int results[3][3][2];

void
simulate(char *name, int algorithm, int nf)
{
   0:	7171                	addi	sp,sp,-176
   2:	f506                	sd	ra,168(sp)
   4:	f122                	sd	s0,160(sp)
   6:	ed26                	sd	s1,152(sp)
   8:	e94a                	sd	s2,144(sp)
   a:	e54e                	sd	s3,136(sp)
   c:	e152                	sd	s4,128(sp)
   e:	fcd6                	sd	s5,120(sp)
  10:	f8da                	sd	s6,112(sp)
  12:	f4de                	sd	s7,104(sp)
  14:	f0e2                	sd	s8,96(sp)
  16:	ece6                	sd	s9,88(sp)
  18:	e8ea                	sd	s10,80(sp)
  1a:	e4ee                	sd	s11,72(sp)
  1c:	1900                	addi	s0,sp,176
  1e:	8dae                	mv	s11,a1
  20:	84b2                	mv	s1,a2
  int i, j, k;
  int hit, faults = 0, hits = 0;
  int pointer = 0;
  int victim, farthest, found;

  for(i = 0; i < nf; i++){
  22:	00c05f63          	blez	a2,40 <simulate+0x40>
  26:	f7840793          	addi	a5,s0,-136
  2a:	f6040713          	addi	a4,s0,-160
  2e:	060a                	slli	a2,a2,0x2
  30:	963e                	add	a2,a2,a5
    frame[i] = -1;
  32:	56fd                	li	a3,-1
  34:	c394                	sw	a3,0(a5)
    last[i] = -1;
  36:	c314                	sw	a3,0(a4)
  for(i = 0; i < nf; i++){
  38:	0791                	addi	a5,a5,4
  3a:	0711                	addi	a4,a4,4
  3c:	fec79ce3          	bne	a5,a2,34 <simulate+0x34>
  }

  printf("\n%s - %d FRAMES\n", name, nf);
  40:	8626                	mv	a2,s1
  42:	85aa                	mv	a1,a0
  44:	00001517          	auipc	a0,0x1
  48:	c5c50513          	addi	a0,a0,-932 # ca0 <malloc+0xf8>
  4c:	2a1000ef          	jal	aec <printf>
  printf("Page\tFrames\t\tResult\n");
  50:	00001517          	auipc	a0,0x1
  54:	c6850513          	addi	a0,a0,-920 # cb8 <malloc+0x110>
  58:	295000ef          	jal	aec <printf>

  for(i = 0; i < N; i++){
  5c:	00001b17          	auipc	s6,0x1
  60:	fa8b0b13          	addi	s6,s6,-88 # 1004 <ref+0x4>
  printf("Page\tFrames\t\tResult\n");
  64:	4a85                	li	s5,1
  int pointer = 0;
  66:	f4043823          	sd	zero,-176(s0)
  int hit, faults = 0, hits = 0;
  6a:	4d01                	li	s10,0
  6c:	f4043c23          	sd	zero,-168(s0)
    }

    printf("%d\t", ref[i]);

    for(j = 0; j < nf; j++){
      if(frame[j] == -1)
  70:	5a7d                	li	s4,-1
        printf("- ");
      else
        printf("%d ", frame[j]);
  72:	00001b97          	auipc	s7,0x1
  76:	c66b8b93          	addi	s7,s7,-922 # cd8 <malloc+0x130>
        printf("- ");
  7a:	00001c97          	auipc	s9,0x1
  7e:	c56c8c93          	addi	s9,s9,-938 # cd0 <malloc+0x128>
  82:	a221                	j	18a <simulate+0x18a>
        last[victim] = i;
  84:	078a                	slli	a5,a5,0x2
  86:	f6040713          	addi	a4,s0,-160
  8a:	97ba                	add	a5,a5,a4
  8c:	c390                	sw	a2,0(a5)
  8e:	a439                	j	29c <simulate+0x29c>
        if(algorithm == 0){
  90:	020d9363          	bnez	s11,b6 <simulate+0xb6>
          pointer = (pointer + 1) % nf;
  94:	f5043783          	ld	a5,-176(s0)
  98:	0017871b          	addiw	a4,a5,1
  9c:	0297673b          	remw	a4,a4,s1
  a0:	f4e43823          	sd	a4,-176(s0)
      frame[victim] = ref[i];
  a4:	078a                	slli	a5,a5,0x2
  a6:	f9040713          	addi	a4,s0,-112
  aa:	97ba                	add	a5,a5,a4
  ac:	ffcb2703          	lw	a4,-4(s6)
  b0:	fee7a423          	sw	a4,-24(a5)
      if(algorithm == 1)
  b4:	aa0d                	j	1e6 <simulate+0x1e6>
        else if(algorithm == 1){
  b6:	4705                	li	a4,1
  b8:	04ed8563          	beq	s11,a4,102 <simulate+0x102>
          for(j = 0; j < nf; j++){
  bc:	f7840313          	addi	t1,s0,-136
          victim = 0;
  c0:	4e81                	li	t4,0
          for(j = 0; j < nf; j++){
  c2:	4801                	li	a6,0
            for(k = i + 1; k < N; k++){
  c4:	000a889b          	sext.w	a7,s5
  c8:	4e4d                	li	t3,19
  ca:	4551                	li	a0,20
          for(j = 0; j < nf; j++){
  cc:	02905963          	blez	s1,fe <simulate+0xfe>
            for(k = i + 1; k < N; k++){
  d0:	011e4d63          	blt	t3,a7,ea <simulate+0xea>
  d4:	8746                	mv	a4,a7
              if(ref[k] == frame[j]){
  d6:	00032583          	lw	a1,0(t1)
  da:	86da                	mv	a3,s6
  dc:	4290                	lw	a2,0(a3)
  de:	04b60863          	beq	a2,a1,12e <simulate+0x12e>
            for(k = i + 1; k < N; k++){
  e2:	2705                	addiw	a4,a4,1
  e4:	0691                	addi	a3,a3,4
  e6:	fea71be3          	bne	a4,a0,dc <simulate+0xdc>
      frame[victim] = ref[i];
  ea:	00281793          	slli	a5,a6,0x2
  ee:	f9040713          	addi	a4,s0,-112
  f2:	97ba                	add	a5,a5,a4
  f4:	ffcb2703          	lw	a4,-4(s6)
  f8:	fee7a423          	sw	a4,-24(a5)
      if(algorithm == 1)
  fc:	a0ed                	j	1e6 <simulate+0x1e6>
          victim = 0;
  fe:	4781                	li	a5,0
 100:	b755                	j	a4 <simulate+0xa4>
          for(j = 1; j < nf; j++){
 102:	4785                	li	a5,1
 104:	1497dc63          	bge	a5,s1,25c <simulate+0x25c>
 108:	f6040593          	addi	a1,s0,-160
 10c:	86ee                	mv	a3,s11
          victim = 0;
 10e:	4781                	li	a5,0
            if(last[j] < last[victim])
 110:	882e                	mv	a6,a1
 112:	a029                	j	11c <simulate+0x11c>
          for(j = 1; j < nf; j++){
 114:	2685                	addiw	a3,a3,1
 116:	0591                	addi	a1,a1,4
 118:	14d48863          	beq	s1,a3,268 <simulate+0x268>
            if(last[j] < last[victim])
 11c:	00279713          	slli	a4,a5,0x2
 120:	9742                	add	a4,a4,a6
 122:	41c8                	lw	a0,4(a1)
 124:	4318                	lw	a4,0(a4)
 126:	fee557e3          	bge	a0,a4,114 <simulate+0x114>
              victim = j;
 12a:	87b6                	mv	a5,a3
 12c:	b7e5                	j	114 <simulate+0x114>
            if(next[j] > farthest){
 12e:	00e7c863          	blt	a5,a4,13e <simulate+0x13e>
          for(j = 0; j < nf; j++){
 132:	2805                	addiw	a6,a6,1
 134:	0311                	addi	t1,t1,4
 136:	f9049de3          	bne	s1,a6,d0 <simulate+0xd0>
 13a:	8876                	mv	a6,t4
 13c:	b77d                	j	ea <simulate+0xea>
              farthest = next[j];
 13e:	87ba                	mv	a5,a4
              victim = j;
 140:	8ec2                	mv	t4,a6
 142:	bfc5                	j	132 <simulate+0x132>
        printf("- ");
 144:	8566                	mv	a0,s9
 146:	1a7000ef          	jal	aec <printf>
    for(j = 0; j < nf; j++){
 14a:	2905                	addiw	s2,s2,1
 14c:	0991                	addi	s3,s3,4
 14e:	00995a63          	bge	s2,s1,162 <simulate+0x162>
      if(frame[j] == -1)
 152:	0009a583          	lw	a1,0(s3)
 156:	ff4587e3          	beq	a1,s4,144 <simulate+0x144>
        printf("%d ", frame[j]);
 15a:	855e                	mv	a0,s7
 15c:	191000ef          	jal	aec <printf>
 160:	b7ed                	j	14a <simulate+0x14a>
    }

    if(hit)
 162:	000c1963          	bnez	s8,174 <simulate+0x174>
      printf("\tHIT\n");
    else
      printf("\tFAULT\n");
 166:	00001517          	auipc	a0,0x1
 16a:	b8250513          	addi	a0,a0,-1150 # ce8 <malloc+0x140>
 16e:	17f000ef          	jal	aec <printf>
 172:	a039                	j	180 <simulate+0x180>
      printf("\tHIT\n");
 174:	00001517          	auipc	a0,0x1
 178:	b6c50513          	addi	a0,a0,-1172 # ce0 <malloc+0x138>
 17c:	171000ef          	jal	aec <printf>
  for(i = 0; i < N; i++){
 180:	0a85                	addi	s5,s5,1
 182:	0b11                	addi	s6,s6,4
 184:	47d5                	li	a5,21
 186:	06fa8c63          	beq	s5,a5,1fe <simulate+0x1fe>
 18a:	fffa861b          	addiw	a2,s5,-1
    for(j = 0; j < nf; j++){
 18e:	0e905c63          	blez	s1,286 <simulate+0x286>
      if(frame[j] == ref[i]){
 192:	ffcb2583          	lw	a1,-4(s6)
 196:	f7840713          	addi	a4,s0,-136
    for(j = 0; j < nf; j++){
 19a:	4781                	li	a5,0
      if(frame[j] == ref[i]){
 19c:	4314                	lw	a3,0(a4)
 19e:	0eb68b63          	beq	a3,a1,294 <simulate+0x294>
    for(j = 0; j < nf; j++){
 1a2:	2785                	addiw	a5,a5,1
 1a4:	0711                	addi	a4,a4,4
 1a6:	fef49be3          	bne	s1,a5,19c <simulate+0x19c>
      faults++;
 1aa:	f5843783          	ld	a5,-168(s0)
 1ae:	2785                	addiw	a5,a5,1
 1b0:	f4f43c23          	sd	a5,-168(s0)
      for(j = 0; j < nf; j++){
 1b4:	f7840713          	addi	a4,s0,-136
 1b8:	4781                	li	a5,0
        if(frame[j] == -1){
 1ba:	4314                	lw	a3,0(a4)
 1bc:	01468763          	beq	a3,s4,1ca <simulate+0x1ca>
      for(j = 0; j < nf; j++){
 1c0:	2785                	addiw	a5,a5,1
 1c2:	0711                	addi	a4,a4,4
 1c4:	fef49be3          	bne	s1,a5,1ba <simulate+0x1ba>
    victim = -1;
 1c8:	87d2                	mv	a5,s4
      if(victim == -1){
 1ca:	ed4783e3          	beq	a5,s4,90 <simulate+0x90>
      frame[victim] = ref[i];
 1ce:	00279713          	slli	a4,a5,0x2
 1d2:	f9040693          	addi	a3,s0,-112
 1d6:	9736                	add	a4,a4,a3
 1d8:	ffcb2683          	lw	a3,-4(s6)
 1dc:	fed72423          	sw	a3,-24(a4)
      if(algorithm == 1)
 1e0:	4705                	li	a4,1
 1e2:	08ed8c63          	beq	s11,a4,27a <simulate+0x27a>
    printf("%d\t", ref[i]);
 1e6:	ffcb2583          	lw	a1,-4(s6)
 1ea:	00001517          	auipc	a0,0x1
 1ee:	b4650513          	addi	a0,a0,-1210 # d30 <malloc+0x188>
 1f2:	0fb000ef          	jal	aec <printf>
    for(j = 0; j < nf; j++){
 1f6:	4c01                	li	s8,0
 1f8:	0a904963          	bgtz	s1,2aa <simulate+0x2aa>
 1fc:	b7ad                	j	166 <simulate+0x166>
  }

  results[nf - 3][algorithm][0] = hits;
 1fe:	34f5                	addiw	s1,s1,-3
 200:	00149793          	slli	a5,s1,0x1
 204:	97a6                	add	a5,a5,s1
 206:	97ee                	add	a5,a5,s11
 208:	078e                	slli	a5,a5,0x3
 20a:	00001717          	auipc	a4,0x1
 20e:	e5670713          	addi	a4,a4,-426 # 1060 <results>
 212:	97ba                	add	a5,a5,a4
 214:	01a7a023          	sw	s10,0(a5)
  results[nf - 3][algorithm][1] = faults;
 218:	f5843703          	ld	a4,-168(s0)
 21c:	c3d8                	sw	a4,4(a5)

  printf("Hits: %d | Faults: %d | Hit ratio: %d%% | Fault ratio: %d%%\n",
 21e:	87ba                	mv	a5,a4
 220:	0027171b          	slliw	a4,a4,0x2
 224:	002d169b          	slliw	a3,s10,0x2
 228:	9f3d                	addw	a4,a4,a5
 22a:	01a686bb          	addw	a3,a3,s10
 22e:	863e                	mv	a2,a5
 230:	85ea                	mv	a1,s10
 232:	00001517          	auipc	a0,0x1
 236:	abe50513          	addi	a0,a0,-1346 # cf0 <malloc+0x148>
 23a:	0b3000ef          	jal	aec <printf>
         hits, faults, hits * 100 / N, faults * 100 / N);
}
 23e:	70aa                	ld	ra,168(sp)
 240:	740a                	ld	s0,160(sp)
 242:	64ea                	ld	s1,152(sp)
 244:	694a                	ld	s2,144(sp)
 246:	69aa                	ld	s3,136(sp)
 248:	6a0a                	ld	s4,128(sp)
 24a:	7ae6                	ld	s5,120(sp)
 24c:	7b46                	ld	s6,112(sp)
 24e:	7ba6                	ld	s7,104(sp)
 250:	7c06                	ld	s8,96(sp)
 252:	6ce6                	ld	s9,88(sp)
 254:	6d46                	ld	s10,80(sp)
 256:	6da6                	ld	s11,72(sp)
 258:	614d                	addi	sp,sp,176
 25a:	8082                	ret
      frame[victim] = ref[i];
 25c:	ffcb2783          	lw	a5,-4(s6)
 260:	f6f42c23          	sw	a5,-136(s0)
          victim = 0;
 264:	4781                	li	a5,0
 266:	a811                	j	27a <simulate+0x27a>
      frame[victim] = ref[i];
 268:	00279713          	slli	a4,a5,0x2
 26c:	f9040693          	addi	a3,s0,-112
 270:	9736                	add	a4,a4,a3
 272:	ffcb2683          	lw	a3,-4(s6)
 276:	fed72423          	sw	a3,-24(a4)
        last[victim] = i;
 27a:	078a                	slli	a5,a5,0x2
 27c:	f6040713          	addi	a4,s0,-160
 280:	97ba                	add	a5,a5,a4
 282:	c390                	sw	a2,0(a5)
 284:	b78d                	j	1e6 <simulate+0x1e6>
      faults++;
 286:	f5843783          	ld	a5,-168(s0)
 28a:	2785                	addiw	a5,a5,1
 28c:	f4f43c23          	sd	a5,-168(s0)
    victim = -1;
 290:	57fd                	li	a5,-1
 292:	bf25                	j	1ca <simulate+0x1ca>
      hits++;
 294:	2d05                	addiw	s10,s10,1
      if(algorithm == 1)
 296:	4705                	li	a4,1
 298:	deed86e3          	beq	s11,a4,84 <simulate+0x84>
    printf("%d\t", ref[i]);
 29c:	00001517          	auipc	a0,0x1
 2a0:	a9450513          	addi	a0,a0,-1388 # d30 <malloc+0x188>
 2a4:	049000ef          	jal	aec <printf>
 2a8:	4c05                	li	s8,1
 2aa:	f7840993          	addi	s3,s0,-136
    for(j = 0; j < nf; j++){
 2ae:	4901                	li	s2,0
 2b0:	b54d                	j	152 <simulate+0x152>

00000000000002b2 <main>:

int
main(void)
{
 2b2:	7119                	addi	sp,sp,-128
 2b4:	fc86                	sd	ra,120(sp)
 2b6:	f8a2                	sd	s0,112(sp)
 2b8:	f4a6                	sd	s1,104(sp)
 2ba:	f0ca                	sd	s2,96(sp)
 2bc:	ecce                	sd	s3,88(sp)
 2be:	e8d2                	sd	s4,80(sp)
 2c0:	e4d6                	sd	s5,72(sp)
 2c2:	e0da                	sd	s6,64(sp)
 2c4:	fc5e                	sd	s7,56(sp)
 2c6:	f862                	sd	s8,48(sp)
 2c8:	f466                	sd	s9,40(sp)
 2ca:	f06a                	sd	s10,32(sp)
 2cc:	0100                	addi	s0,sp,128
  int nf;

  printf("\n===== PAGE REPLACEMENT ALGORITHMS =====\n");
 2ce:	00001517          	auipc	a0,0x1
 2d2:	a6a50513          	addi	a0,a0,-1430 # d38 <malloc+0x190>
 2d6:	017000ef          	jal	aec <printf>
  printf("Reference string: 7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1\n");
 2da:	00001517          	auipc	a0,0x1
 2de:	a8e50513          	addi	a0,a0,-1394 # d68 <malloc+0x1c0>
 2e2:	00b000ef          	jal	aec <printf>

  for(nf = 3; nf <= 5; nf++){
 2e6:	448d                	li	s1,3
    simulate("FIFO", 0, nf);
 2e8:	00001b97          	auipc	s7,0x1
 2ec:	ac0b8b93          	addi	s7,s7,-1344 # da8 <malloc+0x200>
    simulate("LRU", 1, nf);
 2f0:	4b05                	li	s6,1
 2f2:	00001a97          	auipc	s5,0x1
 2f6:	abea8a93          	addi	s5,s5,-1346 # db0 <malloc+0x208>
    simulate("OPTIMAL", 2, nf);
 2fa:	4a09                	li	s4,2
 2fc:	00001997          	auipc	s3,0x1
 300:	abc98993          	addi	s3,s3,-1348 # db8 <malloc+0x210>
  for(nf = 3; nf <= 5; nf++){
 304:	4919                	li	s2,6
    simulate("FIFO", 0, nf);
 306:	8626                	mv	a2,s1
 308:	4581                	li	a1,0
 30a:	855e                	mv	a0,s7
 30c:	cf5ff0ef          	jal	0 <simulate>
    simulate("LRU", 1, nf);
 310:	8626                	mv	a2,s1
 312:	85da                	mv	a1,s6
 314:	8556                	mv	a0,s5
 316:	cebff0ef          	jal	0 <simulate>
    simulate("OPTIMAL", 2, nf);
 31a:	8626                	mv	a2,s1
 31c:	85d2                	mv	a1,s4
 31e:	854e                	mv	a0,s3
 320:	ce1ff0ef          	jal	0 <simulate>
  for(nf = 3; nf <= 5; nf++){
 324:	2485                	addiw	s1,s1,1
 326:	ff2490e3          	bne	s1,s2,306 <main+0x54>
  }

  printf("\n===== FINAL COMPARISON TABLE =====\n");
 32a:	00001517          	auipc	a0,0x1
 32e:	a9650513          	addi	a0,a0,-1386 # dc0 <malloc+0x218>
 332:	7ba000ef          	jal	aec <printf>
  printf("Frames  Algorithm  Hits  Faults  Hit ratio  Fault ratio\n");
 336:	00001517          	auipc	a0,0x1
 33a:	ab250513          	addi	a0,a0,-1358 # de8 <malloc+0x240>
 33e:	7ae000ef          	jal	aec <printf>

  for(nf = 3; nf <= 5; nf++){
 342:	00001b17          	auipc	s6,0x1
 346:	d1eb0b13          	addi	s6,s6,-738 # 1060 <results>
 34a:	498d                	li	s3,3
    int a;
    char *names[] = {"FIFO", "LRU", "OPTIMAL"};
 34c:	00001d17          	auipc	s10,0x1
 350:	a5cd0d13          	addi	s10,s10,-1444 # da8 <malloc+0x200>
 354:	00001c97          	auipc	s9,0x1
 358:	a5cc8c93          	addi	s9,s9,-1444 # db0 <malloc+0x208>
 35c:	00001c17          	auipc	s8,0x1
 360:	a5cc0c13          	addi	s8,s8,-1444 # db8 <malloc+0x210>
 364:	fa040a93          	addi	s5,s0,-96

    for(a = 0; a < 3; a++){
      int h = results[nf - 3][a][0];
      int f = results[nf - 3][a][1];

      printf("%d       %s       %d     %d       %d%%        %d%%\n",
 368:	00001a17          	auipc	s4,0x1
 36c:	ac0a0a13          	addi	s4,s4,-1344 # e28 <malloc+0x280>
  for(nf = 3; nf <= 5; nf++){
 370:	4b99                	li	s7,6
    char *names[] = {"FIFO", "LRU", "OPTIMAL"};
 372:	f9a43423          	sd	s10,-120(s0)
 376:	f9943823          	sd	s9,-112(s0)
 37a:	f9843c23          	sd	s8,-104(s0)
    for(a = 0; a < 3; a++){
 37e:	f8840913          	addi	s2,s0,-120
    char *names[] = {"FIFO", "LRU", "OPTIMAL"};
 382:	84da                	mv	s1,s6
      int h = results[nf - 3][a][0];
 384:	4094                	lw	a3,0(s1)
      int f = results[nf - 3][a][1];
 386:	40d8                	lw	a4,4(s1)
      printf("%d       %s       %d     %d       %d%%        %d%%\n",
 388:	0027181b          	slliw	a6,a4,0x2
 38c:	0026979b          	slliw	a5,a3,0x2
 390:	00e8083b          	addw	a6,a6,a4
 394:	9fb5                	addw	a5,a5,a3
 396:	00093603          	ld	a2,0(s2)
 39a:	85ce                	mv	a1,s3
 39c:	8552                	mv	a0,s4
 39e:	74e000ef          	jal	aec <printf>
    for(a = 0; a < 3; a++){
 3a2:	04a1                	addi	s1,s1,8
 3a4:	0921                	addi	s2,s2,8
 3a6:	fd591fe3          	bne	s2,s5,384 <main+0xd2>
  for(nf = 3; nf <= 5; nf++){
 3aa:	2985                	addiw	s3,s3,1
 3ac:	0b61                	addi	s6,s6,24
 3ae:	fd7992e3          	bne	s3,s7,372 <main+0xc0>
             nf, names[a], h, f, h * 100 / N, f * 100 / N);
    }
  }

  exit(0);
 3b2:	4501                	li	a0,0
 3b4:	2ba000ef          	jal	66e <exit>

00000000000003b8 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 3b8:	1141                	addi	sp,sp,-16
 3ba:	e406                	sd	ra,8(sp)
 3bc:	e022                	sd	s0,0(sp)
 3be:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 3c0:	ef3ff0ef          	jal	2b2 <main>
  exit(r);
 3c4:	2aa000ef          	jal	66e <exit>

00000000000003c8 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 3c8:	1141                	addi	sp,sp,-16
 3ca:	e406                	sd	ra,8(sp)
 3cc:	e022                	sd	s0,0(sp)
 3ce:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 3d0:	87aa                	mv	a5,a0
 3d2:	0585                	addi	a1,a1,1
 3d4:	0785                	addi	a5,a5,1
 3d6:	fff5c703          	lbu	a4,-1(a1)
 3da:	fee78fa3          	sb	a4,-1(a5)
 3de:	fb75                	bnez	a4,3d2 <strcpy+0xa>
    ;
  return os;
}
 3e0:	60a2                	ld	ra,8(sp)
 3e2:	6402                	ld	s0,0(sp)
 3e4:	0141                	addi	sp,sp,16
 3e6:	8082                	ret

00000000000003e8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 3e8:	1141                	addi	sp,sp,-16
 3ea:	e406                	sd	ra,8(sp)
 3ec:	e022                	sd	s0,0(sp)
 3ee:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 3f0:	00054783          	lbu	a5,0(a0)
 3f4:	cb91                	beqz	a5,408 <strcmp+0x20>
 3f6:	0005c703          	lbu	a4,0(a1)
 3fa:	00f71763          	bne	a4,a5,408 <strcmp+0x20>
    p++, q++;
 3fe:	0505                	addi	a0,a0,1
 400:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 402:	00054783          	lbu	a5,0(a0)
 406:	fbe5                	bnez	a5,3f6 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 408:	0005c503          	lbu	a0,0(a1)
}
 40c:	40a7853b          	subw	a0,a5,a0
 410:	60a2                	ld	ra,8(sp)
 412:	6402                	ld	s0,0(sp)
 414:	0141                	addi	sp,sp,16
 416:	8082                	ret

0000000000000418 <strlen>:

uint
strlen(const char *s)
{
 418:	1141                	addi	sp,sp,-16
 41a:	e406                	sd	ra,8(sp)
 41c:	e022                	sd	s0,0(sp)
 41e:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 420:	00054783          	lbu	a5,0(a0)
 424:	cf91                	beqz	a5,440 <strlen+0x28>
 426:	00150793          	addi	a5,a0,1
 42a:	86be                	mv	a3,a5
 42c:	0785                	addi	a5,a5,1
 42e:	fff7c703          	lbu	a4,-1(a5)
 432:	ff65                	bnez	a4,42a <strlen+0x12>
 434:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 438:	60a2                	ld	ra,8(sp)
 43a:	6402                	ld	s0,0(sp)
 43c:	0141                	addi	sp,sp,16
 43e:	8082                	ret
  for (n = 0; s[n]; n++)
 440:	4501                	li	a0,0
 442:	bfdd                	j	438 <strlen+0x20>

0000000000000444 <memset>:

void *
memset(void *dst, int c, uint n)
{
 444:	1141                	addi	sp,sp,-16
 446:	e406                	sd	ra,8(sp)
 448:	e022                	sd	s0,0(sp)
 44a:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 44c:	ca19                	beqz	a2,462 <memset+0x1e>
 44e:	87aa                	mv	a5,a0
 450:	1602                	slli	a2,a2,0x20
 452:	9201                	srli	a2,a2,0x20
 454:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 458:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 45c:	0785                	addi	a5,a5,1
 45e:	fee79de3          	bne	a5,a4,458 <memset+0x14>
  }
  return dst;
}
 462:	60a2                	ld	ra,8(sp)
 464:	6402                	ld	s0,0(sp)
 466:	0141                	addi	sp,sp,16
 468:	8082                	ret

000000000000046a <strchr>:

char *
strchr(const char *s, char c)
{
 46a:	1141                	addi	sp,sp,-16
 46c:	e406                	sd	ra,8(sp)
 46e:	e022                	sd	s0,0(sp)
 470:	0800                	addi	s0,sp,16
  for (; *s; s++)
 472:	00054783          	lbu	a5,0(a0)
 476:	c799                	beqz	a5,484 <strchr+0x1a>
    if (*s == c)
 478:	00f58763          	beq	a1,a5,486 <strchr+0x1c>
  for (; *s; s++)
 47c:	0505                	addi	a0,a0,1
 47e:	00054783          	lbu	a5,0(a0)
 482:	fbfd                	bnez	a5,478 <strchr+0xe>
      return (char *)s;
  return 0;
 484:	4501                	li	a0,0
}
 486:	60a2                	ld	ra,8(sp)
 488:	6402                	ld	s0,0(sp)
 48a:	0141                	addi	sp,sp,16
 48c:	8082                	ret

000000000000048e <gets>:

char *
gets(char *buf, int max)
{
 48e:	711d                	addi	sp,sp,-96
 490:	ec86                	sd	ra,88(sp)
 492:	e8a2                	sd	s0,80(sp)
 494:	e4a6                	sd	s1,72(sp)
 496:	e0ca                	sd	s2,64(sp)
 498:	fc4e                	sd	s3,56(sp)
 49a:	f852                	sd	s4,48(sp)
 49c:	f456                	sd	s5,40(sp)
 49e:	f05a                	sd	s6,32(sp)
 4a0:	ec5e                	sd	s7,24(sp)
 4a2:	e862                	sd	s8,16(sp)
 4a4:	1080                	addi	s0,sp,96
 4a6:	8baa                	mv	s7,a0
 4a8:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 4aa:	892a                	mv	s2,a0
 4ac:	4481                	li	s1,0
    cc = read(0, &c, 1);
 4ae:	faf40b13          	addi	s6,s0,-81
 4b2:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 4b4:	8c26                	mv	s8,s1
 4b6:	0014899b          	addiw	s3,s1,1
 4ba:	84ce                	mv	s1,s3
 4bc:	0349d863          	bge	s3,s4,4ec <gets+0x5e>
    cc = read(0, &c, 1);
 4c0:	8656                	mv	a2,s5
 4c2:	85da                	mv	a1,s6
 4c4:	4501                	li	a0,0
 4c6:	1c0000ef          	jal	686 <read>
    if (cc < 1)
 4ca:	02a05163          	blez	a0,4ec <gets+0x5e>
      break;
    buf[i++] = c;
 4ce:	faf44783          	lbu	a5,-81(s0)
 4d2:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 4d6:	0905                	addi	s2,s2,1
 4d8:	ff678713          	addi	a4,a5,-10
 4dc:	00173713          	seqz	a4,a4
 4e0:	17cd                	addi	a5,a5,-13
 4e2:	0017b793          	seqz	a5,a5
 4e6:	8fd9                	or	a5,a5,a4
 4e8:	d7f1                	beqz	a5,4b4 <gets+0x26>
    buf[i++] = c;
 4ea:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 4ec:	9c5e                	add	s8,s8,s7
 4ee:	000c0023          	sb	zero,0(s8)
  return buf;
}
 4f2:	855e                	mv	a0,s7
 4f4:	60e6                	ld	ra,88(sp)
 4f6:	6446                	ld	s0,80(sp)
 4f8:	64a6                	ld	s1,72(sp)
 4fa:	6906                	ld	s2,64(sp)
 4fc:	79e2                	ld	s3,56(sp)
 4fe:	7a42                	ld	s4,48(sp)
 500:	7aa2                	ld	s5,40(sp)
 502:	7b02                	ld	s6,32(sp)
 504:	6be2                	ld	s7,24(sp)
 506:	6c42                	ld	s8,16(sp)
 508:	6125                	addi	sp,sp,96
 50a:	8082                	ret

000000000000050c <stat>:

int
stat(const char *n, struct stat *st)
{
 50c:	1101                	addi	sp,sp,-32
 50e:	ec06                	sd	ra,24(sp)
 510:	e822                	sd	s0,16(sp)
 512:	e04a                	sd	s2,0(sp)
 514:	1000                	addi	s0,sp,32
 516:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 518:	4581                	li	a1,0
 51a:	194000ef          	jal	6ae <open>
  if (fd < 0)
 51e:	02054263          	bltz	a0,542 <stat+0x36>
 522:	e426                	sd	s1,8(sp)
 524:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 526:	85ca                	mv	a1,s2
 528:	19e000ef          	jal	6c6 <fstat>
 52c:	892a                	mv	s2,a0
  close(fd);
 52e:	8526                	mv	a0,s1
 530:	166000ef          	jal	696 <close>
  return r;
 534:	64a2                	ld	s1,8(sp)
}
 536:	854a                	mv	a0,s2
 538:	60e2                	ld	ra,24(sp)
 53a:	6442                	ld	s0,16(sp)
 53c:	6902                	ld	s2,0(sp)
 53e:	6105                	addi	sp,sp,32
 540:	8082                	ret
    return -1;
 542:	57fd                	li	a5,-1
 544:	893e                	mv	s2,a5
 546:	bfc5                	j	536 <stat+0x2a>

0000000000000548 <atoi>:

int
atoi(const char *s)
{
 548:	1141                	addi	sp,sp,-16
 54a:	e406                	sd	ra,8(sp)
 54c:	e022                	sd	s0,0(sp)
 54e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 550:	00054683          	lbu	a3,0(a0)
 554:	fd06879b          	addiw	a5,a3,-48
 558:	0ff7f793          	zext.b	a5,a5
 55c:	4625                	li	a2,9
 55e:	02f66963          	bltu	a2,a5,590 <atoi+0x48>
 562:	872a                	mv	a4,a0
  n = 0;
 564:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 566:	0705                	addi	a4,a4,1
 568:	0025179b          	slliw	a5,a0,0x2
 56c:	9fa9                	addw	a5,a5,a0
 56e:	0017979b          	slliw	a5,a5,0x1
 572:	9fb5                	addw	a5,a5,a3
 574:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 578:	00074683          	lbu	a3,0(a4)
 57c:	fd06879b          	addiw	a5,a3,-48
 580:	0ff7f793          	zext.b	a5,a5
 584:	fef671e3          	bgeu	a2,a5,566 <atoi+0x1e>
  return n;
}
 588:	60a2                	ld	ra,8(sp)
 58a:	6402                	ld	s0,0(sp)
 58c:	0141                	addi	sp,sp,16
 58e:	8082                	ret
  n = 0;
 590:	4501                	li	a0,0
 592:	bfdd                	j	588 <atoi+0x40>

0000000000000594 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 594:	1141                	addi	sp,sp,-16
 596:	e406                	sd	ra,8(sp)
 598:	e022                	sd	s0,0(sp)
 59a:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 59c:	02b57563          	bgeu	a0,a1,5c6 <memmove+0x32>
    while (n-- > 0)
 5a0:	00c05f63          	blez	a2,5be <memmove+0x2a>
 5a4:	1602                	slli	a2,a2,0x20
 5a6:	9201                	srli	a2,a2,0x20
 5a8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 5ac:	872a                	mv	a4,a0
      *dst++ = *src++;
 5ae:	0585                	addi	a1,a1,1
 5b0:	0705                	addi	a4,a4,1
 5b2:	fff5c683          	lbu	a3,-1(a1)
 5b6:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 5ba:	fee79ae3          	bne	a5,a4,5ae <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 5be:	60a2                	ld	ra,8(sp)
 5c0:	6402                	ld	s0,0(sp)
 5c2:	0141                	addi	sp,sp,16
 5c4:	8082                	ret
    while (n-- > 0)
 5c6:	fec05ce3          	blez	a2,5be <memmove+0x2a>
    dst += n;
 5ca:	00c50733          	add	a4,a0,a2
    src += n;
 5ce:	95b2                	add	a1,a1,a2
 5d0:	fff6079b          	addiw	a5,a2,-1
 5d4:	1782                	slli	a5,a5,0x20
 5d6:	9381                	srli	a5,a5,0x20
 5d8:	fff7c793          	not	a5,a5
 5dc:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 5de:	15fd                	addi	a1,a1,-1
 5e0:	177d                	addi	a4,a4,-1
 5e2:	0005c683          	lbu	a3,0(a1)
 5e6:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 5ea:	fef71ae3          	bne	a4,a5,5de <memmove+0x4a>
 5ee:	bfc1                	j	5be <memmove+0x2a>

00000000000005f0 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 5f0:	1141                	addi	sp,sp,-16
 5f2:	e406                	sd	ra,8(sp)
 5f4:	e022                	sd	s0,0(sp)
 5f6:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 5f8:	ce19                	beqz	a2,616 <memcmp+0x26>
 5fa:	1602                	slli	a2,a2,0x20
 5fc:	9201                	srli	a2,a2,0x20
 5fe:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 602:	00054783          	lbu	a5,0(a0)
 606:	0005c703          	lbu	a4,0(a1)
 60a:	00e79b63          	bne	a5,a4,620 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 60e:	0505                	addi	a0,a0,1
    p2++;
 610:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 612:	fed518e3          	bne	a0,a3,602 <memcmp+0x12>
  }
  return 0;
 616:	4501                	li	a0,0
}
 618:	60a2                	ld	ra,8(sp)
 61a:	6402                	ld	s0,0(sp)
 61c:	0141                	addi	sp,sp,16
 61e:	8082                	ret
      return *p1 - *p2;
 620:	40e7853b          	subw	a0,a5,a4
 624:	bfd5                	j	618 <memcmp+0x28>

0000000000000626 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 626:	1141                	addi	sp,sp,-16
 628:	e406                	sd	ra,8(sp)
 62a:	e022                	sd	s0,0(sp)
 62c:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 62e:	f67ff0ef          	jal	594 <memmove>
}
 632:	60a2                	ld	ra,8(sp)
 634:	6402                	ld	s0,0(sp)
 636:	0141                	addi	sp,sp,16
 638:	8082                	ret

000000000000063a <sbrk>:

char *
sbrk(int n)
{
 63a:	1141                	addi	sp,sp,-16
 63c:	e406                	sd	ra,8(sp)
 63e:	e022                	sd	s0,0(sp)
 640:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 642:	4585                	li	a1,1
 644:	0b2000ef          	jal	6f6 <sys_sbrk>
}
 648:	60a2                	ld	ra,8(sp)
 64a:	6402                	ld	s0,0(sp)
 64c:	0141                	addi	sp,sp,16
 64e:	8082                	ret

0000000000000650 <sbrklazy>:

char *
sbrklazy(int n)
{
 650:	1141                	addi	sp,sp,-16
 652:	e406                	sd	ra,8(sp)
 654:	e022                	sd	s0,0(sp)
 656:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 658:	4589                	li	a1,2
 65a:	09c000ef          	jal	6f6 <sys_sbrk>
}
 65e:	60a2                	ld	ra,8(sp)
 660:	6402                	ld	s0,0(sp)
 662:	0141                	addi	sp,sp,16
 664:	8082                	ret

0000000000000666 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 666:	4885                	li	a7,1
 ecall
 668:	00000073          	ecall
 ret
 66c:	8082                	ret

000000000000066e <exit>:
.global exit
exit:
 li a7, SYS_exit
 66e:	4889                	li	a7,2
 ecall
 670:	00000073          	ecall
 ret
 674:	8082                	ret

0000000000000676 <wait>:
.global wait
wait:
 li a7, SYS_wait
 676:	488d                	li	a7,3
 ecall
 678:	00000073          	ecall
 ret
 67c:	8082                	ret

000000000000067e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 67e:	4891                	li	a7,4
 ecall
 680:	00000073          	ecall
 ret
 684:	8082                	ret

0000000000000686 <read>:
.global read
read:
 li a7, SYS_read
 686:	4895                	li	a7,5
 ecall
 688:	00000073          	ecall
 ret
 68c:	8082                	ret

000000000000068e <write>:
.global write
write:
 li a7, SYS_write
 68e:	48c1                	li	a7,16
 ecall
 690:	00000073          	ecall
 ret
 694:	8082                	ret

0000000000000696 <close>:
.global close
close:
 li a7, SYS_close
 696:	48d5                	li	a7,21
 ecall
 698:	00000073          	ecall
 ret
 69c:	8082                	ret

000000000000069e <kill>:
.global kill
kill:
 li a7, SYS_kill
 69e:	4899                	li	a7,6
 ecall
 6a0:	00000073          	ecall
 ret
 6a4:	8082                	ret

00000000000006a6 <exec>:
.global exec
exec:
 li a7, SYS_exec
 6a6:	489d                	li	a7,7
 ecall
 6a8:	00000073          	ecall
 ret
 6ac:	8082                	ret

00000000000006ae <open>:
.global open
open:
 li a7, SYS_open
 6ae:	48bd                	li	a7,15
 ecall
 6b0:	00000073          	ecall
 ret
 6b4:	8082                	ret

00000000000006b6 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 6b6:	48c5                	li	a7,17
 ecall
 6b8:	00000073          	ecall
 ret
 6bc:	8082                	ret

00000000000006be <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 6be:	48c9                	li	a7,18
 ecall
 6c0:	00000073          	ecall
 ret
 6c4:	8082                	ret

00000000000006c6 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 6c6:	48a1                	li	a7,8
 ecall
 6c8:	00000073          	ecall
 ret
 6cc:	8082                	ret

00000000000006ce <link>:
.global link
link:
 li a7, SYS_link
 6ce:	48cd                	li	a7,19
 ecall
 6d0:	00000073          	ecall
 ret
 6d4:	8082                	ret

00000000000006d6 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 6d6:	48d1                	li	a7,20
 ecall
 6d8:	00000073          	ecall
 ret
 6dc:	8082                	ret

00000000000006de <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 6de:	48a5                	li	a7,9
 ecall
 6e0:	00000073          	ecall
 ret
 6e4:	8082                	ret

00000000000006e6 <dup>:
.global dup
dup:
 li a7, SYS_dup
 6e6:	48a9                	li	a7,10
 ecall
 6e8:	00000073          	ecall
 ret
 6ec:	8082                	ret

00000000000006ee <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 6ee:	48ad                	li	a7,11
 ecall
 6f0:	00000073          	ecall
 ret
 6f4:	8082                	ret

00000000000006f6 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 6f6:	48b1                	li	a7,12
 ecall
 6f8:	00000073          	ecall
 ret
 6fc:	8082                	ret

00000000000006fe <pause>:
.global pause
pause:
 li a7, SYS_pause
 6fe:	48b5                	li	a7,13
 ecall
 700:	00000073          	ecall
 ret
 704:	8082                	ret

0000000000000706 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 706:	48b9                	li	a7,14
 ecall
 708:	00000073          	ecall
 ret
 70c:	8082                	ret

000000000000070e <sync>:
.global sync
sync:
 li a7, SYS_sync
 70e:	48d9                	li	a7,22
 ecall
 710:	00000073          	ecall
 ret
 714:	8082                	ret

0000000000000716 <memstats>:
.global memstats
memstats:
 li a7, SYS_memstats
 716:	48dd                	li	a7,23
 ecall
 718:	00000073          	ecall
 ret
 71c:	8082                	ret

000000000000071e <vtop>:
.global vtop
vtop:
 li a7, SYS_vtop
 71e:	48e1                	li	a7,24
 ecall
 720:	00000073          	ecall
 ret
 724:	8082                	ret

0000000000000726 <pageinfo>:
.global pageinfo
pageinfo:
 li a7, SYS_pageinfo
 726:	48e5                	li	a7,25
 ecall
 728:	00000073          	ecall
 ret
 72c:	8082                	ret

000000000000072e <setreadonly>:
.global setreadonly
setreadonly:
 li a7, SYS_setreadonly
 72e:	48e9                	li	a7,26
 ecall
 730:	00000073          	ecall
 ret
 734:	8082                	ret

0000000000000736 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 736:	1101                	addi	sp,sp,-32
 738:	ec06                	sd	ra,24(sp)
 73a:	e822                	sd	s0,16(sp)
 73c:	1000                	addi	s0,sp,32
 73e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 742:	4605                	li	a2,1
 744:	fef40593          	addi	a1,s0,-17
 748:	f47ff0ef          	jal	68e <write>
}
 74c:	60e2                	ld	ra,24(sp)
 74e:	6442                	ld	s0,16(sp)
 750:	6105                	addi	sp,sp,32
 752:	8082                	ret

0000000000000754 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 754:	715d                	addi	sp,sp,-80
 756:	e486                	sd	ra,72(sp)
 758:	e0a2                	sd	s0,64(sp)
 75a:	f84a                	sd	s2,48(sp)
 75c:	f44e                	sd	s3,40(sp)
 75e:	0880                	addi	s0,sp,80
 760:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 762:	00d036b3          	snez	a3,a3
 766:	03f5d793          	srli	a5,a1,0x3f
 76a:	8efd                	and	a3,a3,a5
  neg = 0;
 76c:	4301                	li	t1,0
  if (sgn && xx < 0) {
 76e:	c681                	beqz	a3,776 <printint+0x22>
    neg = 1;
    x = -xx;
 770:	40b005b3          	neg	a1,a1
    neg = 1;
 774:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 776:	fb840993          	addi	s3,s0,-72
  neg = 0;
 77a:	86ce                	mv	a3,s3
  i = 0;
 77c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 77e:	00000817          	auipc	a6,0x0
 782:	6ea80813          	addi	a6,a6,1770 # e68 <digits>
 786:	88ba                	mv	a7,a4
 788:	0017051b          	addiw	a0,a4,1
 78c:	872a                	mv	a4,a0
 78e:	02c5f7b3          	remu	a5,a1,a2
 792:	97c2                	add	a5,a5,a6
 794:	0007c783          	lbu	a5,0(a5)
 798:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 79c:	87ae                	mv	a5,a1
 79e:	02c5d5b3          	divu	a1,a1,a2
 7a2:	0685                	addi	a3,a3,1
 7a4:	fec7f1e3          	bgeu	a5,a2,786 <printint+0x32>
  if (neg)
 7a8:	00030b63          	beqz	t1,7be <printint+0x6a>
    buf[i++] = '-';
 7ac:	fd040793          	addi	a5,s0,-48
 7b0:	953e                	add	a0,a0,a5
 7b2:	02d00793          	li	a5,45
 7b6:	fef50423          	sb	a5,-24(a0)
 7ba:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 7be:	02e05563          	blez	a4,7e8 <printint+0x94>
 7c2:	fc26                	sd	s1,56(sp)
 7c4:	377d                	addiw	a4,a4,-1
 7c6:	00e984b3          	add	s1,s3,a4
 7ca:	19fd                	addi	s3,s3,-1
 7cc:	99ba                	add	s3,s3,a4
 7ce:	1702                	slli	a4,a4,0x20
 7d0:	9301                	srli	a4,a4,0x20
 7d2:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 7d6:	0004c583          	lbu	a1,0(s1)
 7da:	854a                	mv	a0,s2
 7dc:	f5bff0ef          	jal	736 <putc>
  while (--i >= 0)
 7e0:	14fd                	addi	s1,s1,-1
 7e2:	ff349ae3          	bne	s1,s3,7d6 <printint+0x82>
 7e6:	74e2                	ld	s1,56(sp)
}
 7e8:	60a6                	ld	ra,72(sp)
 7ea:	6406                	ld	s0,64(sp)
 7ec:	7942                	ld	s2,48(sp)
 7ee:	79a2                	ld	s3,40(sp)
 7f0:	6161                	addi	sp,sp,80
 7f2:	8082                	ret

00000000000007f4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 7f4:	711d                	addi	sp,sp,-96
 7f6:	ec86                	sd	ra,88(sp)
 7f8:	e8a2                	sd	s0,80(sp)
 7fa:	e4a6                	sd	s1,72(sp)
 7fc:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 7fe:	0005c483          	lbu	s1,0(a1)
 802:	2a048063          	beqz	s1,aa2 <vprintf+0x2ae>
 806:	e0ca                	sd	s2,64(sp)
 808:	fc4e                	sd	s3,56(sp)
 80a:	f852                	sd	s4,48(sp)
 80c:	f456                	sd	s5,40(sp)
 80e:	f05a                	sd	s6,32(sp)
 810:	ec5e                	sd	s7,24(sp)
 812:	e862                	sd	s8,16(sp)
 814:	8b2a                	mv	s6,a0
 816:	8a2e                	mv	s4,a1
 818:	8bb2                	mv	s7,a2
  state = 0;
 81a:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 81c:	4901                	li	s2,0
 81e:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 820:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 824:	06400c13          	li	s8,100
 828:	a00d                	j	84a <vprintf+0x56>
        putc(fd, c0);
 82a:	85a6                	mv	a1,s1
 82c:	855a                	mv	a0,s6
 82e:	f09ff0ef          	jal	736 <putc>
 832:	a019                	j	838 <vprintf+0x44>
    } else if (state == '%') {
 834:	03598363          	beq	s3,s5,85a <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 838:	0019079b          	addiw	a5,s2,1
 83c:	893e                	mv	s2,a5
 83e:	873e                	mv	a4,a5
 840:	97d2                	add	a5,a5,s4
 842:	0007c483          	lbu	s1,0(a5)
 846:	24048763          	beqz	s1,a94 <vprintf+0x2a0>
    c0 = fmt[i] & 0xff;
 84a:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 84e:	fe0993e3          	bnez	s3,834 <vprintf+0x40>
      if (c0 == '%') {
 852:	fd579ce3          	bne	a5,s5,82a <vprintf+0x36>
        state = '%';
 856:	89be                	mv	s3,a5
 858:	b7c5                	j	838 <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 85a:	00ea06b3          	add	a3,s4,a4
 85e:	0016c603          	lbu	a2,1(a3)
      if (c1)
 862:	24060563          	beqz	a2,aac <vprintf+0x2b8>
      if (c0 == 'd') {
 866:	0b878763          	beq	a5,s8,914 <vprintf+0x120>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 86a:	f9478693          	addi	a3,a5,-108
 86e:	0016b693          	seqz	a3,a3
 872:	f9c60593          	addi	a1,a2,-100
 876:	0015b593          	seqz	a1,a1
 87a:	8df5                	and	a1,a1,a3
 87c:	e9c5                	bnez	a1,92c <vprintf+0x138>
        c2 = fmt[i + 2] & 0xff;
 87e:	9752                	add	a4,a4,s4
 880:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 884:	f9460713          	addi	a4,a2,-108
 888:	00173713          	seqz	a4,a4
 88c:	8f75                	and	a4,a4,a3
 88e:	f9c50593          	addi	a1,a0,-100
 892:	0015b593          	seqz	a1,a1
 896:	8df9                	and	a1,a1,a4
 898:	e5dd                	bnez	a1,946 <vprintf+0x152>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 89a:	07500593          	li	a1,117
 89e:	0cb78163          	beq	a5,a1,960 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint32), 10, 0);
      } else if (c0 == 'l' && c1 == 'u') {
 8a2:	f8b60593          	addi	a1,a2,-117
 8a6:	0015b593          	seqz	a1,a1
 8aa:	8df5                	and	a1,a1,a3
 8ac:	e5f1                	bnez	a1,978 <vprintf+0x184>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 8ae:	f8b50593          	addi	a1,a0,-117
 8b2:	0015b593          	seqz	a1,a1
 8b6:	8df9                	and	a1,a1,a4
 8b8:	ede9                	bnez	a1,992 <vprintf+0x19e>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 8ba:	07800593          	li	a1,120
 8be:	0eb78763          	beq	a5,a1,9ac <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint32), 16, 0);
      } else if (c0 == 'l' && c1 == 'x') {
 8c2:	f8860613          	addi	a2,a2,-120
 8c6:	00163613          	seqz	a2,a2
 8ca:	8ef1                	and	a3,a3,a2
 8cc:	0e069c63          	bnez	a3,9c4 <vprintf+0x1d0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 8d0:	f8850513          	addi	a0,a0,-120
 8d4:	00153513          	seqz	a0,a0
 8d8:	8f69                	and	a4,a4,a0
 8da:	10071263          	bnez	a4,9de <vprintf+0x1ea>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 8de:	07000713          	li	a4,112
 8e2:	10e78a63          	beq	a5,a4,9f6 <vprintf+0x202>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 8e6:	06300713          	li	a4,99
 8ea:	14e78a63          	beq	a5,a4,a3e <vprintf+0x24a>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 8ee:	07300713          	li	a4,115
 8f2:	16e78063          	beq	a5,a4,a52 <vprintf+0x25e>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 8f6:	02500713          	li	a4,37
 8fa:	18e78863          	beq	a5,a4,a8a <vprintf+0x296>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 8fe:	02500593          	li	a1,37
 902:	855a                	mv	a0,s6
 904:	e33ff0ef          	jal	736 <putc>
        putc(fd, c0);
 908:	85a6                	mv	a1,s1
 90a:	855a                	mv	a0,s6
 90c:	e2bff0ef          	jal	736 <putc>
      }

      state = 0;
 910:	4981                	li	s3,0
 912:	b71d                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 914:	008b8493          	addi	s1,s7,8
 918:	4685                	li	a3,1
 91a:	4629                	li	a2,10
 91c:	000ba583          	lw	a1,0(s7)
 920:	855a                	mv	a0,s6
 922:	e33ff0ef          	jal	754 <printint>
 926:	8ba6                	mv	s7,s1
      state = 0;
 928:	4981                	li	s3,0
 92a:	b739                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 92c:	008b8493          	addi	s1,s7,8
 930:	4685                	li	a3,1
 932:	4629                	li	a2,10
 934:	000bb583          	ld	a1,0(s7)
 938:	855a                	mv	a0,s6
 93a:	e1bff0ef          	jal	754 <printint>
        i += 1;
 93e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 940:	8ba6                	mv	s7,s1
      state = 0;
 942:	4981                	li	s3,0
 944:	bdd5                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 946:	008b8493          	addi	s1,s7,8
 94a:	4685                	li	a3,1
 94c:	4629                	li	a2,10
 94e:	000bb583          	ld	a1,0(s7)
 952:	855a                	mv	a0,s6
 954:	e01ff0ef          	jal	754 <printint>
        i += 2;
 958:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 95a:	8ba6                	mv	s7,s1
      state = 0;
 95c:	4981                	li	s3,0
        i += 2;
 95e:	bde9                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 960:	008b8493          	addi	s1,s7,8
 964:	4681                	li	a3,0
 966:	4629                	li	a2,10
 968:	000be583          	lwu	a1,0(s7)
 96c:	855a                	mv	a0,s6
 96e:	de7ff0ef          	jal	754 <printint>
 972:	8ba6                	mv	s7,s1
      state = 0;
 974:	4981                	li	s3,0
 976:	b5c9                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 978:	008b8493          	addi	s1,s7,8
 97c:	4681                	li	a3,0
 97e:	4629                	li	a2,10
 980:	000bb583          	ld	a1,0(s7)
 984:	855a                	mv	a0,s6
 986:	dcfff0ef          	jal	754 <printint>
        i += 1;
 98a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 98c:	8ba6                	mv	s7,s1
      state = 0;
 98e:	4981                	li	s3,0
 990:	b565                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 992:	008b8493          	addi	s1,s7,8
 996:	4681                	li	a3,0
 998:	4629                	li	a2,10
 99a:	000bb583          	ld	a1,0(s7)
 99e:	855a                	mv	a0,s6
 9a0:	db5ff0ef          	jal	754 <printint>
        i += 2;
 9a4:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 9a6:	8ba6                	mv	s7,s1
      state = 0;
 9a8:	4981                	li	s3,0
        i += 2;
 9aa:	b579                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 9ac:	008b8493          	addi	s1,s7,8
 9b0:	4681                	li	a3,0
 9b2:	4641                	li	a2,16
 9b4:	000be583          	lwu	a1,0(s7)
 9b8:	855a                	mv	a0,s6
 9ba:	d9bff0ef          	jal	754 <printint>
 9be:	8ba6                	mv	s7,s1
      state = 0;
 9c0:	4981                	li	s3,0
 9c2:	bd9d                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9c4:	008b8493          	addi	s1,s7,8
 9c8:	4681                	li	a3,0
 9ca:	4641                	li	a2,16
 9cc:	000bb583          	ld	a1,0(s7)
 9d0:	855a                	mv	a0,s6
 9d2:	d83ff0ef          	jal	754 <printint>
        i += 1;
 9d6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 9d8:	8ba6                	mv	s7,s1
      state = 0;
 9da:	4981                	li	s3,0
 9dc:	bdb1                	j	838 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9de:	008b8493          	addi	s1,s7,8
 9e2:	4641                	li	a2,16
 9e4:	000bb583          	ld	a1,0(s7)
 9e8:	855a                	mv	a0,s6
 9ea:	d6bff0ef          	jal	754 <printint>
        i += 2;
 9ee:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 9f0:	8ba6                	mv	s7,s1
      state = 0;
 9f2:	4981                	li	s3,0
        i += 2;
 9f4:	b591                	j	838 <vprintf+0x44>
 9f6:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 9f8:	008b8793          	addi	a5,s7,8
 9fc:	8cbe                	mv	s9,a5
 9fe:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 a02:	03000593          	li	a1,48
 a06:	855a                	mv	a0,s6
 a08:	d2fff0ef          	jal	736 <putc>
  putc(fd, 'x');
 a0c:	07800593          	li	a1,120
 a10:	855a                	mv	a0,s6
 a12:	d25ff0ef          	jal	736 <putc>
 a16:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a18:	00000b97          	auipc	s7,0x0
 a1c:	450b8b93          	addi	s7,s7,1104 # e68 <digits>
 a20:	03c9d793          	srli	a5,s3,0x3c
 a24:	97de                	add	a5,a5,s7
 a26:	0007c583          	lbu	a1,0(a5)
 a2a:	855a                	mv	a0,s6
 a2c:	d0bff0ef          	jal	736 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a30:	0992                	slli	s3,s3,0x4
 a32:	34fd                	addiw	s1,s1,-1
 a34:	f4f5                	bnez	s1,a20 <vprintf+0x22c>
        printptr(fd, va_arg(ap, uint64));
 a36:	8be6                	mv	s7,s9
      state = 0;
 a38:	4981                	li	s3,0
 a3a:	6ca2                	ld	s9,8(sp)
 a3c:	bbf5                	j	838 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 a3e:	008b8493          	addi	s1,s7,8
 a42:	000bc583          	lbu	a1,0(s7)
 a46:	855a                	mv	a0,s6
 a48:	cefff0ef          	jal	736 <putc>
 a4c:	8ba6                	mv	s7,s1
      state = 0;
 a4e:	4981                	li	s3,0
 a50:	b3e5                	j	838 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 a52:	008b8993          	addi	s3,s7,8
 a56:	000bb483          	ld	s1,0(s7)
 a5a:	cc91                	beqz	s1,a76 <vprintf+0x282>
        for (; *s; s++)
 a5c:	0004c583          	lbu	a1,0(s1)
 a60:	c195                	beqz	a1,a84 <vprintf+0x290>
          putc(fd, *s);
 a62:	855a                	mv	a0,s6
 a64:	cd3ff0ef          	jal	736 <putc>
        for (; *s; s++)
 a68:	0485                	addi	s1,s1,1
 a6a:	0004c583          	lbu	a1,0(s1)
 a6e:	f9f5                	bnez	a1,a62 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 a70:	8bce                	mv	s7,s3
      state = 0;
 a72:	4981                	li	s3,0
 a74:	b3d1                	j	838 <vprintf+0x44>
          s = "(null)";
 a76:	00000497          	auipc	s1,0x0
 a7a:	3ea48493          	addi	s1,s1,1002 # e60 <malloc+0x2b8>
        for (; *s; s++)
 a7e:	02800593          	li	a1,40
 a82:	b7c5                	j	a62 <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 a84:	8bce                	mv	s7,s3
      state = 0;
 a86:	4981                	li	s3,0
 a88:	bb45                	j	838 <vprintf+0x44>
        putc(fd, '%');
 a8a:	85be                	mv	a1,a5
 a8c:	855a                	mv	a0,s6
 a8e:	ca9ff0ef          	jal	736 <putc>
 a92:	bdbd                	j	910 <vprintf+0x11c>
 a94:	6906                	ld	s2,64(sp)
 a96:	79e2                	ld	s3,56(sp)
 a98:	7a42                	ld	s4,48(sp)
 a9a:	7aa2                	ld	s5,40(sp)
 a9c:	7b02                	ld	s6,32(sp)
 a9e:	6be2                	ld	s7,24(sp)
 aa0:	6c42                	ld	s8,16(sp)
    }
  }
}
 aa2:	60e6                	ld	ra,88(sp)
 aa4:	6446                	ld	s0,80(sp)
 aa6:	64a6                	ld	s1,72(sp)
 aa8:	6125                	addi	sp,sp,96
 aaa:	8082                	ret
      if (c0 == 'd') {
 aac:	06400713          	li	a4,100
 ab0:	e6e782e3          	beq	a5,a4,914 <vprintf+0x120>
      } else if (c0 == 'l' && c1 == 'd') {
 ab4:	f9478693          	addi	a3,a5,-108
 ab8:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 abc:	8532                	mv	a0,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 abe:	4701                	li	a4,0
 ac0:	bbe9                	j	89a <vprintf+0xa6>

0000000000000ac2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 ac2:	715d                	addi	sp,sp,-80
 ac4:	ec06                	sd	ra,24(sp)
 ac6:	e822                	sd	s0,16(sp)
 ac8:	1000                	addi	s0,sp,32
 aca:	e010                	sd	a2,0(s0)
 acc:	e414                	sd	a3,8(s0)
 ace:	e818                	sd	a4,16(s0)
 ad0:	ec1c                	sd	a5,24(s0)
 ad2:	03043023          	sd	a6,32(s0)
 ad6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 ada:	8622                	mv	a2,s0
 adc:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 ae0:	d15ff0ef          	jal	7f4 <vprintf>
}
 ae4:	60e2                	ld	ra,24(sp)
 ae6:	6442                	ld	s0,16(sp)
 ae8:	6161                	addi	sp,sp,80
 aea:	8082                	ret

0000000000000aec <printf>:

void
printf(const char *fmt, ...)
{
 aec:	711d                	addi	sp,sp,-96
 aee:	ec06                	sd	ra,24(sp)
 af0:	e822                	sd	s0,16(sp)
 af2:	1000                	addi	s0,sp,32
 af4:	e40c                	sd	a1,8(s0)
 af6:	e810                	sd	a2,16(s0)
 af8:	ec14                	sd	a3,24(s0)
 afa:	f018                	sd	a4,32(s0)
 afc:	f41c                	sd	a5,40(s0)
 afe:	03043823          	sd	a6,48(s0)
 b02:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 b06:	00840613          	addi	a2,s0,8
 b0a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 b0e:	85aa                	mv	a1,a0
 b10:	4505                	li	a0,1
 b12:	ce3ff0ef          	jal	7f4 <vprintf>
}
 b16:	60e2                	ld	ra,24(sp)
 b18:	6442                	ld	s0,16(sp)
 b1a:	6125                	addi	sp,sp,96
 b1c:	8082                	ret

0000000000000b1e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 b1e:	1141                	addi	sp,sp,-16
 b20:	e406                	sd	ra,8(sp)
 b22:	e022                	sd	s0,0(sp)
 b24:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 b26:	ff050713          	addi	a4,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b2a:	00000797          	auipc	a5,0x0
 b2e:	5267b783          	ld	a5,1318(a5) # 1050 <freep>
 b32:	a095                	j	b96 <free+0x78>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
 b34:	ff852583          	lw	a1,-8(a0)
 b38:	6390                	ld	a2,0(a5)
 b3a:	02059813          	slli	a6,a1,0x20
 b3e:	01c85693          	srli	a3,a6,0x1c
 b42:	96ba                	add	a3,a3,a4
 b44:	02d60563          	beq	a2,a3,b6e <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 b48:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 b4c:	4790                	lw	a2,8(a5)
 b4e:	02061593          	slli	a1,a2,0x20
 b52:	01c5d693          	srli	a3,a1,0x1c
 b56:	96be                	add	a3,a3,a5
 b58:	02d70263          	beq	a4,a3,b7c <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 b5c:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 b5e:	00000717          	auipc	a4,0x0
 b62:	4ef73923          	sd	a5,1266(a4) # 1050 <freep>
}
 b66:	60a2                	ld	ra,8(sp)
 b68:	6402                	ld	s0,0(sp)
 b6a:	0141                	addi	sp,sp,16
 b6c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 b6e:	4614                	lw	a3,8(a2)
 b70:	9ead                	addw	a3,a3,a1
 b72:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 b76:	6394                	ld	a3,0(a5)
 b78:	6290                	ld	a2,0(a3)
 b7a:	b7f9                	j	b48 <free+0x2a>
    p->s.size += bp->s.size;
 b7c:	ff852703          	lw	a4,-8(a0)
 b80:	9f31                	addw	a4,a4,a2
 b82:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 b84:	ff053703          	ld	a4,-16(a0)
 b88:	bfd1                	j	b5c <free+0x3e>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b8a:	6394                	ld	a3,0(a5)
 b8c:	00d7e463          	bltu	a5,a3,b94 <free+0x76>
 b90:	fad762e3          	bltu	a4,a3,b34 <free+0x16>
 b94:	87b6                	mv	a5,a3
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b96:	fee7fae3          	bgeu	a5,a4,b8a <free+0x6c>
 b9a:	6394                	ld	a3,0(a5)
 b9c:	f8d76ce3          	bltu	a4,a3,b34 <free+0x16>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ba0:	f8d7fae3          	bgeu	a5,a3,b34 <free+0x16>
 ba4:	87b6                	mv	a5,a3
 ba6:	bfc5                	j	b96 <free+0x78>

0000000000000ba8 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 ba8:	7139                	addi	sp,sp,-64
 baa:	fc06                	sd	ra,56(sp)
 bac:	f822                	sd	s0,48(sp)
 bae:	f04a                	sd	s2,32(sp)
 bb0:	ec4e                	sd	s3,24(sp)
 bb2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 bb4:	02051993          	slli	s3,a0,0x20
 bb8:	0209d993          	srli	s3,s3,0x20
 bbc:	09bd                	addi	s3,s3,15
 bbe:	0049d993          	srli	s3,s3,0x4
 bc2:	2985                	addiw	s3,s3,1
 bc4:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 bc6:	00000517          	auipc	a0,0x0
 bca:	48a53503          	ld	a0,1162(a0) # 1050 <freep>
 bce:	c905                	beqz	a0,bfe <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 bd0:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 bd2:	4798                	lw	a4,8(a5)
 bd4:	09377663          	bgeu	a4,s3,c60 <malloc+0xb8>
 bd8:	f426                	sd	s1,40(sp)
 bda:	e852                	sd	s4,16(sp)
 bdc:	e456                	sd	s5,8(sp)
 bde:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 be0:	8a4e                	mv	s4,s3
 be2:	6705                	lui	a4,0x1
 be4:	00e9f363          	bgeu	s3,a4,bea <malloc+0x42>
 be8:	6a05                	lui	s4,0x1
 bea:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 bee:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 bf2:	00000497          	auipc	s1,0x0
 bf6:	45e48493          	addi	s1,s1,1118 # 1050 <freep>
  if (p == SBRK_ERROR)
 bfa:	5afd                	li	s5,-1
 bfc:	a83d                	j	c3a <malloc+0x92>
 bfe:	f426                	sd	s1,40(sp)
 c00:	e852                	sd	s4,16(sp)
 c02:	e456                	sd	s5,8(sp)
 c04:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 c06:	00000797          	auipc	a5,0x0
 c0a:	4a278793          	addi	a5,a5,1186 # 10a8 <base>
 c0e:	00000717          	auipc	a4,0x0
 c12:	44f73123          	sd	a5,1090(a4) # 1050 <freep>
 c16:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 c18:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 c1c:	b7d1                	j	be0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 c1e:	6398                	ld	a4,0(a5)
 c20:	e118                	sd	a4,0(a0)
 c22:	a899                	j	c78 <malloc+0xd0>
  hp->s.size = nu;
 c24:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 c28:	0541                	addi	a0,a0,16
 c2a:	ef5ff0ef          	jal	b1e <free>
  return freep;
 c2e:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 c30:	c125                	beqz	a0,c90 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 c32:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 c34:	4798                	lw	a4,8(a5)
 c36:	03277163          	bgeu	a4,s2,c58 <malloc+0xb0>
    if (p == freep)
 c3a:	6098                	ld	a4,0(s1)
 c3c:	853e                	mv	a0,a5
 c3e:	fef71ae3          	bne	a4,a5,c32 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 c42:	8552                	mv	a0,s4
 c44:	9f7ff0ef          	jal	63a <sbrk>
  if (p == SBRK_ERROR)
 c48:	fd551ee3          	bne	a0,s5,c24 <malloc+0x7c>
        return 0;
 c4c:	4501                	li	a0,0
 c4e:	74a2                	ld	s1,40(sp)
 c50:	6a42                	ld	s4,16(sp)
 c52:	6aa2                	ld	s5,8(sp)
 c54:	6b02                	ld	s6,0(sp)
 c56:	a03d                	j	c84 <malloc+0xdc>
 c58:	74a2                	ld	s1,40(sp)
 c5a:	6a42                	ld	s4,16(sp)
 c5c:	6aa2                	ld	s5,8(sp)
 c5e:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 c60:	fae90fe3          	beq	s2,a4,c1e <malloc+0x76>
        p->s.size -= nunits;
 c64:	4137073b          	subw	a4,a4,s3
 c68:	c798                	sw	a4,8(a5)
        p += p->s.size;
 c6a:	02071693          	slli	a3,a4,0x20
 c6e:	01c6d713          	srli	a4,a3,0x1c
 c72:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 c74:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 c78:	00000717          	auipc	a4,0x0
 c7c:	3ca73c23          	sd	a0,984(a4) # 1050 <freep>
      return (void *)(p + 1);
 c80:	01078513          	addi	a0,a5,16
  }
}
 c84:	70e2                	ld	ra,56(sp)
 c86:	7442                	ld	s0,48(sp)
 c88:	7902                	ld	s2,32(sp)
 c8a:	69e2                	ld	s3,24(sp)
 c8c:	6121                	addi	sp,sp,64
 c8e:	8082                	ret
 c90:	74a2                	ld	s1,40(sp)
 c92:	6a42                	ld	s4,16(sp)
 c94:	6aa2                	ld	s5,8(sp)
 c96:	6b02                	ld	s6,0(sp)
 c98:	b7f5                	j	c84 <malloc+0xdc>
