
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	99010113          	addi	sp,sp,-1648 # 80007990 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	042000ef          	jal	80000058 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000024:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000028:	577d                	li	a4,-1
    8000002a:	177e                	slli	a4,a4,0x3f
    8000002c:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002e:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000032:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000036:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    8000003a:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003e:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000042:	000f4737          	lui	a4,0xf4
    80000046:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000004a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004c:	14d79073          	csrw	stimecmp,a5
}
    80000050:	60a2                	ld	ra,8(sp)
    80000052:	6402                	ld	s0,0(sp)
    80000054:	0141                	addi	sp,sp,16
    80000056:	8082                	ret

0000000080000058 <start>:
{
    80000058:	1141                	addi	sp,sp,-16
    8000005a:	e406                	sd	ra,8(sp)
    8000005c:	e022                	sd	s0,0(sp)
    8000005e:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000060:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000064:	7779                	lui	a4,0xffffe
    80000066:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd947>
    8000006a:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000006c:	6705                	lui	a4,0x1
    8000006e:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80000072:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000074:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000078:	00001797          	auipc	a5,0x1
    8000007c:	ea278793          	addi	a5,a5,-350 # 80000f1a <main>
    80000080:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000084:	4781                	li	a5,0
    80000086:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    8000008a:	67c1                	lui	a5,0x10
    8000008c:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008e:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    80000092:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000096:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    8000009a:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009e:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    800000a2:	57fd                	li	a5,-1
    800000a4:	83a9                	srli	a5,a5,0xa
    800000a6:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000aa:	47bd                	li	a5,15
    800000ac:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000b0:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b4:	4705                	li	a4,1
    800000b6:	1776                	slli	a4,a4,0x3d
    800000b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000ba:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000be:	f5fff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000c2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c6:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c8:	823e                	mv	tp,a5
  asm volatile("mret");
    800000ca:	30200073          	mret
}
    800000ce:	60a2                	ld	ra,8(sp)
    800000d0:	6402                	ld	s0,0(sp)
    800000d2:	0141                	addi	sp,sp,16
    800000d4:	8082                	ret

00000000800000d6 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d6:	7119                	addi	sp,sp,-128
    800000d8:	fc86                	sd	ra,120(sp)
    800000da:	f8a2                	sd	s0,112(sp)
    800000dc:	f4a6                	sd	s1,104(sp)
    800000de:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000e0:	06c05b63          	blez	a2,80000156 <consolewrite+0x80>
    800000e4:	f0ca                	sd	s2,96(sp)
    800000e6:	ecce                	sd	s3,88(sp)
    800000e8:	e8d2                	sd	s4,80(sp)
    800000ea:	e4d6                	sd	s5,72(sp)
    800000ec:	e0da                	sd	s6,64(sp)
    800000ee:	fc5e                	sd	s7,56(sp)
    800000f0:	f862                	sd	s8,48(sp)
    800000f2:	f466                	sd	s9,40(sp)
    800000f4:	f06a                	sd	s10,32(sp)
    800000f6:	8b2a                	mv	s6,a0
    800000f8:	8bae                	mv	s7,a1
    800000fa:	8a32                	mv	s4,a2
  int i = 0;
    800000fc:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000fe:	02000c93          	li	s9,32
    80000102:	02000d13          	li	s10,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000106:	f8040a93          	addi	s5,s0,-128
    8000010a:	5c7d                	li	s8,-1
    8000010c:	a025                	j	80000134 <consolewrite+0x5e>
    if (nn > n - i)
    8000010e:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000112:	86ce                	mv	a3,s3
    80000114:	01748633          	add	a2,s1,s7
    80000118:	85da                	mv	a1,s6
    8000011a:	8556                	mv	a0,s5
    8000011c:	384020ef          	jal	800024a0 <either_copyin>
    80000120:	03850d63          	beq	a0,s8,8000015a <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000124:	85ce                	mv	a1,s3
    80000126:	8556                	mv	a0,s5
    80000128:	7d6000ef          	jal	800008fe <uartwrite>
    i += nn;
    8000012c:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    80000130:	0144d963          	bge	s1,s4,80000142 <consolewrite+0x6c>
    if (nn > n - i)
    80000134:	409a07bb          	subw	a5,s4,s1
    80000138:	893e                	mv	s2,a5
    8000013a:	fcfcdae3          	bge	s9,a5,8000010e <consolewrite+0x38>
    8000013e:	896a                	mv	s2,s10
    80000140:	b7f9                	j	8000010e <consolewrite+0x38>
    80000142:	7906                	ld	s2,96(sp)
    80000144:	69e6                	ld	s3,88(sp)
    80000146:	6a46                	ld	s4,80(sp)
    80000148:	6aa6                	ld	s5,72(sp)
    8000014a:	6b06                	ld	s6,64(sp)
    8000014c:	7be2                	ld	s7,56(sp)
    8000014e:	7c42                	ld	s8,48(sp)
    80000150:	7ca2                	ld	s9,40(sp)
    80000152:	7d02                	ld	s10,32(sp)
    80000154:	a821                	j	8000016c <consolewrite+0x96>
  int i = 0;
    80000156:	4481                	li	s1,0
    80000158:	a811                	j	8000016c <consolewrite+0x96>
    8000015a:	7906                	ld	s2,96(sp)
    8000015c:	69e6                	ld	s3,88(sp)
    8000015e:	6a46                	ld	s4,80(sp)
    80000160:	6aa6                	ld	s5,72(sp)
    80000162:	6b06                	ld	s6,64(sp)
    80000164:	7be2                	ld	s7,56(sp)
    80000166:	7c42                	ld	s8,48(sp)
    80000168:	7ca2                	ld	s9,40(sp)
    8000016a:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016c:	8526                	mv	a0,s1
    8000016e:	70e6                	ld	ra,120(sp)
    80000170:	7446                	ld	s0,112(sp)
    80000172:	74a6                	ld	s1,104(sp)
    80000174:	6109                	addi	sp,sp,128
    80000176:	8082                	ret

0000000080000178 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000178:	711d                	addi	sp,sp,-96
    8000017a:	ec86                	sd	ra,88(sp)
    8000017c:	e8a2                	sd	s0,80(sp)
    8000017e:	e4a6                	sd	s1,72(sp)
    80000180:	e0ca                	sd	s2,64(sp)
    80000182:	fc4e                	sd	s3,56(sp)
    80000184:	f852                	sd	s4,48(sp)
    80000186:	f05a                	sd	s6,32(sp)
    80000188:	ec5e                	sd	s7,24(sp)
    8000018a:	1080                	addi	s0,sp,96
    8000018c:	8b2a                	mv	s6,a0
    8000018e:	8a2e                	mv	s4,a1
    80000190:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000192:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000194:	0000f517          	auipc	a0,0xf
    80000198:	7fc50513          	addi	a0,a0,2044 # 8000f990 <cons>
    8000019c:	317000ef          	jal	80000cb2 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    800001a0:	0000f497          	auipc	s1,0xf
    800001a4:	7f048493          	addi	s1,s1,2032 # 8000f990 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a8:	00010917          	auipc	s2,0x10
    800001ac:	88090913          	addi	s2,s2,-1920 # 8000fa28 <cons+0x98>
  while (n > 0) {
    800001b0:	0d305263          	blez	s3,80000274 <consoleread+0xfc>
    while (cons.r == cons.w) {
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	0af71763          	bne	a4,a5,8000026a <consoleread+0xf2>
      if (killed(myproc())) {
    800001c0:	0c5010ef          	jal	80001a84 <myproc>
    800001c4:	15e020ef          	jal	80002322 <killed>
    800001c8:	e925                	bnez	a0,80000238 <consoleread+0xc0>
      sleep_prepare(&cons.r);
    800001ca:	854a                	mv	a0,s2
    800001cc:	6ff010ef          	jal	800020ca <sleep_prepare>
      release(&cons.lock);
    800001d0:	8526                	mv	a0,s1
    800001d2:	365000ef          	jal	80000d36 <release>
      sleep();
    800001d6:	731010ef          	jal	80002106 <sleep>
      acquire(&cons.lock);
    800001da:	8526                	mv	a0,s1
    800001dc:	2d7000ef          	jal	80000cb2 <acquire>
    while (cons.r == cons.w) {
    800001e0:	0984a783          	lw	a5,152(s1)
    800001e4:	09c4a703          	lw	a4,156(s1)
    800001e8:	fcf70ce3          	beq	a4,a5,800001c0 <consoleread+0x48>
    800001ec:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ee:	0000f717          	auipc	a4,0xf
    800001f2:	7a270713          	addi	a4,a4,1954 # 8000f990 <cons>
    800001f6:	0017869b          	addiw	a3,a5,1
    800001fa:	08d72c23          	sw	a3,152(a4)
    800001fe:	07f7f693          	andi	a3,a5,127
    80000202:	9736                	add	a4,a4,a3
    80000204:	01874703          	lbu	a4,24(a4)
    80000208:	00070a9b          	sext.w	s5,a4

    if (c == C('D')) { // end-of-file
    8000020c:	4691                	li	a3,4
    8000020e:	04da8663          	beq	s5,a3,8000025a <consoleread+0xe2>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000212:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000216:	4685                	li	a3,1
    80000218:	faf40613          	addi	a2,s0,-81
    8000021c:	85d2                	mv	a1,s4
    8000021e:	855a                	mv	a0,s6
    80000220:	234020ef          	jal	80002454 <either_copyout>
    80000224:	57fd                	li	a5,-1
    80000226:	04f50663          	beq	a0,a5,80000272 <consoleread+0xfa>
      break;

    dst++;
    8000022a:	0a05                	addi	s4,s4,1
    --n;
    8000022c:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    8000022e:	47a9                	li	a5,10
    80000230:	04fa8b63          	beq	s5,a5,80000286 <consoleread+0x10e>
    80000234:	7aa2                	ld	s5,40(sp)
    80000236:	bfad                	j	800001b0 <consoleread+0x38>
        release(&cons.lock);
    80000238:	0000f517          	auipc	a0,0xf
    8000023c:	75850513          	addi	a0,a0,1880 # 8000f990 <cons>
    80000240:	2f7000ef          	jal	80000d36 <release>
        return -1;
    80000244:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000246:	60e6                	ld	ra,88(sp)
    80000248:	6446                	ld	s0,80(sp)
    8000024a:	64a6                	ld	s1,72(sp)
    8000024c:	6906                	ld	s2,64(sp)
    8000024e:	79e2                	ld	s3,56(sp)
    80000250:	7a42                	ld	s4,48(sp)
    80000252:	7b02                	ld	s6,32(sp)
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	6125                	addi	sp,sp,96
    80000258:	8082                	ret
      if (n < target) {
    8000025a:	0179fa63          	bgeu	s3,s7,8000026e <consoleread+0xf6>
        cons.r--;
    8000025e:	0000f717          	auipc	a4,0xf
    80000262:	7cf72523          	sw	a5,1994(a4) # 8000fa28 <cons+0x98>
    80000266:	7aa2                	ld	s5,40(sp)
    80000268:	a031                	j	80000274 <consoleread+0xfc>
    8000026a:	f456                	sd	s5,40(sp)
    8000026c:	b749                	j	800001ee <consoleread+0x76>
    8000026e:	7aa2                	ld	s5,40(sp)
    80000270:	a011                	j	80000274 <consoleread+0xfc>
    80000272:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000274:	0000f517          	auipc	a0,0xf
    80000278:	71c50513          	addi	a0,a0,1820 # 8000f990 <cons>
    8000027c:	2bb000ef          	jal	80000d36 <release>
  return target - n;
    80000280:	413b853b          	subw	a0,s7,s3
    80000284:	b7c9                	j	80000246 <consoleread+0xce>
    80000286:	7aa2                	ld	s5,40(sp)
    80000288:	b7f5                	j	80000274 <consoleread+0xfc>

000000008000028a <consputc>:
{
    8000028a:	1141                	addi	sp,sp,-16
    8000028c:	e406                	sd	ra,8(sp)
    8000028e:	e022                	sd	s0,0(sp)
    80000290:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000292:	10000793          	li	a5,256
    80000296:	00f50863          	beq	a0,a5,800002a6 <consputc+0x1c>
    uartputc_sync(c);
    8000029a:	6ea000ef          	jal	80000984 <uartputc_sync>
}
    8000029e:	60a2                	ld	ra,8(sp)
    800002a0:	6402                	ld	s0,0(sp)
    800002a2:	0141                	addi	sp,sp,16
    800002a4:	8082                	ret
    uartputc_sync('\b');
    800002a6:	4521                	li	a0,8
    800002a8:	6dc000ef          	jal	80000984 <uartputc_sync>
    uartputc_sync(' ');
    800002ac:	02000513          	li	a0,32
    800002b0:	6d4000ef          	jal	80000984 <uartputc_sync>
    uartputc_sync('\b');
    800002b4:	4521                	li	a0,8
    800002b6:	6ce000ef          	jal	80000984 <uartputc_sync>
    800002ba:	b7d5                	j	8000029e <consputc+0x14>

00000000800002bc <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002bc:	1101                	addi	sp,sp,-32
    800002be:	ec06                	sd	ra,24(sp)
    800002c0:	e822                	sd	s0,16(sp)
    800002c2:	e426                	sd	s1,8(sp)
    800002c4:	1000                	addi	s0,sp,32
    800002c6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c8:	0000f517          	auipc	a0,0xf
    800002cc:	6c850513          	addi	a0,a0,1736 # 8000f990 <cons>
    800002d0:	1e3000ef          	jal	80000cb2 <acquire>

  switch (c) {
    800002d4:	47d5                	li	a5,21
    800002d6:	0af48163          	beq	s1,a5,80000378 <consoleintr+0xbc>
    800002da:	0297c563          	blt	a5,s1,80000304 <consoleintr+0x48>
    800002de:	47a1                	li	a5,8
    800002e0:	0ef48663          	beq	s1,a5,800003cc <consoleintr+0x110>
    800002e4:	47c1                	li	a5,16
    800002e6:	10f49763          	bne	s1,a5,800003f4 <consoleintr+0x138>
  case C('P'): // Print process list.
    procdump();
    800002ea:	202020ef          	jal	800024ec <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ee:	0000f517          	auipc	a0,0xf
    800002f2:	6a250513          	addi	a0,a0,1698 # 8000f990 <cons>
    800002f6:	241000ef          	jal	80000d36 <release>
}
    800002fa:	60e2                	ld	ra,24(sp)
    800002fc:	6442                	ld	s0,16(sp)
    800002fe:	64a2                	ld	s1,8(sp)
    80000300:	6105                	addi	sp,sp,32
    80000302:	8082                	ret
  switch (c) {
    80000304:	07f00793          	li	a5,127
    80000308:	0cf48263          	beq	s1,a5,800003cc <consoleintr+0x110>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030c:	0000f717          	auipc	a4,0xf
    80000310:	68470713          	addi	a4,a4,1668 # 8000f990 <cons>
    80000314:	0a072783          	lw	a5,160(a4)
    80000318:	09872703          	lw	a4,152(a4)
    8000031c:	9f99                	subw	a5,a5,a4
    8000031e:	07f00713          	li	a4,127
    80000322:	fcf766e3          	bltu	a4,a5,800002ee <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000326:	47b5                	li	a5,13
    80000328:	0cf48963          	beq	s1,a5,800003fa <consoleintr+0x13e>
      consputc(c);
    8000032c:	8526                	mv	a0,s1
    8000032e:	f5dff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000332:	0000f717          	auipc	a4,0xf
    80000336:	65e70713          	addi	a4,a4,1630 # 8000f990 <cons>
    8000033a:	0a072683          	lw	a3,160(a4)
    8000033e:	0016879b          	addiw	a5,a3,1
    80000342:	863e                	mv	a2,a5
    80000344:	0af72023          	sw	a5,160(a4)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	9736                	add	a4,a4,a3
    8000034e:	00970c23          	sb	s1,24(a4)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	ff648713          	addi	a4,s1,-10
    80000356:	00173713          	seqz	a4,a4
    8000035a:	14f1                	addi	s1,s1,-4
    8000035c:	0014b493          	seqz	s1,s1
    80000360:	8f45                	or	a4,a4,s1
    80000362:	e361                	bnez	a4,80000422 <consoleintr+0x166>
    80000364:	0000f717          	auipc	a4,0xf
    80000368:	6c472703          	lw	a4,1732(a4) # 8000fa28 <cons+0x98>
    8000036c:	9f99                	subw	a5,a5,a4
    8000036e:	08000713          	li	a4,128
    80000372:	f6e79ee3          	bne	a5,a4,800002ee <consoleintr+0x32>
    80000376:	a075                	j	80000422 <consoleintr+0x166>
    80000378:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    8000037a:	0000f717          	auipc	a4,0xf
    8000037e:	61670713          	addi	a4,a4,1558 # 8000f990 <cons>
    80000382:	0a072783          	lw	a5,160(a4)
    80000386:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    8000038a:	0000f497          	auipc	s1,0xf
    8000038e:	60648493          	addi	s1,s1,1542 # 8000f990 <cons>
    while (cons.e != cons.w &&
    80000392:	4929                	li	s2,10
    80000394:	02f70863          	beq	a4,a5,800003c4 <consoleintr+0x108>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000398:	37fd                	addiw	a5,a5,-1
    8000039a:	07f7f713          	andi	a4,a5,127
    8000039e:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    800003a0:	01874703          	lbu	a4,24(a4)
    800003a4:	03270263          	beq	a4,s2,800003c8 <consoleintr+0x10c>
      cons.e--;
    800003a8:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003ac:	10000513          	li	a0,256
    800003b0:	edbff0ef          	jal	8000028a <consputc>
    while (cons.e != cons.w &&
    800003b4:	0a04a783          	lw	a5,160(s1)
    800003b8:	09c4a703          	lw	a4,156(s1)
    800003bc:	fcf71ee3          	bne	a4,a5,80000398 <consoleintr+0xdc>
    800003c0:	6902                	ld	s2,0(sp)
    800003c2:	b735                	j	800002ee <consoleintr+0x32>
    800003c4:	6902                	ld	s2,0(sp)
    800003c6:	b725                	j	800002ee <consoleintr+0x32>
    800003c8:	6902                	ld	s2,0(sp)
    800003ca:	b715                	j	800002ee <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003cc:	0000f717          	auipc	a4,0xf
    800003d0:	5c470713          	addi	a4,a4,1476 # 8000f990 <cons>
    800003d4:	0a072783          	lw	a5,160(a4)
    800003d8:	09c72703          	lw	a4,156(a4)
    800003dc:	f0f709e3          	beq	a4,a5,800002ee <consoleintr+0x32>
      cons.e--;
    800003e0:	37fd                	addiw	a5,a5,-1
    800003e2:	0000f717          	auipc	a4,0xf
    800003e6:	64f72723          	sw	a5,1614(a4) # 8000fa30 <cons+0xa0>
      consputc(BACKSPACE);
    800003ea:	10000513          	li	a0,256
    800003ee:	e9dff0ef          	jal	8000028a <consputc>
    800003f2:	bdf5                	j	800002ee <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003f4:	ee048de3          	beqz	s1,800002ee <consoleintr+0x32>
    800003f8:	bf11                	j	8000030c <consoleintr+0x50>
      consputc(c);
    800003fa:	4529                	li	a0,10
    800003fc:	e8fff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000400:	0000f797          	auipc	a5,0xf
    80000404:	59078793          	addi	a5,a5,1424 # 8000f990 <cons>
    80000408:	0a07a703          	lw	a4,160(a5)
    8000040c:	0017069b          	addiw	a3,a4,1
    80000410:	8636                	mv	a2,a3
    80000412:	0ad7a023          	sw	a3,160(a5)
    80000416:	07f77713          	andi	a4,a4,127
    8000041a:	97ba                	add	a5,a5,a4
    8000041c:	4729                	li	a4,10
    8000041e:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000422:	0000f797          	auipc	a5,0xf
    80000426:	60c7a523          	sw	a2,1546(a5) # 8000fa2c <cons+0x9c>
        wakeup(&cons.r);
    8000042a:	0000f517          	auipc	a0,0xf
    8000042e:	5fe50513          	addi	a0,a0,1534 # 8000fa28 <cons+0x98>
    80000432:	505010ef          	jal	80002136 <wakeup>
    80000436:	bd65                	j	800002ee <consoleintr+0x32>

0000000080000438 <consoleinit>:

void
consoleinit(void)
{
    80000438:	1141                	addi	sp,sp,-16
    8000043a:	e406                	sd	ra,8(sp)
    8000043c:	e022                	sd	s0,0(sp)
    8000043e:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000440:	00007597          	auipc	a1,0x7
    80000444:	bc058593          	addi	a1,a1,-1088 # 80007000 <etext>
    80000448:	0000f517          	auipc	a0,0xf
    8000044c:	54850513          	addi	a0,a0,1352 # 8000f990 <cons>
    80000450:	7e2000ef          	jal	80000c32 <initlock>

  uartinit();
    80000454:	454000ef          	jal	800008a8 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000458:	00020797          	auipc	a5,0x20
    8000045c:	8c878793          	addi	a5,a5,-1848 # 8001fd20 <devsw>
    80000460:	00000717          	auipc	a4,0x0
    80000464:	d1870713          	addi	a4,a4,-744 # 80000178 <consoleread>
    80000468:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000046a:	00000717          	auipc	a4,0x0
    8000046e:	c6c70713          	addi	a4,a4,-916 # 800000d6 <consolewrite>
    80000472:	ef98                	sd	a4,24(a5)
}
    80000474:	60a2                	ld	ra,8(sp)
    80000476:	6402                	ld	s0,0(sp)
    80000478:	0141                	addi	sp,sp,16
    8000047a:	8082                	ret

000000008000047c <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    8000047c:	7139                	addi	sp,sp,-64
    8000047e:	fc06                	sd	ra,56(sp)
    80000480:	f822                	sd	s0,48(sp)
    80000482:	f04a                	sd	s2,32(sp)
    80000484:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    80000486:	c219                	beqz	a2,8000048c <printint+0x10>
    80000488:	08054063          	bltz	a0,80000508 <printint+0x8c>
    x = -xx;
  else
    x = xx;
    8000048c:	4301                	li	t1,0

  i = 0;
    8000048e:	fc840913          	addi	s2,s0,-56
    x = xx;
    80000492:	86ca                	mv	a3,s2
  i = 0;
    80000494:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80000496:	00007817          	auipc	a6,0x7
    8000049a:	37a80813          	addi	a6,a6,890 # 80007810 <digits>
    8000049e:	88ba                	mv	a7,a4
    800004a0:	0017061b          	addiw	a2,a4,1
    800004a4:	8732                	mv	a4,a2
    800004a6:	02b577b3          	remu	a5,a0,a1
    800004aa:	97c2                	add	a5,a5,a6
    800004ac:	0007c783          	lbu	a5,0(a5)
    800004b0:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    800004b4:	87aa                	mv	a5,a0
    800004b6:	02b55533          	divu	a0,a0,a1
    800004ba:	0685                	addi	a3,a3,1
    800004bc:	feb7f1e3          	bgeu	a5,a1,8000049e <printint+0x22>

  if (sign)
    800004c0:	00030b63          	beqz	t1,800004d6 <printint+0x5a>
    buf[i++] = '-';
    800004c4:	fe040793          	addi	a5,s0,-32
    800004c8:	963e                	add	a2,a2,a5
    800004ca:	02d00793          	li	a5,45
    800004ce:	fef60423          	sb	a5,-24(a2)
    800004d2:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    800004d6:	02e05463          	blez	a4,800004fe <printint+0x82>
    800004da:	f426                	sd	s1,40(sp)
    800004dc:	377d                	addiw	a4,a4,-1
    800004de:	00e904b3          	add	s1,s2,a4
    800004e2:	197d                	addi	s2,s2,-1
    800004e4:	993a                	add	s2,s2,a4
    800004e6:	1702                	slli	a4,a4,0x20
    800004e8:	9301                	srli	a4,a4,0x20
    800004ea:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004ee:	0004c503          	lbu	a0,0(s1)
    800004f2:	d99ff0ef          	jal	8000028a <consputc>
  while (--i >= 0)
    800004f6:	14fd                	addi	s1,s1,-1
    800004f8:	ff249be3          	bne	s1,s2,800004ee <printint+0x72>
    800004fc:	74a2                	ld	s1,40(sp)
}
    800004fe:	70e2                	ld	ra,56(sp)
    80000500:	7442                	ld	s0,48(sp)
    80000502:	7902                	ld	s2,32(sp)
    80000504:	6121                	addi	sp,sp,64
    80000506:	8082                	ret
    x = -xx;
    80000508:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    8000050c:	4305                	li	t1,1
    x = -xx;
    8000050e:	b741                	j	8000048e <printint+0x12>

0000000080000510 <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    80000510:	7131                	addi	sp,sp,-192
    80000512:	fc86                	sd	ra,120(sp)
    80000514:	f8a2                	sd	s0,112(sp)
    80000516:	f4a6                	sd	s1,104(sp)
    80000518:	0100                	addi	s0,sp,128
    8000051a:	84aa                	mv	s1,a0
    8000051c:	e40c                	sd	a1,8(s0)
    8000051e:	e810                	sd	a2,16(s0)
    80000520:	ec14                	sd	a3,24(s0)
    80000522:	f018                	sd	a4,32(s0)
    80000524:	f41c                	sd	a5,40(s0)
    80000526:	03043823          	sd	a6,48(s0)
    8000052a:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    8000052e:	00007797          	auipc	a5,0x7
    80000532:	4367a783          	lw	a5,1078(a5) # 80007964 <panicking>
    80000536:	cf9d                	beqz	a5,80000574 <printk+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000538:	00840793          	addi	a5,s0,8
    8000053c:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000540:	0004c503          	lbu	a0,0(s1)
    80000544:	22050363          	beqz	a0,8000076a <printk+0x25a>
    80000548:	f0ca                	sd	s2,96(sp)
    8000054a:	ecce                	sd	s3,88(sp)
    8000054c:	e8d2                	sd	s4,80(sp)
    8000054e:	e4d6                	sd	s5,72(sp)
    80000550:	e0da                	sd	s6,64(sp)
    80000552:	fc5e                	sd	s7,56(sp)
    80000554:	f862                	sd	s8,48(sp)
    80000556:	f06a                	sd	s10,32(sp)
    80000558:	ec6e                	sd	s11,24(sp)
    8000055a:	4a01                	li	s4,0
    if (cx != '%') {
    8000055c:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    80000560:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    80000564:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000568:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    8000056c:	4b29                	li	s6,10
    if (c0 == 'd') {
    8000056e:	06400b93          	li	s7,100
    80000572:	a015                	j	80000596 <printk+0x86>
    acquire(&pr.lock);
    80000574:	0000f517          	auipc	a0,0xf
    80000578:	4c450513          	addi	a0,a0,1220 # 8000fa38 <pr>
    8000057c:	736000ef          	jal	80000cb2 <acquire>
    80000580:	bf65                	j	80000538 <printk+0x28>
      consputc(cx);
    80000582:	d09ff0ef          	jal	8000028a <consputc>
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000586:	001a079b          	addiw	a5,s4,1
    8000058a:	8a3e                	mv	s4,a5
    8000058c:	97a6                	add	a5,a5,s1
    8000058e:	0007c503          	lbu	a0,0(a5)
    80000592:	1c050363          	beqz	a0,80000758 <printk+0x248>
    if (cx != '%') {
    80000596:	ff3516e3          	bne	a0,s3,80000582 <printk+0x72>
    i++;
    8000059a:	001a091b          	addiw	s2,s4,1
    c0 = fmt[i + 0] & 0xff;
    8000059e:	012487b3          	add	a5,s1,s2
    800005a2:	0007ca83          	lbu	s5,0(a5)
    if (c0)
    800005a6:	200a8763          	beqz	s5,800007b4 <printk+0x2a4>
      c1 = fmt[i + 1] & 0xff;
    800005aa:	0017c703          	lbu	a4,1(a5)
    if (c1)
    800005ae:	1e070a63          	beqz	a4,800007a2 <printk+0x292>
    if (c0 == 'd') {
    800005b2:	037a8963          	beq	s5,s7,800005e4 <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800005b6:	f94a8793          	addi	a5,s5,-108
    800005ba:	0017b793          	seqz	a5,a5
    800005be:	f9c70693          	addi	a3,a4,-100
    800005c2:	0016b693          	seqz	a3,a3
    800005c6:	8efd                	and	a3,a3,a5
    800005c8:	ca9d                	beqz	a3,800005fe <printk+0xee>
      printint(va_arg(ap, uint64), 10, 1);
    800005ca:	f8843783          	ld	a5,-120(s0)
    800005ce:	00878713          	addi	a4,a5,8
    800005d2:	f8e43423          	sd	a4,-120(s0)
    800005d6:	4605                	li	a2,1
    800005d8:	85da                	mv	a1,s6
    800005da:	6388                	ld	a0,0(a5)
    800005dc:	ea1ff0ef          	jal	8000047c <printint>
      i += 1;
    800005e0:	2a09                	addiw	s4,s4,2
    800005e2:	b755                	j	80000586 <printk+0x76>
      printint(va_arg(ap, int), 10, 1);
    800005e4:	f8843783          	ld	a5,-120(s0)
    800005e8:	00878713          	addi	a4,a5,8
    800005ec:	f8e43423          	sd	a4,-120(s0)
    800005f0:	4605                	li	a2,1
    800005f2:	85da                	mv	a1,s6
    800005f4:	4388                	lw	a0,0(a5)
    800005f6:	e87ff0ef          	jal	8000047c <printint>
    i++;
    800005fa:	8a4a                	mv	s4,s2
    800005fc:	b769                	j	80000586 <printk+0x76>
      c2 = fmt[i + 2] & 0xff;
    800005fe:	012486b3          	add	a3,s1,s2
    80000602:	863a                	mv	a2,a4
    80000604:	0026c703          	lbu	a4,2(a3)
    80000608:	aa65                	j	800007c0 <printk+0x2b0>
      printint(va_arg(ap, uint64), 10, 1);
    8000060a:	f8843783          	ld	a5,-120(s0)
    8000060e:	00878713          	addi	a4,a5,8
    80000612:	f8e43423          	sd	a4,-120(s0)
    80000616:	4605                	li	a2,1
    80000618:	45a9                	li	a1,10
    8000061a:	6388                	ld	a0,0(a5)
    8000061c:	e61ff0ef          	jal	8000047c <printint>
      i += 2;
    80000620:	2a0d                	addiw	s4,s4,3
    80000622:	b795                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint32), 10, 0);
    80000624:	f8843783          	ld	a5,-120(s0)
    80000628:	00878713          	addi	a4,a5,8
    8000062c:	f8e43423          	sd	a4,-120(s0)
    80000630:	4601                	li	a2,0
    80000632:	85da                	mv	a1,s6
    80000634:	0007e503          	lwu	a0,0(a5)
    80000638:	e45ff0ef          	jal	8000047c <printint>
    8000063c:	bf7d                	j	800005fa <printk+0xea>
      printint(va_arg(ap, uint64), 10, 0);
    8000063e:	f8843783          	ld	a5,-120(s0)
    80000642:	00878713          	addi	a4,a5,8
    80000646:	f8e43423          	sd	a4,-120(s0)
    8000064a:	4601                	li	a2,0
    8000064c:	85da                	mv	a1,s6
    8000064e:	6388                	ld	a0,0(a5)
    80000650:	e2dff0ef          	jal	8000047c <printint>
      i += 1;
    80000654:	2a09                	addiw	s4,s4,2
    80000656:	bf05                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint64), 10, 0);
    80000658:	f8843783          	ld	a5,-120(s0)
    8000065c:	00878713          	addi	a4,a5,8
    80000660:	f8e43423          	sd	a4,-120(s0)
    80000664:	4601                	li	a2,0
    80000666:	45a9                	li	a1,10
    80000668:	6388                	ld	a0,0(a5)
    8000066a:	e13ff0ef          	jal	8000047c <printint>
      i += 2;
    8000066e:	2a0d                	addiw	s4,s4,3
    80000670:	bf19                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint32), 16, 0);
    80000672:	f8843783          	ld	a5,-120(s0)
    80000676:	00878713          	addi	a4,a5,8
    8000067a:	f8e43423          	sd	a4,-120(s0)
    8000067e:	4601                	li	a2,0
    80000680:	45c1                	li	a1,16
    80000682:	0007e503          	lwu	a0,0(a5)
    80000686:	df7ff0ef          	jal	8000047c <printint>
    8000068a:	bf85                	j	800005fa <printk+0xea>
      printint(va_arg(ap, uint64), 16, 0);
    8000068c:	f8843783          	ld	a5,-120(s0)
    80000690:	00878713          	addi	a4,a5,8
    80000694:	f8e43423          	sd	a4,-120(s0)
    80000698:	4601                	li	a2,0
    8000069a:	45c1                	li	a1,16
    8000069c:	6388                	ld	a0,0(a5)
    8000069e:	ddfff0ef          	jal	8000047c <printint>
      i += 1;
    800006a2:	2a09                	addiw	s4,s4,2
    800006a4:	b5cd                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint64), 16, 0);
    800006a6:	f8843783          	ld	a5,-120(s0)
    800006aa:	00878713          	addi	a4,a5,8
    800006ae:	f8e43423          	sd	a4,-120(s0)
    800006b2:	45c1                	li	a1,16
    800006b4:	6388                	ld	a0,0(a5)
    800006b6:	dc7ff0ef          	jal	8000047c <printint>
      i += 2;
    800006ba:	2a0d                	addiw	s4,s4,3
    800006bc:	b5e9                	j	80000586 <printk+0x76>
    800006be:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006c0:	f8843783          	ld	a5,-120(s0)
    800006c4:	00878713          	addi	a4,a5,8
    800006c8:	f8e43423          	sd	a4,-120(s0)
    800006cc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006d0:	03000513          	li	a0,48
    800006d4:	bb7ff0ef          	jal	8000028a <consputc>
  consputc('x');
    800006d8:	07800513          	li	a0,120
    800006dc:	bafff0ef          	jal	8000028a <consputc>
    800006e0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006e2:	00007c97          	auipc	s9,0x7
    800006e6:	12ec8c93          	addi	s9,s9,302 # 80007810 <digits>
    800006ea:	03cad793          	srli	a5,s5,0x3c
    800006ee:	97e6                	add	a5,a5,s9
    800006f0:	0007c503          	lbu	a0,0(a5)
    800006f4:	b97ff0ef          	jal	8000028a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006f8:	0a92                	slli	s5,s5,0x4
    800006fa:	3a7d                	addiw	s4,s4,-1
    800006fc:	fe0a17e3          	bnez	s4,800006ea <printk+0x1da>
    80000700:	7ca2                	ld	s9,40(sp)
    80000702:	bde5                	j	800005fa <printk+0xea>
    } else if (c0 == 'c') {
      consputc(va_arg(ap, uint));
    80000704:	f8843783          	ld	a5,-120(s0)
    80000708:	00878713          	addi	a4,a5,8
    8000070c:	f8e43423          	sd	a4,-120(s0)
    80000710:	4388                	lw	a0,0(a5)
    80000712:	b79ff0ef          	jal	8000028a <consputc>
    80000716:	b5d5                	j	800005fa <printk+0xea>
    } else if (c0 == 's') {
      if ((s = va_arg(ap, char *)) == 0)
    80000718:	f8843783          	ld	a5,-120(s0)
    8000071c:	00878713          	addi	a4,a5,8
    80000720:	f8e43423          	sd	a4,-120(s0)
    80000724:	0007ba03          	ld	s4,0(a5)
    80000728:	000a0d63          	beqz	s4,80000742 <printk+0x232>
        s = "(null)";
      for (; *s; s++)
    8000072c:	000a4503          	lbu	a0,0(s4)
    80000730:	ec0505e3          	beqz	a0,800005fa <printk+0xea>
        consputc(*s);
    80000734:	b57ff0ef          	jal	8000028a <consputc>
      for (; *s; s++)
    80000738:	0a05                	addi	s4,s4,1
    8000073a:	000a4503          	lbu	a0,0(s4)
    8000073e:	f97d                	bnez	a0,80000734 <printk+0x224>
    80000740:	bd6d                	j	800005fa <printk+0xea>
        s = "(null)";
    80000742:	00007a17          	auipc	s4,0x7
    80000746:	8c6a0a13          	addi	s4,s4,-1850 # 80007008 <etext+0x8>
      for (; *s; s++)
    8000074a:	02800513          	li	a0,40
    8000074e:	b7dd                	j	80000734 <printk+0x224>
    } else if (c0 == '%') {
      consputc('%');
    80000750:	8556                	mv	a0,s5
    80000752:	b39ff0ef          	jal	8000028a <consputc>
    80000756:	b555                	j	800005fa <printk+0xea>
    80000758:	7906                	ld	s2,96(sp)
    8000075a:	69e6                	ld	s3,88(sp)
    8000075c:	6a46                	ld	s4,80(sp)
    8000075e:	6aa6                	ld	s5,72(sp)
    80000760:	6b06                	ld	s6,64(sp)
    80000762:	7be2                	ld	s7,56(sp)
    80000764:	7c42                	ld	s8,48(sp)
    80000766:	7d02                	ld	s10,32(sp)
    80000768:	6de2                	ld	s11,24(sp)
      consputc(c0);
    }
  }
  va_end(ap);

  if (panicking == 0)
    8000076a:	00007797          	auipc	a5,0x7
    8000076e:	1fa7a783          	lw	a5,506(a5) # 80007964 <panicking>
    80000772:	c38d                	beqz	a5,80000794 <printk+0x284>
    release(&pr.lock);

  return 0;
}
    80000774:	4501                	li	a0,0
    80000776:	70e6                	ld	ra,120(sp)
    80000778:	7446                	ld	s0,112(sp)
    8000077a:	74a6                	ld	s1,104(sp)
    8000077c:	6129                	addi	sp,sp,192
    8000077e:	8082                	ret
    80000780:	7906                	ld	s2,96(sp)
    80000782:	69e6                	ld	s3,88(sp)
    80000784:	6a46                	ld	s4,80(sp)
    80000786:	6aa6                	ld	s5,72(sp)
    80000788:	6b06                	ld	s6,64(sp)
    8000078a:	7be2                	ld	s7,56(sp)
    8000078c:	7c42                	ld	s8,48(sp)
    8000078e:	7d02                	ld	s10,32(sp)
    80000790:	6de2                	ld	s11,24(sp)
    80000792:	bfe1                	j	8000076a <printk+0x25a>
    release(&pr.lock);
    80000794:	0000f517          	auipc	a0,0xf
    80000798:	2a450513          	addi	a0,a0,676 # 8000fa38 <pr>
    8000079c:	59a000ef          	jal	80000d36 <release>
  return 0;
    800007a0:	bfd1                	j	80000774 <printk+0x264>
    if (c0 == 'd') {
    800007a2:	e57a81e3          	beq	s5,s7,800005e4 <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800007a6:	f94a8793          	addi	a5,s5,-108
    800007aa:	0017b793          	seqz	a5,a5
    800007ae:	863a                	mv	a2,a4
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007b0:	4681                	li	a3,0
    800007b2:	a01d                	j	800007d8 <printk+0x2c8>
    } else if (c0 == 'l' && c1 == 'd') {
    800007b4:	f94a8793          	addi	a5,s5,-108
    800007b8:	0017b793          	seqz	a5,a5
    c1 = c2 = 0;
    800007bc:	8656                	mv	a2,s5
    800007be:	8756                	mv	a4,s5
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007c0:	f9460693          	addi	a3,a2,-108
    800007c4:	0016b693          	seqz	a3,a3
    800007c8:	8efd                	and	a3,a3,a5
    800007ca:	f9c70593          	addi	a1,a4,-100
    800007ce:	0015b593          	seqz	a1,a1
    800007d2:	8df5                	and	a1,a1,a3
    800007d4:	e2059be3          	bnez	a1,8000060a <printk+0xfa>
    } else if (c0 == 'u') {
    800007d8:	e58a86e3          	beq	s5,s8,80000624 <printk+0x114>
    } else if (c0 == 'l' && c1 == 'u') {
    800007dc:	f8b60593          	addi	a1,a2,-117
    800007e0:	0015b593          	seqz	a1,a1
    800007e4:	8dfd                	and	a1,a1,a5
    800007e6:	e4059ce3          	bnez	a1,8000063e <printk+0x12e>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    800007ea:	f8b70593          	addi	a1,a4,-117
    800007ee:	0015b593          	seqz	a1,a1
    800007f2:	8df5                	and	a1,a1,a3
    800007f4:	e60592e3          	bnez	a1,80000658 <printk+0x148>
    } else if (c0 == 'x') {
    800007f8:	e7aa8de3          	beq	s5,s10,80000672 <printk+0x162>
    } else if (c0 == 'l' && c1 == 'x') {
    800007fc:	f8860613          	addi	a2,a2,-120
    80000800:	00163613          	seqz	a2,a2
    80000804:	8e7d                	and	a2,a2,a5
    80000806:	e80613e3          	bnez	a2,8000068c <printk+0x17c>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    8000080a:	f8870713          	addi	a4,a4,-120
    8000080e:	00173713          	seqz	a4,a4
    80000812:	8f75                	and	a4,a4,a3
    80000814:	e80719e3          	bnez	a4,800006a6 <printk+0x196>
    } else if (c0 == 'p') {
    80000818:	ebba83e3          	beq	s5,s11,800006be <printk+0x1ae>
    } else if (c0 == 'c') {
    8000081c:	06300793          	li	a5,99
    80000820:	eefa82e3          	beq	s5,a5,80000704 <printk+0x1f4>
    } else if (c0 == 's') {
    80000824:	07300793          	li	a5,115
    80000828:	eefa88e3          	beq	s5,a5,80000718 <printk+0x208>
    } else if (c0 == '%') {
    8000082c:	02500793          	li	a5,37
    80000830:	f2fa80e3          	beq	s5,a5,80000750 <printk+0x240>
    } else if (c0 == 0) {
    80000834:	f40a86e3          	beqz	s5,80000780 <printk+0x270>
      consputc('%');
    80000838:	02500513          	li	a0,37
    8000083c:	a4fff0ef          	jal	8000028a <consputc>
      consputc(c0);
    80000840:	8556                	mv	a0,s5
    80000842:	a49ff0ef          	jal	8000028a <consputc>
    80000846:	bb55                	j	800005fa <printk+0xea>

0000000080000848 <panic>:

void
panic(char *s)
{
    80000848:	1101                	addi	sp,sp,-32
    8000084a:	ec06                	sd	ra,24(sp)
    8000084c:	e822                	sd	s0,16(sp)
    8000084e:	e426                	sd	s1,8(sp)
    80000850:	e04a                	sd	s2,0(sp)
    80000852:	1000                	addi	s0,sp,32
    80000854:	892a                	mv	s2,a0
  panicking = 1;
    80000856:	4485                	li	s1,1
    80000858:	00007797          	auipc	a5,0x7
    8000085c:	1097a623          	sw	s1,268(a5) # 80007964 <panicking>
  printk("panic: ");
    80000860:	00006517          	auipc	a0,0x6
    80000864:	7b850513          	addi	a0,a0,1976 # 80007018 <etext+0x18>
    80000868:	ca9ff0ef          	jal	80000510 <printk>
  printk("%s\n", s);
    8000086c:	85ca                	mv	a1,s2
    8000086e:	00006517          	auipc	a0,0x6
    80000872:	7b250513          	addi	a0,a0,1970 # 80007020 <etext+0x20>
    80000876:	c9bff0ef          	jal	80000510 <printk>
  panicked = 1; // freeze uart output from other CPUs
    8000087a:	00007797          	auipc	a5,0x7
    8000087e:	0e97a323          	sw	s1,230(a5) # 80007960 <panicked>
  for (;;)
    80000882:	a001                	j	80000882 <panic+0x3a>

0000000080000884 <printkinit>:
    ;
}

void
printkinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    8000088c:	00006597          	auipc	a1,0x6
    80000890:	79c58593          	addi	a1,a1,1948 # 80007028 <etext+0x28>
    80000894:	0000f517          	auipc	a0,0xf
    80000898:	1a450513          	addi	a0,a0,420 # 8000fa38 <pr>
    8000089c:	396000ef          	jal	80000c32 <initlock>
}
    800008a0:	60a2                	ld	ra,8(sp)
    800008a2:	6402                	ld	s0,0(sp)
    800008a4:	0141                	addi	sp,sp,16
    800008a6:	8082                	ret

00000000800008a8 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    800008a8:	1141                	addi	sp,sp,-16
    800008aa:	e406                	sd	ra,8(sp)
    800008ac:	e022                	sd	s0,0(sp)
    800008ae:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800008b0:	100007b7          	lui	a5,0x10000
    800008b4:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800008b8:	10000737          	lui	a4,0x10000
    800008bc:	f8000693          	li	a3,-128
    800008c0:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008c4:	468d                	li	a3,3
    800008c6:	10000637          	lui	a2,0x10000
    800008ca:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008ce:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008d2:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008d6:	8732                	mv	a4,a2
    800008d8:	461d                	li	a2,7
    800008da:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008de:	00d780a3          	sb	a3,1(a5)

  initsleeplock(&tx_lock, "uart");
    800008e2:	00006597          	auipc	a1,0x6
    800008e6:	74e58593          	addi	a1,a1,1870 # 80007030 <etext+0x30>
    800008ea:	0000f517          	auipc	a0,0xf
    800008ee:	16650513          	addi	a0,a0,358 # 8000fa50 <tx_lock>
    800008f2:	081030ef          	jal	80004172 <initsleeplock>
}
    800008f6:	60a2                	ld	ra,8(sp)
    800008f8:	6402                	ld	s0,0(sp)
    800008fa:	0141                	addi	sp,sp,16
    800008fc:	8082                	ret

00000000800008fe <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008fe:	7139                	addi	sp,sp,-64
    80000900:	fc06                	sd	ra,56(sp)
    80000902:	f822                	sd	s0,48(sp)
    80000904:	f04a                	sd	s2,32(sp)
    80000906:	e456                	sd	s5,8(sp)
    80000908:	0080                	addi	s0,sp,64
    8000090a:	8aaa                	mv	s5,a0
    8000090c:	892e                	mv	s2,a1
  acquiresleep(&tx_lock);
    8000090e:	0000f517          	auipc	a0,0xf
    80000912:	14250513          	addi	a0,a0,322 # 8000fa50 <tx_lock>
    80000916:	093030ef          	jal	800041a8 <acquiresleep>

  int i = 0;
  while (i < n) {
    8000091a:	05205963          	blez	s2,8000096c <uartwrite+0x6e>
    8000091e:	f426                	sd	s1,40(sp)
    80000920:	ec4e                	sd	s3,24(sp)
    80000922:	e852                	sd	s4,16(sp)
    80000924:	e05a                	sd	s6,0(sp)
  int i = 0;
    80000926:	4481                	li	s1,0
    sleep_prepare(&tx_chan);
    80000928:	00007a17          	auipc	s4,0x7
    8000092c:	040a0a13          	addi	s4,s4,64 # 80007968 <tx_chan>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    80000930:	100009b7          	lui	s3,0x10000
    80000934:	0995                	addi	s3,s3,5 # 10000005 <_entry-0x6ffffffb>
      WriteReg(THR, buf[i]);
    80000936:	10000b37          	lui	s6,0x10000
    8000093a:	a029                	j	80000944 <uartwrite+0x46>
      i += 1;
    } else {
      sleep();
    8000093c:	7ca010ef          	jal	80002106 <sleep>
  while (i < n) {
    80000940:	0324d263          	bge	s1,s2,80000964 <uartwrite+0x66>
    sleep_prepare(&tx_chan);
    80000944:	8552                	mv	a0,s4
    80000946:	784010ef          	jal	800020ca <sleep_prepare>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    8000094a:	0009c783          	lbu	a5,0(s3)
    8000094e:	0207f793          	andi	a5,a5,32
    80000952:	d7ed                	beqz	a5,8000093c <uartwrite+0x3e>
      WriteReg(THR, buf[i]);
    80000954:	009a87b3          	add	a5,s5,s1
    80000958:	0007c783          	lbu	a5,0(a5)
    8000095c:	00fb0023          	sb	a5,0(s6) # 10000000 <_entry-0x70000000>
      i += 1;
    80000960:	2485                	addiw	s1,s1,1
    80000962:	bff9                	j	80000940 <uartwrite+0x42>
    80000964:	74a2                	ld	s1,40(sp)
    80000966:	69e2                	ld	s3,24(sp)
    80000968:	6a42                	ld	s4,16(sp)
    8000096a:	6b02                	ld	s6,0(sp)
    }
  }

  releasesleep(&tx_lock);
    8000096c:	0000f517          	auipc	a0,0xf
    80000970:	0e450513          	addi	a0,a0,228 # 8000fa50 <tx_lock>
    80000974:	089030ef          	jal	800041fc <releasesleep>
}
    80000978:	70e2                	ld	ra,56(sp)
    8000097a:	7442                	ld	s0,48(sp)
    8000097c:	7902                	ld	s2,32(sp)
    8000097e:	6aa2                	ld	s5,8(sp)
    80000980:	6121                	addi	sp,sp,64
    80000982:	8082                	ret

0000000080000984 <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000984:	1101                	addi	sp,sp,-32
    80000986:	ec06                	sd	ra,24(sp)
    80000988:	e822                	sd	s0,16(sp)
    8000098a:	e426                	sd	s1,8(sp)
    8000098c:	1000                	addi	s0,sp,32
    8000098e:	84aa                	mv	s1,a0
  if (panicking == 0)
    80000990:	00007797          	auipc	a5,0x7
    80000994:	fd47a783          	lw	a5,-44(a5) # 80007964 <panicking>
    80000998:	cb91                	beqz	a5,800009ac <uartputc_sync+0x28>
    push_off();

  if (panicked) {
    8000099a:	00007797          	auipc	a5,0x7
    8000099e:	fc67a783          	lw	a5,-58(a5) # 80007960 <panicked>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800009a2:	10000737          	lui	a4,0x10000
    800009a6:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
  if (panicked) {
    800009a8:	c789                	beqz	a5,800009b2 <uartputc_sync+0x2e>
    for (;;)
    800009aa:	a001                	j	800009aa <uartputc_sync+0x26>
    push_off();
    800009ac:	2cc000ef          	jal	80000c78 <push_off>
    800009b0:	b7ed                	j	8000099a <uartputc_sync+0x16>
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800009b2:	00074783          	lbu	a5,0(a4)
    800009b6:	0207f793          	andi	a5,a5,32
    800009ba:	dfe5                	beqz	a5,800009b2 <uartputc_sync+0x2e>
    ;
  WriteReg(THR, c);
    800009bc:	100007b7          	lui	a5,0x10000
    800009c0:	00978023          	sb	s1,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    800009c4:	00007797          	auipc	a5,0x7
    800009c8:	fa07a783          	lw	a5,-96(a5) # 80007964 <panicking>
    800009cc:	c791                	beqz	a5,800009d8 <uartputc_sync+0x54>
    pop_off();
}
    800009ce:	60e2                	ld	ra,24(sp)
    800009d0:	6442                	ld	s0,16(sp)
    800009d2:	64a2                	ld	s1,8(sp)
    800009d4:	6105                	addi	sp,sp,32
    800009d6:	8082                	ret
    pop_off();
    800009d8:	316000ef          	jal	80000cee <pop_off>
}
    800009dc:	bfcd                	j	800009ce <uartputc_sync+0x4a>

00000000800009de <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009de:	1101                	addi	sp,sp,-32
    800009e0:	ec06                	sd	ra,24(sp)
    800009e2:	e822                	sd	s0,16(sp)
    800009e4:	e426                	sd	s1,8(sp)
    800009e6:	e04a                	sd	s2,0(sp)
    800009e8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009ea:	100007b7          	lui	a5,0x10000
    800009ee:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009f2:	100007b7          	lui	a5,0x10000
    800009f6:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009fa:	0207f793          	andi	a5,a5,32
    800009fe:	ef99                	bnez	a5,80000a1c <uartintr+0x3e>
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a00:	100004b7          	lui	s1,0x10000
    80000a04:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    80000a06:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a0a:	0004c783          	lbu	a5,0(s1)
    80000a0e:	8b85                	andi	a5,a5,1
    80000a10:	cf89                	beqz	a5,80000a2a <uartintr+0x4c>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a12:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
    80000a16:	8a7ff0ef          	jal	800002bc <consoleintr>
  while (1) {
    80000a1a:	bfc5                	j	80000a0a <uartintr+0x2c>
    wakeup(&tx_chan);
    80000a1c:	00007517          	auipc	a0,0x7
    80000a20:	f4c50513          	addi	a0,a0,-180 # 80007968 <tx_chan>
    80000a24:	712010ef          	jal	80002136 <wakeup>
    80000a28:	bfe1                	j	80000a00 <uartintr+0x22>
  }
}
    80000a2a:	60e2                	ld	ra,24(sp)
    80000a2c:	6442                	ld	s0,16(sp)
    80000a2e:	64a2                	ld	s1,8(sp)
    80000a30:	6902                	ld	s2,0(sp)
    80000a32:	6105                	addi	sp,sp,32
    80000a34:	8082                	ret

0000000080000a36 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a36:	1101                	addi	sp,sp,-32
    80000a38:	ec06                	sd	ra,24(sp)
    80000a3a:	e822                	sd	s0,16(sp)
    80000a3c:	e426                	sd	s1,8(sp)
    80000a3e:	e04a                	sd	s2,0(sp)
    80000a40:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a42:	00020797          	auipc	a5,0x20
    80000a46:	47678793          	addi	a5,a5,1142 # 80020eb8 <end>
    80000a4a:	00f53733          	sltu	a4,a0,a5
    80000a4e:	47c5                	li	a5,17
    80000a50:	07ee                	slli	a5,a5,0x1b
    80000a52:	17fd                	addi	a5,a5,-1
    80000a54:	00a7b7b3          	sltu	a5,a5,a0
    80000a58:	8fd9                	or	a5,a5,a4
    80000a5a:	03451713          	slli	a4,a0,0x34
    80000a5e:	8fd9                	or	a5,a5,a4
    80000a60:	e3a1                	bnez	a5,80000aa0 <kfree+0x6a>
    80000a62:	84aa                	mv	s1,a0
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a64:	6605                	lui	a2,0x1
    80000a66:	4585                	li	a1,1
    80000a68:	306000ef          	jal	80000d6e <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a6c:	0000f917          	auipc	s2,0xf
    80000a70:	01490913          	addi	s2,s2,20 # 8000fa80 <kmem>
    80000a74:	854a                	mv	a0,s2
    80000a76:	23c000ef          	jal	80000cb2 <acquire>
  r->next = kmem.freelist;
    80000a7a:	01893783          	ld	a5,24(s2)
    80000a7e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a80:	00993c23          	sd	s1,24(s2)
  kmem.freed++;
    80000a84:	02492783          	lw	a5,36(s2)
    80000a88:	2785                	addiw	a5,a5,1
    80000a8a:	02f92223          	sw	a5,36(s2)
  release(&kmem.lock);
    80000a8e:	854a                	mv	a0,s2
    80000a90:	2a6000ef          	jal	80000d36 <release>
}
    80000a94:	60e2                	ld	ra,24(sp)
    80000a96:	6442                	ld	s0,16(sp)
    80000a98:	64a2                	ld	s1,8(sp)
    80000a9a:	6902                	ld	s2,0(sp)
    80000a9c:	6105                	addi	sp,sp,32
    80000a9e:	8082                	ret
    panic("kfree");
    80000aa0:	00006517          	auipc	a0,0x6
    80000aa4:	59850513          	addi	a0,a0,1432 # 80007038 <etext+0x38>
    80000aa8:	da1ff0ef          	jal	80000848 <panic>

0000000080000aac <freerange>:
{
    80000aac:	7179                	addi	sp,sp,-48
    80000aae:	f406                	sd	ra,40(sp)
    80000ab0:	f022                	sd	s0,32(sp)
    80000ab2:	ec26                	sd	s1,24(sp)
    80000ab4:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000ab6:	6785                	lui	a5,0x1
    80000ab8:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000abc:	00e504b3          	add	s1,a0,a4
    80000ac0:	777d                	lui	a4,0xfffff
    80000ac2:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ac4:	94be                	add	s1,s1,a5
    80000ac6:	0295e263          	bltu	a1,s1,80000aea <freerange+0x3e>
    80000aca:	e84a                	sd	s2,16(sp)
    80000acc:	e44e                	sd	s3,8(sp)
    80000ace:	e052                	sd	s4,0(sp)
    80000ad0:	892e                	mv	s2,a1
    kfree(p);
    80000ad2:	8a3a                	mv	s4,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ad4:	89be                	mv	s3,a5
    kfree(p);
    80000ad6:	01448533          	add	a0,s1,s4
    80000ada:	f5dff0ef          	jal	80000a36 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ade:	94ce                	add	s1,s1,s3
    80000ae0:	fe997be3          	bgeu	s2,s1,80000ad6 <freerange+0x2a>
    80000ae4:	6942                	ld	s2,16(sp)
    80000ae6:	69a2                	ld	s3,8(sp)
    80000ae8:	6a02                	ld	s4,0(sp)
}
    80000aea:	70a2                	ld	ra,40(sp)
    80000aec:	7402                	ld	s0,32(sp)
    80000aee:	64e2                	ld	s1,24(sp)
    80000af0:	6145                	addi	sp,sp,48
    80000af2:	8082                	ret

0000000080000af4 <kinit>:
{
    80000af4:	1101                	addi	sp,sp,-32
    80000af6:	ec06                	sd	ra,24(sp)
    80000af8:	e822                	sd	s0,16(sp)
    80000afa:	e426                	sd	s1,8(sp)
    80000afc:	1000                	addi	s0,sp,32
  initlock(&kmem.lock, "kmem");
    80000afe:	0000f497          	auipc	s1,0xf
    80000b02:	f8248493          	addi	s1,s1,-126 # 8000fa80 <kmem>
    80000b06:	00006597          	auipc	a1,0x6
    80000b0a:	53a58593          	addi	a1,a1,1338 # 80007040 <etext+0x40>
    80000b0e:	8526                	mv	a0,s1
    80000b10:	122000ef          	jal	80000c32 <initlock>
  freerange(end, (void *)PHYSTOP);
    80000b14:	45c5                	li	a1,17
    80000b16:	05ee                	slli	a1,a1,0x1b
    80000b18:	00020517          	auipc	a0,0x20
    80000b1c:	3a050513          	addi	a0,a0,928 # 80020eb8 <end>
    80000b20:	f8dff0ef          	jal	80000aac <freerange>
  acquire(&kmem.lock);
    80000b24:	8526                	mv	a0,s1
    80000b26:	18c000ef          	jal	80000cb2 <acquire>
  kmem.allocated = 0;
    80000b2a:	0204a023          	sw	zero,32(s1)
  kmem.freed = 0;
    80000b2e:	0204a223          	sw	zero,36(s1)
  release(&kmem.lock);
    80000b32:	8526                	mv	a0,s1
    80000b34:	202000ef          	jal	80000d36 <release>
}
    80000b38:	60e2                	ld	ra,24(sp)
    80000b3a:	6442                	ld	s0,16(sp)
    80000b3c:	64a2                	ld	s1,8(sp)
    80000b3e:	6105                	addi	sp,sp,32
    80000b40:	8082                	ret

0000000080000b42 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b42:	1101                	addi	sp,sp,-32
    80000b44:	ec06                	sd	ra,24(sp)
    80000b46:	e822                	sd	s0,16(sp)
    80000b48:	e426                	sd	s1,8(sp)
    80000b4a:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b4c:	0000f517          	auipc	a0,0xf
    80000b50:	f3450513          	addi	a0,a0,-204 # 8000fa80 <kmem>
    80000b54:	15e000ef          	jal	80000cb2 <acquire>
  r = kmem.freelist;
    80000b58:	0000f497          	auipc	s1,0xf
    80000b5c:	f404b483          	ld	s1,-192(s1) # 8000fa98 <kmem+0x18>
  if (r) {
    80000b60:	c885                	beqz	s1,80000b90 <kalloc+0x4e>
    kmem.freelist = r->next;
    80000b62:	6098                	ld	a4,0(s1)
    80000b64:	0000f797          	auipc	a5,0xf
    80000b68:	f1c78793          	addi	a5,a5,-228 # 8000fa80 <kmem>
    80000b6c:	ef98                	sd	a4,24(a5)
    kmem.allocated++;
    80000b6e:	5398                	lw	a4,32(a5)
    80000b70:	2705                	addiw	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffde149>
    80000b72:	d398                	sw	a4,32(a5)
  }
  release(&kmem.lock);
    80000b74:	853e                	mv	a0,a5
    80000b76:	1c0000ef          	jal	80000d36 <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000b7a:	6605                	lui	a2,0x1
    80000b7c:	4595                	li	a1,5
    80000b7e:	8526                	mv	a0,s1
    80000b80:	1ee000ef          	jal	80000d6e <memset>
  return (void *)r;
}
    80000b84:	8526                	mv	a0,s1
    80000b86:	60e2                	ld	ra,24(sp)
    80000b88:	6442                	ld	s0,16(sp)
    80000b8a:	64a2                	ld	s1,8(sp)
    80000b8c:	6105                	addi	sp,sp,32
    80000b8e:	8082                	ret
  release(&kmem.lock);
    80000b90:	0000f517          	auipc	a0,0xf
    80000b94:	ef050513          	addi	a0,a0,-272 # 8000fa80 <kmem>
    80000b98:	19e000ef          	jal	80000d36 <release>
  if (r)
    80000b9c:	b7e5                	j	80000b84 <kalloc+0x42>

0000000080000b9e <memstats>:

 
// Display physical memory allocation statistics.
void
memstats(void)
{
    80000b9e:	7179                	addi	sp,sp,-48
    80000ba0:	f406                	sd	ra,40(sp)
    80000ba2:	f022                	sd	s0,32(sp)
    80000ba4:	ec26                	sd	s1,24(sp)
    80000ba6:	e84a                	sd	s2,16(sp)
    80000ba8:	e44e                	sd	s3,8(sp)
    80000baa:	1800                	addi	s0,sp,48
  struct run *r;
  int allocated, freed, available = 0;

  acquire(&kmem.lock);
    80000bac:	0000f497          	auipc	s1,0xf
    80000bb0:	ed448493          	addi	s1,s1,-300 # 8000fa80 <kmem>
    80000bb4:	8526                	mv	a0,s1
    80000bb6:	0fc000ef          	jal	80000cb2 <acquire>

  allocated = kmem.allocated;
    80000bba:	0204a983          	lw	s3,32(s1)
  freed = kmem.freed;
    80000bbe:	0244a903          	lw	s2,36(s1)

  for (r = kmem.freelist; r; r = r->next)
    80000bc2:	6c9c                	ld	a5,24(s1)
    80000bc4:	c7ad                	beqz	a5,80000c2e <memstats+0x90>
  int allocated, freed, available = 0;
    80000bc6:	4481                	li	s1,0
    available++;
    80000bc8:	2485                	addiw	s1,s1,1
  for (r = kmem.freelist; r; r = r->next)
    80000bca:	639c                	ld	a5,0(a5)
    80000bcc:	fff5                	bnez	a5,80000bc8 <memstats+0x2a>

  release(&kmem.lock);
    80000bce:	0000f517          	auipc	a0,0xf
    80000bd2:	eb250513          	addi	a0,a0,-334 # 8000fa80 <kmem>
    80000bd6:	160000ef          	jal	80000d36 <release>

  printk("\\nMemory Statistics:\\n");
    80000bda:	00006517          	auipc	a0,0x6
    80000bde:	46e50513          	addi	a0,a0,1134 # 80007048 <etext+0x48>
    80000be2:	92fff0ef          	jal	80000510 <printk>
  printk("Total allocated pages: %d\\n", allocated);
    80000be6:	85ce                	mv	a1,s3
    80000be8:	00006517          	auipc	a0,0x6
    80000bec:	47850513          	addi	a0,a0,1144 # 80007060 <etext+0x60>
    80000bf0:	921ff0ef          	jal	80000510 <printk>
  printk("Total freed pages: %d\\n", freed);
    80000bf4:	85ca                	mv	a1,s2
    80000bf6:	00006517          	auipc	a0,0x6
    80000bfa:	48a50513          	addi	a0,a0,1162 # 80007080 <etext+0x80>
    80000bfe:	913ff0ef          	jal	80000510 <printk>
  printk("Currently allocated pages: %d\\n", allocated - freed);
    80000c02:	412985bb          	subw	a1,s3,s2
    80000c06:	00006517          	auipc	a0,0x6
    80000c0a:	49250513          	addi	a0,a0,1170 # 80007098 <etext+0x98>
    80000c0e:	903ff0ef          	jal	80000510 <printk>
  printk("Available physical pages: %d\\n", available);
    80000c12:	85a6                	mv	a1,s1
    80000c14:	00006517          	auipc	a0,0x6
    80000c18:	4a450513          	addi	a0,a0,1188 # 800070b8 <etext+0xb8>
    80000c1c:	8f5ff0ef          	jal	80000510 <printk>
}
    80000c20:	70a2                	ld	ra,40(sp)
    80000c22:	7402                	ld	s0,32(sp)
    80000c24:	64e2                	ld	s1,24(sp)
    80000c26:	6942                	ld	s2,16(sp)
    80000c28:	69a2                	ld	s3,8(sp)
    80000c2a:	6145                	addi	sp,sp,48
    80000c2c:	8082                	ret
  int allocated, freed, available = 0;
    80000c2e:	4481                	li	s1,0
    80000c30:	bf79                	j	80000bce <memstats+0x30>

0000000080000c32 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000c32:	1141                	addi	sp,sp,-16
    80000c34:	e406                	sd	ra,8(sp)
    80000c36:	e022                	sd	s0,0(sp)
    80000c38:	0800                	addi	s0,sp,16
  lk->name = name;
    80000c3a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000c3c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000c40:	00053823          	sd	zero,16(a0)
}
    80000c44:	60a2                	ld	ra,8(sp)
    80000c46:	6402                	ld	s0,0(sp)
    80000c48:	0141                	addi	sp,sp,16
    80000c4a:	8082                	ret

0000000080000c4c <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000c4c:	411c                	lw	a5,0(a0)
    80000c4e:	e399                	bnez	a5,80000c54 <holding+0x8>
    80000c50:	4501                	li	a0,0
  return r;
}
    80000c52:	8082                	ret
{
    80000c54:	1101                	addi	sp,sp,-32
    80000c56:	ec06                	sd	ra,24(sp)
    80000c58:	e822                	sd	s0,16(sp)
    80000c5a:	e426                	sd	s1,8(sp)
    80000c5c:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000c5e:	691c                	ld	a5,16(a0)
    80000c60:	84be                	mv	s1,a5
    80000c62:	603000ef          	jal	80001a64 <mycpu>
    80000c66:	40a48533          	sub	a0,s1,a0
    80000c6a:	00153513          	seqz	a0,a0
}
    80000c6e:	60e2                	ld	ra,24(sp)
    80000c70:	6442                	ld	s0,16(sp)
    80000c72:	64a2                	ld	s1,8(sp)
    80000c74:	6105                	addi	sp,sp,32
    80000c76:	8082                	ret

0000000080000c78 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000c78:	1101                	addi	sp,sp,-32
    80000c7a:	ec06                	sd	ra,24(sp)
    80000c7c:	e822                	sd	s0,16(sp)
    80000c7e:	e426                	sd	s1,8(sp)
    80000c80:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000c82:	100177f3          	csrrci	a5,sstatus,2
    80000c86:	84be                	mv	s1,a5
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000c88:	5dd000ef          	jal	80001a64 <mycpu>
    80000c8c:	5d3c                	lw	a5,120(a0)
    80000c8e:	cb99                	beqz	a5,80000ca4 <push_off+0x2c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c90:	5d5000ef          	jal	80001a64 <mycpu>
    80000c94:	5d3c                	lw	a5,120(a0)
    80000c96:	2785                	addiw	a5,a5,1
    80000c98:	dd3c                	sw	a5,120(a0)
}
    80000c9a:	60e2                	ld	ra,24(sp)
    80000c9c:	6442                	ld	s0,16(sp)
    80000c9e:	64a2                	ld	s1,8(sp)
    80000ca0:	6105                	addi	sp,sp,32
    80000ca2:	8082                	ret
    mycpu()->intena = old;
    80000ca4:	5c1000ef          	jal	80001a64 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000ca8:	0014d793          	srli	a5,s1,0x1
    80000cac:	8b85                	andi	a5,a5,1
    mycpu()->intena = old;
    80000cae:	dd7c                	sw	a5,124(a0)
    80000cb0:	b7c5                	j	80000c90 <push_off+0x18>

0000000080000cb2 <acquire>:
{
    80000cb2:	1101                	addi	sp,sp,-32
    80000cb4:	ec06                	sd	ra,24(sp)
    80000cb6:	e822                	sd	s0,16(sp)
    80000cb8:	e426                	sd	s1,8(sp)
    80000cba:	1000                	addi	s0,sp,32
    80000cbc:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000cbe:	fbbff0ef          	jal	80000c78 <push_off>
  if (holding(lk))
    80000cc2:	8526                	mv	a0,s1
    80000cc4:	f89ff0ef          	jal	80000c4c <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000cc8:	4705                	li	a4,1
  if (holding(lk))
    80000cca:	ed01                	bnez	a0,80000ce2 <acquire+0x30>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000ccc:	0ce4a7af          	amoswap.w.aq	a5,a4,(s1)
    80000cd0:	fff5                	bnez	a5,80000ccc <acquire+0x1a>
  lk->cpu = mycpu();
    80000cd2:	593000ef          	jal	80001a64 <mycpu>
    80000cd6:	e888                	sd	a0,16(s1)
}
    80000cd8:	60e2                	ld	ra,24(sp)
    80000cda:	6442                	ld	s0,16(sp)
    80000cdc:	64a2                	ld	s1,8(sp)
    80000cde:	6105                	addi	sp,sp,32
    80000ce0:	8082                	ret
    panic("acquire");
    80000ce2:	00006517          	auipc	a0,0x6
    80000ce6:	3f650513          	addi	a0,a0,1014 # 800070d8 <etext+0xd8>
    80000cea:	b5fff0ef          	jal	80000848 <panic>

0000000080000cee <pop_off>:

void
pop_off(void)
{
    80000cee:	1141                	addi	sp,sp,-16
    80000cf0:	e406                	sd	ra,8(sp)
    80000cf2:	e022                	sd	s0,0(sp)
    80000cf4:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000cf6:	56f000ef          	jal	80001a64 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000cfa:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000cfe:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000d00:	ef99                	bnez	a5,80000d1e <pop_off+0x30>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000d02:	5d3c                	lw	a5,120(a0)
    80000d04:	02f05363          	blez	a5,80000d2a <pop_off+0x3c>
    panic("pop_off");
  c->noff -= 1;
    80000d08:	37fd                	addiw	a5,a5,-1
    80000d0a:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000d0c:	e789                	bnez	a5,80000d16 <pop_off+0x28>
    80000d0e:	5d7c                	lw	a5,124(a0)
    80000d10:	c399                	beqz	a5,80000d16 <pop_off+0x28>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000d12:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000d16:	60a2                	ld	ra,8(sp)
    80000d18:	6402                	ld	s0,0(sp)
    80000d1a:	0141                	addi	sp,sp,16
    80000d1c:	8082                	ret
    panic("pop_off - interruptible");
    80000d1e:	00006517          	auipc	a0,0x6
    80000d22:	3c250513          	addi	a0,a0,962 # 800070e0 <etext+0xe0>
    80000d26:	b23ff0ef          	jal	80000848 <panic>
    panic("pop_off");
    80000d2a:	00006517          	auipc	a0,0x6
    80000d2e:	3ce50513          	addi	a0,a0,974 # 800070f8 <etext+0xf8>
    80000d32:	b17ff0ef          	jal	80000848 <panic>

0000000080000d36 <release>:
{
    80000d36:	1101                	addi	sp,sp,-32
    80000d38:	ec06                	sd	ra,24(sp)
    80000d3a:	e822                	sd	s0,16(sp)
    80000d3c:	e426                	sd	s1,8(sp)
    80000d3e:	1000                	addi	s0,sp,32
    80000d40:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000d42:	f0bff0ef          	jal	80000c4c <holding>
    80000d46:	cd11                	beqz	a0,80000d62 <release+0x2c>
  lk->cpu = 0;
    80000d48:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000d4c:	0310000f          	fence	rw,w
    80000d50:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000d54:	f9bff0ef          	jal	80000cee <pop_off>
}
    80000d58:	60e2                	ld	ra,24(sp)
    80000d5a:	6442                	ld	s0,16(sp)
    80000d5c:	64a2                	ld	s1,8(sp)
    80000d5e:	6105                	addi	sp,sp,32
    80000d60:	8082                	ret
    panic("release");
    80000d62:	00006517          	auipc	a0,0x6
    80000d66:	39e50513          	addi	a0,a0,926 # 80007100 <etext+0x100>
    80000d6a:	adfff0ef          	jal	80000848 <panic>

0000000080000d6e <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000d6e:	1141                	addi	sp,sp,-16
    80000d70:	e406                	sd	ra,8(sp)
    80000d72:	e022                	sd	s0,0(sp)
    80000d74:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000d76:	ca19                	beqz	a2,80000d8c <memset+0x1e>
    80000d78:	87aa                	mv	a5,a0
    80000d7a:	1602                	slli	a2,a2,0x20
    80000d7c:	9201                	srli	a2,a2,0x20
    80000d7e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d82:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000d86:	0785                	addi	a5,a5,1
    80000d88:	fee79de3          	bne	a5,a4,80000d82 <memset+0x14>
  }
  return dst;
}
    80000d8c:	60a2                	ld	ra,8(sp)
    80000d8e:	6402                	ld	s0,0(sp)
    80000d90:	0141                	addi	sp,sp,16
    80000d92:	8082                	ret

0000000080000d94 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d94:	1141                	addi	sp,sp,-16
    80000d96:	e406                	sd	ra,8(sp)
    80000d98:	e022                	sd	s0,0(sp)
    80000d9a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000d9c:	ce19                	beqz	a2,80000dba <memcmp+0x26>
    80000d9e:	1602                	slli	a2,a2,0x20
    80000da0:	9201                	srli	a2,a2,0x20
    80000da2:	00c506b3          	add	a3,a0,a2
    if (*s1 != *s2)
    80000da6:	00054783          	lbu	a5,0(a0)
    80000daa:	0005c703          	lbu	a4,0(a1)
    80000dae:	00e79b63          	bne	a5,a4,80000dc4 <memcmp+0x30>
      return *s1 - *s2;
    s1++, s2++;
    80000db2:	0505                	addi	a0,a0,1
    80000db4:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000db6:	fed518e3          	bne	a0,a3,80000da6 <memcmp+0x12>
  }

  return 0;
    80000dba:	4501                	li	a0,0
}
    80000dbc:	60a2                	ld	ra,8(sp)
    80000dbe:	6402                	ld	s0,0(sp)
    80000dc0:	0141                	addi	sp,sp,16
    80000dc2:	8082                	ret
      return *s1 - *s2;
    80000dc4:	40e7853b          	subw	a0,a5,a4
    80000dc8:	bfd5                	j	80000dbc <memcmp+0x28>

0000000080000dca <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000dca:	1141                	addi	sp,sp,-16
    80000dcc:	e406                	sd	ra,8(sp)
    80000dce:	e022                	sd	s0,0(sp)
    80000dd0:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000dd2:	c61d                	beqz	a2,80000e00 <memmove+0x36>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000dd4:	00a5f963          	bgeu	a1,a0,80000de6 <memmove+0x1c>
    80000dd8:	02061693          	slli	a3,a2,0x20
    80000ddc:	9281                	srli	a3,a3,0x20
    80000dde:	00d58733          	add	a4,a1,a3
    80000de2:	02e56363          	bltu	a0,a4,80000e08 <memmove+0x3e>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000de6:	1602                	slli	a2,a2,0x20
    80000de8:	9201                	srli	a2,a2,0x20
    80000dea:	00c587b3          	add	a5,a1,a2
{
    80000dee:	872a                	mv	a4,a0
      *d++ = *s++;
    80000df0:	0585                	addi	a1,a1,1
    80000df2:	0705                	addi	a4,a4,1
    80000df4:	fff5c683          	lbu	a3,-1(a1)
    80000df8:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000dfc:	fef59ae3          	bne	a1,a5,80000df0 <memmove+0x26>

  return dst;
}
    80000e00:	60a2                	ld	ra,8(sp)
    80000e02:	6402                	ld	s0,0(sp)
    80000e04:	0141                	addi	sp,sp,16
    80000e06:	8082                	ret
    d += n;
    80000e08:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000e0a:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000e0e:	1782                	slli	a5,a5,0x20
    80000e10:	9381                	srli	a5,a5,0x20
    80000e12:	fff7c793          	not	a5,a5
    80000e16:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000e18:	177d                	addi	a4,a4,-1
    80000e1a:	16fd                	addi	a3,a3,-1
    80000e1c:	00074603          	lbu	a2,0(a4)
    80000e20:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000e24:	fee79ae3          	bne	a5,a4,80000e18 <memmove+0x4e>
    80000e28:	bfe1                	j	80000e00 <memmove+0x36>

0000000080000e2a <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000e2a:	1141                	addi	sp,sp,-16
    80000e2c:	e406                	sd	ra,8(sp)
    80000e2e:	e022                	sd	s0,0(sp)
    80000e30:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000e32:	f99ff0ef          	jal	80000dca <memmove>
}
    80000e36:	60a2                	ld	ra,8(sp)
    80000e38:	6402                	ld	s0,0(sp)
    80000e3a:	0141                	addi	sp,sp,16
    80000e3c:	8082                	ret

0000000080000e3e <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000e3e:	1141                	addi	sp,sp,-16
    80000e40:	e406                	sd	ra,8(sp)
    80000e42:	e022                	sd	s0,0(sp)
    80000e44:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000e46:	ce01                	beqz	a2,80000e5e <strncmp+0x20>
    80000e48:	00054783          	lbu	a5,0(a0)
    80000e4c:	cb99                	beqz	a5,80000e62 <strncmp+0x24>
    80000e4e:	0005c703          	lbu	a4,0(a1)
    80000e52:	00f71863          	bne	a4,a5,80000e62 <strncmp+0x24>
    n--, p++, q++;
    80000e56:	367d                	addiw	a2,a2,-1
    80000e58:	0505                	addi	a0,a0,1
    80000e5a:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000e5c:	f675                	bnez	a2,80000e48 <strncmp+0xa>
  if (n == 0)
    return 0;
    80000e5e:	4501                	li	a0,0
    80000e60:	a031                	j	80000e6c <strncmp+0x2e>
  return (uchar)*p - (uchar)*q;
    80000e62:	00054503          	lbu	a0,0(a0)
    80000e66:	0005c783          	lbu	a5,0(a1)
    80000e6a:	9d1d                	subw	a0,a0,a5
}
    80000e6c:	60a2                	ld	ra,8(sp)
    80000e6e:	6402                	ld	s0,0(sp)
    80000e70:	0141                	addi	sp,sp,16
    80000e72:	8082                	ret

0000000080000e74 <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000e74:	1141                	addi	sp,sp,-16
    80000e76:	e406                	sd	ra,8(sp)
    80000e78:	e022                	sd	s0,0(sp)
    80000e7a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000e7c:	87aa                	mv	a5,a0
    80000e7e:	a011                	j	80000e82 <strncpy+0xe>
    80000e80:	8636                	mv	a2,a3
    80000e82:	02c05763          	blez	a2,80000eb0 <strncpy+0x3c>
    80000e86:	fff6069b          	addiw	a3,a2,-1
    80000e8a:	0785                	addi	a5,a5,1
    80000e8c:	0005c703          	lbu	a4,0(a1)
    80000e90:	fee78fa3          	sb	a4,-1(a5)
    80000e94:	0585                	addi	a1,a1,1
    80000e96:	f76d                	bnez	a4,80000e80 <strncpy+0xc>
    ;
  while (n-- > 0)
    80000e98:	873e                	mv	a4,a5
    80000e9a:	00d05b63          	blez	a3,80000eb0 <strncpy+0x3c>
    80000e9e:	9fb1                	addw	a5,a5,a2
    80000ea0:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000ea2:	0705                	addi	a4,a4,1
    80000ea4:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000ea8:	40e786bb          	subw	a3,a5,a4
    80000eac:	fed04be3          	bgtz	a3,80000ea2 <strncpy+0x2e>
  return os;
}
    80000eb0:	60a2                	ld	ra,8(sp)
    80000eb2:	6402                	ld	s0,0(sp)
    80000eb4:	0141                	addi	sp,sp,16
    80000eb6:	8082                	ret

0000000080000eb8 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000eb8:	1141                	addi	sp,sp,-16
    80000eba:	e406                	sd	ra,8(sp)
    80000ebc:	e022                	sd	s0,0(sp)
    80000ebe:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000ec0:	02c05363          	blez	a2,80000ee6 <safestrcpy+0x2e>
    80000ec4:	fff6069b          	addiw	a3,a2,-1
    80000ec8:	1682                	slli	a3,a3,0x20
    80000eca:	9281                	srli	a3,a3,0x20
    80000ecc:	96ae                	add	a3,a3,a1
    80000ece:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000ed0:	00d58963          	beq	a1,a3,80000ee2 <safestrcpy+0x2a>
    80000ed4:	0585                	addi	a1,a1,1
    80000ed6:	0785                	addi	a5,a5,1
    80000ed8:	fff5c703          	lbu	a4,-1(a1)
    80000edc:	fee78fa3          	sb	a4,-1(a5)
    80000ee0:	fb65                	bnez	a4,80000ed0 <safestrcpy+0x18>
    ;
  *s = 0;
    80000ee2:	00078023          	sb	zero,0(a5)
  return os;
}
    80000ee6:	60a2                	ld	ra,8(sp)
    80000ee8:	6402                	ld	s0,0(sp)
    80000eea:	0141                	addi	sp,sp,16
    80000eec:	8082                	ret

0000000080000eee <strlen>:

int
strlen(const char *s)
{
    80000eee:	1141                	addi	sp,sp,-16
    80000ef0:	e406                	sd	ra,8(sp)
    80000ef2:	e022                	sd	s0,0(sp)
    80000ef4:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000ef6:	00054783          	lbu	a5,0(a0)
    80000efa:	cf91                	beqz	a5,80000f16 <strlen+0x28>
    80000efc:	00150793          	addi	a5,a0,1
    80000f00:	86be                	mv	a3,a5
    80000f02:	0785                	addi	a5,a5,1
    80000f04:	fff7c703          	lbu	a4,-1(a5)
    80000f08:	ff65                	bnez	a4,80000f00 <strlen+0x12>
    80000f0a:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000f0e:	60a2                	ld	ra,8(sp)
    80000f10:	6402                	ld	s0,0(sp)
    80000f12:	0141                	addi	sp,sp,16
    80000f14:	8082                	ret
  for (n = 0; s[n]; n++)
    80000f16:	4501                	li	a0,0
    80000f18:	bfdd                	j	80000f0e <strlen+0x20>

0000000080000f1a <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000f1a:	1141                	addi	sp,sp,-16
    80000f1c:	e406                	sd	ra,8(sp)
    80000f1e:	e022                	sd	s0,0(sp)
    80000f20:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000f22:	32f000ef          	jal	80001a50 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000f26:	00007717          	auipc	a4,0x7
    80000f2a:	a4670713          	addi	a4,a4,-1466 # 8000796c <started>
  if (cpuid() == 0) {
    80000f2e:	c51d                	beqz	a0,80000f5c <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000f30:	431c                	lw	a5,0(a4)
    80000f32:	0230000f          	fence	r,rw
    80000f36:	2781                	sext.w	a5,a5
    80000f38:	dfe5                	beqz	a5,80000f30 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000f3a:	317000ef          	jal	80001a50 <cpuid>
    80000f3e:	85aa                	mv	a1,a0
    80000f40:	00006517          	auipc	a0,0x6
    80000f44:	1e850513          	addi	a0,a0,488 # 80007128 <etext+0x128>
    80000f48:	dc8ff0ef          	jal	80000510 <printk>
    kvminithart();  // turn on paging
    80000f4c:	082000ef          	jal	80000fce <kvminithart>
    trapinithart(); // install kernel trap vector
    80000f50:	6ca010ef          	jal	8000261a <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000f54:	7f4040ef          	jal	80005748 <plicinithart>
  }

  scheduler();
    80000f58:	7c3000ef          	jal	80001f1a <scheduler>
    consoleinit();
    80000f5c:	cdcff0ef          	jal	80000438 <consoleinit>
    printkinit();
    80000f60:	925ff0ef          	jal	80000884 <printkinit>
    printk("\n");
    80000f64:	00006517          	auipc	a0,0x6
    80000f68:	1a450513          	addi	a0,a0,420 # 80007108 <etext+0x108>
    80000f6c:	da4ff0ef          	jal	80000510 <printk>
    printk("xv6 kernel is booting\n");
    80000f70:	00006517          	auipc	a0,0x6
    80000f74:	1a050513          	addi	a0,a0,416 # 80007110 <etext+0x110>
    80000f78:	d98ff0ef          	jal	80000510 <printk>
    printk("\n");
    80000f7c:	00006517          	auipc	a0,0x6
    80000f80:	18c50513          	addi	a0,a0,396 # 80007108 <etext+0x108>
    80000f84:	d8cff0ef          	jal	80000510 <printk>
    kinit();            // physical page allocator
    80000f88:	b6dff0ef          	jal	80000af4 <kinit>
    kvminit();          // create kernel page table
    80000f8c:	2c2000ef          	jal	8000124e <kvminit>
    kvminithart();      // turn on paging
    80000f90:	03e000ef          	jal	80000fce <kvminithart>
    procinit();         // process table
    80000f94:	205000ef          	jal	80001998 <procinit>
    trapinit();         // trap vectors
    80000f98:	65e010ef          	jal	800025f6 <trapinit>
    trapinithart();     // install kernel trap vector
    80000f9c:	67e010ef          	jal	8000261a <trapinithart>
    plicinit();         // set up interrupt controller
    80000fa0:	78e040ef          	jal	8000572e <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000fa4:	7a4040ef          	jal	80005748 <plicinithart>
    binit();            // buffer cache
    80000fa8:	599010ef          	jal	80002d40 <binit>
    iinit();            // inode table
    80000fac:	2f2020ef          	jal	8000329e <iinit>
    fileinit();         // file table
    80000fb0:	2ce030ef          	jal	8000427e <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000fb4:	085040ef          	jal	80005838 <virtio_disk_init>
    userinit();         // first user process
    80000fb8:	5c1000ef          	jal	80001d78 <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000fbc:	00007797          	auipc	a5,0x7
    80000fc0:	9b078793          	addi	a5,a5,-1616 # 8000796c <started>
    80000fc4:	4705                	li	a4,1
    80000fc6:	0310000f          	fence	rw,w
    80000fca:	c398                	sw	a4,0(a5)
    80000fcc:	b771                	j	80000f58 <main+0x3e>

0000000080000fce <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000fce:	1141                	addi	sp,sp,-16
    80000fd0:	e406                	sd	ra,8(sp)
    80000fd2:	e022                	sd	s0,0(sp)
    80000fd4:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000fd6:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000fda:	00007797          	auipc	a5,0x7
    80000fde:	9967b783          	ld	a5,-1642(a5) # 80007970 <kernel_pagetable>
    80000fe2:	83b1                	srli	a5,a5,0xc
    80000fe4:	577d                	li	a4,-1
    80000fe6:	177e                	slli	a4,a4,0x3f
    80000fe8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000fea:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000fee:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000ff2:	60a2                	ld	ra,8(sp)
    80000ff4:	6402                	ld	s0,0(sp)
    80000ff6:	0141                	addi	sp,sp,16
    80000ff8:	8082                	ret

0000000080000ffa <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000ffa:	7139                	addi	sp,sp,-64
    80000ffc:	fc06                	sd	ra,56(sp)
    80000ffe:	f822                	sd	s0,48(sp)
    80001000:	f426                	sd	s1,40(sp)
    80001002:	f04a                	sd	s2,32(sp)
    80001004:	ec4e                	sd	s3,24(sp)
    80001006:	e852                	sd	s4,16(sp)
    80001008:	e456                	sd	s5,8(sp)
    8000100a:	e05a                	sd	s6,0(sp)
    8000100c:	0080                	addi	s0,sp,64
    8000100e:	84aa                	mv	s1,a0
    80001010:	89ae                	mv	s3,a1
    80001012:	8b32                	mv	s6,a2
  if (va >= MAXVA)
    80001014:	57fd                	li	a5,-1
    80001016:	83e9                	srli	a5,a5,0x1a
    80001018:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    8000101a:	4ab1                	li	s5,12
  if (va >= MAXVA)
    8000101c:	06b7e363          	bltu	a5,a1,80001082 <walk+0x88>
    pte_t *pte = &pagetable[PX(level, va)];
    80001020:	0149d933          	srl	s2,s3,s4
    80001024:	1ff97913          	andi	s2,s2,511
    80001028:	090e                	slli	s2,s2,0x3
    8000102a:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    8000102c:	00093483          	ld	s1,0(s2)
    80001030:	0014f793          	andi	a5,s1,1
      pagetable = (pagetable_t)PTE2PA(*pte);
    80001034:	80a9                	srli	s1,s1,0xa
    80001036:	04b2                	slli	s1,s1,0xc
    if (*pte & PTE_V) {
    80001038:	e395                	bnez	a5,8000105c <walk+0x62>
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    8000103a:	040b0a63          	beqz	s6,8000108e <walk+0x94>
    8000103e:	b05ff0ef          	jal	80000b42 <kalloc>
    80001042:	84aa                	mv	s1,a0
    80001044:	c50d                	beqz	a0,8000106e <walk+0x74>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80001046:	6605                	lui	a2,0x1
    80001048:	4581                	li	a1,0
    8000104a:	d25ff0ef          	jal	80000d6e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000104e:	00c4d793          	srli	a5,s1,0xc
    80001052:	07aa                	slli	a5,a5,0xa
    80001054:	0017e793          	ori	a5,a5,1
    80001058:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    8000105c:	3a5d                	addiw	s4,s4,-9
    8000105e:	fd5a11e3          	bne	s4,s5,80001020 <walk+0x26>
    }
  }
  return &pagetable[PX(0, va)];
    80001062:	00c9d513          	srli	a0,s3,0xc
    80001066:	1ff57513          	andi	a0,a0,511
    8000106a:	050e                	slli	a0,a0,0x3
    8000106c:	9526                	add	a0,a0,s1
}
    8000106e:	70e2                	ld	ra,56(sp)
    80001070:	7442                	ld	s0,48(sp)
    80001072:	74a2                	ld	s1,40(sp)
    80001074:	7902                	ld	s2,32(sp)
    80001076:	69e2                	ld	s3,24(sp)
    80001078:	6a42                	ld	s4,16(sp)
    8000107a:	6aa2                	ld	s5,8(sp)
    8000107c:	6b02                	ld	s6,0(sp)
    8000107e:	6121                	addi	sp,sp,64
    80001080:	8082                	ret
    panic("walk");
    80001082:	00006517          	auipc	a0,0x6
    80001086:	0be50513          	addi	a0,a0,190 # 80007140 <etext+0x140>
    8000108a:	fbeff0ef          	jal	80000848 <panic>
        return 0;
    8000108e:	4501                	li	a0,0
    80001090:	bff9                	j	8000106e <walk+0x74>

0000000080001092 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80001092:	57fd                	li	a5,-1
    80001094:	83e9                	srli	a5,a5,0x1a
    80001096:	00b7f463          	bgeu	a5,a1,8000109e <walkaddr+0xc>
    return 0;
    8000109a:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    8000109c:	8082                	ret
{
    8000109e:	1141                	addi	sp,sp,-16
    800010a0:	e406                	sd	ra,8(sp)
    800010a2:	e022                	sd	s0,0(sp)
    800010a4:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800010a6:	4601                	li	a2,0
    800010a8:	f53ff0ef          	jal	80000ffa <walk>
  if (pte == 0)
    800010ac:	c519                	beqz	a0,800010ba <walkaddr+0x28>
  if ((*pte & PTE_V) == 0)
    800010ae:	6108                	ld	a0,0(a0)
  if ((*pte & PTE_U) == 0)
    800010b0:	01157713          	andi	a4,a0,17
    800010b4:	47c5                	li	a5,17
    800010b6:	00f70763          	beq	a4,a5,800010c4 <walkaddr+0x32>
    return 0;
    800010ba:	4501                	li	a0,0
}
    800010bc:	60a2                	ld	ra,8(sp)
    800010be:	6402                	ld	s0,0(sp)
    800010c0:	0141                	addi	sp,sp,16
    800010c2:	8082                	ret
  pa = PTE2PA(*pte);
    800010c4:	8129                	srli	a0,a0,0xa
    800010c6:	0532                	slli	a0,a0,0xc
  return pa;
    800010c8:	bfd5                	j	800010bc <walkaddr+0x2a>

00000000800010ca <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800010ca:	715d                	addi	sp,sp,-80
    800010cc:	e486                	sd	ra,72(sp)
    800010ce:	e0a2                	sd	s0,64(sp)
    800010d0:	fc26                	sd	s1,56(sp)
    800010d2:	f84a                	sd	s2,48(sp)
    800010d4:	f44e                	sd	s3,40(sp)
    800010d6:	f052                	sd	s4,32(sp)
    800010d8:	ec56                	sd	s5,24(sp)
    800010da:	e85a                	sd	s6,16(sp)
    800010dc:	e45e                	sd	s7,8(sp)
    800010de:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    800010e0:	03459793          	slli	a5,a1,0x34
    800010e4:	e7b1                	bnez	a5,80001130 <mappages+0x66>
    800010e6:	8a2a                	mv	s4,a0
    800010e8:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    800010ea:	03461793          	slli	a5,a2,0x34
    800010ee:	e7b9                	bnez	a5,8000113c <mappages+0x72>
    panic("mappages: size not aligned");

  if (size == 0)
    800010f0:	ce21                	beqz	a2,80001148 <mappages+0x7e>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    800010f2:	77fd                	lui	a5,0xfffff
    800010f4:	963e                	add	a2,a2,a5
    800010f6:	00b60933          	add	s2,a2,a1
  a = va;
    800010fa:	84ae                	mv	s1,a1
  for (;;) {
    if ((pte = walk(pagetable, a, 1)) == 0)
    800010fc:	4b05                	li	s6,1
    800010fe:	40b689b3          	sub	s3,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80001102:	6b85                	lui	s7,0x1
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001104:	865a                	mv	a2,s6
    80001106:	85a6                	mv	a1,s1
    80001108:	8552                	mv	a0,s4
    8000110a:	ef1ff0ef          	jal	80000ffa <walk>
    8000110e:	c929                	beqz	a0,80001160 <mappages+0x96>
    if (*pte & PTE_V)
    80001110:	611c                	ld	a5,0(a0)
    80001112:	8b85                	andi	a5,a5,1
    80001114:	e3a1                	bnez	a5,80001154 <mappages+0x8a>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001116:	013487b3          	add	a5,s1,s3
    8000111a:	83b1                	srli	a5,a5,0xc
    8000111c:	07aa                	slli	a5,a5,0xa
    8000111e:	0157e7b3          	or	a5,a5,s5
    80001122:	0017e793          	ori	a5,a5,1
    80001126:	e11c                	sd	a5,0(a0)
    if (a == last)
    80001128:	05248863          	beq	s1,s2,80001178 <mappages+0xae>
    a += PGSIZE;
    8000112c:	94de                	add	s1,s1,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000112e:	bfd9                	j	80001104 <mappages+0x3a>
    panic("mappages: va not aligned");
    80001130:	00006517          	auipc	a0,0x6
    80001134:	01850513          	addi	a0,a0,24 # 80007148 <etext+0x148>
    80001138:	f10ff0ef          	jal	80000848 <panic>
    panic("mappages: size not aligned");
    8000113c:	00006517          	auipc	a0,0x6
    80001140:	02c50513          	addi	a0,a0,44 # 80007168 <etext+0x168>
    80001144:	f04ff0ef          	jal	80000848 <panic>
    panic("mappages: size");
    80001148:	00006517          	auipc	a0,0x6
    8000114c:	04050513          	addi	a0,a0,64 # 80007188 <etext+0x188>
    80001150:	ef8ff0ef          	jal	80000848 <panic>
      panic("mappages: remap");
    80001154:	00006517          	auipc	a0,0x6
    80001158:	04450513          	addi	a0,a0,68 # 80007198 <etext+0x198>
    8000115c:	eecff0ef          	jal	80000848 <panic>
      return -1;
    80001160:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001162:	60a6                	ld	ra,72(sp)
    80001164:	6406                	ld	s0,64(sp)
    80001166:	74e2                	ld	s1,56(sp)
    80001168:	7942                	ld	s2,48(sp)
    8000116a:	79a2                	ld	s3,40(sp)
    8000116c:	7a02                	ld	s4,32(sp)
    8000116e:	6ae2                	ld	s5,24(sp)
    80001170:	6b42                	ld	s6,16(sp)
    80001172:	6ba2                	ld	s7,8(sp)
    80001174:	6161                	addi	sp,sp,80
    80001176:	8082                	ret
  return 0;
    80001178:	4501                	li	a0,0
    8000117a:	b7e5                	j	80001162 <mappages+0x98>

000000008000117c <kvmmap>:
{
    8000117c:	1141                	addi	sp,sp,-16
    8000117e:	e406                	sd	ra,8(sp)
    80001180:	e022                	sd	s0,0(sp)
    80001182:	0800                	addi	s0,sp,16
    80001184:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001186:	86b2                	mv	a3,a2
    80001188:	863e                	mv	a2,a5
    8000118a:	f41ff0ef          	jal	800010ca <mappages>
    8000118e:	e509                	bnez	a0,80001198 <kvmmap+0x1c>
}
    80001190:	60a2                	ld	ra,8(sp)
    80001192:	6402                	ld	s0,0(sp)
    80001194:	0141                	addi	sp,sp,16
    80001196:	8082                	ret
    panic("kvmmap");
    80001198:	00006517          	auipc	a0,0x6
    8000119c:	01050513          	addi	a0,a0,16 # 800071a8 <etext+0x1a8>
    800011a0:	ea8ff0ef          	jal	80000848 <panic>

00000000800011a4 <kvmmake>:
{
    800011a4:	1101                	addi	sp,sp,-32
    800011a6:	ec06                	sd	ra,24(sp)
    800011a8:	e822                	sd	s0,16(sp)
    800011aa:	e426                	sd	s1,8(sp)
    800011ac:	e04a                	sd	s2,0(sp)
    800011ae:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    800011b0:	993ff0ef          	jal	80000b42 <kalloc>
    800011b4:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800011b6:	6605                	lui	a2,0x1
    800011b8:	4581                	li	a1,0
    800011ba:	bb5ff0ef          	jal	80000d6e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800011be:	4719                	li	a4,6
    800011c0:	6685                	lui	a3,0x1
    800011c2:	10000637          	lui	a2,0x10000
    800011c6:	85b2                	mv	a1,a2
    800011c8:	8526                	mv	a0,s1
    800011ca:	fb3ff0ef          	jal	8000117c <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800011ce:	4719                	li	a4,6
    800011d0:	6685                	lui	a3,0x1
    800011d2:	10001637          	lui	a2,0x10001
    800011d6:	85b2                	mv	a1,a2
    800011d8:	8526                	mv	a0,s1
    800011da:	fa3ff0ef          	jal	8000117c <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800011de:	4719                	li	a4,6
    800011e0:	040006b7          	lui	a3,0x4000
    800011e4:	0c000637          	lui	a2,0xc000
    800011e8:	85b2                	mv	a1,a2
    800011ea:	8526                	mv	a0,s1
    800011ec:	f91ff0ef          	jal	8000117c <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    800011f0:	00006917          	auipc	s2,0x6
    800011f4:	e1090913          	addi	s2,s2,-496 # 80007000 <etext>
    800011f8:	4729                	li	a4,10
    800011fa:	800006b7          	lui	a3,0x80000
    800011fe:	96ca                	add	a3,a3,s2
    80001200:	4605                	li	a2,1
    80001202:	067e                	slli	a2,a2,0x1f
    80001204:	85b2                	mv	a1,a2
    80001206:	8526                	mv	a0,s1
    80001208:	f75ff0ef          	jal	8000117c <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    8000120c:	4719                	li	a4,6
    8000120e:	46c5                	li	a3,17
    80001210:	06ee                	slli	a3,a3,0x1b
    80001212:	412686b3          	sub	a3,a3,s2
    80001216:	864a                	mv	a2,s2
    80001218:	85ca                	mv	a1,s2
    8000121a:	8526                	mv	a0,s1
    8000121c:	f61ff0ef          	jal	8000117c <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001220:	4729                	li	a4,10
    80001222:	6685                	lui	a3,0x1
    80001224:	00005617          	auipc	a2,0x5
    80001228:	ddc60613          	addi	a2,a2,-548 # 80006000 <_trampoline>
    8000122c:	040005b7          	lui	a1,0x4000
    80001230:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001232:	05b2                	slli	a1,a1,0xc
    80001234:	8526                	mv	a0,s1
    80001236:	f47ff0ef          	jal	8000117c <kvmmap>
  proc_mapstacks(kpgtbl);
    8000123a:	8526                	mv	a0,s1
    8000123c:	6c8000ef          	jal	80001904 <proc_mapstacks>
}
    80001240:	8526                	mv	a0,s1
    80001242:	60e2                	ld	ra,24(sp)
    80001244:	6442                	ld	s0,16(sp)
    80001246:	64a2                	ld	s1,8(sp)
    80001248:	6902                	ld	s2,0(sp)
    8000124a:	6105                	addi	sp,sp,32
    8000124c:	8082                	ret

000000008000124e <kvminit>:
{
    8000124e:	1141                	addi	sp,sp,-16
    80001250:	e406                	sd	ra,8(sp)
    80001252:	e022                	sd	s0,0(sp)
    80001254:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001256:	f4fff0ef          	jal	800011a4 <kvmmake>
    8000125a:	00006797          	auipc	a5,0x6
    8000125e:	70a7bb23          	sd	a0,1814(a5) # 80007970 <kernel_pagetable>
}
    80001262:	60a2                	ld	ra,8(sp)
    80001264:	6402                	ld	s0,0(sp)
    80001266:	0141                	addi	sp,sp,16
    80001268:	8082                	ret

000000008000126a <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000126a:	1101                	addi	sp,sp,-32
    8000126c:	ec06                	sd	ra,24(sp)
    8000126e:	e822                	sd	s0,16(sp)
    80001270:	e426                	sd	s1,8(sp)
    80001272:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    80001274:	8cfff0ef          	jal	80000b42 <kalloc>
    80001278:	84aa                	mv	s1,a0
  if (pagetable == 0)
    8000127a:	c509                	beqz	a0,80001284 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000127c:	6605                	lui	a2,0x1
    8000127e:	4581                	li	a1,0
    80001280:	aefff0ef          	jal	80000d6e <memset>
  return pagetable;
}
    80001284:	8526                	mv	a0,s1
    80001286:	60e2                	ld	ra,24(sp)
    80001288:	6442                	ld	s0,16(sp)
    8000128a:	64a2                	ld	s1,8(sp)
    8000128c:	6105                	addi	sp,sp,32
    8000128e:	8082                	ret

0000000080001290 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001290:	7139                	addi	sp,sp,-64
    80001292:	fc06                	sd	ra,56(sp)
    80001294:	f822                	sd	s0,48(sp)
    80001296:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80001298:	03459793          	slli	a5,a1,0x34
    8000129c:	e38d                	bnez	a5,800012be <uvmunmap+0x2e>
    8000129e:	f04a                	sd	s2,32(sp)
    800012a0:	ec4e                	sd	s3,24(sp)
    800012a2:	e852                	sd	s4,16(sp)
    800012a4:	e456                	sd	s5,8(sp)
    800012a6:	e05a                	sd	s6,0(sp)
    800012a8:	8a2a                	mv	s4,a0
    800012aa:	892e                	mv	s2,a1
    800012ac:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800012ae:	0632                	slli	a2,a2,0xc
    800012b0:	00b609b3          	add	s3,a2,a1
    800012b4:	6b05                	lui	s6,0x1
    800012b6:	0535f963          	bgeu	a1,s3,80001308 <uvmunmap+0x78>
    800012ba:	f426                	sd	s1,40(sp)
    800012bc:	a015                	j	800012e0 <uvmunmap+0x50>
    800012be:	f426                	sd	s1,40(sp)
    800012c0:	f04a                	sd	s2,32(sp)
    800012c2:	ec4e                	sd	s3,24(sp)
    800012c4:	e852                	sd	s4,16(sp)
    800012c6:	e456                	sd	s5,8(sp)
    800012c8:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    800012ca:	00006517          	auipc	a0,0x6
    800012ce:	ee650513          	addi	a0,a0,-282 # 800071b0 <etext+0x1b0>
    800012d2:	d76ff0ef          	jal	80000848 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    800012d6:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800012da:	995a                	add	s2,s2,s6
    800012dc:	03397563          	bgeu	s2,s3,80001306 <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800012e0:	4601                	li	a2,0
    800012e2:	85ca                	mv	a1,s2
    800012e4:	8552                	mv	a0,s4
    800012e6:	d15ff0ef          	jal	80000ffa <walk>
    800012ea:	84aa                	mv	s1,a0
    800012ec:	d57d                	beqz	a0,800012da <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    800012ee:	611c                	ld	a5,0(a0)
    800012f0:	0017f713          	andi	a4,a5,1
    800012f4:	d37d                	beqz	a4,800012da <uvmunmap+0x4a>
    if (do_free) {
    800012f6:	fe0a80e3          	beqz	s5,800012d6 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    800012fa:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    800012fc:	00c79513          	slli	a0,a5,0xc
    80001300:	f36ff0ef          	jal	80000a36 <kfree>
    80001304:	bfc9                	j	800012d6 <uvmunmap+0x46>
    80001306:	74a2                	ld	s1,40(sp)
    80001308:	7902                	ld	s2,32(sp)
    8000130a:	69e2                	ld	s3,24(sp)
    8000130c:	6a42                	ld	s4,16(sp)
    8000130e:	6aa2                	ld	s5,8(sp)
    80001310:	6b02                	ld	s6,0(sp)
  }
}
    80001312:	70e2                	ld	ra,56(sp)
    80001314:	7442                	ld	s0,48(sp)
    80001316:	6121                	addi	sp,sp,64
    80001318:	8082                	ret

000000008000131a <uvmdealloc>:
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if (newsz >= oldsz)
    8000131a:	04b67163          	bgeu	a2,a1,8000135c <uvmdealloc+0x42>
{
    8000131e:	1101                	addi	sp,sp,-32
    80001320:	ec06                	sd	ra,24(sp)
    80001322:	e822                	sd	s0,16(sp)
    80001324:	e426                	sd	s1,8(sp)
    80001326:	1000                	addi	s0,sp,32
    80001328:	84b2                	mv	s1,a2
    return oldsz;

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    8000132a:	6785                	lui	a5,0x1
    8000132c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000132e:	00f60733          	add	a4,a2,a5
    80001332:	76fd                	lui	a3,0xfffff
    80001334:	8f75                	and	a4,a4,a3
    80001336:	97ae                	add	a5,a5,a1
    80001338:	8ff5                	and	a5,a5,a3
    8000133a:	00f76863          	bltu	a4,a5,8000134a <uvmdealloc+0x30>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
    8000133e:	8526                	mv	a0,s1
}
    80001340:	60e2                	ld	ra,24(sp)
    80001342:	6442                	ld	s0,16(sp)
    80001344:	64a2                	ld	s1,8(sp)
    80001346:	6105                	addi	sp,sp,32
    80001348:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000134a:	8f99                	sub	a5,a5,a4
    8000134c:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000134e:	4685                	li	a3,1
    80001350:	0007861b          	sext.w	a2,a5
    80001354:	85ba                	mv	a1,a4
    80001356:	f3bff0ef          	jal	80001290 <uvmunmap>
    8000135a:	b7d5                	j	8000133e <uvmdealloc+0x24>
    return oldsz;
    8000135c:	852e                	mv	a0,a1
}
    8000135e:	8082                	ret

0000000080001360 <uvmalloc>:
  if (newsz < oldsz)
    80001360:	08b66e63          	bltu	a2,a1,800013fc <uvmalloc+0x9c>
{
    80001364:	715d                	addi	sp,sp,-80
    80001366:	e486                	sd	ra,72(sp)
    80001368:	e0a2                	sd	s0,64(sp)
    8000136a:	f052                	sd	s4,32(sp)
    8000136c:	ec56                	sd	s5,24(sp)
    8000136e:	e45e                	sd	s7,8(sp)
    80001370:	0880                	addi	s0,sp,80
    80001372:	8aaa                	mv	s5,a0
    80001374:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001376:	6785                	lui	a5,0x1
    80001378:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000137a:	95be                	add	a1,a1,a5
    8000137c:	77fd                	lui	a5,0xfffff
    8000137e:	8fed                	and	a5,a5,a1
    80001380:	8bbe                	mv	s7,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001382:	04c7f163          	bgeu	a5,a2,800013c4 <uvmalloc+0x64>
    80001386:	fc26                	sd	s1,56(sp)
    80001388:	f84a                	sd	s2,48(sp)
    8000138a:	f44e                	sd	s3,40(sp)
    8000138c:	e85a                	sd	s6,16(sp)
    8000138e:	893e                	mv	s2,a5
    memset(mem, 0, PGSIZE);
    80001390:	6985                	lui	s3,0x1
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    80001392:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001396:	facff0ef          	jal	80000b42 <kalloc>
    8000139a:	84aa                	mv	s1,a0
    if (mem == 0) {
    8000139c:	c515                	beqz	a0,800013c8 <uvmalloc+0x68>
    memset(mem, 0, PGSIZE);
    8000139e:	864e                	mv	a2,s3
    800013a0:	4581                	li	a1,0
    800013a2:	9cdff0ef          	jal	80000d6e <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800013a6:	875a                	mv	a4,s6
    800013a8:	86a6                	mv	a3,s1
    800013aa:	864e                	mv	a2,s3
    800013ac:	85ca                	mv	a1,s2
    800013ae:	8556                	mv	a0,s5
    800013b0:	d1bff0ef          	jal	800010ca <mappages>
    800013b4:	e91d                	bnez	a0,800013ea <uvmalloc+0x8a>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    800013b6:	994e                	add	s2,s2,s3
    800013b8:	fd496fe3          	bltu	s2,s4,80001396 <uvmalloc+0x36>
    800013bc:	74e2                	ld	s1,56(sp)
    800013be:	7942                	ld	s2,48(sp)
    800013c0:	79a2                	ld	s3,40(sp)
    800013c2:	6b42                	ld	s6,16(sp)
  return newsz;
    800013c4:	8552                	mv	a0,s4
    800013c6:	a819                	j	800013dc <uvmalloc+0x7c>
      uvmdealloc(pagetable, a, oldsz);
    800013c8:	865e                	mv	a2,s7
    800013ca:	85ca                	mv	a1,s2
    800013cc:	8556                	mv	a0,s5
    800013ce:	f4dff0ef          	jal	8000131a <uvmdealloc>
      return 0;
    800013d2:	4501                	li	a0,0
    800013d4:	74e2                	ld	s1,56(sp)
    800013d6:	7942                	ld	s2,48(sp)
    800013d8:	79a2                	ld	s3,40(sp)
    800013da:	6b42                	ld	s6,16(sp)
}
    800013dc:	60a6                	ld	ra,72(sp)
    800013de:	6406                	ld	s0,64(sp)
    800013e0:	7a02                	ld	s4,32(sp)
    800013e2:	6ae2                	ld	s5,24(sp)
    800013e4:	6ba2                	ld	s7,8(sp)
    800013e6:	6161                	addi	sp,sp,80
    800013e8:	8082                	ret
      kfree(mem);
    800013ea:	8526                	mv	a0,s1
    800013ec:	e4aff0ef          	jal	80000a36 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800013f0:	865e                	mv	a2,s7
    800013f2:	85ca                	mv	a1,s2
    800013f4:	8556                	mv	a0,s5
    800013f6:	f25ff0ef          	jal	8000131a <uvmdealloc>
      return 0;
    800013fa:	bfe1                	j	800013d2 <uvmalloc+0x72>
    return oldsz;
    800013fc:	852e                	mv	a0,a1
}
    800013fe:	8082                	ret

0000000080001400 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001400:	7179                	addi	sp,sp,-48
    80001402:	f406                	sd	ra,40(sp)
    80001404:	f022                	sd	s0,32(sp)
    80001406:	ec26                	sd	s1,24(sp)
    80001408:	e84a                	sd	s2,16(sp)
    8000140a:	e44e                	sd	s3,8(sp)
    8000140c:	1800                	addi	s0,sp,48
    8000140e:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    80001410:	84aa                	mv	s1,a0
    80001412:	6905                	lui	s2,0x1
    80001414:	992a                	add	s2,s2,a0
    80001416:	a811                	j	8000142a <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if (pte & PTE_V) {
      panic("freewalk: leaf");
    80001418:	00006517          	auipc	a0,0x6
    8000141c:	db050513          	addi	a0,a0,-592 # 800071c8 <etext+0x1c8>
    80001420:	c28ff0ef          	jal	80000848 <panic>
  for (int i = 0; i < 512; i++) {
    80001424:	04a1                	addi	s1,s1,8
    80001426:	03248163          	beq	s1,s2,80001448 <freewalk+0x48>
    pte_t pte = pagetable[i];
    8000142a:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    8000142c:	0017f713          	andi	a4,a5,1
    80001430:	db75                	beqz	a4,80001424 <freewalk+0x24>
    80001432:	00e7f713          	andi	a4,a5,14
    80001436:	f36d                	bnez	a4,80001418 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001438:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    8000143a:	00c79513          	slli	a0,a5,0xc
    8000143e:	fc3ff0ef          	jal	80001400 <freewalk>
      pagetable[i] = 0;
    80001442:	0004b023          	sd	zero,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001446:	bff9                	j	80001424 <freewalk+0x24>
    }
  }
  kfree((void *)pagetable);
    80001448:	854e                	mv	a0,s3
    8000144a:	decff0ef          	jal	80000a36 <kfree>
}
    8000144e:	70a2                	ld	ra,40(sp)
    80001450:	7402                	ld	s0,32(sp)
    80001452:	64e2                	ld	s1,24(sp)
    80001454:	6942                	ld	s2,16(sp)
    80001456:	69a2                	ld	s3,8(sp)
    80001458:	6145                	addi	sp,sp,48
    8000145a:	8082                	ret

000000008000145c <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000145c:	1101                	addi	sp,sp,-32
    8000145e:	ec06                	sd	ra,24(sp)
    80001460:	e822                	sd	s0,16(sp)
    80001462:	e426                	sd	s1,8(sp)
    80001464:	1000                	addi	s0,sp,32
    80001466:	84aa                	mv	s1,a0
  if (sz > 0)
    80001468:	e989                	bnez	a1,8000147a <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    8000146a:	8526                	mv	a0,s1
    8000146c:	f95ff0ef          	jal	80001400 <freewalk>
}
    80001470:	60e2                	ld	ra,24(sp)
    80001472:	6442                	ld	s0,16(sp)
    80001474:	64a2                	ld	s1,8(sp)
    80001476:	6105                	addi	sp,sp,32
    80001478:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    8000147a:	6785                	lui	a5,0x1
    8000147c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000147e:	95be                	add	a1,a1,a5
    80001480:	4685                	li	a3,1
    80001482:	00c5d613          	srli	a2,a1,0xc
    80001486:	4581                	li	a1,0
    80001488:	e09ff0ef          	jal	80001290 <uvmunmap>
    8000148c:	bff9                	j	8000146a <uvmfree+0xe>

000000008000148e <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    8000148e:	ca59                	beqz	a2,80001524 <uvmcopy+0x96>
{
    80001490:	715d                	addi	sp,sp,-80
    80001492:	e486                	sd	ra,72(sp)
    80001494:	e0a2                	sd	s0,64(sp)
    80001496:	fc26                	sd	s1,56(sp)
    80001498:	f84a                	sd	s2,48(sp)
    8000149a:	f44e                	sd	s3,40(sp)
    8000149c:	f052                	sd	s4,32(sp)
    8000149e:	ec56                	sd	s5,24(sp)
    800014a0:	e85a                	sd	s6,16(sp)
    800014a2:	e45e                	sd	s7,8(sp)
    800014a4:	0880                	addi	s0,sp,80
    800014a6:	8b2a                	mv	s6,a0
    800014a8:	8bae                	mv	s7,a1
    800014aa:	8ab2                	mv	s5,a2
  for (i = 0; i < sz; i += PGSIZE) {
    800014ac:	4481                	li	s1,0
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    800014ae:	6a05                	lui	s4,0x1
    800014b0:	a021                	j	800014b8 <uvmcopy+0x2a>
  for (i = 0; i < sz; i += PGSIZE) {
    800014b2:	94d2                	add	s1,s1,s4
    800014b4:	0554fc63          	bgeu	s1,s5,8000150c <uvmcopy+0x7e>
    if ((pte = walk(old, i, 0)) == 0)
    800014b8:	4601                	li	a2,0
    800014ba:	85a6                	mv	a1,s1
    800014bc:	855a                	mv	a0,s6
    800014be:	b3dff0ef          	jal	80000ffa <walk>
    800014c2:	d965                	beqz	a0,800014b2 <uvmcopy+0x24>
    if ((*pte & PTE_V) == 0)
    800014c4:	00053983          	ld	s3,0(a0)
    800014c8:	0019f793          	andi	a5,s3,1
    800014cc:	d3fd                	beqz	a5,800014b2 <uvmcopy+0x24>
    if ((mem = kalloc()) == 0)
    800014ce:	e74ff0ef          	jal	80000b42 <kalloc>
    800014d2:	892a                	mv	s2,a0
    800014d4:	c11d                	beqz	a0,800014fa <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    800014d6:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char *)pa, PGSIZE);
    800014da:	8652                	mv	a2,s4
    800014dc:	05b2                	slli	a1,a1,0xc
    800014de:	8edff0ef          	jal	80000dca <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    800014e2:	3ff9f713          	andi	a4,s3,1023
    800014e6:	86ca                	mv	a3,s2
    800014e8:	8652                	mv	a2,s4
    800014ea:	85a6                	mv	a1,s1
    800014ec:	855e                	mv	a0,s7
    800014ee:	bddff0ef          	jal	800010ca <mappages>
    800014f2:	d161                	beqz	a0,800014b2 <uvmcopy+0x24>
      kfree(mem);
    800014f4:	854a                	mv	a0,s2
    800014f6:	d40ff0ef          	jal	80000a36 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800014fa:	4685                	li	a3,1
    800014fc:	00c4d613          	srli	a2,s1,0xc
    80001500:	4581                	li	a1,0
    80001502:	855e                	mv	a0,s7
    80001504:	d8dff0ef          	jal	80001290 <uvmunmap>
  return -1;
    80001508:	557d                	li	a0,-1
    8000150a:	a011                	j	8000150e <uvmcopy+0x80>
  return 0;
    8000150c:	4501                	li	a0,0
}
    8000150e:	60a6                	ld	ra,72(sp)
    80001510:	6406                	ld	s0,64(sp)
    80001512:	74e2                	ld	s1,56(sp)
    80001514:	7942                	ld	s2,48(sp)
    80001516:	79a2                	ld	s3,40(sp)
    80001518:	7a02                	ld	s4,32(sp)
    8000151a:	6ae2                	ld	s5,24(sp)
    8000151c:	6b42                	ld	s6,16(sp)
    8000151e:	6ba2                	ld	s7,8(sp)
    80001520:	6161                	addi	sp,sp,80
    80001522:	8082                	ret
  return 0;
    80001524:	4501                	li	a0,0
}
    80001526:	8082                	ret

0000000080001528 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001528:	1141                	addi	sp,sp,-16
    8000152a:	e406                	sd	ra,8(sp)
    8000152c:	e022                	sd	s0,0(sp)
    8000152e:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    80001530:	4601                	li	a2,0
    80001532:	ac9ff0ef          	jal	80000ffa <walk>
  if (pte == 0)
    80001536:	c901                	beqz	a0,80001546 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001538:	611c                	ld	a5,0(a0)
    8000153a:	9bbd                	andi	a5,a5,-17
    8000153c:	e11c                	sd	a5,0(a0)
}
    8000153e:	60a2                	ld	ra,8(sp)
    80001540:	6402                	ld	s0,0(sp)
    80001542:	0141                	addi	sp,sp,16
    80001544:	8082                	ret
    panic("uvmclear");
    80001546:	00006517          	auipc	a0,0x6
    8000154a:	c9250513          	addi	a0,a0,-878 # 800071d8 <etext+0x1d8>
    8000154e:	afaff0ef          	jal	80000848 <panic>

0000000080001552 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001552:	1141                	addi	sp,sp,-16
    80001554:	e406                	sd	ra,8(sp)
    80001556:	e022                	sd	s0,0(sp)
    80001558:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    8000155a:	4601                	li	a2,0
    8000155c:	a9fff0ef          	jal	80000ffa <walk>
  if (pte == 0) {
    80001560:	c119                	beqz	a0,80001566 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V) {
    80001562:	6108                	ld	a0,0(a0)
    80001564:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001566:	60a2                	ld	ra,8(sp)
    80001568:	6402                	ld	s0,0(sp)
    8000156a:	0141                	addi	sp,sp,16
    8000156c:	8082                	ret

000000008000156e <vmfault>:
{
    8000156e:	7179                	addi	sp,sp,-48
    80001570:	f406                	sd	ra,40(sp)
    80001572:	f022                	sd	s0,32(sp)
    80001574:	e052                	sd	s4,0(sp)
    80001576:	1800                	addi	s0,sp,48
  if (va >= psz)
    80001578:	00b66d63          	bltu	a2,a1,80001592 <vmfault+0x24>
    return 0;
    8000157c:	4a01                	li	s4,0
}
    8000157e:	8552                	mv	a0,s4
    80001580:	70a2                	ld	ra,40(sp)
    80001582:	7402                	ld	s0,32(sp)
    80001584:	6a02                	ld	s4,0(sp)
    80001586:	6145                	addi	sp,sp,48
    80001588:	8082                	ret
    8000158a:	64e2                	ld	s1,24(sp)
    8000158c:	6942                	ld	s2,16(sp)
    8000158e:	69a2                	ld	s3,8(sp)
    80001590:	b7f5                	j	8000157c <vmfault+0xe>
    80001592:	e84a                	sd	s2,16(sp)
    80001594:	e44e                	sd	s3,8(sp)
  va = PGROUNDDOWN(va);
    80001596:	77fd                	lui	a5,0xfffff
    80001598:	00f67933          	and	s2,a2,a5
  if (ismapped(pagetable, va)) {
    8000159c:	85ca                	mv	a1,s2
    8000159e:	89aa                	mv	s3,a0
    800015a0:	fb3ff0ef          	jal	80001552 <ismapped>
    800015a4:	c501                	beqz	a0,800015ac <vmfault+0x3e>
    800015a6:	6942                	ld	s2,16(sp)
    800015a8:	69a2                	ld	s3,8(sp)
    800015aa:	bfc9                	j	8000157c <vmfault+0xe>
    800015ac:	ec26                	sd	s1,24(sp)
  mem = (uint64)kalloc();
    800015ae:	d94ff0ef          	jal	80000b42 <kalloc>
    800015b2:	84aa                	mv	s1,a0
  if (mem == 0)
    800015b4:	d979                	beqz	a0,8000158a <vmfault+0x1c>
  mem = (uint64)kalloc();
    800015b6:	8a2a                	mv	s4,a0
  memset((void *)mem, 0, PGSIZE);
    800015b8:	6605                	lui	a2,0x1
    800015ba:	4581                	li	a1,0
    800015bc:	fb2ff0ef          	jal	80000d6e <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    800015c0:	4759                	li	a4,22
    800015c2:	86a6                	mv	a3,s1
    800015c4:	6605                	lui	a2,0x1
    800015c6:	85ca                	mv	a1,s2
    800015c8:	854e                	mv	a0,s3
    800015ca:	b01ff0ef          	jal	800010ca <mappages>
    800015ce:	e509                	bnez	a0,800015d8 <vmfault+0x6a>
    800015d0:	64e2                	ld	s1,24(sp)
    800015d2:	6942                	ld	s2,16(sp)
    800015d4:	69a2                	ld	s3,8(sp)
    800015d6:	b765                	j	8000157e <vmfault+0x10>
    kfree((void *)mem);
    800015d8:	8526                	mv	a0,s1
    800015da:	c5cff0ef          	jal	80000a36 <kfree>
    return 0;
    800015de:	64e2                	ld	s1,24(sp)
    800015e0:	6942                	ld	s2,16(sp)
    800015e2:	69a2                	ld	s3,8(sp)
    800015e4:	bf61                	j	8000157c <vmfault+0xe>

00000000800015e6 <copyout>:
  while (len > 0) {
    800015e6:	cf55                	beqz	a4,800016a2 <copyout+0xbc>
{
    800015e8:	7159                	addi	sp,sp,-112
    800015ea:	f486                	sd	ra,104(sp)
    800015ec:	f0a2                	sd	s0,96(sp)
    800015ee:	eca6                	sd	s1,88(sp)
    800015f0:	e8ca                	sd	s2,80(sp)
    800015f2:	e4ce                	sd	s3,72(sp)
    800015f4:	e0d2                	sd	s4,64(sp)
    800015f6:	fc56                	sd	s5,56(sp)
    800015f8:	f85a                	sd	s6,48(sp)
    800015fa:	f45e                	sd	s7,40(sp)
    800015fc:	f062                	sd	s8,32(sp)
    800015fe:	ec66                	sd	s9,24(sp)
    80001600:	e86a                	sd	s10,16(sp)
    80001602:	e46e                	sd	s11,8(sp)
    80001604:	1880                	addi	s0,sp,112
    80001606:	8baa                	mv	s7,a0
    80001608:	8dae                	mv	s11,a1
    8000160a:	84b2                	mv	s1,a2
    8000160c:	8b36                	mv	s6,a3
    8000160e:	8aba                	mv	s5,a4
    va0 = PGROUNDDOWN(dstva);
    80001610:	7d7d                	lui	s10,0xfffff
    if (va0 >= MAXVA)
    80001612:	5cfd                	li	s9,-1
    80001614:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001618:	6c05                	lui	s8,0x1
    8000161a:	a089                	j	8000165c <copyout+0x76>
      return -1;
    8000161c:	557d                	li	a0,-1
}
    8000161e:	70a6                	ld	ra,104(sp)
    80001620:	7406                	ld	s0,96(sp)
    80001622:	64e6                	ld	s1,88(sp)
    80001624:	6946                	ld	s2,80(sp)
    80001626:	69a6                	ld	s3,72(sp)
    80001628:	6a06                	ld	s4,64(sp)
    8000162a:	7ae2                	ld	s5,56(sp)
    8000162c:	7b42                	ld	s6,48(sp)
    8000162e:	7ba2                	ld	s7,40(sp)
    80001630:	7c02                	ld	s8,32(sp)
    80001632:	6ce2                	ld	s9,24(sp)
    80001634:	6d42                	ld	s10,16(sp)
    80001636:	6da2                	ld	s11,8(sp)
    80001638:	6165                	addi	sp,sp,112
    8000163a:	8082                	ret
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000163c:	03449513          	slli	a0,s1,0x34
    80001640:	9151                	srli	a0,a0,0x34
    80001642:	0009061b          	sext.w	a2,s2
    80001646:	85da                	mv	a1,s6
    80001648:	954e                	add	a0,a0,s3
    8000164a:	f80ff0ef          	jal	80000dca <memmove>
    len -= n;
    8000164e:	412a8ab3          	sub	s5,s5,s2
    src += n;
    80001652:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    80001654:	018a04b3          	add	s1,s4,s8
  while (len > 0) {
    80001658:	040a8363          	beqz	s5,8000169e <copyout+0xb8>
    va0 = PGROUNDDOWN(dstva);
    8000165c:	01a4fa33          	and	s4,s1,s10
    if (va0 >= MAXVA)
    80001660:	fb4ceee3          	bltu	s9,s4,8000161c <copyout+0x36>
    pa0 = walkaddr(pagetable, va0);
    80001664:	85d2                	mv	a1,s4
    80001666:	855e                	mv	a0,s7
    80001668:	a2bff0ef          	jal	80001092 <walkaddr>
    8000166c:	89aa                	mv	s3,a0
    if (pa0 == 0) {
    8000166e:	e909                	bnez	a0,80001680 <copyout+0x9a>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    80001670:	4681                	li	a3,0
    80001672:	8652                	mv	a2,s4
    80001674:	85ee                	mv	a1,s11
    80001676:	855e                	mv	a0,s7
    80001678:	ef7ff0ef          	jal	8000156e <vmfault>
    8000167c:	89aa                	mv	s3,a0
    8000167e:	dd59                	beqz	a0,8000161c <copyout+0x36>
    pte = walk(pagetable, va0, 0);
    80001680:	4601                	li	a2,0
    80001682:	85d2                	mv	a1,s4
    80001684:	855e                	mv	a0,s7
    80001686:	975ff0ef          	jal	80000ffa <walk>
    if ((*pte & PTE_W) == 0)
    8000168a:	611c                	ld	a5,0(a0)
    8000168c:	8b91                	andi	a5,a5,4
    8000168e:	d7d9                	beqz	a5,8000161c <copyout+0x36>
    n = PGSIZE - (dstva - va0);
    80001690:	409a0933          	sub	s2,s4,s1
    80001694:	9962                	add	s2,s2,s8
    if (n > len)
    80001696:	fb2af3e3          	bgeu	s5,s2,8000163c <copyout+0x56>
    8000169a:	8956                	mv	s2,s5
    8000169c:	b745                	j	8000163c <copyout+0x56>
  return 0;
    8000169e:	4501                	li	a0,0
    800016a0:	bfbd                	j	8000161e <copyout+0x38>
    800016a2:	4501                	li	a0,0
}
    800016a4:	8082                	ret

00000000800016a6 <copyin>:
  while (len > 0) {
    800016a6:	cf49                	beqz	a4,80001740 <copyin+0x9a>
{
    800016a8:	711d                	addi	sp,sp,-96
    800016aa:	ec86                	sd	ra,88(sp)
    800016ac:	e8a2                	sd	s0,80(sp)
    800016ae:	e4a6                	sd	s1,72(sp)
    800016b0:	e0ca                	sd	s2,64(sp)
    800016b2:	fc4e                	sd	s3,56(sp)
    800016b4:	f852                	sd	s4,48(sp)
    800016b6:	f456                	sd	s5,40(sp)
    800016b8:	f05a                	sd	s6,32(sp)
    800016ba:	ec5e                	sd	s7,24(sp)
    800016bc:	e862                	sd	s8,16(sp)
    800016be:	e466                	sd	s9,8(sp)
    800016c0:	e06a                	sd	s10,0(sp)
    800016c2:	1080                	addi	s0,sp,96
    800016c4:	8baa                	mv	s7,a0
    800016c6:	8cae                	mv	s9,a1
    800016c8:	8ab2                	mv	s5,a2
    800016ca:	84b6                	mv	s1,a3
    800016cc:	89ba                	mv	s3,a4
    va0 = PGROUNDDOWN(srcva);
    800016ce:	7c7d                	lui	s8,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016d0:	4d05                	li	s10,1
    n = PGSIZE - (srcva - va0);
    800016d2:	6b05                	lui	s6,0x1
    800016d4:	a03d                	j	80001702 <copyin+0x5c>
    800016d6:	409a0933          	sub	s2,s4,s1
    800016da:	995a                	add	s2,s2,s6
    if (n > len)
    800016dc:	0129f363          	bgeu	s3,s2,800016e2 <copyin+0x3c>
    800016e0:	894e                	mv	s2,s3
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800016e2:	03449593          	slli	a1,s1,0x34
    800016e6:	91d1                	srli	a1,a1,0x34
    800016e8:	0009061b          	sext.w	a2,s2
    800016ec:	95aa                	add	a1,a1,a0
    800016ee:	8556                	mv	a0,s5
    800016f0:	edaff0ef          	jal	80000dca <memmove>
    len -= n;
    800016f4:	412989b3          	sub	s3,s3,s2
    dst += n;
    800016f8:	9aca                	add	s5,s5,s2
    srcva = va0 + PGSIZE;
    800016fa:	016a04b3          	add	s1,s4,s6
  while (len > 0) {
    800016fe:	02098263          	beqz	s3,80001722 <copyin+0x7c>
    va0 = PGROUNDDOWN(srcva);
    80001702:	0184fa33          	and	s4,s1,s8
    pa0 = walkaddr(pagetable, va0);
    80001706:	85d2                	mv	a1,s4
    80001708:	855e                	mv	a0,s7
    8000170a:	989ff0ef          	jal	80001092 <walkaddr>
    if (pa0 == 0) {
    8000170e:	f561                	bnez	a0,800016d6 <copyin+0x30>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001710:	86ea                	mv	a3,s10
    80001712:	8652                	mv	a2,s4
    80001714:	85e6                	mv	a1,s9
    80001716:	855e                	mv	a0,s7
    80001718:	e57ff0ef          	jal	8000156e <vmfault>
    8000171c:	fd4d                	bnez	a0,800016d6 <copyin+0x30>
        return -1;
    8000171e:	557d                	li	a0,-1
    80001720:	a011                	j	80001724 <copyin+0x7e>
  return 0;
    80001722:	4501                	li	a0,0
}
    80001724:	60e6                	ld	ra,88(sp)
    80001726:	6446                	ld	s0,80(sp)
    80001728:	64a6                	ld	s1,72(sp)
    8000172a:	6906                	ld	s2,64(sp)
    8000172c:	79e2                	ld	s3,56(sp)
    8000172e:	7a42                	ld	s4,48(sp)
    80001730:	7aa2                	ld	s5,40(sp)
    80001732:	7b02                	ld	s6,32(sp)
    80001734:	6be2                	ld	s7,24(sp)
    80001736:	6c42                	ld	s8,16(sp)
    80001738:	6ca2                	ld	s9,8(sp)
    8000173a:	6d02                	ld	s10,0(sp)
    8000173c:	6125                	addi	sp,sp,96
    8000173e:	8082                	ret
  return 0;
    80001740:	4501                	li	a0,0
}
    80001742:	8082                	ret

0000000080001744 <copyinstr>:
  while (got_null == 0 && max > 0) {
    80001744:	c771                	beqz	a4,80001810 <copyinstr+0xcc>
{
    80001746:	711d                	addi	sp,sp,-96
    80001748:	ec86                	sd	ra,88(sp)
    8000174a:	e8a2                	sd	s0,80(sp)
    8000174c:	e4a6                	sd	s1,72(sp)
    8000174e:	e0ca                	sd	s2,64(sp)
    80001750:	fc4e                	sd	s3,56(sp)
    80001752:	f852                	sd	s4,48(sp)
    80001754:	f456                	sd	s5,40(sp)
    80001756:	f05a                	sd	s6,32(sp)
    80001758:	ec5e                	sd	s7,24(sp)
    8000175a:	e862                	sd	s8,16(sp)
    8000175c:	e466                	sd	s9,8(sp)
    8000175e:	1080                	addi	s0,sp,96
    80001760:	8b2a                	mv	s6,a0
    80001762:	8c2e                	mv	s8,a1
    80001764:	8932                	mv	s2,a2
    80001766:	84b6                	mv	s1,a3
    80001768:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    8000176a:	7bfd                	lui	s7,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    8000176c:	4c85                	li	s9,1
    n = PGSIZE - (srcva - va0);
    8000176e:	6a85                	lui	s5,0x1
    80001770:	a881                	j	800017c0 <copyinstr+0x7c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001772:	86e6                	mv	a3,s9
    80001774:	864e                	mv	a2,s3
    80001776:	85e2                	mv	a1,s8
    80001778:	855a                	mv	a0,s6
    8000177a:	df5ff0ef          	jal	8000156e <vmfault>
    8000177e:	e921                	bnez	a0,800017ce <copyinstr+0x8a>
        return -1;
    80001780:	557d                	li	a0,-1
    80001782:	a801                	j	80001792 <copyinstr+0x4e>
        *dst = '\0';
    80001784:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffde148>
        got_null = 1;
    80001788:	4785                	li	a5,1
  if (got_null) {
    8000178a:	0017c793          	xori	a5,a5,1
    8000178e:	40f0053b          	negw	a0,a5
}
    80001792:	60e6                	ld	ra,88(sp)
    80001794:	6446                	ld	s0,80(sp)
    80001796:	64a6                	ld	s1,72(sp)
    80001798:	6906                	ld	s2,64(sp)
    8000179a:	79e2                	ld	s3,56(sp)
    8000179c:	7a42                	ld	s4,48(sp)
    8000179e:	7aa2                	ld	s5,40(sp)
    800017a0:	7b02                	ld	s6,32(sp)
    800017a2:	6be2                	ld	s7,24(sp)
    800017a4:	6c42                	ld	s8,16(sp)
    800017a6:	6ca2                	ld	s9,8(sp)
    800017a8:	6125                	addi	sp,sp,96
    800017aa:	8082                	ret
    800017ac:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    800017b0:	974a                	add	a4,a4,s2
      --max;
    800017b2:	40a70a33          	sub	s4,a4,a0
    srcva = va0 + PGSIZE;
    800017b6:	015984b3          	add	s1,s3,s5
  while (got_null == 0 && max > 0) {
    800017ba:	04e50563          	beq	a0,a4,80001804 <copyinstr+0xc0>
{
    800017be:	893e                	mv	s2,a5
    va0 = PGROUNDDOWN(srcva);
    800017c0:	0174f9b3          	and	s3,s1,s7
    pa0 = walkaddr(pagetable, va0);
    800017c4:	85ce                	mv	a1,s3
    800017c6:	855a                	mv	a0,s6
    800017c8:	8cbff0ef          	jal	80001092 <walkaddr>
    if (pa0 == 0) {
    800017cc:	d15d                	beqz	a0,80001772 <copyinstr+0x2e>
    n = PGSIZE - (srcva - va0);
    800017ce:	40998633          	sub	a2,s3,s1
    800017d2:	9656                	add	a2,a2,s5
    if (n > max)
    800017d4:	00ca7363          	bgeu	s4,a2,800017da <copyinstr+0x96>
    800017d8:	8652                	mv	a2,s4
    while (n > 0) {
    800017da:	c61d                	beqz	a2,80001808 <copyinstr+0xc4>
    char *p = (char *)(pa0 + (srcva - va0));
    800017dc:	03449593          	slli	a1,s1,0x34
    800017e0:	91d1                	srli	a1,a1,0x34
    800017e2:	95aa                	add	a1,a1,a0
    800017e4:	87ca                	mv	a5,s2
      if (*p == '\0') {
    800017e6:	412585b3          	sub	a1,a1,s2
    while (n > 0) {
    800017ea:	964a                	add	a2,a2,s2
    800017ec:	853e                	mv	a0,a5
      if (*p == '\0') {
    800017ee:	00f58733          	add	a4,a1,a5
    800017f2:	00074683          	lbu	a3,0(a4)
    800017f6:	d6d9                	beqz	a3,80001784 <copyinstr+0x40>
        *dst = *p;
    800017f8:	00d78023          	sb	a3,0(a5)
      dst++;
    800017fc:	0785                	addi	a5,a5,1
    while (n > 0) {
    800017fe:	fec797e3          	bne	a5,a2,800017ec <copyinstr+0xa8>
    80001802:	b76d                	j	800017ac <copyinstr+0x68>
    srcva = va0 + PGSIZE;
    80001804:	4781                	li	a5,0
    80001806:	b751                	j	8000178a <copyinstr+0x46>
    80001808:	6485                	lui	s1,0x1
    8000180a:	94ce                	add	s1,s1,s3
    8000180c:	87ca                	mv	a5,s2
    8000180e:	bf45                	j	800017be <copyinstr+0x7a>
    80001810:	4781                	li	a5,0
  if (got_null) {
    80001812:	0017c793          	xori	a5,a5,1
    80001816:	40f0053b          	negw	a0,a5
}
    8000181a:	8082                	ret

000000008000181c <vtop>:
vtop(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    8000181c:	57fd                	li	a5,-1
    8000181e:	83e9                	srli	a5,a5,0x1a
    80001820:	00b7f463          	bgeu	a5,a1,80001828 <vtop+0xc>
    return 0;
    80001824:	4501                	li	a0,0

  pa = PTE2PA(*pte);

  // Combine physical frame address with page offset.
  return pa | (va & (PGSIZE - 1));
}
    80001826:	8082                	ret
{
    80001828:	1101                	addi	sp,sp,-32
    8000182a:	ec06                	sd	ra,24(sp)
    8000182c:	e822                	sd	s0,16(sp)
    8000182e:	e426                	sd	s1,8(sp)
    80001830:	1000                	addi	s0,sp,32
  pte = walk(pagetable, va, 0);
    80001832:	4601                	li	a2,0
    80001834:	84ae                	mv	s1,a1
    80001836:	fc4ff0ef          	jal	80000ffa <walk>
  if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0)
    8000183a:	c519                	beqz	a0,80001848 <vtop+0x2c>
    8000183c:	6108                	ld	a0,0(a0)
    8000183e:	01157713          	andi	a4,a0,17
    80001842:	47c5                	li	a5,17
    80001844:	00f70863          	beq	a4,a5,80001854 <vtop+0x38>
    return 0;
    80001848:	4501                	li	a0,0
}
    8000184a:	60e2                	ld	ra,24(sp)
    8000184c:	6442                	ld	s0,16(sp)
    8000184e:	64a2                	ld	s1,8(sp)
    80001850:	6105                	addi	sp,sp,32
    80001852:	8082                	ret
  pa = PTE2PA(*pte);
    80001854:	8129                	srli	a0,a0,0xa
    80001856:	0532                	slli	a0,a0,0xc
  return pa | (va & (PGSIZE - 1));
    80001858:	03449593          	slli	a1,s1,0x34
    8000185c:	91d1                	srli	a1,a1,0x34
    8000185e:	8d4d                	or	a0,a0,a1
    80001860:	b7ed                	j	8000184a <vtop+0x2e>

0000000080001862 <pageinfo>:
int
pageinfo(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;

  if (va >= MAXVA)
    80001862:	57fd                	li	a5,-1
    80001864:	83e9                	srli	a5,a5,0x1a
    80001866:	04b7ee63          	bltu	a5,a1,800018c2 <pageinfo+0x60>
{
    8000186a:	1101                	addi	sp,sp,-32
    8000186c:	ec06                	sd	ra,24(sp)
    8000186e:	e822                	sd	s0,16(sp)
    80001870:	e426                	sd	s1,8(sp)
    80001872:	1000                	addi	s0,sp,32
    80001874:	84ae                	mv	s1,a1
    return -1;

  pte = walk(pagetable, va, 0);
    80001876:	4601                	li	a2,0
    80001878:	f82ff0ef          	jal	80000ffa <walk>
  if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0) {
    8000187c:	c91d                	beqz	a0,800018b2 <pageinfo+0x50>
    8000187e:	6110                	ld	a2,0(a0)
    80001880:	01167713          	andi	a4,a2,17
    80001884:	47c5                	li	a5,17
    80001886:	02f71663          	bne	a4,a5,800018b2 <pageinfo+0x50>
    printk("pageinfo: address is not mapped\n");
    return -1;
  }

  printk("pageinfo: VA=%p PA=%p P=%d W=%d U=%d\n",
    8000188a:	00265713          	srli	a4,a2,0x2
         (void*)va, (void*)PTE2PA(*pte),
    8000188e:	8229                	srli	a2,a2,0xa
  printk("pageinfo: VA=%p PA=%p P=%d W=%d U=%d\n",
    80001890:	4785                	li	a5,1
    80001892:	8f7d                	and	a4,a4,a5
    80001894:	86be                	mv	a3,a5
    80001896:	0632                	slli	a2,a2,0xc
    80001898:	85a6                	mv	a1,s1
    8000189a:	00006517          	auipc	a0,0x6
    8000189e:	97650513          	addi	a0,a0,-1674 # 80007210 <etext+0x210>
    800018a2:	c6ffe0ef          	jal	80000510 <printk>
         (*pte & PTE_V) != 0,
         (*pte & PTE_W) != 0,
         (*pte & PTE_U) != 0);
  return 0;
    800018a6:	4501                	li	a0,0
}
    800018a8:	60e2                	ld	ra,24(sp)
    800018aa:	6442                	ld	s0,16(sp)
    800018ac:	64a2                	ld	s1,8(sp)
    800018ae:	6105                	addi	sp,sp,32
    800018b0:	8082                	ret
    printk("pageinfo: address is not mapped\n");
    800018b2:	00006517          	auipc	a0,0x6
    800018b6:	93650513          	addi	a0,a0,-1738 # 800071e8 <etext+0x1e8>
    800018ba:	c57fe0ef          	jal	80000510 <printk>
    return -1;
    800018be:	557d                	li	a0,-1
    800018c0:	b7e5                	j	800018a8 <pageinfo+0x46>
    800018c2:	557d                	li	a0,-1
}
    800018c4:	8082                	ret

00000000800018c6 <setreadonly>:
int
setreadonly(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;

  if (va >= MAXVA)
    800018c6:	57fd                	li	a5,-1
    800018c8:	83e9                	srli	a5,a5,0x1a
    800018ca:	02b7eb63          	bltu	a5,a1,80001900 <setreadonly+0x3a>
{
    800018ce:	1141                	addi	sp,sp,-16
    800018d0:	e406                	sd	ra,8(sp)
    800018d2:	e022                	sd	s0,0(sp)
    800018d4:	0800                	addi	s0,sp,16
    return -1;

  pte = walk(pagetable, va, 0);
    800018d6:	4601                	li	a2,0
    800018d8:	f22ff0ef          	jal	80000ffa <walk>
  if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0)
    800018dc:	c105                	beqz	a0,800018fc <setreadonly+0x36>
    800018de:	611c                	ld	a5,0(a0)
    800018e0:	0117f693          	andi	a3,a5,17
    800018e4:	4745                	li	a4,17
    800018e6:	00e69b63          	bne	a3,a4,800018fc <setreadonly+0x36>
    return -1;

  *pte &= ~PTE_W;
    800018ea:	9bed                	andi	a5,a5,-5
    800018ec:	e11c                	sd	a5,0(a0)
    800018ee:	12000073          	sfence.vma
  sfence_vma();
  return 0;
    800018f2:	4501                	li	a0,0
}
    800018f4:	60a2                	ld	ra,8(sp)
    800018f6:	6402                	ld	s0,0(sp)
    800018f8:	0141                	addi	sp,sp,16
    800018fa:	8082                	ret
    return -1;
    800018fc:	557d                	li	a0,-1
    800018fe:	bfdd                	j	800018f4 <setreadonly+0x2e>
    80001900:	557d                	li	a0,-1
}
    80001902:	8082                	ret

0000000080001904 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001904:	715d                	addi	sp,sp,-80
    80001906:	e486                	sd	ra,72(sp)
    80001908:	e0a2                	sd	s0,64(sp)
    8000190a:	fc26                	sd	s1,56(sp)
    8000190c:	f84a                	sd	s2,48(sp)
    8000190e:	f44e                	sd	s3,40(sp)
    80001910:	f052                	sd	s4,32(sp)
    80001912:	ec56                	sd	s5,24(sp)
    80001914:	e85a                	sd	s6,16(sp)
    80001916:	e45e                	sd	s7,8(sp)
    80001918:	0880                	addi	s0,sp,80
    8000191a:	8aaa                	mv	s5,a0
    8000191c:	4481                	li	s1,0

  for (p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    8000191e:	ff4df937          	lui	s2,0xff4df
    80001922:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdb05>
    80001926:	0936                	slli	s2,s2,0xd
    80001928:	6f590913          	addi	s2,s2,1781
    8000192c:	0936                	slli	s2,s2,0xd
    8000192e:	bd390913          	addi	s2,s2,-1069
    80001932:	0932                	slli	s2,s2,0xc
    80001934:	7a790913          	addi	s2,s2,1959
    80001938:	040009b7          	lui	s3,0x4000
    8000193c:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000193e:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001940:	4b99                	li	s7,6
    80001942:	6b05                	lui	s6,0x1
  for (p = proc; p < &proc[NPROC]; p++) {
    80001944:	6a19                	lui	s4,0x6
    80001946:	c00a0a13          	addi	s4,s4,-1024 # 5c00 <_entry-0x7fffa400>
    char *pa = kalloc();
    8000194a:	9f8ff0ef          	jal	80000b42 <kalloc>
    8000194e:	862a                	mv	a2,a0
    if (pa == 0)
    80001950:	cd15                	beqz	a0,8000198c <proc_mapstacks+0x88>
    uint64 va = KSTACK((int)(p - proc));
    80001952:	4044d593          	srai	a1,s1,0x4
    80001956:	032585b3          	mul	a1,a1,s2
    8000195a:	05b6                	slli	a1,a1,0xd
    8000195c:	6789                	lui	a5,0x2
    8000195e:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001960:	875e                	mv	a4,s7
    80001962:	86da                	mv	a3,s6
    80001964:	40b985b3          	sub	a1,s3,a1
    80001968:	8556                	mv	a0,s5
    8000196a:	813ff0ef          	jal	8000117c <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000196e:	17048493          	addi	s1,s1,368 # 1170 <_entry-0x7fffee90>
    80001972:	fd449ce3          	bne	s1,s4,8000194a <proc_mapstacks+0x46>
  }
}
    80001976:	60a6                	ld	ra,72(sp)
    80001978:	6406                	ld	s0,64(sp)
    8000197a:	74e2                	ld	s1,56(sp)
    8000197c:	7942                	ld	s2,48(sp)
    8000197e:	79a2                	ld	s3,40(sp)
    80001980:	7a02                	ld	s4,32(sp)
    80001982:	6ae2                	ld	s5,24(sp)
    80001984:	6b42                	ld	s6,16(sp)
    80001986:	6ba2                	ld	s7,8(sp)
    80001988:	6161                	addi	sp,sp,80
    8000198a:	8082                	ret
      panic("kalloc");
    8000198c:	00006517          	auipc	a0,0x6
    80001990:	8ac50513          	addi	a0,a0,-1876 # 80007238 <etext+0x238>
    80001994:	eb5fe0ef          	jal	80000848 <panic>

0000000080001998 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001998:	7139                	addi	sp,sp,-64
    8000199a:	fc06                	sd	ra,56(sp)
    8000199c:	f822                	sd	s0,48(sp)
    8000199e:	f426                	sd	s1,40(sp)
    800019a0:	f04a                	sd	s2,32(sp)
    800019a2:	ec4e                	sd	s3,24(sp)
    800019a4:	e852                	sd	s4,16(sp)
    800019a6:	e456                	sd	s5,8(sp)
    800019a8:	e05a                	sd	s6,0(sp)
    800019aa:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    800019ac:	00006597          	auipc	a1,0x6
    800019b0:	89458593          	addi	a1,a1,-1900 # 80007240 <etext+0x240>
    800019b4:	0000e517          	auipc	a0,0xe
    800019b8:	0f450513          	addi	a0,a0,244 # 8000faa8 <pid_lock>
    800019bc:	a76ff0ef          	jal	80000c32 <initlock>
  initlock(&wait_lock, "wait_lock");
    800019c0:	00006597          	auipc	a1,0x6
    800019c4:	88858593          	addi	a1,a1,-1912 # 80007248 <etext+0x248>
    800019c8:	0000e517          	auipc	a0,0xe
    800019cc:	0f850513          	addi	a0,a0,248 # 8000fac0 <wait_lock>
    800019d0:	a62ff0ef          	jal	80000c32 <initlock>
    800019d4:	4901                	li	s2,0
  for (p = proc; p < &proc[NPROC]; p++) {
    800019d6:	0000e497          	auipc	s1,0xe
    800019da:	50248493          	addi	s1,s1,1282 # 8000fed8 <proc>
    initlock(&p->lock, "proc");
    800019de:	00006a97          	auipc	s5,0x6
    800019e2:	87aa8a93          	addi	s5,s5,-1926 # 80007258 <etext+0x258>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    800019e6:	ff4df9b7          	lui	s3,0xff4df
    800019ea:	9bd98993          	addi	s3,s3,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdb05>
    800019ee:	09b6                	slli	s3,s3,0xd
    800019f0:	6f598993          	addi	s3,s3,1781
    800019f4:	09b6                	slli	s3,s3,0xd
    800019f6:	bd398993          	addi	s3,s3,-1069
    800019fa:	09b2                	slli	s3,s3,0xc
    800019fc:	7a798993          	addi	s3,s3,1959
    80001a00:	04000a37          	lui	s4,0x4000
    80001a04:	1a7d                	addi	s4,s4,-1 # 3ffffff <_entry-0x7c000001>
    80001a06:	0a32                	slli	s4,s4,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001a08:	00014b17          	auipc	s6,0x14
    80001a0c:	0d0b0b13          	addi	s6,s6,208 # 80015ad8 <tickslock>
    initlock(&p->lock, "proc");
    80001a10:	85d6                	mv	a1,s5
    80001a12:	8526                	mv	a0,s1
    80001a14:	a1eff0ef          	jal	80000c32 <initlock>
    p->state = UNUSED;
    80001a18:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    80001a1c:	40495793          	srai	a5,s2,0x4
    80001a20:	033787b3          	mul	a5,a5,s3
    80001a24:	07b6                	slli	a5,a5,0xd
    80001a26:	6709                	lui	a4,0x2
    80001a28:	9fb9                	addw	a5,a5,a4
    80001a2a:	40fa07b3          	sub	a5,s4,a5
    80001a2e:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    80001a30:	17048493          	addi	s1,s1,368
    80001a34:	17090913          	addi	s2,s2,368
    80001a38:	fd649ce3          	bne	s1,s6,80001a10 <procinit+0x78>
  }
}
    80001a3c:	70e2                	ld	ra,56(sp)
    80001a3e:	7442                	ld	s0,48(sp)
    80001a40:	74a2                	ld	s1,40(sp)
    80001a42:	7902                	ld	s2,32(sp)
    80001a44:	69e2                	ld	s3,24(sp)
    80001a46:	6a42                	ld	s4,16(sp)
    80001a48:	6aa2                	ld	s5,8(sp)
    80001a4a:	6b02                	ld	s6,0(sp)
    80001a4c:	6121                	addi	sp,sp,64
    80001a4e:	8082                	ret

0000000080001a50 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001a50:	1141                	addi	sp,sp,-16
    80001a52:	e406                	sd	ra,8(sp)
    80001a54:	e022                	sd	s0,0(sp)
    80001a56:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    80001a58:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001a5a:	2501                	sext.w	a0,a0
    80001a5c:	60a2                	ld	ra,8(sp)
    80001a5e:	6402                	ld	s0,0(sp)
    80001a60:	0141                	addi	sp,sp,16
    80001a62:	8082                	ret

0000000080001a64 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    80001a64:	1141                	addi	sp,sp,-16
    80001a66:	e406                	sd	ra,8(sp)
    80001a68:	e022                	sd	s0,0(sp)
    80001a6a:	0800                	addi	s0,sp,16
    80001a6c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001a6e:	2781                	sext.w	a5,a5
    80001a70:	079e                	slli	a5,a5,0x7
  return c;
}
    80001a72:	0000e517          	auipc	a0,0xe
    80001a76:	06650513          	addi	a0,a0,102 # 8000fad8 <cpus>
    80001a7a:	953e                	add	a0,a0,a5
    80001a7c:	60a2                	ld	ra,8(sp)
    80001a7e:	6402                	ld	s0,0(sp)
    80001a80:	0141                	addi	sp,sp,16
    80001a82:	8082                	ret

0000000080001a84 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    80001a84:	1101                	addi	sp,sp,-32
    80001a86:	ec06                	sd	ra,24(sp)
    80001a88:	e822                	sd	s0,16(sp)
    80001a8a:	e426                	sd	s1,8(sp)
    80001a8c:	1000                	addi	s0,sp,32
  push_off();
    80001a8e:	9eaff0ef          	jal	80000c78 <push_off>
    80001a92:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001a94:	2781                	sext.w	a5,a5
    80001a96:	079e                	slli	a5,a5,0x7
    80001a98:	0000e717          	auipc	a4,0xe
    80001a9c:	01070713          	addi	a4,a4,16 # 8000faa8 <pid_lock>
    80001aa0:	97ba                	add	a5,a5,a4
    80001aa2:	7b9c                	ld	a5,48(a5)
    80001aa4:	84be                	mv	s1,a5
  pop_off();
    80001aa6:	a48ff0ef          	jal	80000cee <pop_off>
  return p;
}
    80001aaa:	8526                	mv	a0,s1
    80001aac:	60e2                	ld	ra,24(sp)
    80001aae:	6442                	ld	s0,16(sp)
    80001ab0:	64a2                	ld	s1,8(sp)
    80001ab2:	6105                	addi	sp,sp,32
    80001ab4:	8082                	ret

0000000080001ab6 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001ab6:	7179                	addi	sp,sp,-48
    80001ab8:	f406                	sd	ra,40(sp)
    80001aba:	f022                	sd	s0,32(sp)
    80001abc:	ec26                	sd	s1,24(sp)
    80001abe:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001ac0:	fc5ff0ef          	jal	80001a84 <myproc>
    80001ac4:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001ac6:	a70ff0ef          	jal	80000d36 <release>

  if (__atomic_load_n(&first, __ATOMIC_ACQUIRE)) {
    80001aca:	00006797          	auipc	a5,0x6
    80001ace:	e8678793          	addi	a5,a5,-378 # 80007950 <first.1>
    80001ad2:	439c                	lw	a5,0(a5)
    80001ad4:	0230000f          	fence	r,rw
    80001ad8:	2781                	sext.w	a5,a5
    80001ada:	c3a1                	beqz	a5,80001b1a <forkret+0x64>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001adc:	4505                	li	a0,1
    80001ade:	47d010ef          	jal	8000375a <fsinit>

    // ensure other cores see first=0.
    __atomic_store_n(&first, 0, __ATOMIC_RELEASE);
    80001ae2:	00006797          	auipc	a5,0x6
    80001ae6:	e6e78793          	addi	a5,a5,-402 # 80007950 <first.1>
    80001aea:	0310000f          	fence	rw,w
    80001aee:	0007a023          	sw	zero,0(a5)

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    80001af2:	00005797          	auipc	a5,0x5
    80001af6:	76e78793          	addi	a5,a5,1902 # 80007260 <etext+0x260>
    80001afa:	fcf43823          	sd	a5,-48(s0)
    80001afe:	fc043c23          	sd	zero,-40(s0)
    80001b02:	fd040593          	addi	a1,s0,-48
    80001b06:	853e                	mv	a0,a5
    80001b08:	6b9020ef          	jal	800049c0 <kexec>
    80001b0c:	6cbc                	ld	a5,88(s1)
    80001b0e:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001b10:	6cbc                	ld	a5,88(s1)
    80001b12:	7bb8                	ld	a4,112(a5)
    80001b14:	57fd                	li	a5,-1
    80001b16:	02f70d63          	beq	a4,a5,80001b50 <forkret+0x9a>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001b1a:	31d000ef          	jal	80002636 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001b1e:	68a8                	ld	a0,80(s1)
    80001b20:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001b22:	04000737          	lui	a4,0x4000
    80001b26:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001b28:	0732                	slli	a4,a4,0xc
    80001b2a:	00004797          	auipc	a5,0x4
    80001b2e:	57278793          	addi	a5,a5,1394 # 8000609c <userret>
    80001b32:	00004697          	auipc	a3,0x4
    80001b36:	4ce68693          	addi	a3,a3,1230 # 80006000 <_trampoline>
    80001b3a:	8f95                	sub	a5,a5,a3
    80001b3c:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001b3e:	577d                	li	a4,-1
    80001b40:	177e                	slli	a4,a4,0x3f
    80001b42:	8d59                	or	a0,a0,a4
    80001b44:	9782                	jalr	a5
}
    80001b46:	70a2                	ld	ra,40(sp)
    80001b48:	7402                	ld	s0,32(sp)
    80001b4a:	64e2                	ld	s1,24(sp)
    80001b4c:	6145                	addi	sp,sp,48
    80001b4e:	8082                	ret
      panic("exec");
    80001b50:	00005517          	auipc	a0,0x5
    80001b54:	71850513          	addi	a0,a0,1816 # 80007268 <etext+0x268>
    80001b58:	cf1fe0ef          	jal	80000848 <panic>

0000000080001b5c <allocpid>:
{
    80001b5c:	1101                	addi	sp,sp,-32
    80001b5e:	ec06                	sd	ra,24(sp)
    80001b60:	e822                	sd	s0,16(sp)
    80001b62:	e426                	sd	s1,8(sp)
    80001b64:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001b66:	0000e517          	auipc	a0,0xe
    80001b6a:	f4250513          	addi	a0,a0,-190 # 8000faa8 <pid_lock>
    80001b6e:	944ff0ef          	jal	80000cb2 <acquire>
  pid = nextpid;
    80001b72:	00006797          	auipc	a5,0x6
    80001b76:	de278793          	addi	a5,a5,-542 # 80007954 <nextpid>
    80001b7a:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001b7c:	0014871b          	addiw	a4,s1,1
    80001b80:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001b82:	0000e517          	auipc	a0,0xe
    80001b86:	f2650513          	addi	a0,a0,-218 # 8000faa8 <pid_lock>
    80001b8a:	9acff0ef          	jal	80000d36 <release>
}
    80001b8e:	8526                	mv	a0,s1
    80001b90:	60e2                	ld	ra,24(sp)
    80001b92:	6442                	ld	s0,16(sp)
    80001b94:	64a2                	ld	s1,8(sp)
    80001b96:	6105                	addi	sp,sp,32
    80001b98:	8082                	ret

0000000080001b9a <proc_pagetable>:
{
    80001b9a:	1101                	addi	sp,sp,-32
    80001b9c:	ec06                	sd	ra,24(sp)
    80001b9e:	e822                	sd	s0,16(sp)
    80001ba0:	e426                	sd	s1,8(sp)
    80001ba2:	e04a                	sd	s2,0(sp)
    80001ba4:	1000                	addi	s0,sp,32
    80001ba6:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001ba8:	ec2ff0ef          	jal	8000126a <uvmcreate>
    80001bac:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001bae:	cd05                	beqz	a0,80001be6 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    80001bb0:	4729                	li	a4,10
    80001bb2:	00004697          	auipc	a3,0x4
    80001bb6:	44e68693          	addi	a3,a3,1102 # 80006000 <_trampoline>
    80001bba:	6605                	lui	a2,0x1
    80001bbc:	040005b7          	lui	a1,0x4000
    80001bc0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001bc2:	05b2                	slli	a1,a1,0xc
    80001bc4:	d06ff0ef          	jal	800010ca <mappages>
    80001bc8:	02054663          	bltz	a0,80001bf4 <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    80001bcc:	4719                	li	a4,6
    80001bce:	05893683          	ld	a3,88(s2)
    80001bd2:	6605                	lui	a2,0x1
    80001bd4:	020005b7          	lui	a1,0x2000
    80001bd8:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001bda:	05b6                	slli	a1,a1,0xd
    80001bdc:	8526                	mv	a0,s1
    80001bde:	cecff0ef          	jal	800010ca <mappages>
    80001be2:	00054f63          	bltz	a0,80001c00 <proc_pagetable+0x66>
}
    80001be6:	8526                	mv	a0,s1
    80001be8:	60e2                	ld	ra,24(sp)
    80001bea:	6442                	ld	s0,16(sp)
    80001bec:	64a2                	ld	s1,8(sp)
    80001bee:	6902                	ld	s2,0(sp)
    80001bf0:	6105                	addi	sp,sp,32
    80001bf2:	8082                	ret
    uvmfree(pagetable, 0);
    80001bf4:	4581                	li	a1,0
    80001bf6:	8526                	mv	a0,s1
    80001bf8:	865ff0ef          	jal	8000145c <uvmfree>
    return 0;
    80001bfc:	4481                	li	s1,0
    80001bfe:	b7e5                	j	80001be6 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001c00:	4681                	li	a3,0
    80001c02:	4605                	li	a2,1
    80001c04:	040005b7          	lui	a1,0x4000
    80001c08:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001c0a:	05b2                	slli	a1,a1,0xc
    80001c0c:	8526                	mv	a0,s1
    80001c0e:	e82ff0ef          	jal	80001290 <uvmunmap>
    uvmfree(pagetable, 0);
    80001c12:	4581                	li	a1,0
    80001c14:	8526                	mv	a0,s1
    80001c16:	847ff0ef          	jal	8000145c <uvmfree>
    return 0;
    80001c1a:	b7cd                	j	80001bfc <proc_pagetable+0x62>

0000000080001c1c <proc_freepagetable>:
{
    80001c1c:	1101                	addi	sp,sp,-32
    80001c1e:	ec06                	sd	ra,24(sp)
    80001c20:	e822                	sd	s0,16(sp)
    80001c22:	e426                	sd	s1,8(sp)
    80001c24:	e04a                	sd	s2,0(sp)
    80001c26:	1000                	addi	s0,sp,32
    80001c28:	84aa                	mv	s1,a0
    80001c2a:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001c2c:	4681                	li	a3,0
    80001c2e:	4605                	li	a2,1
    80001c30:	040005b7          	lui	a1,0x4000
    80001c34:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001c36:	05b2                	slli	a1,a1,0xc
    80001c38:	e58ff0ef          	jal	80001290 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001c3c:	4681                	li	a3,0
    80001c3e:	4605                	li	a2,1
    80001c40:	020005b7          	lui	a1,0x2000
    80001c44:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001c46:	05b6                	slli	a1,a1,0xd
    80001c48:	8526                	mv	a0,s1
    80001c4a:	e46ff0ef          	jal	80001290 <uvmunmap>
  uvmfree(pagetable, sz);
    80001c4e:	85ca                	mv	a1,s2
    80001c50:	8526                	mv	a0,s1
    80001c52:	80bff0ef          	jal	8000145c <uvmfree>
}
    80001c56:	60e2                	ld	ra,24(sp)
    80001c58:	6442                	ld	s0,16(sp)
    80001c5a:	64a2                	ld	s1,8(sp)
    80001c5c:	6902                	ld	s2,0(sp)
    80001c5e:	6105                	addi	sp,sp,32
    80001c60:	8082                	ret

0000000080001c62 <freeproc>:
{
    80001c62:	1101                	addi	sp,sp,-32
    80001c64:	ec06                	sd	ra,24(sp)
    80001c66:	e822                	sd	s0,16(sp)
    80001c68:	e426                	sd	s1,8(sp)
    80001c6a:	1000                	addi	s0,sp,32
    80001c6c:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001c6e:	6d28                	ld	a0,88(a0)
    80001c70:	c119                	beqz	a0,80001c76 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001c72:	dc5fe0ef          	jal	80000a36 <kfree>
  p->trapframe = 0;
    80001c76:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001c7a:	68a8                	ld	a0,80(s1)
    80001c7c:	c501                	beqz	a0,80001c84 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001c7e:	64ac                	ld	a1,72(s1)
    80001c80:	f9dff0ef          	jal	80001c1c <proc_freepagetable>
  p->pagetable = 0;
    80001c84:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001c88:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001c8c:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001c90:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001c94:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001c98:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001c9c:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ca0:	0004ac23          	sw	zero,24(s1)
}
    80001ca4:	60e2                	ld	ra,24(sp)
    80001ca6:	6442                	ld	s0,16(sp)
    80001ca8:	64a2                	ld	s1,8(sp)
    80001caa:	6105                	addi	sp,sp,32
    80001cac:	8082                	ret

0000000080001cae <allocproc>:
{
    80001cae:	1101                	addi	sp,sp,-32
    80001cb0:	ec06                	sd	ra,24(sp)
    80001cb2:	e822                	sd	s0,16(sp)
    80001cb4:	e426                	sd	s1,8(sp)
    80001cb6:	e04a                	sd	s2,0(sp)
    80001cb8:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001cba:	0000e497          	auipc	s1,0xe
    80001cbe:	21e48493          	addi	s1,s1,542 # 8000fed8 <proc>
    80001cc2:	00014917          	auipc	s2,0x14
    80001cc6:	e1690913          	addi	s2,s2,-490 # 80015ad8 <tickslock>
    acquire(&p->lock);
    80001cca:	8526                	mv	a0,s1
    80001ccc:	fe7fe0ef          	jal	80000cb2 <acquire>
    if (p->state == UNUSED) {
    80001cd0:	4c9c                	lw	a5,24(s1)
    80001cd2:	cb91                	beqz	a5,80001ce6 <allocproc+0x38>
      release(&p->lock);
    80001cd4:	8526                	mv	a0,s1
    80001cd6:	860ff0ef          	jal	80000d36 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001cda:	17048493          	addi	s1,s1,368
    80001cde:	ff2496e3          	bne	s1,s2,80001cca <allocproc+0x1c>
  return 0;
    80001ce2:	4481                	li	s1,0
    80001ce4:	a09d                	j	80001d4a <allocproc+0x9c>
  p->pid = allocpid();
    80001ce6:	e77ff0ef          	jal	80001b5c <allocpid>
    80001cea:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001cec:	4785                	li	a5,1
    80001cee:	cc9c                	sw	a5,24(s1)
  acquire(&tickslock);
    80001cf0:	00014517          	auipc	a0,0x14
    80001cf4:	de850513          	addi	a0,a0,-536 # 80015ad8 <tickslock>
    80001cf8:	fbbfe0ef          	jal	80000cb2 <acquire>
  p->ctime = ticks;
    80001cfc:	00006797          	auipc	a5,0x6
    80001d00:	c847e783          	lwu	a5,-892(a5) # 80007980 <ticks>
    80001d04:	16f4b423          	sd	a5,360(s1)
  release(&tickslock);
    80001d08:	00014517          	auipc	a0,0x14
    80001d0c:	dd050513          	addi	a0,a0,-560 # 80015ad8 <tickslock>
    80001d10:	826ff0ef          	jal	80000d36 <release>
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001d14:	e2ffe0ef          	jal	80000b42 <kalloc>
    80001d18:	892a                	mv	s2,a0
    80001d1a:	eca8                	sd	a0,88(s1)
    80001d1c:	cd15                	beqz	a0,80001d58 <allocproc+0xaa>
  p->pagetable = proc_pagetable(p);
    80001d1e:	8526                	mv	a0,s1
    80001d20:	e7bff0ef          	jal	80001b9a <proc_pagetable>
    80001d24:	892a                	mv	s2,a0
    80001d26:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001d28:	c121                	beqz	a0,80001d68 <allocproc+0xba>
  memset(&p->context, 0, sizeof(p->context));
    80001d2a:	07000613          	li	a2,112
    80001d2e:	4581                	li	a1,0
    80001d30:	06048513          	addi	a0,s1,96
    80001d34:	83aff0ef          	jal	80000d6e <memset>
  p->context.ra = (uint64)forkret;
    80001d38:	00000797          	auipc	a5,0x0
    80001d3c:	d7e78793          	addi	a5,a5,-642 # 80001ab6 <forkret>
    80001d40:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001d42:	60bc                	ld	a5,64(s1)
    80001d44:	6705                	lui	a4,0x1
    80001d46:	97ba                	add	a5,a5,a4
    80001d48:	f4bc                	sd	a5,104(s1)
}
    80001d4a:	8526                	mv	a0,s1
    80001d4c:	60e2                	ld	ra,24(sp)
    80001d4e:	6442                	ld	s0,16(sp)
    80001d50:	64a2                	ld	s1,8(sp)
    80001d52:	6902                	ld	s2,0(sp)
    80001d54:	6105                	addi	sp,sp,32
    80001d56:	8082                	ret
    freeproc(p);
    80001d58:	8526                	mv	a0,s1
    80001d5a:	f09ff0ef          	jal	80001c62 <freeproc>
    release(&p->lock);
    80001d5e:	8526                	mv	a0,s1
    80001d60:	fd7fe0ef          	jal	80000d36 <release>
    return 0;
    80001d64:	84ca                	mv	s1,s2
    80001d66:	b7d5                	j	80001d4a <allocproc+0x9c>
    freeproc(p);
    80001d68:	8526                	mv	a0,s1
    80001d6a:	ef9ff0ef          	jal	80001c62 <freeproc>
    release(&p->lock);
    80001d6e:	8526                	mv	a0,s1
    80001d70:	fc7fe0ef          	jal	80000d36 <release>
    return 0;
    80001d74:	84ca                	mv	s1,s2
    80001d76:	bfd1                	j	80001d4a <allocproc+0x9c>

0000000080001d78 <userinit>:
{
    80001d78:	1101                	addi	sp,sp,-32
    80001d7a:	ec06                	sd	ra,24(sp)
    80001d7c:	e822                	sd	s0,16(sp)
    80001d7e:	e426                	sd	s1,8(sp)
    80001d80:	1000                	addi	s0,sp,32
  p = allocproc();
    80001d82:	f2dff0ef          	jal	80001cae <allocproc>
    80001d86:	84aa                	mv	s1,a0
  initproc = p;
    80001d88:	00006797          	auipc	a5,0x6
    80001d8c:	bea7b823          	sd	a0,-1040(a5) # 80007978 <initproc>
  p->cwd = namei("/");
    80001d90:	00005517          	auipc	a0,0x5
    80001d94:	4e050513          	addi	a0,a0,1248 # 80007270 <etext+0x270>
    80001d98:	71b010ef          	jal	80003cb2 <namei>
    80001d9c:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001da0:	478d                	li	a5,3
    80001da2:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001da4:	8526                	mv	a0,s1
    80001da6:	f91fe0ef          	jal	80000d36 <release>
}
    80001daa:	60e2                	ld	ra,24(sp)
    80001dac:	6442                	ld	s0,16(sp)
    80001dae:	64a2                	ld	s1,8(sp)
    80001db0:	6105                	addi	sp,sp,32
    80001db2:	8082                	ret

0000000080001db4 <growproc>:
{
    80001db4:	1101                	addi	sp,sp,-32
    80001db6:	ec06                	sd	ra,24(sp)
    80001db8:	e822                	sd	s0,16(sp)
    80001dba:	e426                	sd	s1,8(sp)
    80001dbc:	e04a                	sd	s2,0(sp)
    80001dbe:	1000                	addi	s0,sp,32
    80001dc0:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001dc2:	cc3ff0ef          	jal	80001a84 <myproc>
    80001dc6:	892a                	mv	s2,a0
  sz = p->sz;
    80001dc8:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001dca:	02905b63          	blez	s1,80001e00 <growproc+0x4c>
    if (sz + n > TRAPFRAME) {
    80001dce:	00b48633          	add	a2,s1,a1
    80001dd2:	020007b7          	lui	a5,0x2000
    80001dd6:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001dd8:	07b6                	slli	a5,a5,0xd
    80001dda:	02c7e163          	bltu	a5,a2,80001dfc <growproc+0x48>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001dde:	4691                	li	a3,4
    80001de0:	6928                	ld	a0,80(a0)
    80001de2:	d7eff0ef          	jal	80001360 <uvmalloc>
    80001de6:	85aa                	mv	a1,a0
    80001de8:	c911                	beqz	a0,80001dfc <growproc+0x48>
  p->sz = sz;
    80001dea:	04b93423          	sd	a1,72(s2)
  return 0;
    80001dee:	4501                	li	a0,0
}
    80001df0:	60e2                	ld	ra,24(sp)
    80001df2:	6442                	ld	s0,16(sp)
    80001df4:	64a2                	ld	s1,8(sp)
    80001df6:	6902                	ld	s2,0(sp)
    80001df8:	6105                	addi	sp,sp,32
    80001dfa:	8082                	ret
      return -1;
    80001dfc:	557d                	li	a0,-1
    80001dfe:	bfcd                	j	80001df0 <growproc+0x3c>
  } else if (n < 0) {
    80001e00:	fe04d5e3          	bgez	s1,80001dea <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001e04:	00b48633          	add	a2,s1,a1
    80001e08:	6928                	ld	a0,80(a0)
    80001e0a:	d10ff0ef          	jal	8000131a <uvmdealloc>
    80001e0e:	85aa                	mv	a1,a0
    80001e10:	bfe9                	j	80001dea <growproc+0x36>

0000000080001e12 <kfork>:
{
    80001e12:	7139                	addi	sp,sp,-64
    80001e14:	fc06                	sd	ra,56(sp)
    80001e16:	f822                	sd	s0,48(sp)
    80001e18:	f426                	sd	s1,40(sp)
    80001e1a:	e456                	sd	s5,8(sp)
    80001e1c:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001e1e:	c67ff0ef          	jal	80001a84 <myproc>
    80001e22:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001e24:	e8bff0ef          	jal	80001cae <allocproc>
    80001e28:	c92d                	beqz	a0,80001e9a <kfork+0x88>
    80001e2a:	e852                	sd	s4,16(sp)
    80001e2c:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001e2e:	048ab603          	ld	a2,72(s5)
    80001e32:	692c                	ld	a1,80(a0)
    80001e34:	050ab503          	ld	a0,80(s5)
    80001e38:	e56ff0ef          	jal	8000148e <uvmcopy>
    80001e3c:	04054863          	bltz	a0,80001e8c <kfork+0x7a>
    80001e40:	f04a                	sd	s2,32(sp)
    80001e42:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001e44:	048ab783          	ld	a5,72(s5)
    80001e48:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001e4c:	058ab683          	ld	a3,88(s5)
    80001e50:	87b6                	mv	a5,a3
    80001e52:	058a3703          	ld	a4,88(s4)
    80001e56:	12068693          	addi	a3,a3,288
    80001e5a:	6388                	ld	a0,0(a5)
    80001e5c:	678c                	ld	a1,8(a5)
    80001e5e:	6b90                	ld	a2,16(a5)
    80001e60:	e308                	sd	a0,0(a4)
    80001e62:	e70c                	sd	a1,8(a4)
    80001e64:	eb10                	sd	a2,16(a4)
    80001e66:	6f90                	ld	a2,24(a5)
    80001e68:	ef10                	sd	a2,24(a4)
    80001e6a:	02078793          	addi	a5,a5,32
    80001e6e:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001e72:	fed794e3          	bne	a5,a3,80001e5a <kfork+0x48>
  np->trapframe->a0 = 0;
    80001e76:	058a3783          	ld	a5,88(s4)
    80001e7a:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001e7e:	0d0a8493          	addi	s1,s5,208
    80001e82:	0d0a0913          	addi	s2,s4,208
    80001e86:	150a8993          	addi	s3,s5,336
    80001e8a:	a831                	j	80001ea6 <kfork+0x94>
    freeproc(np);
    80001e8c:	8552                	mv	a0,s4
    80001e8e:	dd5ff0ef          	jal	80001c62 <freeproc>
    release(&np->lock);
    80001e92:	8552                	mv	a0,s4
    80001e94:	ea3fe0ef          	jal	80000d36 <release>
    return -1;
    80001e98:	6a42                	ld	s4,16(sp)
    return -1;
    80001e9a:	54fd                	li	s1,-1
    80001e9c:	a885                	j	80001f0c <kfork+0xfa>
  for (i = 0; i < NOFILE; i++)
    80001e9e:	04a1                	addi	s1,s1,8
    80001ea0:	0921                	addi	s2,s2,8
    80001ea2:	01348963          	beq	s1,s3,80001eb4 <kfork+0xa2>
    if (p->ofile[i])
    80001ea6:	6088                	ld	a0,0(s1)
    80001ea8:	d97d                	beqz	a0,80001e9e <kfork+0x8c>
      np->ofile[i] = filedup(p->ofile[i]);
    80001eaa:	456020ef          	jal	80004300 <filedup>
    80001eae:	00a93023          	sd	a0,0(s2)
    80001eb2:	b7f5                	j	80001e9e <kfork+0x8c>
  np->cwd = idup(p->cwd);
    80001eb4:	150ab503          	ld	a0,336(s5)
    80001eb8:	578010ef          	jal	80003430 <idup>
    80001ebc:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001ec0:	4641                	li	a2,16
    80001ec2:	158a8593          	addi	a1,s5,344
    80001ec6:	158a0513          	addi	a0,s4,344
    80001eca:	feffe0ef          	jal	80000eb8 <safestrcpy>
  pid = np->pid;
    80001ece:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001ed2:	8552                	mv	a0,s4
    80001ed4:	e63fe0ef          	jal	80000d36 <release>
  acquire(&wait_lock);
    80001ed8:	0000e517          	auipc	a0,0xe
    80001edc:	be850513          	addi	a0,a0,-1048 # 8000fac0 <wait_lock>
    80001ee0:	dd3fe0ef          	jal	80000cb2 <acquire>
  np->parent = p;
    80001ee4:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001ee8:	0000e517          	auipc	a0,0xe
    80001eec:	bd850513          	addi	a0,a0,-1064 # 8000fac0 <wait_lock>
    80001ef0:	e47fe0ef          	jal	80000d36 <release>
  acquire(&np->lock);
    80001ef4:	8552                	mv	a0,s4
    80001ef6:	dbdfe0ef          	jal	80000cb2 <acquire>
  np->state = RUNNABLE;
    80001efa:	478d                	li	a5,3
    80001efc:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001f00:	8552                	mv	a0,s4
    80001f02:	e35fe0ef          	jal	80000d36 <release>
    80001f06:	7902                	ld	s2,32(sp)
    80001f08:	69e2                	ld	s3,24(sp)
    80001f0a:	6a42                	ld	s4,16(sp)
}
    80001f0c:	8526                	mv	a0,s1
    80001f0e:	70e2                	ld	ra,56(sp)
    80001f10:	7442                	ld	s0,48(sp)
    80001f12:	74a2                	ld	s1,40(sp)
    80001f14:	6aa2                	ld	s5,8(sp)
    80001f16:	6121                	addi	sp,sp,64
    80001f18:	8082                	ret

0000000080001f1a <scheduler>:
{
    80001f1a:	715d                	addi	sp,sp,-80
    80001f1c:	e486                	sd	ra,72(sp)
    80001f1e:	e0a2                	sd	s0,64(sp)
    80001f20:	fc26                	sd	s1,56(sp)
    80001f22:	f84a                	sd	s2,48(sp)
    80001f24:	f44e                	sd	s3,40(sp)
    80001f26:	f052                	sd	s4,32(sp)
    80001f28:	ec56                	sd	s5,24(sp)
    80001f2a:	e85a                	sd	s6,16(sp)
    80001f2c:	e45e                	sd	s7,8(sp)
    80001f2e:	e062                	sd	s8,0(sp)
    80001f30:	0880                	addi	s0,sp,80
    80001f32:	8792                	mv	a5,tp
  int id = r_tp();
    80001f34:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001f36:	00779693          	slli	a3,a5,0x7
    80001f3a:	0000e717          	auipc	a4,0xe
    80001f3e:	b6e70713          	addi	a4,a4,-1170 # 8000faa8 <pid_lock>
    80001f42:	9736                	add	a4,a4,a3
    80001f44:	02073823          	sd	zero,48(a4)
      swtch(&c->context, &selected->context);
    80001f48:	0000eb17          	auipc	s6,0xe
    80001f4c:	b98b0b13          	addi	s6,s6,-1128 # 8000fae0 <cpus+0x8>
    80001f50:	9b36                	add	s6,s6,a3
      if (p->state == RUNNABLE) {
    80001f52:	4a0d                	li	s4,3
    for (p = proc; p < &proc[NPROC]; p++) {
    80001f54:	00014997          	auipc	s3,0x14
    80001f58:	b8498993          	addi	s3,s3,-1148 # 80015ad8 <tickslock>
      selected->state = RUNNING;
    80001f5c:	4c11                	li	s8,4
      c->proc = selected;
    80001f5e:	0000eb97          	auipc	s7,0xe
    80001f62:	b4ab8b93          	addi	s7,s7,-1206 # 8000faa8 <pid_lock>
    80001f66:	8aba                	mv	s5,a4
    80001f68:	a08d                	j	80001fca <scheduler+0xb0>
      release(&p->lock);
    80001f6a:	8526                	mv	a0,s1
    80001f6c:	dcbfe0ef          	jal	80000d36 <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001f70:	17048493          	addi	s1,s1,368
    80001f74:	03348563          	beq	s1,s3,80001f9e <scheduler+0x84>
      acquire(&p->lock);
    80001f78:	8526                	mv	a0,s1
    80001f7a:	d39fe0ef          	jal	80000cb2 <acquire>
      if (p->state == RUNNABLE) {
    80001f7e:	4c9c                	lw	a5,24(s1)
    80001f80:	ff4795e3          	bne	a5,s4,80001f6a <scheduler+0x50>
        if (selected == 0 || p->ctime < selected->ctime) {
    80001f84:	00090b63          	beqz	s2,80001f9a <scheduler+0x80>
    80001f88:	1684b703          	ld	a4,360(s1)
    80001f8c:	16893783          	ld	a5,360(s2)
    80001f90:	fcf77de3          	bgeu	a4,a5,80001f6a <scheduler+0x50>
            release(&selected->lock);
    80001f94:	854a                	mv	a0,s2
    80001f96:	da1fe0ef          	jal	80000d36 <release>
          selected = p;
    80001f9a:	8926                	mv	s2,s1
    80001f9c:	bfd1                	j	80001f70 <scheduler+0x56>
    if (selected) {
    80001f9e:	04090063          	beqz	s2,80001fde <scheduler+0xc4>
      selected->state = RUNNING;
    80001fa2:	01892c23          	sw	s8,24(s2)
      c->proc = selected;
    80001fa6:	032ab823          	sd	s2,48(s5)
      swtch(&c->context, &selected->context);
    80001faa:	06090593          	addi	a1,s2,96
    80001fae:	855a                	mv	a0,s6
    80001fb0:	5dc000ef          	jal	8000258c <swtch>
    80001fb4:	8792                	mv	a5,tp
      mycpu()->intena = 0;
    80001fb6:	2781                	sext.w	a5,a5
    80001fb8:	079e                	slli	a5,a5,0x7
    80001fba:	97de                	add	a5,a5,s7
    80001fbc:	0a07a623          	sw	zero,172(a5)
      c->proc = 0;
    80001fc0:	020ab823          	sd	zero,48(s5)
      release(&selected->lock);
    80001fc4:	854a                	mv	a0,s2
    80001fc6:	d71fe0ef          	jal	80000d36 <release>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001fca:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001fce:	10017073          	csrci	sstatus,2
    selected = 0;
    80001fd2:	4901                	li	s2,0
    for (p = proc; p < &proc[NPROC]; p++) {
    80001fd4:	0000e497          	auipc	s1,0xe
    80001fd8:	f0448493          	addi	s1,s1,-252 # 8000fed8 <proc>
    80001fdc:	bf71                	j	80001f78 <scheduler+0x5e>
      asm volatile("wfi");
    80001fde:	10500073          	wfi
    80001fe2:	b7e5                	j	80001fca <scheduler+0xb0>

0000000080001fe4 <sched>:
{
    80001fe4:	7179                	addi	sp,sp,-48
    80001fe6:	f406                	sd	ra,40(sp)
    80001fe8:	f022                	sd	s0,32(sp)
    80001fea:	ec26                	sd	s1,24(sp)
    80001fec:	e84a                	sd	s2,16(sp)
    80001fee:	e44e                	sd	s3,8(sp)
    80001ff0:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001ff2:	a93ff0ef          	jal	80001a84 <myproc>
    80001ff6:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001ff8:	c55fe0ef          	jal	80000c4c <holding>
    80001ffc:	c92d                	beqz	a0,8000206e <sched+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001ffe:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80002000:	2781                	sext.w	a5,a5
    80002002:	079e                	slli	a5,a5,0x7
    80002004:	0000e717          	auipc	a4,0xe
    80002008:	aa470713          	addi	a4,a4,-1372 # 8000faa8 <pid_lock>
    8000200c:	97ba                	add	a5,a5,a4
    8000200e:	0a87a703          	lw	a4,168(a5)
    80002012:	4785                	li	a5,1
    80002014:	06f71363          	bne	a4,a5,8000207a <sched+0x96>
  if (p->state == RUNNING)
    80002018:	4c98                	lw	a4,24(s1)
    8000201a:	4791                	li	a5,4
    8000201c:	06f70563          	beq	a4,a5,80002086 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002020:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002024:	8b89                	andi	a5,a5,2
  if (intr_get())
    80002026:	e7b5                	bnez	a5,80002092 <sched+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80002028:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    8000202a:	0000e917          	auipc	s2,0xe
    8000202e:	a7e90913          	addi	s2,s2,-1410 # 8000faa8 <pid_lock>
    80002032:	2781                	sext.w	a5,a5
    80002034:	079e                	slli	a5,a5,0x7
    80002036:	97ca                	add	a5,a5,s2
    80002038:	0ac7a983          	lw	s3,172(a5)
    8000203c:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    8000203e:	2781                	sext.w	a5,a5
    80002040:	079e                	slli	a5,a5,0x7
    80002042:	0000e597          	auipc	a1,0xe
    80002046:	a9e58593          	addi	a1,a1,-1378 # 8000fae0 <cpus+0x8>
    8000204a:	95be                	add	a1,a1,a5
    8000204c:	06048513          	addi	a0,s1,96
    80002050:	53c000ef          	jal	8000258c <swtch>
    80002054:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80002056:	2781                	sext.w	a5,a5
    80002058:	079e                	slli	a5,a5,0x7
    8000205a:	993e                	add	s2,s2,a5
    8000205c:	0b392623          	sw	s3,172(s2)
}
    80002060:	70a2                	ld	ra,40(sp)
    80002062:	7402                	ld	s0,32(sp)
    80002064:	64e2                	ld	s1,24(sp)
    80002066:	6942                	ld	s2,16(sp)
    80002068:	69a2                	ld	s3,8(sp)
    8000206a:	6145                	addi	sp,sp,48
    8000206c:	8082                	ret
    panic("sched p->lock");
    8000206e:	00005517          	auipc	a0,0x5
    80002072:	20a50513          	addi	a0,a0,522 # 80007278 <etext+0x278>
    80002076:	fd2fe0ef          	jal	80000848 <panic>
    panic("sched locks");
    8000207a:	00005517          	auipc	a0,0x5
    8000207e:	20e50513          	addi	a0,a0,526 # 80007288 <etext+0x288>
    80002082:	fc6fe0ef          	jal	80000848 <panic>
    panic("sched RUNNING");
    80002086:	00005517          	auipc	a0,0x5
    8000208a:	21250513          	addi	a0,a0,530 # 80007298 <etext+0x298>
    8000208e:	fbafe0ef          	jal	80000848 <panic>
    panic("sched interruptible");
    80002092:	00005517          	auipc	a0,0x5
    80002096:	21650513          	addi	a0,a0,534 # 800072a8 <etext+0x2a8>
    8000209a:	faefe0ef          	jal	80000848 <panic>

000000008000209e <yield>:
{
    8000209e:	1101                	addi	sp,sp,-32
    800020a0:	ec06                	sd	ra,24(sp)
    800020a2:	e822                	sd	s0,16(sp)
    800020a4:	e426                	sd	s1,8(sp)
    800020a6:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800020a8:	9ddff0ef          	jal	80001a84 <myproc>
    800020ac:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020ae:	c05fe0ef          	jal	80000cb2 <acquire>
  p->state = RUNNABLE;
    800020b2:	478d                	li	a5,3
    800020b4:	cc9c                	sw	a5,24(s1)
  sched();
    800020b6:	f2fff0ef          	jal	80001fe4 <sched>
  release(&p->lock);
    800020ba:	8526                	mv	a0,s1
    800020bc:	c7bfe0ef          	jal	80000d36 <release>
}
    800020c0:	60e2                	ld	ra,24(sp)
    800020c2:	6442                	ld	s0,16(sp)
    800020c4:	64a2                	ld	s1,8(sp)
    800020c6:	6105                	addi	sp,sp,32
    800020c8:	8082                	ret

00000000800020ca <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    800020ca:	1101                	addi	sp,sp,-32
    800020cc:	ec06                	sd	ra,24(sp)
    800020ce:	e822                	sd	s0,16(sp)
    800020d0:	e426                	sd	s1,8(sp)
    800020d2:	e04a                	sd	s2,0(sp)
    800020d4:	1000                	addi	s0,sp,32
    800020d6:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800020d8:	9adff0ef          	jal	80001a84 <myproc>
    800020dc:	892a                	mv	s2,a0

  acquire(&p->lock);
    800020de:	bd5fe0ef          	jal	80000cb2 <acquire>
  if (chan == 0)
    800020e2:	cc81                	beqz	s1,800020fa <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    800020e4:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    800020e8:	854a                	mv	a0,s2
    800020ea:	c4dfe0ef          	jal	80000d36 <release>
}
    800020ee:	60e2                	ld	ra,24(sp)
    800020f0:	6442                	ld	s0,16(sp)
    800020f2:	64a2                	ld	s1,8(sp)
    800020f4:	6902                	ld	s2,0(sp)
    800020f6:	6105                	addi	sp,sp,32
    800020f8:	8082                	ret
    panic("sleep_prepare: zero chan");
    800020fa:	00005517          	auipc	a0,0x5
    800020fe:	1c650513          	addi	a0,a0,454 # 800072c0 <etext+0x2c0>
    80002102:	f46fe0ef          	jal	80000848 <panic>

0000000080002106 <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80002106:	1101                	addi	sp,sp,-32
    80002108:	ec06                	sd	ra,24(sp)
    8000210a:	e822                	sd	s0,16(sp)
    8000210c:	e426                	sd	s1,8(sp)
    8000210e:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80002110:	975ff0ef          	jal	80001a84 <myproc>
    80002114:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80002116:	b9dfe0ef          	jal	80000cb2 <acquire>
  if (p->chan != 0) {
    8000211a:	709c                	ld	a5,32(s1)
    8000211c:	c789                	beqz	a5,80002126 <sleep+0x20>
    p->state = SLEEPING;
    8000211e:	4789                	li	a5,2
    80002120:	cc9c                	sw	a5,24(s1)
    sched();
    80002122:	ec3ff0ef          	jal	80001fe4 <sched>
  }
  release(&p->lock);
    80002126:	8526                	mv	a0,s1
    80002128:	c0ffe0ef          	jal	80000d36 <release>
}
    8000212c:	60e2                	ld	ra,24(sp)
    8000212e:	6442                	ld	s0,16(sp)
    80002130:	64a2                	ld	s1,8(sp)
    80002132:	6105                	addi	sp,sp,32
    80002134:	8082                	ret

0000000080002136 <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80002136:	7139                	addi	sp,sp,-64
    80002138:	fc06                	sd	ra,56(sp)
    8000213a:	f822                	sd	s0,48(sp)
    8000213c:	f426                	sd	s1,40(sp)
    8000213e:	f04a                	sd	s2,32(sp)
    80002140:	ec4e                	sd	s3,24(sp)
    80002142:	e852                	sd	s4,16(sp)
    80002144:	e456                	sd	s5,8(sp)
    80002146:	0080                	addi	s0,sp,64
    80002148:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    8000214a:	0000e497          	auipc	s1,0xe
    8000214e:	d8e48493          	addi	s1,s1,-626 # 8000fed8 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80002152:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80002154:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80002156:	00014997          	auipc	s3,0x14
    8000215a:	98298993          	addi	s3,s3,-1662 # 80015ad8 <tickslock>
    8000215e:	a801                	j	8000216e <wakeup+0x38>
      }
    }
    release(&p->lock);
    80002160:	8526                	mv	a0,s1
    80002162:	bd5fe0ef          	jal	80000d36 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002166:	17048493          	addi	s1,s1,368
    8000216a:	03348063          	beq	s1,s3,8000218a <wakeup+0x54>
    acquire(&p->lock);
    8000216e:	8526                	mv	a0,s1
    80002170:	b43fe0ef          	jal	80000cb2 <acquire>
    if (p->chan == chan) {
    80002174:	709c                	ld	a5,32(s1)
    80002176:	ff2795e3          	bne	a5,s2,80002160 <wakeup+0x2a>
      p->chan = 0;
    8000217a:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    8000217e:	4c9c                	lw	a5,24(s1)
    80002180:	ff4790e3          	bne	a5,s4,80002160 <wakeup+0x2a>
        p->state = RUNNABLE;
    80002184:	0154ac23          	sw	s5,24(s1)
    80002188:	bfe1                	j	80002160 <wakeup+0x2a>
  }
}
    8000218a:	70e2                	ld	ra,56(sp)
    8000218c:	7442                	ld	s0,48(sp)
    8000218e:	74a2                	ld	s1,40(sp)
    80002190:	7902                	ld	s2,32(sp)
    80002192:	69e2                	ld	s3,24(sp)
    80002194:	6a42                	ld	s4,16(sp)
    80002196:	6aa2                	ld	s5,8(sp)
    80002198:	6121                	addi	sp,sp,64
    8000219a:	8082                	ret

000000008000219c <reparent>:
{
    8000219c:	7179                	addi	sp,sp,-48
    8000219e:	f406                	sd	ra,40(sp)
    800021a0:	f022                	sd	s0,32(sp)
    800021a2:	ec26                	sd	s1,24(sp)
    800021a4:	e84a                	sd	s2,16(sp)
    800021a6:	e44e                	sd	s3,8(sp)
    800021a8:	e052                	sd	s4,0(sp)
    800021aa:	1800                	addi	s0,sp,48
    800021ac:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    800021ae:	0000e497          	auipc	s1,0xe
    800021b2:	d2a48493          	addi	s1,s1,-726 # 8000fed8 <proc>
      pp->parent = initproc;
    800021b6:	00005a17          	auipc	s4,0x5
    800021ba:	7c2a0a13          	addi	s4,s4,1986 # 80007978 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    800021be:	00014997          	auipc	s3,0x14
    800021c2:	91a98993          	addi	s3,s3,-1766 # 80015ad8 <tickslock>
    800021c6:	a029                	j	800021d0 <reparent+0x34>
    800021c8:	17048493          	addi	s1,s1,368
    800021cc:	01348b63          	beq	s1,s3,800021e2 <reparent+0x46>
    if (pp->parent == p) {
    800021d0:	7c9c                	ld	a5,56(s1)
    800021d2:	ff279be3          	bne	a5,s2,800021c8 <reparent+0x2c>
      pp->parent = initproc;
    800021d6:	000a3503          	ld	a0,0(s4)
    800021da:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    800021dc:	f5bff0ef          	jal	80002136 <wakeup>
    800021e0:	b7e5                	j	800021c8 <reparent+0x2c>
}
    800021e2:	70a2                	ld	ra,40(sp)
    800021e4:	7402                	ld	s0,32(sp)
    800021e6:	64e2                	ld	s1,24(sp)
    800021e8:	6942                	ld	s2,16(sp)
    800021ea:	69a2                	ld	s3,8(sp)
    800021ec:	6a02                	ld	s4,0(sp)
    800021ee:	6145                	addi	sp,sp,48
    800021f0:	8082                	ret

00000000800021f2 <kexit>:
{
    800021f2:	7179                	addi	sp,sp,-48
    800021f4:	f406                	sd	ra,40(sp)
    800021f6:	f022                	sd	s0,32(sp)
    800021f8:	ec26                	sd	s1,24(sp)
    800021fa:	e84a                	sd	s2,16(sp)
    800021fc:	e44e                	sd	s3,8(sp)
    800021fe:	e052                	sd	s4,0(sp)
    80002200:	1800                	addi	s0,sp,48
    80002202:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002204:	881ff0ef          	jal	80001a84 <myproc>
    80002208:	89aa                	mv	s3,a0
  if (p == initproc)
    8000220a:	00005797          	auipc	a5,0x5
    8000220e:	76e7b783          	ld	a5,1902(a5) # 80007978 <initproc>
    80002212:	0d050493          	addi	s1,a0,208
    80002216:	15050913          	addi	s2,a0,336
    8000221a:	00a79b63          	bne	a5,a0,80002230 <kexit+0x3e>
    panic("init exiting");
    8000221e:	00005517          	auipc	a0,0x5
    80002222:	0c250513          	addi	a0,a0,194 # 800072e0 <etext+0x2e0>
    80002226:	e22fe0ef          	jal	80000848 <panic>
  for (int fd = 0; fd < NOFILE; fd++) {
    8000222a:	04a1                	addi	s1,s1,8
    8000222c:	01248963          	beq	s1,s2,8000223e <kexit+0x4c>
    if (p->ofile[fd]) {
    80002230:	6088                	ld	a0,0(s1)
    80002232:	dd65                	beqz	a0,8000222a <kexit+0x38>
      fileclose(f);
    80002234:	112020ef          	jal	80004346 <fileclose>
      p->ofile[fd] = 0;
    80002238:	0004b023          	sd	zero,0(s1)
    8000223c:	b7fd                	j	8000222a <kexit+0x38>
  begin_op();
    8000223e:	453010ef          	jal	80003e90 <begin_op>
  iput(p->cwd);
    80002242:	1509b503          	ld	a0,336(s3)
    80002246:	3a2010ef          	jal	800035e8 <iput>
  end_op();
    8000224a:	4d3010ef          	jal	80003f1c <end_op>
  p->cwd = 0;
    8000224e:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002252:	0000e517          	auipc	a0,0xe
    80002256:	86e50513          	addi	a0,a0,-1938 # 8000fac0 <wait_lock>
    8000225a:	a59fe0ef          	jal	80000cb2 <acquire>
  reparent(p);
    8000225e:	854e                	mv	a0,s3
    80002260:	f3dff0ef          	jal	8000219c <reparent>
  wakeup(p->parent);
    80002264:	0389b503          	ld	a0,56(s3)
    80002268:	ecfff0ef          	jal	80002136 <wakeup>
  acquire(&p->lock);
    8000226c:	854e                	mv	a0,s3
    8000226e:	a45fe0ef          	jal	80000cb2 <acquire>
  p->xstate = status;
    80002272:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002276:	4795                	li	a5,5
    80002278:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    8000227c:	0000e517          	auipc	a0,0xe
    80002280:	84450513          	addi	a0,a0,-1980 # 8000fac0 <wait_lock>
    80002284:	ab3fe0ef          	jal	80000d36 <release>
  sched();
    80002288:	d5dff0ef          	jal	80001fe4 <sched>
  panic("zombie exit");
    8000228c:	00005517          	auipc	a0,0x5
    80002290:	06450513          	addi	a0,a0,100 # 800072f0 <etext+0x2f0>
    80002294:	db4fe0ef          	jal	80000848 <panic>

0000000080002298 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    80002298:	7179                	addi	sp,sp,-48
    8000229a:	f406                	sd	ra,40(sp)
    8000229c:	f022                	sd	s0,32(sp)
    8000229e:	ec26                	sd	s1,24(sp)
    800022a0:	e84a                	sd	s2,16(sp)
    800022a2:	e44e                	sd	s3,8(sp)
    800022a4:	1800                	addi	s0,sp,48
    800022a6:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    800022a8:	0000e497          	auipc	s1,0xe
    800022ac:	c3048493          	addi	s1,s1,-976 # 8000fed8 <proc>
    800022b0:	00014997          	auipc	s3,0x14
    800022b4:	82898993          	addi	s3,s3,-2008 # 80015ad8 <tickslock>
    acquire(&p->lock);
    800022b8:	8526                	mv	a0,s1
    800022ba:	9f9fe0ef          	jal	80000cb2 <acquire>
    if (p->pid == pid) {
    800022be:	589c                	lw	a5,48(s1)
    800022c0:	01278b63          	beq	a5,s2,800022d6 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800022c4:	8526                	mv	a0,s1
    800022c6:	a71fe0ef          	jal	80000d36 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800022ca:	17048493          	addi	s1,s1,368
    800022ce:	ff3495e3          	bne	s1,s3,800022b8 <kkill+0x20>
  }
  return -1;
    800022d2:	557d                	li	a0,-1
    800022d4:	a819                	j	800022ea <kkill+0x52>
      p->killed = 1;
    800022d6:	4785                	li	a5,1
    800022d8:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    800022da:	4c98                	lw	a4,24(s1)
    800022dc:	4789                	li	a5,2
    800022de:	00f70d63          	beq	a4,a5,800022f8 <kkill+0x60>
      release(&p->lock);
    800022e2:	8526                	mv	a0,s1
    800022e4:	a53fe0ef          	jal	80000d36 <release>
      return 0;
    800022e8:	4501                	li	a0,0
}
    800022ea:	70a2                	ld	ra,40(sp)
    800022ec:	7402                	ld	s0,32(sp)
    800022ee:	64e2                	ld	s1,24(sp)
    800022f0:	6942                	ld	s2,16(sp)
    800022f2:	69a2                	ld	s3,8(sp)
    800022f4:	6145                	addi	sp,sp,48
    800022f6:	8082                	ret
        p->state = RUNNABLE;
    800022f8:	478d                	li	a5,3
    800022fa:	cc9c                	sw	a5,24(s1)
    800022fc:	b7dd                	j	800022e2 <kkill+0x4a>

00000000800022fe <setkilled>:

void
setkilled(struct proc *p)
{
    800022fe:	1101                	addi	sp,sp,-32
    80002300:	ec06                	sd	ra,24(sp)
    80002302:	e822                	sd	s0,16(sp)
    80002304:	e426                	sd	s1,8(sp)
    80002306:	1000                	addi	s0,sp,32
    80002308:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000230a:	9a9fe0ef          	jal	80000cb2 <acquire>
  p->killed = 1;
    8000230e:	4785                	li	a5,1
    80002310:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002312:	8526                	mv	a0,s1
    80002314:	a23fe0ef          	jal	80000d36 <release>
}
    80002318:	60e2                	ld	ra,24(sp)
    8000231a:	6442                	ld	s0,16(sp)
    8000231c:	64a2                	ld	s1,8(sp)
    8000231e:	6105                	addi	sp,sp,32
    80002320:	8082                	ret

0000000080002322 <killed>:

int
killed(struct proc *p)
{
    80002322:	1101                	addi	sp,sp,-32
    80002324:	ec06                	sd	ra,24(sp)
    80002326:	e822                	sd	s0,16(sp)
    80002328:	e426                	sd	s1,8(sp)
    8000232a:	e04a                	sd	s2,0(sp)
    8000232c:	1000                	addi	s0,sp,32
    8000232e:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    80002330:	983fe0ef          	jal	80000cb2 <acquire>
  k = p->killed;
    80002334:	549c                	lw	a5,40(s1)
    80002336:	893e                	mv	s2,a5
  release(&p->lock);
    80002338:	8526                	mv	a0,s1
    8000233a:	9fdfe0ef          	jal	80000d36 <release>
  return k;
}
    8000233e:	854a                	mv	a0,s2
    80002340:	60e2                	ld	ra,24(sp)
    80002342:	6442                	ld	s0,16(sp)
    80002344:	64a2                	ld	s1,8(sp)
    80002346:	6902                	ld	s2,0(sp)
    80002348:	6105                	addi	sp,sp,32
    8000234a:	8082                	ret

000000008000234c <kwait>:
{
    8000234c:	715d                	addi	sp,sp,-80
    8000234e:	e486                	sd	ra,72(sp)
    80002350:	e0a2                	sd	s0,64(sp)
    80002352:	fc26                	sd	s1,56(sp)
    80002354:	f84a                	sd	s2,48(sp)
    80002356:	f44e                	sd	s3,40(sp)
    80002358:	f052                	sd	s4,32(sp)
    8000235a:	ec56                	sd	s5,24(sp)
    8000235c:	e85a                	sd	s6,16(sp)
    8000235e:	e45e                	sd	s7,8(sp)
    80002360:	0880                	addi	s0,sp,80
    80002362:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    80002364:	f20ff0ef          	jal	80001a84 <myproc>
    80002368:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000236a:	0000d517          	auipc	a0,0xd
    8000236e:	75650513          	addi	a0,a0,1878 # 8000fac0 <wait_lock>
    80002372:	941fe0ef          	jal	80000cb2 <acquire>
        if (pp->state == ZOMBIE) {
    80002376:	4a15                	li	s4,5
        havekids = 1;
    80002378:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000237a:	00013997          	auipc	s3,0x13
    8000237e:	75e98993          	addi	s3,s3,1886 # 80015ad8 <tickslock>
    release(&wait_lock);
    80002382:	0000db17          	auipc	s6,0xd
    80002386:	73eb0b13          	addi	s6,s6,1854 # 8000fac0 <wait_lock>
    8000238a:	a07d                	j	80002438 <kwait+0xec>
          pid = pp->pid;
    8000238c:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    80002390:	000b8e63          	beqz	s7,800023ac <kwait+0x60>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    80002394:	4711                	li	a4,4
    80002396:	02c48693          	addi	a3,s1,44
    8000239a:	865e                	mv	a2,s7
    8000239c:	04893583          	ld	a1,72(s2)
    800023a0:	05093503          	ld	a0,80(s2)
    800023a4:	a42ff0ef          	jal	800015e6 <copyout>
          if (addr != 0 &&
    800023a8:	02054c63          	bltz	a0,800023e0 <kwait+0x94>
          pp->parent = 0;
    800023ac:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    800023b0:	8526                	mv	a0,s1
    800023b2:	8b1ff0ef          	jal	80001c62 <freeproc>
          release(&pp->lock);
    800023b6:	8526                	mv	a0,s1
    800023b8:	97ffe0ef          	jal	80000d36 <release>
          release(&wait_lock);
    800023bc:	0000d517          	auipc	a0,0xd
    800023c0:	70450513          	addi	a0,a0,1796 # 8000fac0 <wait_lock>
    800023c4:	973fe0ef          	jal	80000d36 <release>
}
    800023c8:	854e                	mv	a0,s3
    800023ca:	60a6                	ld	ra,72(sp)
    800023cc:	6406                	ld	s0,64(sp)
    800023ce:	74e2                	ld	s1,56(sp)
    800023d0:	7942                	ld	s2,48(sp)
    800023d2:	79a2                	ld	s3,40(sp)
    800023d4:	7a02                	ld	s4,32(sp)
    800023d6:	6ae2                	ld	s5,24(sp)
    800023d8:	6b42                	ld	s6,16(sp)
    800023da:	6ba2                	ld	s7,8(sp)
    800023dc:	6161                	addi	sp,sp,80
    800023de:	8082                	ret
            release(&pp->lock);
    800023e0:	8526                	mv	a0,s1
    800023e2:	955fe0ef          	jal	80000d36 <release>
            release(&wait_lock);
    800023e6:	0000d517          	auipc	a0,0xd
    800023ea:	6da50513          	addi	a0,a0,1754 # 8000fac0 <wait_lock>
    800023ee:	949fe0ef          	jal	80000d36 <release>
            return -1;
    800023f2:	a8b9                	j	80002450 <kwait+0x104>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800023f4:	17048493          	addi	s1,s1,368
    800023f8:	03348063          	beq	s1,s3,80002418 <kwait+0xcc>
      if (pp->parent == p) {
    800023fc:	7c9c                	ld	a5,56(s1)
    800023fe:	ff279be3          	bne	a5,s2,800023f4 <kwait+0xa8>
        acquire(&pp->lock);
    80002402:	8526                	mv	a0,s1
    80002404:	8affe0ef          	jal	80000cb2 <acquire>
        if (pp->state == ZOMBIE) {
    80002408:	4c9c                	lw	a5,24(s1)
    8000240a:	f94781e3          	beq	a5,s4,8000238c <kwait+0x40>
        release(&pp->lock);
    8000240e:	8526                	mv	a0,s1
    80002410:	927fe0ef          	jal	80000d36 <release>
        havekids = 1;
    80002414:	8756                	mv	a4,s5
    80002416:	bff9                	j	800023f4 <kwait+0xa8>
    if (!havekids || killed(p)) {
    80002418:	c715                	beqz	a4,80002444 <kwait+0xf8>
    8000241a:	854a                	mv	a0,s2
    8000241c:	f07ff0ef          	jal	80002322 <killed>
    80002420:	e115                	bnez	a0,80002444 <kwait+0xf8>
    sleep_prepare(p); //DOC: wait-sleep
    80002422:	854a                	mv	a0,s2
    80002424:	ca7ff0ef          	jal	800020ca <sleep_prepare>
    release(&wait_lock);
    80002428:	855a                	mv	a0,s6
    8000242a:	90dfe0ef          	jal	80000d36 <release>
    sleep();
    8000242e:	cd9ff0ef          	jal	80002106 <sleep>
    acquire(&wait_lock);
    80002432:	855a                	mv	a0,s6
    80002434:	87ffe0ef          	jal	80000cb2 <acquire>
    havekids = 0;
    80002438:	4701                	li	a4,0
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000243a:	0000e497          	auipc	s1,0xe
    8000243e:	a9e48493          	addi	s1,s1,-1378 # 8000fed8 <proc>
    80002442:	bf6d                	j	800023fc <kwait+0xb0>
      release(&wait_lock);
    80002444:	0000d517          	auipc	a0,0xd
    80002448:	67c50513          	addi	a0,a0,1660 # 8000fac0 <wait_lock>
    8000244c:	8ebfe0ef          	jal	80000d36 <release>
            return -1;
    80002450:	59fd                	li	s3,-1
    80002452:	bf9d                	j	800023c8 <kwait+0x7c>

0000000080002454 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002454:	7179                	addi	sp,sp,-48
    80002456:	f406                	sd	ra,40(sp)
    80002458:	f022                	sd	s0,32(sp)
    8000245a:	ec26                	sd	s1,24(sp)
    8000245c:	e84a                	sd	s2,16(sp)
    8000245e:	e44e                	sd	s3,8(sp)
    80002460:	e052                	sd	s4,0(sp)
    80002462:	1800                	addi	s0,sp,48
    80002464:	84aa                	mv	s1,a0
    80002466:	8a2e                	mv	s4,a1
    80002468:	89b2                	mv	s3,a2
    8000246a:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000246c:	e18ff0ef          	jal	80001a84 <myproc>
  if (user_dst) {
    80002470:	c085                	beqz	s1,80002490 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    80002472:	874a                	mv	a4,s2
    80002474:	86ce                	mv	a3,s3
    80002476:	8652                	mv	a2,s4
    80002478:	652c                	ld	a1,72(a0)
    8000247a:	6928                	ld	a0,80(a0)
    8000247c:	96aff0ef          	jal	800015e6 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002480:	70a2                	ld	ra,40(sp)
    80002482:	7402                	ld	s0,32(sp)
    80002484:	64e2                	ld	s1,24(sp)
    80002486:	6942                	ld	s2,16(sp)
    80002488:	69a2                	ld	s3,8(sp)
    8000248a:	6a02                	ld	s4,0(sp)
    8000248c:	6145                	addi	sp,sp,48
    8000248e:	8082                	ret
    memmove((char *)dst, src, len);
    80002490:	0009061b          	sext.w	a2,s2
    80002494:	85ce                	mv	a1,s3
    80002496:	8552                	mv	a0,s4
    80002498:	933fe0ef          	jal	80000dca <memmove>
    return 0;
    8000249c:	8526                	mv	a0,s1
    8000249e:	b7cd                	j	80002480 <either_copyout+0x2c>

00000000800024a0 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800024a0:	7179                	addi	sp,sp,-48
    800024a2:	f406                	sd	ra,40(sp)
    800024a4:	f022                	sd	s0,32(sp)
    800024a6:	ec26                	sd	s1,24(sp)
    800024a8:	e84a                	sd	s2,16(sp)
    800024aa:	e44e                	sd	s3,8(sp)
    800024ac:	e052                	sd	s4,0(sp)
    800024ae:	1800                	addi	s0,sp,48
    800024b0:	8a2a                	mv	s4,a0
    800024b2:	84ae                	mv	s1,a1
    800024b4:	89b2                	mv	s3,a2
    800024b6:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800024b8:	dccff0ef          	jal	80001a84 <myproc>
  if (user_src) {
    800024bc:	c085                	beqz	s1,800024dc <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    800024be:	874a                	mv	a4,s2
    800024c0:	86ce                	mv	a3,s3
    800024c2:	8652                	mv	a2,s4
    800024c4:	652c                	ld	a1,72(a0)
    800024c6:	6928                	ld	a0,80(a0)
    800024c8:	9deff0ef          	jal	800016a6 <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    800024cc:	70a2                	ld	ra,40(sp)
    800024ce:	7402                	ld	s0,32(sp)
    800024d0:	64e2                	ld	s1,24(sp)
    800024d2:	6942                	ld	s2,16(sp)
    800024d4:	69a2                	ld	s3,8(sp)
    800024d6:	6a02                	ld	s4,0(sp)
    800024d8:	6145                	addi	sp,sp,48
    800024da:	8082                	ret
    memmove(dst, (char *)src, len);
    800024dc:	0009061b          	sext.w	a2,s2
    800024e0:	85ce                	mv	a1,s3
    800024e2:	8552                	mv	a0,s4
    800024e4:	8e7fe0ef          	jal	80000dca <memmove>
    return 0;
    800024e8:	8526                	mv	a0,s1
    800024ea:	b7cd                	j	800024cc <either_copyin+0x2c>

00000000800024ec <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800024ec:	715d                	addi	sp,sp,-80
    800024ee:	e486                	sd	ra,72(sp)
    800024f0:	e0a2                	sd	s0,64(sp)
    800024f2:	fc26                	sd	s1,56(sp)
    800024f4:	f84a                	sd	s2,48(sp)
    800024f6:	f44e                	sd	s3,40(sp)
    800024f8:	f052                	sd	s4,32(sp)
    800024fa:	ec56                	sd	s5,24(sp)
    800024fc:	e85a                	sd	s6,16(sp)
    800024fe:	e45e                	sd	s7,8(sp)
    80002500:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    80002502:	00005517          	auipc	a0,0x5
    80002506:	c0650513          	addi	a0,a0,-1018 # 80007108 <etext+0x108>
    8000250a:	806fe0ef          	jal	80000510 <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000250e:	0000e497          	auipc	s1,0xe
    80002512:	b2248493          	addi	s1,s1,-1246 # 80010030 <proc+0x158>
    80002516:	00013917          	auipc	s2,0x13
    8000251a:	71a90913          	addi	s2,s2,1818 # 80015c30 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000251e:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002520:	00005a97          	auipc	s5,0x5
    80002524:	de0a8a93          	addi	s5,s5,-544 # 80007300 <etext+0x300>
    printk("%d %s %s", p->pid, state, p->name);
    80002528:	00005a17          	auipc	s4,0x5
    8000252c:	de0a0a13          	addi	s4,s4,-544 # 80007308 <etext+0x308>
    printk("\n");
    80002530:	00005997          	auipc	s3,0x5
    80002534:	bd898993          	addi	s3,s3,-1064 # 80007108 <etext+0x108>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002538:	00005b97          	auipc	s7,0x5
    8000253c:	2f0b8b93          	addi	s7,s7,752 # 80007828 <states.0>
    80002540:	a829                	j	8000255a <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    80002542:	ed86a583          	lw	a1,-296(a3)
    80002546:	8552                	mv	a0,s4
    80002548:	fc9fd0ef          	jal	80000510 <printk>
    printk("\n");
    8000254c:	854e                	mv	a0,s3
    8000254e:	fc3fd0ef          	jal	80000510 <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002552:	17048493          	addi	s1,s1,368
    80002556:	03248063          	beq	s1,s2,80002576 <procdump+0x8a>
    if (p->state == UNUSED)
    8000255a:	86a6                	mv	a3,s1
    8000255c:	ec04a783          	lw	a5,-320(s1)
    80002560:	dbed                	beqz	a5,80002552 <procdump+0x66>
      state = "???";
    80002562:	8656                	mv	a2,s5
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002564:	fcfb6fe3          	bltu	s6,a5,80002542 <procdump+0x56>
    80002568:	02079713          	slli	a4,a5,0x20
    8000256c:	01d75793          	srli	a5,a4,0x1d
    80002570:	97de                	add	a5,a5,s7
    80002572:	6390                	ld	a2,0(a5)
      state = states[p->state];
    80002574:	b7f9                	j	80002542 <procdump+0x56>
  }
}
    80002576:	60a6                	ld	ra,72(sp)
    80002578:	6406                	ld	s0,64(sp)
    8000257a:	74e2                	ld	s1,56(sp)
    8000257c:	7942                	ld	s2,48(sp)
    8000257e:	79a2                	ld	s3,40(sp)
    80002580:	7a02                	ld	s4,32(sp)
    80002582:	6ae2                	ld	s5,24(sp)
    80002584:	6b42                	ld	s6,16(sp)
    80002586:	6ba2                	ld	s7,8(sp)
    80002588:	6161                	addi	sp,sp,80
    8000258a:	8082                	ret

000000008000258c <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    8000258c:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002590:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002594:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002596:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002598:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    8000259c:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800025a0:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800025a4:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800025a8:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800025ac:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800025b0:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800025b4:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800025b8:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800025bc:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800025c0:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800025c4:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800025c8:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800025ca:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    800025cc:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    800025d0:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    800025d4:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800025d8:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800025dc:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800025e0:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800025e4:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800025e8:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800025ec:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800025f0:	0685bd83          	ld	s11,104(a1)
        
        ret
    800025f4:	8082                	ret

00000000800025f6 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800025f6:	1141                	addi	sp,sp,-16
    800025f8:	e406                	sd	ra,8(sp)
    800025fa:	e022                	sd	s0,0(sp)
    800025fc:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800025fe:	00005597          	auipc	a1,0x5
    80002602:	d4a58593          	addi	a1,a1,-694 # 80007348 <etext+0x348>
    80002606:	00013517          	auipc	a0,0x13
    8000260a:	4d250513          	addi	a0,a0,1234 # 80015ad8 <tickslock>
    8000260e:	e24fe0ef          	jal	80000c32 <initlock>
}
    80002612:	60a2                	ld	ra,8(sp)
    80002614:	6402                	ld	s0,0(sp)
    80002616:	0141                	addi	sp,sp,16
    80002618:	8082                	ret

000000008000261a <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000261a:	1141                	addi	sp,sp,-16
    8000261c:	e406                	sd	ra,8(sp)
    8000261e:	e022                	sd	s0,0(sp)
    80002620:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002622:	00003797          	auipc	a5,0x3
    80002626:	0ae78793          	addi	a5,a5,174 # 800056d0 <kernelvec>
    8000262a:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000262e:	60a2                	ld	ra,8(sp)
    80002630:	6402                	ld	s0,0(sp)
    80002632:	0141                	addi	sp,sp,16
    80002634:	8082                	ret

0000000080002636 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002636:	1141                	addi	sp,sp,-16
    80002638:	e406                	sd	ra,8(sp)
    8000263a:	e022                	sd	s0,0(sp)
    8000263c:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    8000263e:	c46ff0ef          	jal	80001a84 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80002642:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002646:	04000737          	lui	a4,0x4000
    8000264a:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000264c:	0732                	slli	a4,a4,0xc
    8000264e:	00004797          	auipc	a5,0x4
    80002652:	9b278793          	addi	a5,a5,-1614 # 80006000 <_trampoline>
    80002656:	00004697          	auipc	a3,0x4
    8000265a:	9aa68693          	addi	a3,a3,-1622 # 80006000 <_trampoline>
    8000265e:	8f95                	sub	a5,a5,a3
    80002660:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002662:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002666:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    80002668:	18002773          	csrr	a4,satp
    8000266c:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000266e:	6d38                	ld	a4,88(a0)
    80002670:	613c                	ld	a5,64(a0)
    80002672:	6685                	lui	a3,0x1
    80002674:	97b6                	add	a5,a5,a3
    80002676:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002678:	6d3c                	ld	a5,88(a0)
    8000267a:	00000717          	auipc	a4,0x0
    8000267e:	0f470713          	addi	a4,a4,244 # 8000276e <usertrap>
    80002682:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    80002684:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    80002686:	8712                	mv	a4,tp
    80002688:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000268a:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000268e:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002692:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002696:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000269a:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000269c:	6f9c                	ld	a5,24(a5)
    8000269e:	14179073          	csrw	sepc,a5
}
    800026a2:	60a2                	ld	ra,8(sp)
    800026a4:	6402                	ld	s0,0(sp)
    800026a6:	0141                	addi	sp,sp,16
    800026a8:	8082                	ret

00000000800026aa <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800026aa:	1141                	addi	sp,sp,-16
    800026ac:	e406                	sd	ra,8(sp)
    800026ae:	e022                	sd	s0,0(sp)
    800026b0:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    800026b2:	b9eff0ef          	jal	80001a50 <cpuid>
    800026b6:	cd11                	beqz	a0,800026d2 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    800026b8:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800026bc:	000f4737          	lui	a4,0xf4
    800026c0:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800026c4:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    800026c6:	14d79073          	csrw	stimecmp,a5
}
    800026ca:	60a2                	ld	ra,8(sp)
    800026cc:	6402                	ld	s0,0(sp)
    800026ce:	0141                	addi	sp,sp,16
    800026d0:	8082                	ret
    acquire(&tickslock);
    800026d2:	00013517          	auipc	a0,0x13
    800026d6:	40650513          	addi	a0,a0,1030 # 80015ad8 <tickslock>
    800026da:	dd8fe0ef          	jal	80000cb2 <acquire>
    ticks++;
    800026de:	00005717          	auipc	a4,0x5
    800026e2:	2a270713          	addi	a4,a4,674 # 80007980 <ticks>
    800026e6:	431c                	lw	a5,0(a4)
    800026e8:	2785                	addiw	a5,a5,1
    800026ea:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    800026ec:	853a                	mv	a0,a4
    800026ee:	a49ff0ef          	jal	80002136 <wakeup>
    release(&tickslock);
    800026f2:	00013517          	auipc	a0,0x13
    800026f6:	3e650513          	addi	a0,a0,998 # 80015ad8 <tickslock>
    800026fa:	e3cfe0ef          	jal	80000d36 <release>
    800026fe:	bf6d                	j	800026b8 <clockintr+0xe>

0000000080002700 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002700:	1101                	addi	sp,sp,-32
    80002702:	ec06                	sd	ra,24(sp)
    80002704:	e822                	sd	s0,16(sp)
    80002706:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    80002708:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    8000270c:	57fd                	li	a5,-1
    8000270e:	17fe                	slli	a5,a5,0x3f
    80002710:	07a5                	addi	a5,a5,9
    80002712:	00f70c63          	beq	a4,a5,8000272a <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    80002716:	57fd                	li	a5,-1
    80002718:	17fe                	slli	a5,a5,0x3f
    8000271a:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000271c:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    8000271e:	04f70463          	beq	a4,a5,80002766 <devintr+0x66>
  }
}
    80002722:	60e2                	ld	ra,24(sp)
    80002724:	6442                	ld	s0,16(sp)
    80002726:	6105                	addi	sp,sp,32
    80002728:	8082                	ret
    8000272a:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000272c:	050030ef          	jal	8000577c <plic_claim>
    80002730:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    80002732:	47a9                	li	a5,10
    80002734:	02f50363          	beq	a0,a5,8000275a <devintr+0x5a>
    } else if (irq == VIRTIO0_IRQ) {
    80002738:	4785                	li	a5,1
    8000273a:	02f50363          	beq	a0,a5,80002760 <devintr+0x60>
    } else if (irq) {
    8000273e:	c919                	beqz	a0,80002754 <devintr+0x54>
      printk("unexpected interrupt irq=%d\n", irq);
    80002740:	85aa                	mv	a1,a0
    80002742:	00005517          	auipc	a0,0x5
    80002746:	c0e50513          	addi	a0,a0,-1010 # 80007350 <etext+0x350>
    8000274a:	dc7fd0ef          	jal	80000510 <printk>
      plic_complete(irq);
    8000274e:	8526                	mv	a0,s1
    80002750:	04c030ef          	jal	8000579c <plic_complete>
    return 1;
    80002754:	4505                	li	a0,1
    80002756:	64a2                	ld	s1,8(sp)
    80002758:	b7e9                	j	80002722 <devintr+0x22>
      uartintr();
    8000275a:	a84fe0ef          	jal	800009de <uartintr>
    if (irq)
    8000275e:	bfc5                	j	8000274e <devintr+0x4e>
      virtio_disk_intr();
    80002760:	4c2030ef          	jal	80005c22 <virtio_disk_intr>
    if (irq)
    80002764:	b7ed                	j	8000274e <devintr+0x4e>
    clockintr();
    80002766:	f45ff0ef          	jal	800026aa <clockintr>
    return 2;
    8000276a:	4509                	li	a0,2
    8000276c:	bf5d                	j	80002722 <devintr+0x22>

000000008000276e <usertrap>:
{
    8000276e:	1101                	addi	sp,sp,-32
    80002770:	ec06                	sd	ra,24(sp)
    80002772:	e822                	sd	s0,16(sp)
    80002774:	e426                	sd	s1,8(sp)
    80002776:	e04a                	sd	s2,0(sp)
    80002778:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000277a:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    8000277e:	1007f793          	andi	a5,a5,256
    80002782:	eba5                	bnez	a5,800027f2 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002784:	00003797          	auipc	a5,0x3
    80002788:	f4c78793          	addi	a5,a5,-180 # 800056d0 <kernelvec>
    8000278c:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002790:	af4ff0ef          	jal	80001a84 <myproc>
    80002794:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002796:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002798:	14102773          	csrr	a4,sepc
    8000279c:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    8000279e:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    800027a2:	47a1                	li	a5,8
    800027a4:	04f70d63          	beq	a4,a5,800027fe <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    800027a8:	f59ff0ef          	jal	80002700 <devintr>
    800027ac:	892a                	mv	s2,a0
    800027ae:	e54d                	bnez	a0,80002858 <usertrap+0xea>
    800027b0:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800027b4:	47bd                	li	a5,15
    800027b6:	08f70463          	beq	a4,a5,8000283e <usertrap+0xd0>
    800027ba:	14202773          	csrr	a4,scause
    800027be:	47b5                	li	a5,13
    800027c0:	06f70f63          	beq	a4,a5,8000283e <usertrap+0xd0>
    800027c4:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800027c8:	5890                	lw	a2,48(s1)
    800027ca:	00005517          	auipc	a0,0x5
    800027ce:	bc650513          	addi	a0,a0,-1082 # 80007390 <etext+0x390>
    800027d2:	d3ffd0ef          	jal	80000510 <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800027d6:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800027da:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800027de:	00005517          	auipc	a0,0x5
    800027e2:	be250513          	addi	a0,a0,-1054 # 800073c0 <etext+0x3c0>
    800027e6:	d2bfd0ef          	jal	80000510 <printk>
    setkilled(p);
    800027ea:	8526                	mv	a0,s1
    800027ec:	b13ff0ef          	jal	800022fe <setkilled>
    800027f0:	a015                	j	80002814 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    800027f2:	00005517          	auipc	a0,0x5
    800027f6:	b7e50513          	addi	a0,a0,-1154 # 80007370 <etext+0x370>
    800027fa:	84efe0ef          	jal	80000848 <panic>
    if (killed(p))
    800027fe:	b25ff0ef          	jal	80002322 <killed>
    80002802:	e915                	bnez	a0,80002836 <usertrap+0xc8>
    p->trapframe->epc += 4;
    80002804:	6cb8                	ld	a4,88(s1)
    80002806:	6f1c                	ld	a5,24(a4)
    80002808:	0791                	addi	a5,a5,4
    8000280a:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    8000280c:	10016073          	csrsi	sstatus,2
    syscall();
    80002810:	240000ef          	jal	80002a50 <syscall>
  if (killed(p))
    80002814:	8526                	mv	a0,s1
    80002816:	b0dff0ef          	jal	80002322 <killed>
    8000281a:	e521                	bnez	a0,80002862 <usertrap+0xf4>
  prepare_return();
    8000281c:	e1bff0ef          	jal	80002636 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002820:	68a8                	ld	a0,80(s1)
    80002822:	8131                	srli	a0,a0,0xc
    80002824:	57fd                	li	a5,-1
    80002826:	17fe                	slli	a5,a5,0x3f
    80002828:	8d5d                	or	a0,a0,a5
}
    8000282a:	60e2                	ld	ra,24(sp)
    8000282c:	6442                	ld	s0,16(sp)
    8000282e:	64a2                	ld	s1,8(sp)
    80002830:	6902                	ld	s2,0(sp)
    80002832:	6105                	addi	sp,sp,32
    80002834:	8082                	ret
      kexit(-1);
    80002836:	557d                	li	a0,-1
    80002838:	9bbff0ef          	jal	800021f2 <kexit>
    8000283c:	b7e1                	j	80002804 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    8000283e:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    80002842:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    80002846:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    80002848:	0016b693          	seqz	a3,a3
    8000284c:	64ac                	ld	a1,72(s1)
    8000284e:	68a8                	ld	a0,80(s1)
    80002850:	d1ffe0ef          	jal	8000156e <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002854:	f161                	bnez	a0,80002814 <usertrap+0xa6>
    80002856:	b7bd                	j	800027c4 <usertrap+0x56>
  if (killed(p))
    80002858:	8526                	mv	a0,s1
    8000285a:	ac9ff0ef          	jal	80002322 <killed>
    8000285e:	c511                	beqz	a0,8000286a <usertrap+0xfc>
    80002860:	a011                	j	80002864 <usertrap+0xf6>
    80002862:	4901                	li	s2,0
    kexit(-1);
    80002864:	557d                	li	a0,-1
    80002866:	98dff0ef          	jal	800021f2 <kexit>
  if (which_dev == 2)
    8000286a:	4789                	li	a5,2
    8000286c:	faf918e3          	bne	s2,a5,8000281c <usertrap+0xae>
    yield();
    80002870:	82fff0ef          	jal	8000209e <yield>
    80002874:	b765                	j	8000281c <usertrap+0xae>

0000000080002876 <kerneltrap>:
{
    80002876:	7179                	addi	sp,sp,-48
    80002878:	f406                	sd	ra,40(sp)
    8000287a:	f022                	sd	s0,32(sp)
    8000287c:	ec26                	sd	s1,24(sp)
    8000287e:	e84a                	sd	s2,16(sp)
    80002880:	e44e                	sd	s3,8(sp)
    80002882:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002884:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002888:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    8000288c:	142027f3          	csrr	a5,scause
    80002890:	89be                	mv	s3,a5
  if ((sstatus & SSTATUS_SPP) == 0)
    80002892:	1004f793          	andi	a5,s1,256
    80002896:	c795                	beqz	a5,800028c2 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002898:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000289c:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    8000289e:	eb85                	bnez	a5,800028ce <kerneltrap+0x58>
  if ((which_dev = devintr()) == 0) {
    800028a0:	e61ff0ef          	jal	80002700 <devintr>
    800028a4:	c91d                	beqz	a0,800028da <kerneltrap+0x64>
  if (which_dev == 2 && myproc() != 0)
    800028a6:	4789                	li	a5,2
    800028a8:	04f50a63          	beq	a0,a5,800028fc <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r"(x));
    800028ac:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    800028b0:	10049073          	csrw	sstatus,s1
}
    800028b4:	70a2                	ld	ra,40(sp)
    800028b6:	7402                	ld	s0,32(sp)
    800028b8:	64e2                	ld	s1,24(sp)
    800028ba:	6942                	ld	s2,16(sp)
    800028bc:	69a2                	ld	s3,8(sp)
    800028be:	6145                	addi	sp,sp,48
    800028c0:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800028c2:	00005517          	auipc	a0,0x5
    800028c6:	b2650513          	addi	a0,a0,-1242 # 800073e8 <etext+0x3e8>
    800028ca:	f7ffd0ef          	jal	80000848 <panic>
    panic("kerneltrap: interrupts enabled");
    800028ce:	00005517          	auipc	a0,0x5
    800028d2:	b4250513          	addi	a0,a0,-1214 # 80007410 <etext+0x410>
    800028d6:	f73fd0ef          	jal	80000848 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800028da:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800028de:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    800028e2:	85ce                	mv	a1,s3
    800028e4:	00005517          	auipc	a0,0x5
    800028e8:	b4c50513          	addi	a0,a0,-1204 # 80007430 <etext+0x430>
    800028ec:	c25fd0ef          	jal	80000510 <printk>
    panic("kerneltrap");
    800028f0:	00005517          	auipc	a0,0x5
    800028f4:	b6850513          	addi	a0,a0,-1176 # 80007458 <etext+0x458>
    800028f8:	f51fd0ef          	jal	80000848 <panic>
  if (which_dev == 2 && myproc() != 0)
    800028fc:	988ff0ef          	jal	80001a84 <myproc>
    80002900:	d555                	beqz	a0,800028ac <kerneltrap+0x36>
    yield();
    80002902:	f9cff0ef          	jal	8000209e <yield>
    80002906:	b75d                	j	800028ac <kerneltrap+0x36>

0000000080002908 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002908:	1101                	addi	sp,sp,-32
    8000290a:	ec06                	sd	ra,24(sp)
    8000290c:	e822                	sd	s0,16(sp)
    8000290e:	e426                	sd	s1,8(sp)
    80002910:	1000                	addi	s0,sp,32
    80002912:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002914:	970ff0ef          	jal	80001a84 <myproc>
  switch (n) {
    80002918:	4795                	li	a5,5
    8000291a:	0497e163          	bltu	a5,s1,8000295c <argraw+0x54>
    8000291e:	048a                	slli	s1,s1,0x2
    80002920:	00005717          	auipc	a4,0x5
    80002924:	f3870713          	addi	a4,a4,-200 # 80007858 <states.0+0x30>
    80002928:	94ba                	add	s1,s1,a4
    8000292a:	409c                	lw	a5,0(s1)
    8000292c:	97ba                	add	a5,a5,a4
    8000292e:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002930:	6d3c                	ld	a5,88(a0)
    80002932:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002934:	60e2                	ld	ra,24(sp)
    80002936:	6442                	ld	s0,16(sp)
    80002938:	64a2                	ld	s1,8(sp)
    8000293a:	6105                	addi	sp,sp,32
    8000293c:	8082                	ret
    return p->trapframe->a1;
    8000293e:	6d3c                	ld	a5,88(a0)
    80002940:	7fa8                	ld	a0,120(a5)
    80002942:	bfcd                	j	80002934 <argraw+0x2c>
    return p->trapframe->a2;
    80002944:	6d3c                	ld	a5,88(a0)
    80002946:	63c8                	ld	a0,128(a5)
    80002948:	b7f5                	j	80002934 <argraw+0x2c>
    return p->trapframe->a3;
    8000294a:	6d3c                	ld	a5,88(a0)
    8000294c:	67c8                	ld	a0,136(a5)
    8000294e:	b7dd                	j	80002934 <argraw+0x2c>
    return p->trapframe->a4;
    80002950:	6d3c                	ld	a5,88(a0)
    80002952:	6bc8                	ld	a0,144(a5)
    80002954:	b7c5                	j	80002934 <argraw+0x2c>
    return p->trapframe->a5;
    80002956:	6d3c                	ld	a5,88(a0)
    80002958:	6fc8                	ld	a0,152(a5)
    8000295a:	bfe9                	j	80002934 <argraw+0x2c>
  panic("argraw");
    8000295c:	00005517          	auipc	a0,0x5
    80002960:	b0c50513          	addi	a0,a0,-1268 # 80007468 <etext+0x468>
    80002964:	ee5fd0ef          	jal	80000848 <panic>

0000000080002968 <fetchaddr>:
{
    80002968:	1101                	addi	sp,sp,-32
    8000296a:	ec06                	sd	ra,24(sp)
    8000296c:	e822                	sd	s0,16(sp)
    8000296e:	e426                	sd	s1,8(sp)
    80002970:	e04a                	sd	s2,0(sp)
    80002972:	1000                	addi	s0,sp,32
    80002974:	84aa                	mv	s1,a0
    80002976:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002978:	90cff0ef          	jal	80001a84 <myproc>
  if (addr >= p->sz ||
    8000297c:	652c                	ld	a1,72(a0)
    8000297e:	02b4f663          	bgeu	s1,a1,800029aa <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002982:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    80002986:	02f5e263          	bltu	a1,a5,800029aa <fetchaddr+0x42>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    8000298a:	4721                	li	a4,8
    8000298c:	86a6                	mv	a3,s1
    8000298e:	864a                	mv	a2,s2
    80002990:	6928                	ld	a0,80(a0)
    80002992:	d15fe0ef          	jal	800016a6 <copyin>
    80002996:	00a03533          	snez	a0,a0
    8000299a:	40a0053b          	negw	a0,a0
}
    8000299e:	60e2                	ld	ra,24(sp)
    800029a0:	6442                	ld	s0,16(sp)
    800029a2:	64a2                	ld	s1,8(sp)
    800029a4:	6902                	ld	s2,0(sp)
    800029a6:	6105                	addi	sp,sp,32
    800029a8:	8082                	ret
    return -1;
    800029aa:	557d                	li	a0,-1
    800029ac:	bfcd                	j	8000299e <fetchaddr+0x36>

00000000800029ae <fetchstr>:
{
    800029ae:	7179                	addi	sp,sp,-48
    800029b0:	f406                	sd	ra,40(sp)
    800029b2:	f022                	sd	s0,32(sp)
    800029b4:	ec26                	sd	s1,24(sp)
    800029b6:	e84a                	sd	s2,16(sp)
    800029b8:	e44e                	sd	s3,8(sp)
    800029ba:	1800                	addi	s0,sp,48
    800029bc:	89aa                	mv	s3,a0
    800029be:	84ae                	mv	s1,a1
    800029c0:	8932                	mv	s2,a2
  struct proc *p = myproc();
    800029c2:	8c2ff0ef          	jal	80001a84 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    800029c6:	874a                	mv	a4,s2
    800029c8:	86ce                	mv	a3,s3
    800029ca:	8626                	mv	a2,s1
    800029cc:	652c                	ld	a1,72(a0)
    800029ce:	6928                	ld	a0,80(a0)
    800029d0:	d75fe0ef          	jal	80001744 <copyinstr>
    800029d4:	00054c63          	bltz	a0,800029ec <fetchstr+0x3e>
  return strlen(buf);
    800029d8:	8526                	mv	a0,s1
    800029da:	d14fe0ef          	jal	80000eee <strlen>
}
    800029de:	70a2                	ld	ra,40(sp)
    800029e0:	7402                	ld	s0,32(sp)
    800029e2:	64e2                	ld	s1,24(sp)
    800029e4:	6942                	ld	s2,16(sp)
    800029e6:	69a2                	ld	s3,8(sp)
    800029e8:	6145                	addi	sp,sp,48
    800029ea:	8082                	ret
    return -1;
    800029ec:	557d                	li	a0,-1
    800029ee:	bfc5                	j	800029de <fetchstr+0x30>

00000000800029f0 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800029f0:	1101                	addi	sp,sp,-32
    800029f2:	ec06                	sd	ra,24(sp)
    800029f4:	e822                	sd	s0,16(sp)
    800029f6:	e426                	sd	s1,8(sp)
    800029f8:	1000                	addi	s0,sp,32
    800029fa:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800029fc:	f0dff0ef          	jal	80002908 <argraw>
    80002a00:	c088                	sw	a0,0(s1)
}
    80002a02:	60e2                	ld	ra,24(sp)
    80002a04:	6442                	ld	s0,16(sp)
    80002a06:	64a2                	ld	s1,8(sp)
    80002a08:	6105                	addi	sp,sp,32
    80002a0a:	8082                	ret

0000000080002a0c <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002a0c:	1101                	addi	sp,sp,-32
    80002a0e:	ec06                	sd	ra,24(sp)
    80002a10:	e822                	sd	s0,16(sp)
    80002a12:	e426                	sd	s1,8(sp)
    80002a14:	1000                	addi	s0,sp,32
    80002a16:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a18:	ef1ff0ef          	jal	80002908 <argraw>
    80002a1c:	e088                	sd	a0,0(s1)
}
    80002a1e:	60e2                	ld	ra,24(sp)
    80002a20:	6442                	ld	s0,16(sp)
    80002a22:	64a2                	ld	s1,8(sp)
    80002a24:	6105                	addi	sp,sp,32
    80002a26:	8082                	ret

0000000080002a28 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002a28:	1101                	addi	sp,sp,-32
    80002a2a:	ec06                	sd	ra,24(sp)
    80002a2c:	e822                	sd	s0,16(sp)
    80002a2e:	e426                	sd	s1,8(sp)
    80002a30:	e04a                	sd	s2,0(sp)
    80002a32:	1000                	addi	s0,sp,32
    80002a34:	892e                	mv	s2,a1
    80002a36:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002a38:	ed1ff0ef          	jal	80002908 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80002a3c:	8626                	mv	a2,s1
    80002a3e:	85ca                	mv	a1,s2
    80002a40:	f6fff0ef          	jal	800029ae <fetchstr>
}
    80002a44:	60e2                	ld	ra,24(sp)
    80002a46:	6442                	ld	s0,16(sp)
    80002a48:	64a2                	ld	s1,8(sp)
    80002a4a:	6902                	ld	s2,0(sp)
    80002a4c:	6105                	addi	sp,sp,32
    80002a4e:	8082                	ret

0000000080002a50 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    80002a50:	1101                	addi	sp,sp,-32
    80002a52:	ec06                	sd	ra,24(sp)
    80002a54:	e822                	sd	s0,16(sp)
    80002a56:	e426                	sd	s1,8(sp)
    80002a58:	e04a                	sd	s2,0(sp)
    80002a5a:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002a5c:	828ff0ef          	jal	80001a84 <myproc>
    80002a60:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002a62:	05853903          	ld	s2,88(a0)
    80002a66:	0a893783          	ld	a5,168(s2)
    80002a6a:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002a6e:	37fd                	addiw	a5,a5,-1
    80002a70:	4765                	li	a4,25
    80002a72:	00f76f63          	bltu	a4,a5,80002a90 <syscall+0x40>
    80002a76:	00369713          	slli	a4,a3,0x3
    80002a7a:	00005797          	auipc	a5,0x5
    80002a7e:	df678793          	addi	a5,a5,-522 # 80007870 <syscalls>
    80002a82:	97ba                	add	a5,a5,a4
    80002a84:	639c                	ld	a5,0(a5)
    80002a86:	c789                	beqz	a5,80002a90 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002a88:	9782                	jalr	a5
    80002a8a:	06a93823          	sd	a0,112(s2)
    80002a8e:	a829                	j	80002aa8 <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    80002a90:	15848613          	addi	a2,s1,344
    80002a94:	588c                	lw	a1,48(s1)
    80002a96:	00005517          	auipc	a0,0x5
    80002a9a:	9da50513          	addi	a0,a0,-1574 # 80007470 <etext+0x470>
    80002a9e:	a73fd0ef          	jal	80000510 <printk>
    p->trapframe->a0 = -1;
    80002aa2:	6cbc                	ld	a5,88(s1)
    80002aa4:	577d                	li	a4,-1
    80002aa6:	fbb8                	sd	a4,112(a5)
  }
}
    80002aa8:	60e2                	ld	ra,24(sp)
    80002aaa:	6442                	ld	s0,16(sp)
    80002aac:	64a2                	ld	s1,8(sp)
    80002aae:	6902                	ld	s2,0(sp)
    80002ab0:	6105                	addi	sp,sp,32
    80002ab2:	8082                	ret

0000000080002ab4 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002ab4:	1101                	addi	sp,sp,-32
    80002ab6:	ec06                	sd	ra,24(sp)
    80002ab8:	e822                	sd	s0,16(sp)
    80002aba:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002abc:	fec40593          	addi	a1,s0,-20
    80002ac0:	4501                	li	a0,0
    80002ac2:	f2fff0ef          	jal	800029f0 <argint>
  kexit(n);
    80002ac6:	fec42503          	lw	a0,-20(s0)
    80002aca:	f28ff0ef          	jal	800021f2 <kexit>
  return 0; // not reached
}
    80002ace:	4501                	li	a0,0
    80002ad0:	60e2                	ld	ra,24(sp)
    80002ad2:	6442                	ld	s0,16(sp)
    80002ad4:	6105                	addi	sp,sp,32
    80002ad6:	8082                	ret

0000000080002ad8 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002ad8:	1141                	addi	sp,sp,-16
    80002ada:	e406                	sd	ra,8(sp)
    80002adc:	e022                	sd	s0,0(sp)
    80002ade:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002ae0:	fa5fe0ef          	jal	80001a84 <myproc>
}
    80002ae4:	5908                	lw	a0,48(a0)
    80002ae6:	60a2                	ld	ra,8(sp)
    80002ae8:	6402                	ld	s0,0(sp)
    80002aea:	0141                	addi	sp,sp,16
    80002aec:	8082                	ret

0000000080002aee <sys_fork>:

uint64
sys_fork(void)
{
    80002aee:	1141                	addi	sp,sp,-16
    80002af0:	e406                	sd	ra,8(sp)
    80002af2:	e022                	sd	s0,0(sp)
    80002af4:	0800                	addi	s0,sp,16
  return kfork();
    80002af6:	b1cff0ef          	jal	80001e12 <kfork>
}
    80002afa:	60a2                	ld	ra,8(sp)
    80002afc:	6402                	ld	s0,0(sp)
    80002afe:	0141                	addi	sp,sp,16
    80002b00:	8082                	ret

0000000080002b02 <sys_wait>:

uint64
sys_wait(void)
{
    80002b02:	1101                	addi	sp,sp,-32
    80002b04:	ec06                	sd	ra,24(sp)
    80002b06:	e822                	sd	s0,16(sp)
    80002b08:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002b0a:	fe840593          	addi	a1,s0,-24
    80002b0e:	4501                	li	a0,0
    80002b10:	efdff0ef          	jal	80002a0c <argaddr>
  return kwait(p);
    80002b14:	fe843503          	ld	a0,-24(s0)
    80002b18:	835ff0ef          	jal	8000234c <kwait>
}
    80002b1c:	60e2                	ld	ra,24(sp)
    80002b1e:	6442                	ld	s0,16(sp)
    80002b20:	6105                	addi	sp,sp,32
    80002b22:	8082                	ret

0000000080002b24 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002b24:	7179                	addi	sp,sp,-48
    80002b26:	f406                	sd	ra,40(sp)
    80002b28:	f022                	sd	s0,32(sp)
    80002b2a:	ec26                	sd	s1,24(sp)
    80002b2c:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002b2e:	fd840593          	addi	a1,s0,-40
    80002b32:	4501                	li	a0,0
    80002b34:	ebdff0ef          	jal	800029f0 <argint>
  argint(1, &t);
    80002b38:	fdc40593          	addi	a1,s0,-36
    80002b3c:	4505                	li	a0,1
    80002b3e:	eb3ff0ef          	jal	800029f0 <argint>
  addr = myproc()->sz;
    80002b42:	f43fe0ef          	jal	80001a84 <myproc>
    80002b46:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    80002b48:	fdc42703          	lw	a4,-36(s0)
    80002b4c:	4785                	li	a5,1
    80002b4e:	02f70a63          	beq	a4,a5,80002b82 <sys_sbrk+0x5e>
    80002b52:	fd842783          	lw	a5,-40(s0)
    80002b56:	0207c663          	bltz	a5,80002b82 <sys_sbrk+0x5e>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    80002b5a:	00978733          	add	a4,a5,s1
      return -1;
    if (addr + n > TRAPFRAME)
    80002b5e:	020007b7          	lui	a5,0x2000
    80002b62:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80002b64:	07b6                	slli	a5,a5,0xd
    80002b66:	00e7b7b3          	sltu	a5,a5,a4
    if (addr + n < addr)
    80002b6a:	00973733          	sltu	a4,a4,s1
    if (addr + n > TRAPFRAME)
    80002b6e:	8fd9                	or	a5,a5,a4
    80002b70:	e79d                	bnez	a5,80002b9e <sys_sbrk+0x7a>
      return -1;
    myproc()->sz += n;
    80002b72:	f13fe0ef          	jal	80001a84 <myproc>
    80002b76:	fd842703          	lw	a4,-40(s0)
    80002b7a:	653c                	ld	a5,72(a0)
    80002b7c:	97ba                	add	a5,a5,a4
    80002b7e:	e53c                	sd	a5,72(a0)
    80002b80:	a039                	j	80002b8e <sys_sbrk+0x6a>
    if (growproc(n) < 0) {
    80002b82:	fd842503          	lw	a0,-40(s0)
    80002b86:	a2eff0ef          	jal	80001db4 <growproc>
    80002b8a:	00054863          	bltz	a0,80002b9a <sys_sbrk+0x76>
  }
  return addr;
}
    80002b8e:	8526                	mv	a0,s1
    80002b90:	70a2                	ld	ra,40(sp)
    80002b92:	7402                	ld	s0,32(sp)
    80002b94:	64e2                	ld	s1,24(sp)
    80002b96:	6145                	addi	sp,sp,48
    80002b98:	8082                	ret
      return -1;
    80002b9a:	54fd                	li	s1,-1
    80002b9c:	bfcd                	j	80002b8e <sys_sbrk+0x6a>
      return -1;
    80002b9e:	54fd                	li	s1,-1
    80002ba0:	b7fd                	j	80002b8e <sys_sbrk+0x6a>

0000000080002ba2 <sys_pause>:

uint64
sys_pause(void)
{
    80002ba2:	7139                	addi	sp,sp,-64
    80002ba4:	fc06                	sd	ra,56(sp)
    80002ba6:	f822                	sd	s0,48(sp)
    80002ba8:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002baa:	fcc40593          	addi	a1,s0,-52
    80002bae:	4501                	li	a0,0
    80002bb0:	e41ff0ef          	jal	800029f0 <argint>
  if (n < 0)
    80002bb4:	fcc42783          	lw	a5,-52(s0)
    80002bb8:	0807c063          	bltz	a5,80002c38 <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    80002bbc:	00013517          	auipc	a0,0x13
    80002bc0:	f1c50513          	addi	a0,a0,-228 # 80015ad8 <tickslock>
    80002bc4:	8eefe0ef          	jal	80000cb2 <acquire>
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    80002bc8:	fcc42783          	lw	a5,-52(s0)
    80002bcc:	cbb9                	beqz	a5,80002c22 <sys_pause+0x80>
    80002bce:	f426                	sd	s1,40(sp)
    80002bd0:	f04a                	sd	s2,32(sp)
    80002bd2:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002bd4:	00005997          	auipc	s3,0x5
    80002bd8:	dac9a983          	lw	s3,-596(s3) # 80007980 <ticks>
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    80002bdc:	00005917          	auipc	s2,0x5
    80002be0:	da490913          	addi	s2,s2,-604 # 80007980 <ticks>
    release(&tickslock);
    80002be4:	00013497          	auipc	s1,0x13
    80002be8:	ef448493          	addi	s1,s1,-268 # 80015ad8 <tickslock>
    if (killed(myproc())) {
    80002bec:	e99fe0ef          	jal	80001a84 <myproc>
    80002bf0:	f32ff0ef          	jal	80002322 <killed>
    80002bf4:	e529                	bnez	a0,80002c3e <sys_pause+0x9c>
    sleep_prepare(&ticks);
    80002bf6:	854a                	mv	a0,s2
    80002bf8:	cd2ff0ef          	jal	800020ca <sleep_prepare>
    release(&tickslock);
    80002bfc:	8526                	mv	a0,s1
    80002bfe:	938fe0ef          	jal	80000d36 <release>
    sleep();
    80002c02:	d04ff0ef          	jal	80002106 <sleep>
    acquire(&tickslock);
    80002c06:	8526                	mv	a0,s1
    80002c08:	8aafe0ef          	jal	80000cb2 <acquire>
  while (ticks - ticks0 < n) {
    80002c0c:	00092783          	lw	a5,0(s2)
    80002c10:	413787bb          	subw	a5,a5,s3
    80002c14:	fcc42703          	lw	a4,-52(s0)
    80002c18:	fce7eae3          	bltu	a5,a4,80002bec <sys_pause+0x4a>
    80002c1c:	74a2                	ld	s1,40(sp)
    80002c1e:	7902                	ld	s2,32(sp)
    80002c20:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002c22:	00013517          	auipc	a0,0x13
    80002c26:	eb650513          	addi	a0,a0,-330 # 80015ad8 <tickslock>
    80002c2a:	90cfe0ef          	jal	80000d36 <release>
  return 0;
    80002c2e:	4501                	li	a0,0
}
    80002c30:	70e2                	ld	ra,56(sp)
    80002c32:	7442                	ld	s0,48(sp)
    80002c34:	6121                	addi	sp,sp,64
    80002c36:	8082                	ret
    n = 0;
    80002c38:	fc042623          	sw	zero,-52(s0)
    80002c3c:	b741                	j	80002bbc <sys_pause+0x1a>
      release(&tickslock);
    80002c3e:	00013517          	auipc	a0,0x13
    80002c42:	e9a50513          	addi	a0,a0,-358 # 80015ad8 <tickslock>
    80002c46:	8f0fe0ef          	jal	80000d36 <release>
      return -1;
    80002c4a:	557d                	li	a0,-1
    80002c4c:	74a2                	ld	s1,40(sp)
    80002c4e:	7902                	ld	s2,32(sp)
    80002c50:	69e2                	ld	s3,24(sp)
    80002c52:	bff9                	j	80002c30 <sys_pause+0x8e>

0000000080002c54 <sys_kill>:

uint64
sys_kill(void)
{
    80002c54:	1101                	addi	sp,sp,-32
    80002c56:	ec06                	sd	ra,24(sp)
    80002c58:	e822                	sd	s0,16(sp)
    80002c5a:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002c5c:	fec40593          	addi	a1,s0,-20
    80002c60:	4501                	li	a0,0
    80002c62:	d8fff0ef          	jal	800029f0 <argint>
  return kkill(pid);
    80002c66:	fec42503          	lw	a0,-20(s0)
    80002c6a:	e2eff0ef          	jal	80002298 <kkill>
}
    80002c6e:	60e2                	ld	ra,24(sp)
    80002c70:	6442                	ld	s0,16(sp)
    80002c72:	6105                	addi	sp,sp,32
    80002c74:	8082                	ret

0000000080002c76 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002c76:	1101                	addi	sp,sp,-32
    80002c78:	ec06                	sd	ra,24(sp)
    80002c7a:	e822                	sd	s0,16(sp)
    80002c7c:	e426                	sd	s1,8(sp)
    80002c7e:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002c80:	00013517          	auipc	a0,0x13
    80002c84:	e5850513          	addi	a0,a0,-424 # 80015ad8 <tickslock>
    80002c88:	82afe0ef          	jal	80000cb2 <acquire>
  xticks = ticks;
    80002c8c:	00005797          	auipc	a5,0x5
    80002c90:	cf47a783          	lw	a5,-780(a5) # 80007980 <ticks>
    80002c94:	84be                	mv	s1,a5
  release(&tickslock);
    80002c96:	00013517          	auipc	a0,0x13
    80002c9a:	e4250513          	addi	a0,a0,-446 # 80015ad8 <tickslock>
    80002c9e:	898fe0ef          	jal	80000d36 <release>
  return xticks;
}
    80002ca2:	02049513          	slli	a0,s1,0x20
    80002ca6:	9101                	srli	a0,a0,0x20
    80002ca8:	60e2                	ld	ra,24(sp)
    80002caa:	6442                	ld	s0,16(sp)
    80002cac:	64a2                	ld	s1,8(sp)
    80002cae:	6105                	addi	sp,sp,32
    80002cb0:	8082                	ret

0000000080002cb2 <sys_memstats>:

 
// System call: display memory statistics.
uint64
sys_memstats(void)
{
    80002cb2:	1141                	addi	sp,sp,-16
    80002cb4:	e406                	sd	ra,8(sp)
    80002cb6:	e022                	sd	s0,0(sp)
    80002cb8:	0800                	addi	s0,sp,16
  memstats();
    80002cba:	ee5fd0ef          	jal	80000b9e <memstats>
  return 0;
}
    80002cbe:	4501                	li	a0,0
    80002cc0:	60a2                	ld	ra,8(sp)
    80002cc2:	6402                	ld	s0,0(sp)
    80002cc4:	0141                	addi	sp,sp,16
    80002cc6:	8082                	ret

0000000080002cc8 <sys_vtop>:

// Q2: Translate a user virtual address to a physical address.
uint64
sys_vtop(void)
{
    80002cc8:	1101                	addi	sp,sp,-32
    80002cca:	ec06                	sd	ra,24(sp)
    80002ccc:	e822                	sd	s0,16(sp)
    80002cce:	1000                	addi	s0,sp,32
  uint64 va;
  argaddr(0, &va);
    80002cd0:	fe840593          	addi	a1,s0,-24
    80002cd4:	4501                	li	a0,0
    80002cd6:	d37ff0ef          	jal	80002a0c <argaddr>
  return vtop(myproc()->pagetable, va);
    80002cda:	dabfe0ef          	jal	80001a84 <myproc>
    80002cde:	fe843583          	ld	a1,-24(s0)
    80002ce2:	6928                	ld	a0,80(a0)
    80002ce4:	b39fe0ef          	jal	8000181c <vtop>
}
    80002ce8:	60e2                	ld	ra,24(sp)
    80002cea:	6442                	ld	s0,16(sp)
    80002cec:	6105                	addi	sp,sp,32
    80002cee:	8082                	ret

0000000080002cf0 <sys_pageinfo>:


// Q3: Display information about a user page.
uint64
sys_pageinfo(void)
{
    80002cf0:	1101                	addi	sp,sp,-32
    80002cf2:	ec06                	sd	ra,24(sp)
    80002cf4:	e822                	sd	s0,16(sp)
    80002cf6:	1000                	addi	s0,sp,32
  uint64 va;
  argaddr(0, &va);
    80002cf8:	fe840593          	addi	a1,s0,-24
    80002cfc:	4501                	li	a0,0
    80002cfe:	d0fff0ef          	jal	80002a0c <argaddr>
  return pageinfo(myproc()->pagetable, va);
    80002d02:	d83fe0ef          	jal	80001a84 <myproc>
    80002d06:	fe843583          	ld	a1,-24(s0)
    80002d0a:	6928                	ld	a0,80(a0)
    80002d0c:	b57fe0ef          	jal	80001862 <pageinfo>
}
    80002d10:	60e2                	ld	ra,24(sp)
    80002d12:	6442                	ld	s0,16(sp)
    80002d14:	6105                	addi	sp,sp,32
    80002d16:	8082                	ret

0000000080002d18 <sys_setreadonly>:

// Q3: Make a user page read-only.
uint64
sys_setreadonly(void)
{
    80002d18:	1101                	addi	sp,sp,-32
    80002d1a:	ec06                	sd	ra,24(sp)
    80002d1c:	e822                	sd	s0,16(sp)
    80002d1e:	1000                	addi	s0,sp,32
  uint64 va;
  argaddr(0, &va);
    80002d20:	fe840593          	addi	a1,s0,-24
    80002d24:	4501                	li	a0,0
    80002d26:	ce7ff0ef          	jal	80002a0c <argaddr>
  return setreadonly(myproc()->pagetable, va);
    80002d2a:	d5bfe0ef          	jal	80001a84 <myproc>
    80002d2e:	fe843583          	ld	a1,-24(s0)
    80002d32:	6928                	ld	a0,80(a0)
    80002d34:	b93fe0ef          	jal	800018c6 <setreadonly>
}
    80002d38:	60e2                	ld	ra,24(sp)
    80002d3a:	6442                	ld	s0,16(sp)
    80002d3c:	6105                	addi	sp,sp,32
    80002d3e:	8082                	ret

0000000080002d40 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002d40:	7179                	addi	sp,sp,-48
    80002d42:	f406                	sd	ra,40(sp)
    80002d44:	f022                	sd	s0,32(sp)
    80002d46:	ec26                	sd	s1,24(sp)
    80002d48:	e84a                	sd	s2,16(sp)
    80002d4a:	e44e                	sd	s3,8(sp)
    80002d4c:	e052                	sd	s4,0(sp)
    80002d4e:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002d50:	00004597          	auipc	a1,0x4
    80002d54:	74058593          	addi	a1,a1,1856 # 80007490 <etext+0x490>
    80002d58:	00013517          	auipc	a0,0x13
    80002d5c:	d9850513          	addi	a0,a0,-616 # 80015af0 <bcache>
    80002d60:	ed3fd0ef          	jal	80000c32 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002d64:	0001b797          	auipc	a5,0x1b
    80002d68:	d8c78793          	addi	a5,a5,-628 # 8001daf0 <bcache+0x8000>
    80002d6c:	0001b717          	auipc	a4,0x1b
    80002d70:	fec70713          	addi	a4,a4,-20 # 8001dd58 <bcache+0x8268>
    80002d74:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002d78:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002d7c:	00013497          	auipc	s1,0x13
    80002d80:	d8c48493          	addi	s1,s1,-628 # 80015b08 <bcache+0x18>
    b->next = bcache.head.next;
    80002d84:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002d86:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002d88:	00004a17          	auipc	s4,0x4
    80002d8c:	710a0a13          	addi	s4,s4,1808 # 80007498 <etext+0x498>
    b->next = bcache.head.next;
    80002d90:	2b893783          	ld	a5,696(s2)
    80002d94:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002d96:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002d9a:	85d2                	mv	a1,s4
    80002d9c:	01048513          	addi	a0,s1,16
    80002da0:	3d2010ef          	jal	80004172 <initsleeplock>
    bcache.head.next->prev = b;
    80002da4:	2b893783          	ld	a5,696(s2)
    80002da8:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002daa:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002dae:	45848493          	addi	s1,s1,1112
    80002db2:	fd349fe3          	bne	s1,s3,80002d90 <binit+0x50>
  }
}
    80002db6:	70a2                	ld	ra,40(sp)
    80002db8:	7402                	ld	s0,32(sp)
    80002dba:	64e2                	ld	s1,24(sp)
    80002dbc:	6942                	ld	s2,16(sp)
    80002dbe:	69a2                	ld	s3,8(sp)
    80002dc0:	6a02                	ld	s4,0(sp)
    80002dc2:	6145                	addi	sp,sp,48
    80002dc4:	8082                	ret

0000000080002dc6 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002dc6:	7179                	addi	sp,sp,-48
    80002dc8:	f406                	sd	ra,40(sp)
    80002dca:	f022                	sd	s0,32(sp)
    80002dcc:	ec26                	sd	s1,24(sp)
    80002dce:	e84a                	sd	s2,16(sp)
    80002dd0:	e44e                	sd	s3,8(sp)
    80002dd2:	1800                	addi	s0,sp,48
    80002dd4:	892a                	mv	s2,a0
    80002dd6:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002dd8:	00013517          	auipc	a0,0x13
    80002ddc:	d1850513          	addi	a0,a0,-744 # 80015af0 <bcache>
    80002de0:	ed3fd0ef          	jal	80000cb2 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002de4:	0001b497          	auipc	s1,0x1b
    80002de8:	fc44b483          	ld	s1,-60(s1) # 8001dda8 <bcache+0x82b8>
    80002dec:	0001b797          	auipc	a5,0x1b
    80002df0:	f6c78793          	addi	a5,a5,-148 # 8001dd58 <bcache+0x8268>
    80002df4:	02f48b63          	beq	s1,a5,80002e2a <bread+0x64>
    80002df8:	873e                	mv	a4,a5
    80002dfa:	a021                	j	80002e02 <bread+0x3c>
    80002dfc:	68a4                	ld	s1,80(s1)
    80002dfe:	02e48663          	beq	s1,a4,80002e2a <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002e02:	449c                	lw	a5,8(s1)
    80002e04:	ff279ce3          	bne	a5,s2,80002dfc <bread+0x36>
    80002e08:	44dc                	lw	a5,12(s1)
    80002e0a:	ff3799e3          	bne	a5,s3,80002dfc <bread+0x36>
      b->refcnt++;
    80002e0e:	40bc                	lw	a5,64(s1)
    80002e10:	2785                	addiw	a5,a5,1
    80002e12:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e14:	00013517          	auipc	a0,0x13
    80002e18:	cdc50513          	addi	a0,a0,-804 # 80015af0 <bcache>
    80002e1c:	f1bfd0ef          	jal	80000d36 <release>
      acquiresleep(&b->lock);
    80002e20:	01048513          	addi	a0,s1,16
    80002e24:	384010ef          	jal	800041a8 <acquiresleep>
      return b;
    80002e28:	a889                	j	80002e7a <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002e2a:	0001b497          	auipc	s1,0x1b
    80002e2e:	f764b483          	ld	s1,-138(s1) # 8001dda0 <bcache+0x82b0>
    80002e32:	0001b797          	auipc	a5,0x1b
    80002e36:	f2678793          	addi	a5,a5,-218 # 8001dd58 <bcache+0x8268>
    80002e3a:	00f48863          	beq	s1,a5,80002e4a <bread+0x84>
    80002e3e:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002e40:	40bc                	lw	a5,64(s1)
    80002e42:	cb91                	beqz	a5,80002e56 <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002e44:	64a4                	ld	s1,72(s1)
    80002e46:	fee49de3          	bne	s1,a4,80002e40 <bread+0x7a>
  panic("bget: no buffers");
    80002e4a:	00004517          	auipc	a0,0x4
    80002e4e:	65650513          	addi	a0,a0,1622 # 800074a0 <etext+0x4a0>
    80002e52:	9f7fd0ef          	jal	80000848 <panic>
      b->dev = dev;
    80002e56:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002e5a:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002e5e:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002e62:	4785                	li	a5,1
    80002e64:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e66:	00013517          	auipc	a0,0x13
    80002e6a:	c8a50513          	addi	a0,a0,-886 # 80015af0 <bcache>
    80002e6e:	ec9fd0ef          	jal	80000d36 <release>
      acquiresleep(&b->lock);
    80002e72:	01048513          	addi	a0,s1,16
    80002e76:	332010ef          	jal	800041a8 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002e7a:	409c                	lw	a5,0(s1)
    80002e7c:	cb89                	beqz	a5,80002e8e <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002e7e:	8526                	mv	a0,s1
    80002e80:	70a2                	ld	ra,40(sp)
    80002e82:	7402                	ld	s0,32(sp)
    80002e84:	64e2                	ld	s1,24(sp)
    80002e86:	6942                	ld	s2,16(sp)
    80002e88:	69a2                	ld	s3,8(sp)
    80002e8a:	6145                	addi	sp,sp,48
    80002e8c:	8082                	ret
    virtio_disk_rw(b, 0);
    80002e8e:	4581                	li	a1,0
    80002e90:	8526                	mv	a0,s1
    80002e92:	361020ef          	jal	800059f2 <virtio_disk_rw>
    b->valid = 1;
    80002e96:	4785                	li	a5,1
    80002e98:	c09c                	sw	a5,0(s1)
  return b;
    80002e9a:	b7d5                	j	80002e7e <bread+0xb8>

0000000080002e9c <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002e9c:	1101                	addi	sp,sp,-32
    80002e9e:	ec06                	sd	ra,24(sp)
    80002ea0:	e822                	sd	s0,16(sp)
    80002ea2:	e426                	sd	s1,8(sp)
    80002ea4:	1000                	addi	s0,sp,32
    80002ea6:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002ea8:	0541                	addi	a0,a0,16
    80002eaa:	38a010ef          	jal	80004234 <holdingsleep>
    80002eae:	c911                	beqz	a0,80002ec2 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002eb0:	4585                	li	a1,1
    80002eb2:	8526                	mv	a0,s1
    80002eb4:	33f020ef          	jal	800059f2 <virtio_disk_rw>
}
    80002eb8:	60e2                	ld	ra,24(sp)
    80002eba:	6442                	ld	s0,16(sp)
    80002ebc:	64a2                	ld	s1,8(sp)
    80002ebe:	6105                	addi	sp,sp,32
    80002ec0:	8082                	ret
    panic("bwrite");
    80002ec2:	00004517          	auipc	a0,0x4
    80002ec6:	5f650513          	addi	a0,a0,1526 # 800074b8 <etext+0x4b8>
    80002eca:	97ffd0ef          	jal	80000848 <panic>

0000000080002ece <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002ece:	1101                	addi	sp,sp,-32
    80002ed0:	ec06                	sd	ra,24(sp)
    80002ed2:	e822                	sd	s0,16(sp)
    80002ed4:	e426                	sd	s1,8(sp)
    80002ed6:	e04a                	sd	s2,0(sp)
    80002ed8:	1000                	addi	s0,sp,32
    80002eda:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002edc:	01050913          	addi	s2,a0,16
    80002ee0:	854a                	mv	a0,s2
    80002ee2:	352010ef          	jal	80004234 <holdingsleep>
    80002ee6:	c125                	beqz	a0,80002f46 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002ee8:	854a                	mv	a0,s2
    80002eea:	312010ef          	jal	800041fc <releasesleep>

  acquire(&bcache.lock);
    80002eee:	00013517          	auipc	a0,0x13
    80002ef2:	c0250513          	addi	a0,a0,-1022 # 80015af0 <bcache>
    80002ef6:	dbdfd0ef          	jal	80000cb2 <acquire>
  b->refcnt--;
    80002efa:	40bc                	lw	a5,64(s1)
    80002efc:	37fd                	addiw	a5,a5,-1
    80002efe:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002f00:	e79d                	bnez	a5,80002f2e <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002f02:	68b8                	ld	a4,80(s1)
    80002f04:	64bc                	ld	a5,72(s1)
    80002f06:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002f08:	68b8                	ld	a4,80(s1)
    80002f0a:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002f0c:	0001b797          	auipc	a5,0x1b
    80002f10:	be478793          	addi	a5,a5,-1052 # 8001daf0 <bcache+0x8000>
    80002f14:	2b87b703          	ld	a4,696(a5)
    80002f18:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002f1a:	0001b717          	auipc	a4,0x1b
    80002f1e:	e3e70713          	addi	a4,a4,-450 # 8001dd58 <bcache+0x8268>
    80002f22:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002f24:	2b87b703          	ld	a4,696(a5)
    80002f28:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002f2a:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002f2e:	00013517          	auipc	a0,0x13
    80002f32:	bc250513          	addi	a0,a0,-1086 # 80015af0 <bcache>
    80002f36:	e01fd0ef          	jal	80000d36 <release>
}
    80002f3a:	60e2                	ld	ra,24(sp)
    80002f3c:	6442                	ld	s0,16(sp)
    80002f3e:	64a2                	ld	s1,8(sp)
    80002f40:	6902                	ld	s2,0(sp)
    80002f42:	6105                	addi	sp,sp,32
    80002f44:	8082                	ret
    panic("brelse");
    80002f46:	00004517          	auipc	a0,0x4
    80002f4a:	57a50513          	addi	a0,a0,1402 # 800074c0 <etext+0x4c0>
    80002f4e:	8fbfd0ef          	jal	80000848 <panic>

0000000080002f52 <bpin>:

void
bpin(struct buf *b)
{
    80002f52:	1101                	addi	sp,sp,-32
    80002f54:	ec06                	sd	ra,24(sp)
    80002f56:	e822                	sd	s0,16(sp)
    80002f58:	e426                	sd	s1,8(sp)
    80002f5a:	1000                	addi	s0,sp,32
    80002f5c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002f5e:	00013517          	auipc	a0,0x13
    80002f62:	b9250513          	addi	a0,a0,-1134 # 80015af0 <bcache>
    80002f66:	d4dfd0ef          	jal	80000cb2 <acquire>
  b->refcnt++;
    80002f6a:	40bc                	lw	a5,64(s1)
    80002f6c:	2785                	addiw	a5,a5,1
    80002f6e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002f70:	00013517          	auipc	a0,0x13
    80002f74:	b8050513          	addi	a0,a0,-1152 # 80015af0 <bcache>
    80002f78:	dbffd0ef          	jal	80000d36 <release>
}
    80002f7c:	60e2                	ld	ra,24(sp)
    80002f7e:	6442                	ld	s0,16(sp)
    80002f80:	64a2                	ld	s1,8(sp)
    80002f82:	6105                	addi	sp,sp,32
    80002f84:	8082                	ret

0000000080002f86 <bunpin>:

void
bunpin(struct buf *b)
{
    80002f86:	1101                	addi	sp,sp,-32
    80002f88:	ec06                	sd	ra,24(sp)
    80002f8a:	e822                	sd	s0,16(sp)
    80002f8c:	e426                	sd	s1,8(sp)
    80002f8e:	1000                	addi	s0,sp,32
    80002f90:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002f92:	00013517          	auipc	a0,0x13
    80002f96:	b5e50513          	addi	a0,a0,-1186 # 80015af0 <bcache>
    80002f9a:	d19fd0ef          	jal	80000cb2 <acquire>
  b->refcnt--;
    80002f9e:	40bc                	lw	a5,64(s1)
    80002fa0:	37fd                	addiw	a5,a5,-1
    80002fa2:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002fa4:	00013517          	auipc	a0,0x13
    80002fa8:	b4c50513          	addi	a0,a0,-1204 # 80015af0 <bcache>
    80002fac:	d8bfd0ef          	jal	80000d36 <release>
}
    80002fb0:	60e2                	ld	ra,24(sp)
    80002fb2:	6442                	ld	s0,16(sp)
    80002fb4:	64a2                	ld	s1,8(sp)
    80002fb6:	6105                	addi	sp,sp,32
    80002fb8:	8082                	ret

0000000080002fba <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002fba:	1101                	addi	sp,sp,-32
    80002fbc:	ec06                	sd	ra,24(sp)
    80002fbe:	e822                	sd	s0,16(sp)
    80002fc0:	e426                	sd	s1,8(sp)
    80002fc2:	e04a                	sd	s2,0(sp)
    80002fc4:	1000                	addi	s0,sp,32
    80002fc6:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002fc8:	00d5d79b          	srliw	a5,a1,0xd
    80002fcc:	0001b597          	auipc	a1,0x1b
    80002fd0:	2005a583          	lw	a1,512(a1) # 8001e1cc <sb+0x1c>
    80002fd4:	9dbd                	addw	a1,a1,a5
    80002fd6:	df1ff0ef          	jal	80002dc6 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002fda:	0074f713          	andi	a4,s1,7
    80002fde:	4785                	li	a5,1
    80002fe0:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002fe4:	14ce                	slli	s1,s1,0x33
  if ((bp->data[bi / 8] & m) == 0)
    80002fe6:	90d9                	srli	s1,s1,0x36
    80002fe8:	00950733          	add	a4,a0,s1
    80002fec:	05874703          	lbu	a4,88(a4)
    80002ff0:	00e7f6b3          	and	a3,a5,a4
    80002ff4:	c29d                	beqz	a3,8000301a <bfree+0x60>
    80002ff6:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002ff8:	94aa                	add	s1,s1,a0
    80002ffa:	fff7c793          	not	a5,a5
    80002ffe:	8f7d                	and	a4,a4,a5
    80003000:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80003004:	03a010ef          	jal	8000403e <log_write>
  brelse(bp);
    80003008:	854a                	mv	a0,s2
    8000300a:	ec5ff0ef          	jal	80002ece <brelse>
}
    8000300e:	60e2                	ld	ra,24(sp)
    80003010:	6442                	ld	s0,16(sp)
    80003012:	64a2                	ld	s1,8(sp)
    80003014:	6902                	ld	s2,0(sp)
    80003016:	6105                	addi	sp,sp,32
    80003018:	8082                	ret
    panic("freeing free block");
    8000301a:	00004517          	auipc	a0,0x4
    8000301e:	4ae50513          	addi	a0,a0,1198 # 800074c8 <etext+0x4c8>
    80003022:	827fd0ef          	jal	80000848 <panic>

0000000080003026 <balloc>:
{
    80003026:	715d                	addi	sp,sp,-80
    80003028:	e486                	sd	ra,72(sp)
    8000302a:	e0a2                	sd	s0,64(sp)
    8000302c:	fc26                	sd	s1,56(sp)
    8000302e:	0880                	addi	s0,sp,80
  for (b = 0; b < sb.size; b += BPB) {
    80003030:	0001b797          	auipc	a5,0x1b
    80003034:	1847a783          	lw	a5,388(a5) # 8001e1b4 <sb+0x4>
    80003038:	0e078263          	beqz	a5,8000311c <balloc+0xf6>
    8000303c:	f84a                	sd	s2,48(sp)
    8000303e:	f44e                	sd	s3,40(sp)
    80003040:	f052                	sd	s4,32(sp)
    80003042:	ec56                	sd	s5,24(sp)
    80003044:	e85a                	sd	s6,16(sp)
    80003046:	e45e                	sd	s7,8(sp)
    80003048:	e062                	sd	s8,0(sp)
    8000304a:	8baa                	mv	s7,a0
    8000304c:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    8000304e:	0001bb17          	auipc	s6,0x1b
    80003052:	162b0b13          	addi	s6,s6,354 # 8001e1b0 <sb>
      m = 1 << (bi % 8);
    80003056:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003058:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    8000305a:	6c09                	lui	s8,0x2
    8000305c:	a09d                	j	800030c2 <balloc+0x9c>
        bp->data[bi / 8] |= m;           // Mark block in use.
    8000305e:	97ca                	add	a5,a5,s2
    80003060:	8e55                	or	a2,a2,a3
    80003062:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80003066:	854a                	mv	a0,s2
    80003068:	7d7000ef          	jal	8000403e <log_write>
        brelse(bp);
    8000306c:	854a                	mv	a0,s2
    8000306e:	e61ff0ef          	jal	80002ece <brelse>
  bp = bread(dev, bno);
    80003072:	85a6                	mv	a1,s1
    80003074:	855e                	mv	a0,s7
    80003076:	d51ff0ef          	jal	80002dc6 <bread>
    8000307a:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    8000307c:	40000613          	li	a2,1024
    80003080:	4581                	li	a1,0
    80003082:	05850513          	addi	a0,a0,88
    80003086:	ce9fd0ef          	jal	80000d6e <memset>
  log_write(bp);
    8000308a:	854a                	mv	a0,s2
    8000308c:	7b3000ef          	jal	8000403e <log_write>
  brelse(bp);
    80003090:	854a                	mv	a0,s2
    80003092:	e3dff0ef          	jal	80002ece <brelse>
        return b + bi;
    80003096:	7942                	ld	s2,48(sp)
    80003098:	79a2                	ld	s3,40(sp)
    8000309a:	7a02                	ld	s4,32(sp)
    8000309c:	6ae2                	ld	s5,24(sp)
    8000309e:	6b42                	ld	s6,16(sp)
    800030a0:	6ba2                	ld	s7,8(sp)
    800030a2:	6c02                	ld	s8,0(sp)
}
    800030a4:	8526                	mv	a0,s1
    800030a6:	60a6                	ld	ra,72(sp)
    800030a8:	6406                	ld	s0,64(sp)
    800030aa:	74e2                	ld	s1,56(sp)
    800030ac:	6161                	addi	sp,sp,80
    800030ae:	8082                	ret
    brelse(bp);
    800030b0:	854a                	mv	a0,s2
    800030b2:	e1dff0ef          	jal	80002ece <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    800030b6:	015c0abb          	addw	s5,s8,s5
    800030ba:	004b2783          	lw	a5,4(s6)
    800030be:	04faf863          	bgeu	s5,a5,8000310e <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    800030c2:	40dad59b          	sraiw	a1,s5,0xd
    800030c6:	01cb2783          	lw	a5,28(s6)
    800030ca:	9dbd                	addw	a1,a1,a5
    800030cc:	855e                	mv	a0,s7
    800030ce:	cf9ff0ef          	jal	80002dc6 <bread>
    800030d2:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    800030d4:	004b2503          	lw	a0,4(s6)
    800030d8:	84d6                	mv	s1,s5
    800030da:	4701                	li	a4,0
    800030dc:	fca4fae3          	bgeu	s1,a0,800030b0 <balloc+0x8a>
      m = 1 << (bi % 8);
    800030e0:	00777693          	andi	a3,a4,7
    800030e4:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    800030e8:	41f7579b          	sraiw	a5,a4,0x1f
    800030ec:	01d7d79b          	srliw	a5,a5,0x1d
    800030f0:	9fb9                	addw	a5,a5,a4
    800030f2:	4037d79b          	sraiw	a5,a5,0x3
    800030f6:	00f90633          	add	a2,s2,a5
    800030fa:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    800030fe:	00c6f5b3          	and	a1,a3,a2
    80003102:	ddb1                	beqz	a1,8000305e <balloc+0x38>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003104:	2705                	addiw	a4,a4,1
    80003106:	2485                	addiw	s1,s1,1
    80003108:	fd471ae3          	bne	a4,s4,800030dc <balloc+0xb6>
    8000310c:	b755                	j	800030b0 <balloc+0x8a>
    8000310e:	7942                	ld	s2,48(sp)
    80003110:	79a2                	ld	s3,40(sp)
    80003112:	7a02                	ld	s4,32(sp)
    80003114:	6ae2                	ld	s5,24(sp)
    80003116:	6b42                	ld	s6,16(sp)
    80003118:	6ba2                	ld	s7,8(sp)
    8000311a:	6c02                	ld	s8,0(sp)
  printk("balloc: out of blocks\n");
    8000311c:	00004517          	auipc	a0,0x4
    80003120:	3c450513          	addi	a0,a0,964 # 800074e0 <etext+0x4e0>
    80003124:	becfd0ef          	jal	80000510 <printk>
  return 0;
    80003128:	4481                	li	s1,0
    8000312a:	bfad                	j	800030a4 <balloc+0x7e>

000000008000312c <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000312c:	7179                	addi	sp,sp,-48
    8000312e:	f406                	sd	ra,40(sp)
    80003130:	f022                	sd	s0,32(sp)
    80003132:	ec26                	sd	s1,24(sp)
    80003134:	e84a                	sd	s2,16(sp)
    80003136:	e44e                	sd	s3,8(sp)
    80003138:	1800                	addi	s0,sp,48
    8000313a:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    8000313c:	47ad                	li	a5,11
    8000313e:	02b7e363          	bltu	a5,a1,80003164 <bmap+0x38>
    if ((addr = ip->addrs[bn]) == 0) {
    80003142:	02059793          	slli	a5,a1,0x20
    80003146:	01e7d593          	srli	a1,a5,0x1e
    8000314a:	00b509b3          	add	s3,a0,a1
    8000314e:	0509a483          	lw	s1,80(s3)
    80003152:	e0b5                	bnez	s1,800031b6 <bmap+0x8a>
      addr = balloc(ip->dev);
    80003154:	4108                	lw	a0,0(a0)
    80003156:	ed1ff0ef          	jal	80003026 <balloc>
    8000315a:	84aa                	mv	s1,a0
      if (addr == 0)
    8000315c:	cd29                	beqz	a0,800031b6 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    8000315e:	04a9a823          	sw	a0,80(s3)
    80003162:	a891                	j	800031b6 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003164:	ff45879b          	addiw	a5,a1,-12
    80003168:	873e                	mv	a4,a5
    8000316a:	89be                	mv	s3,a5

  if (bn < NINDIRECT) {
    8000316c:	0ff00793          	li	a5,255
    80003170:	06e7e763          	bltu	a5,a4,800031de <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80003174:	08052483          	lw	s1,128(a0)
    80003178:	e891                	bnez	s1,8000318c <bmap+0x60>
      addr = balloc(ip->dev);
    8000317a:	4108                	lw	a0,0(a0)
    8000317c:	eabff0ef          	jal	80003026 <balloc>
    80003180:	84aa                	mv	s1,a0
      if (addr == 0)
    80003182:	c915                	beqz	a0,800031b6 <bmap+0x8a>
    80003184:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003186:	08a92023          	sw	a0,128(s2)
    8000318a:	a011                	j	8000318e <bmap+0x62>
    8000318c:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000318e:	85a6                	mv	a1,s1
    80003190:	00092503          	lw	a0,0(s2)
    80003194:	c33ff0ef          	jal	80002dc6 <bread>
    80003198:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    8000319a:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    8000319e:	02099713          	slli	a4,s3,0x20
    800031a2:	01e75593          	srli	a1,a4,0x1e
    800031a6:	97ae                	add	a5,a5,a1
    800031a8:	89be                	mv	s3,a5
    800031aa:	4384                	lw	s1,0(a5)
    800031ac:	cc89                	beqz	s1,800031c6 <bmap+0x9a>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800031ae:	8552                	mv	a0,s4
    800031b0:	d1fff0ef          	jal	80002ece <brelse>
    return addr;
    800031b4:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    800031b6:	8526                	mv	a0,s1
    800031b8:	70a2                	ld	ra,40(sp)
    800031ba:	7402                	ld	s0,32(sp)
    800031bc:	64e2                	ld	s1,24(sp)
    800031be:	6942                	ld	s2,16(sp)
    800031c0:	69a2                	ld	s3,8(sp)
    800031c2:	6145                	addi	sp,sp,48
    800031c4:	8082                	ret
      addr = balloc(ip->dev);
    800031c6:	00092503          	lw	a0,0(s2)
    800031ca:	e5dff0ef          	jal	80003026 <balloc>
    800031ce:	84aa                	mv	s1,a0
      if (addr) {
    800031d0:	dd79                	beqz	a0,800031ae <bmap+0x82>
        a[bn] = addr;
    800031d2:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    800031d6:	8552                	mv	a0,s4
    800031d8:	667000ef          	jal	8000403e <log_write>
    800031dc:	bfc9                	j	800031ae <bmap+0x82>
    800031de:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800031e0:	00004517          	auipc	a0,0x4
    800031e4:	31850513          	addi	a0,a0,792 # 800074f8 <etext+0x4f8>
    800031e8:	e60fd0ef          	jal	80000848 <panic>

00000000800031ec <iget>:
{
    800031ec:	7179                	addi	sp,sp,-48
    800031ee:	f406                	sd	ra,40(sp)
    800031f0:	f022                	sd	s0,32(sp)
    800031f2:	ec26                	sd	s1,24(sp)
    800031f4:	e84a                	sd	s2,16(sp)
    800031f6:	e44e                	sd	s3,8(sp)
    800031f8:	e052                	sd	s4,0(sp)
    800031fa:	1800                	addi	s0,sp,48
    800031fc:	89aa                	mv	s3,a0
    800031fe:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003200:	0001b517          	auipc	a0,0x1b
    80003204:	fd050513          	addi	a0,a0,-48 # 8001e1d0 <itable>
    80003208:	aabfd0ef          	jal	80000cb2 <acquire>
  empty = 0;
    8000320c:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    8000320e:	0001b497          	auipc	s1,0x1b
    80003212:	fda48493          	addi	s1,s1,-38 # 8001e1e8 <itable+0x18>
    80003216:	0001d697          	auipc	a3,0x1d
    8000321a:	a6268693          	addi	a3,a3,-1438 # 8001fc78 <log>
    8000321e:	a819                	j	80003234 <iget+0x48>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80003220:	0017b793          	seqz	a5,a5
    80003224:	00193713          	seqz	a4,s2
    80003228:	8ff9                	and	a5,a5,a4
    8000322a:	eb85                	bnez	a5,8000325a <iget+0x6e>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    8000322c:	08848493          	addi	s1,s1,136
    80003230:	02d48763          	beq	s1,a3,8000325e <iget+0x72>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80003234:	449c                	lw	a5,8(s1)
    80003236:	fef055e3          	blez	a5,80003220 <iget+0x34>
    8000323a:	4098                	lw	a4,0(s1)
    8000323c:	ff3718e3          	bne	a4,s3,8000322c <iget+0x40>
    80003240:	40d8                	lw	a4,4(s1)
    80003242:	ff4715e3          	bne	a4,s4,8000322c <iget+0x40>
      ip->ref++;
    80003246:	2785                	addiw	a5,a5,1
    80003248:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    8000324a:	0001b517          	auipc	a0,0x1b
    8000324e:	f8650513          	addi	a0,a0,-122 # 8001e1d0 <itable>
    80003252:	ae5fd0ef          	jal	80000d36 <release>
      return ip;
    80003256:	8926                	mv	s2,s1
    80003258:	a025                	j	80003280 <iget+0x94>
      empty = ip;
    8000325a:	8926                	mv	s2,s1
    8000325c:	bfc1                	j	8000322c <iget+0x40>
  if (empty == 0)
    8000325e:	02090a63          	beqz	s2,80003292 <iget+0xa6>
  ip->dev = dev;
    80003262:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003266:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    8000326a:	4785                	li	a5,1
    8000326c:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003270:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80003274:	0001b517          	auipc	a0,0x1b
    80003278:	f5c50513          	addi	a0,a0,-164 # 8001e1d0 <itable>
    8000327c:	abbfd0ef          	jal	80000d36 <release>
}
    80003280:	854a                	mv	a0,s2
    80003282:	70a2                	ld	ra,40(sp)
    80003284:	7402                	ld	s0,32(sp)
    80003286:	64e2                	ld	s1,24(sp)
    80003288:	6942                	ld	s2,16(sp)
    8000328a:	69a2                	ld	s3,8(sp)
    8000328c:	6a02                	ld	s4,0(sp)
    8000328e:	6145                	addi	sp,sp,48
    80003290:	8082                	ret
    panic("iget: no inodes");
    80003292:	00004517          	auipc	a0,0x4
    80003296:	27e50513          	addi	a0,a0,638 # 80007510 <etext+0x510>
    8000329a:	daefd0ef          	jal	80000848 <panic>

000000008000329e <iinit>:
{
    8000329e:	7179                	addi	sp,sp,-48
    800032a0:	f406                	sd	ra,40(sp)
    800032a2:	f022                	sd	s0,32(sp)
    800032a4:	ec26                	sd	s1,24(sp)
    800032a6:	e84a                	sd	s2,16(sp)
    800032a8:	e44e                	sd	s3,8(sp)
    800032aa:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800032ac:	00004597          	auipc	a1,0x4
    800032b0:	27458593          	addi	a1,a1,628 # 80007520 <etext+0x520>
    800032b4:	0001b517          	auipc	a0,0x1b
    800032b8:	f1c50513          	addi	a0,a0,-228 # 8001e1d0 <itable>
    800032bc:	977fd0ef          	jal	80000c32 <initlock>
  for (i = 0; i < NINODE; i++) {
    800032c0:	0001b497          	auipc	s1,0x1b
    800032c4:	f3848493          	addi	s1,s1,-200 # 8001e1f8 <itable+0x28>
    800032c8:	0001d997          	auipc	s3,0x1d
    800032cc:	9c098993          	addi	s3,s3,-1600 # 8001fc88 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800032d0:	00004917          	auipc	s2,0x4
    800032d4:	25890913          	addi	s2,s2,600 # 80007528 <etext+0x528>
    800032d8:	85ca                	mv	a1,s2
    800032da:	8526                	mv	a0,s1
    800032dc:	697000ef          	jal	80004172 <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    800032e0:	08848493          	addi	s1,s1,136
    800032e4:	ff349ae3          	bne	s1,s3,800032d8 <iinit+0x3a>
}
    800032e8:	70a2                	ld	ra,40(sp)
    800032ea:	7402                	ld	s0,32(sp)
    800032ec:	64e2                	ld	s1,24(sp)
    800032ee:	6942                	ld	s2,16(sp)
    800032f0:	69a2                	ld	s3,8(sp)
    800032f2:	6145                	addi	sp,sp,48
    800032f4:	8082                	ret

00000000800032f6 <ialloc>:
{
    800032f6:	7139                	addi	sp,sp,-64
    800032f8:	fc06                	sd	ra,56(sp)
    800032fa:	f822                	sd	s0,48(sp)
    800032fc:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    800032fe:	0001b717          	auipc	a4,0x1b
    80003302:	ebe72703          	lw	a4,-322(a4) # 8001e1bc <sb+0xc>
    80003306:	4785                	li	a5,1
    80003308:	06e7f063          	bgeu	a5,a4,80003368 <ialloc+0x72>
    8000330c:	f426                	sd	s1,40(sp)
    8000330e:	f04a                	sd	s2,32(sp)
    80003310:	ec4e                	sd	s3,24(sp)
    80003312:	e852                	sd	s4,16(sp)
    80003314:	e456                	sd	s5,8(sp)
    80003316:	e05a                	sd	s6,0(sp)
    80003318:	8aaa                	mv	s5,a0
    8000331a:	8b2e                	mv	s6,a1
    8000331c:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    8000331e:	0001ba17          	auipc	s4,0x1b
    80003322:	e92a0a13          	addi	s4,s4,-366 # 8001e1b0 <sb>
    80003326:	00495593          	srli	a1,s2,0x4
    8000332a:	018a2783          	lw	a5,24(s4)
    8000332e:	9dbd                	addw	a1,a1,a5
    80003330:	8556                	mv	a0,s5
    80003332:	a95ff0ef          	jal	80002dc6 <bread>
    80003336:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    80003338:	05850993          	addi	s3,a0,88
    8000333c:	00f97793          	andi	a5,s2,15
    80003340:	079a                	slli	a5,a5,0x6
    80003342:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    80003344:	00099783          	lh	a5,0(s3)
    80003348:	cb9d                	beqz	a5,8000337e <ialloc+0x88>
    brelse(bp);
    8000334a:	b85ff0ef          	jal	80002ece <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    8000334e:	0905                	addi	s2,s2,1
    80003350:	00ca2703          	lw	a4,12(s4)
    80003354:	0009079b          	sext.w	a5,s2
    80003358:	fce7e7e3          	bltu	a5,a4,80003326 <ialloc+0x30>
    8000335c:	74a2                	ld	s1,40(sp)
    8000335e:	7902                	ld	s2,32(sp)
    80003360:	69e2                	ld	s3,24(sp)
    80003362:	6a42                	ld	s4,16(sp)
    80003364:	6aa2                	ld	s5,8(sp)
    80003366:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    80003368:	00004517          	auipc	a0,0x4
    8000336c:	1c850513          	addi	a0,a0,456 # 80007530 <etext+0x530>
    80003370:	9a0fd0ef          	jal	80000510 <printk>
  return 0;
    80003374:	4501                	li	a0,0
}
    80003376:	70e2                	ld	ra,56(sp)
    80003378:	7442                	ld	s0,48(sp)
    8000337a:	6121                	addi	sp,sp,64
    8000337c:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    8000337e:	04000613          	li	a2,64
    80003382:	4581                	li	a1,0
    80003384:	854e                	mv	a0,s3
    80003386:	9e9fd0ef          	jal	80000d6e <memset>
      dip->type = type;
    8000338a:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    8000338e:	8526                	mv	a0,s1
    80003390:	4af000ef          	jal	8000403e <log_write>
      brelse(bp);
    80003394:	8526                	mv	a0,s1
    80003396:	b39ff0ef          	jal	80002ece <brelse>
      return iget(dev, inum);
    8000339a:	0009059b          	sext.w	a1,s2
    8000339e:	8556                	mv	a0,s5
    800033a0:	e4dff0ef          	jal	800031ec <iget>
    800033a4:	74a2                	ld	s1,40(sp)
    800033a6:	7902                	ld	s2,32(sp)
    800033a8:	69e2                	ld	s3,24(sp)
    800033aa:	6a42                	ld	s4,16(sp)
    800033ac:	6aa2                	ld	s5,8(sp)
    800033ae:	6b02                	ld	s6,0(sp)
    800033b0:	b7d9                	j	80003376 <ialloc+0x80>

00000000800033b2 <iupdate>:
{
    800033b2:	1101                	addi	sp,sp,-32
    800033b4:	ec06                	sd	ra,24(sp)
    800033b6:	e822                	sd	s0,16(sp)
    800033b8:	e426                	sd	s1,8(sp)
    800033ba:	e04a                	sd	s2,0(sp)
    800033bc:	1000                	addi	s0,sp,32
    800033be:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800033c0:	415c                	lw	a5,4(a0)
    800033c2:	0047d79b          	srliw	a5,a5,0x4
    800033c6:	0001b597          	auipc	a1,0x1b
    800033ca:	e025a583          	lw	a1,-510(a1) # 8001e1c8 <sb+0x18>
    800033ce:	9dbd                	addw	a1,a1,a5
    800033d0:	4108                	lw	a0,0(a0)
    800033d2:	9f5ff0ef          	jal	80002dc6 <bread>
    800033d6:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    800033d8:	05850793          	addi	a5,a0,88
    800033dc:	40d8                	lw	a4,4(s1)
    800033de:	8b3d                	andi	a4,a4,15
    800033e0:	071a                	slli	a4,a4,0x6
    800033e2:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800033e4:	04449703          	lh	a4,68(s1)
    800033e8:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800033ec:	04649703          	lh	a4,70(s1)
    800033f0:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800033f4:	04849703          	lh	a4,72(s1)
    800033f8:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800033fc:	04a49703          	lh	a4,74(s1)
    80003400:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003404:	44f8                	lw	a4,76(s1)
    80003406:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003408:	03400613          	li	a2,52
    8000340c:	05048593          	addi	a1,s1,80
    80003410:	00c78513          	addi	a0,a5,12
    80003414:	9b7fd0ef          	jal	80000dca <memmove>
  log_write(bp);
    80003418:	854a                	mv	a0,s2
    8000341a:	425000ef          	jal	8000403e <log_write>
  brelse(bp);
    8000341e:	854a                	mv	a0,s2
    80003420:	aafff0ef          	jal	80002ece <brelse>
}
    80003424:	60e2                	ld	ra,24(sp)
    80003426:	6442                	ld	s0,16(sp)
    80003428:	64a2                	ld	s1,8(sp)
    8000342a:	6902                	ld	s2,0(sp)
    8000342c:	6105                	addi	sp,sp,32
    8000342e:	8082                	ret

0000000080003430 <idup>:
{
    80003430:	1101                	addi	sp,sp,-32
    80003432:	ec06                	sd	ra,24(sp)
    80003434:	e822                	sd	s0,16(sp)
    80003436:	e426                	sd	s1,8(sp)
    80003438:	1000                	addi	s0,sp,32
    8000343a:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000343c:	0001b517          	auipc	a0,0x1b
    80003440:	d9450513          	addi	a0,a0,-620 # 8001e1d0 <itable>
    80003444:	86ffd0ef          	jal	80000cb2 <acquire>
  ip->ref++;
    80003448:	449c                	lw	a5,8(s1)
    8000344a:	2785                	addiw	a5,a5,1
    8000344c:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000344e:	0001b517          	auipc	a0,0x1b
    80003452:	d8250513          	addi	a0,a0,-638 # 8001e1d0 <itable>
    80003456:	8e1fd0ef          	jal	80000d36 <release>
}
    8000345a:	8526                	mv	a0,s1
    8000345c:	60e2                	ld	ra,24(sp)
    8000345e:	6442                	ld	s0,16(sp)
    80003460:	64a2                	ld	s1,8(sp)
    80003462:	6105                	addi	sp,sp,32
    80003464:	8082                	ret

0000000080003466 <ilock>:
{
    80003466:	1101                	addi	sp,sp,-32
    80003468:	ec06                	sd	ra,24(sp)
    8000346a:	e822                	sd	s0,16(sp)
    8000346c:	e426                	sd	s1,8(sp)
    8000346e:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    80003470:	cd19                	beqz	a0,8000348e <ilock+0x28>
    80003472:	84aa                	mv	s1,a0
    80003474:	451c                	lw	a5,8(a0)
    80003476:	00f05c63          	blez	a5,8000348e <ilock+0x28>
  acquiresleep(&ip->lock);
    8000347a:	0541                	addi	a0,a0,16
    8000347c:	52d000ef          	jal	800041a8 <acquiresleep>
  if (ip->valid == 0) {
    80003480:	40bc                	lw	a5,64(s1)
    80003482:	cf89                	beqz	a5,8000349c <ilock+0x36>
}
    80003484:	60e2                	ld	ra,24(sp)
    80003486:	6442                	ld	s0,16(sp)
    80003488:	64a2                	ld	s1,8(sp)
    8000348a:	6105                	addi	sp,sp,32
    8000348c:	8082                	ret
    8000348e:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003490:	00004517          	auipc	a0,0x4
    80003494:	0b850513          	addi	a0,a0,184 # 80007548 <etext+0x548>
    80003498:	bb0fd0ef          	jal	80000848 <panic>
    8000349c:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000349e:	40dc                	lw	a5,4(s1)
    800034a0:	0047d79b          	srliw	a5,a5,0x4
    800034a4:	0001b597          	auipc	a1,0x1b
    800034a8:	d245a583          	lw	a1,-732(a1) # 8001e1c8 <sb+0x18>
    800034ac:	9dbd                	addw	a1,a1,a5
    800034ae:	4088                	lw	a0,0(s1)
    800034b0:	917ff0ef          	jal	80002dc6 <bread>
    800034b4:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    800034b6:	05850593          	addi	a1,a0,88
    800034ba:	40dc                	lw	a5,4(s1)
    800034bc:	8bbd                	andi	a5,a5,15
    800034be:	079a                	slli	a5,a5,0x6
    800034c0:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800034c2:	00059783          	lh	a5,0(a1)
    800034c6:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800034ca:	00259783          	lh	a5,2(a1)
    800034ce:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800034d2:	00459783          	lh	a5,4(a1)
    800034d6:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800034da:	00659783          	lh	a5,6(a1)
    800034de:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800034e2:	459c                	lw	a5,8(a1)
    800034e4:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800034e6:	03400613          	li	a2,52
    800034ea:	05b1                	addi	a1,a1,12
    800034ec:	05048513          	addi	a0,s1,80
    800034f0:	8dbfd0ef          	jal	80000dca <memmove>
    brelse(bp);
    800034f4:	854a                	mv	a0,s2
    800034f6:	9d9ff0ef          	jal	80002ece <brelse>
    ip->valid = 1;
    800034fa:	4785                	li	a5,1
    800034fc:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    800034fe:	04449783          	lh	a5,68(s1)
    80003502:	c399                	beqz	a5,80003508 <ilock+0xa2>
    80003504:	6902                	ld	s2,0(sp)
    80003506:	bfbd                	j	80003484 <ilock+0x1e>
      panic("ilock: no type");
    80003508:	00004517          	auipc	a0,0x4
    8000350c:	04850513          	addi	a0,a0,72 # 80007550 <etext+0x550>
    80003510:	b38fd0ef          	jal	80000848 <panic>

0000000080003514 <iunlock>:
{
    80003514:	1101                	addi	sp,sp,-32
    80003516:	ec06                	sd	ra,24(sp)
    80003518:	e822                	sd	s0,16(sp)
    8000351a:	e426                	sd	s1,8(sp)
    8000351c:	e04a                	sd	s2,0(sp)
    8000351e:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003520:	c505                	beqz	a0,80003548 <iunlock+0x34>
    80003522:	84aa                	mv	s1,a0
    80003524:	01050913          	addi	s2,a0,16
    80003528:	854a                	mv	a0,s2
    8000352a:	50b000ef          	jal	80004234 <holdingsleep>
    8000352e:	cd09                	beqz	a0,80003548 <iunlock+0x34>
    80003530:	449c                	lw	a5,8(s1)
    80003532:	00f05b63          	blez	a5,80003548 <iunlock+0x34>
  releasesleep(&ip->lock);
    80003536:	854a                	mv	a0,s2
    80003538:	4c5000ef          	jal	800041fc <releasesleep>
}
    8000353c:	60e2                	ld	ra,24(sp)
    8000353e:	6442                	ld	s0,16(sp)
    80003540:	64a2                	ld	s1,8(sp)
    80003542:	6902                	ld	s2,0(sp)
    80003544:	6105                	addi	sp,sp,32
    80003546:	8082                	ret
    panic("iunlock");
    80003548:	00004517          	auipc	a0,0x4
    8000354c:	01850513          	addi	a0,a0,24 # 80007560 <etext+0x560>
    80003550:	af8fd0ef          	jal	80000848 <panic>

0000000080003554 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003554:	7179                	addi	sp,sp,-48
    80003556:	f406                	sd	ra,40(sp)
    80003558:	f022                	sd	s0,32(sp)
    8000355a:	ec26                	sd	s1,24(sp)
    8000355c:	e84a                	sd	s2,16(sp)
    8000355e:	e44e                	sd	s3,8(sp)
    80003560:	1800                	addi	s0,sp,48
    80003562:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    80003564:	05050493          	addi	s1,a0,80
    80003568:	08050913          	addi	s2,a0,128
    8000356c:	a021                	j	80003574 <itrunc+0x20>
    8000356e:	0491                	addi	s1,s1,4
    80003570:	01248b63          	beq	s1,s2,80003586 <itrunc+0x32>
    if (ip->addrs[i]) {
    80003574:	408c                	lw	a1,0(s1)
    80003576:	dde5                	beqz	a1,8000356e <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003578:	0009a503          	lw	a0,0(s3)
    8000357c:	a3fff0ef          	jal	80002fba <bfree>
      ip->addrs[i] = 0;
    80003580:	0004a023          	sw	zero,0(s1)
    80003584:	b7ed                	j	8000356e <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    80003586:	0809a583          	lw	a1,128(s3)
    8000358a:	ed89                	bnez	a1,800035a4 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000358c:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003590:	854e                	mv	a0,s3
    80003592:	e21ff0ef          	jal	800033b2 <iupdate>
}
    80003596:	70a2                	ld	ra,40(sp)
    80003598:	7402                	ld	s0,32(sp)
    8000359a:	64e2                	ld	s1,24(sp)
    8000359c:	6942                	ld	s2,16(sp)
    8000359e:	69a2                	ld	s3,8(sp)
    800035a0:	6145                	addi	sp,sp,48
    800035a2:	8082                	ret
    800035a4:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800035a6:	0009a503          	lw	a0,0(s3)
    800035aa:	81dff0ef          	jal	80002dc6 <bread>
    800035ae:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    800035b0:	05850493          	addi	s1,a0,88
    800035b4:	45850913          	addi	s2,a0,1112
    800035b8:	a021                	j	800035c0 <itrunc+0x6c>
    800035ba:	0491                	addi	s1,s1,4
    800035bc:	01248963          	beq	s1,s2,800035ce <itrunc+0x7a>
      if (a[j])
    800035c0:	408c                	lw	a1,0(s1)
    800035c2:	dde5                	beqz	a1,800035ba <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800035c4:	0009a503          	lw	a0,0(s3)
    800035c8:	9f3ff0ef          	jal	80002fba <bfree>
    800035cc:	b7fd                	j	800035ba <itrunc+0x66>
    brelse(bp);
    800035ce:	8552                	mv	a0,s4
    800035d0:	8ffff0ef          	jal	80002ece <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800035d4:	0809a583          	lw	a1,128(s3)
    800035d8:	0009a503          	lw	a0,0(s3)
    800035dc:	9dfff0ef          	jal	80002fba <bfree>
    ip->addrs[NDIRECT] = 0;
    800035e0:	0809a023          	sw	zero,128(s3)
    800035e4:	6a02                	ld	s4,0(sp)
    800035e6:	b75d                	j	8000358c <itrunc+0x38>

00000000800035e8 <iput>:
{
    800035e8:	1101                	addi	sp,sp,-32
    800035ea:	ec06                	sd	ra,24(sp)
    800035ec:	e822                	sd	s0,16(sp)
    800035ee:	e426                	sd	s1,8(sp)
    800035f0:	1000                	addi	s0,sp,32
    800035f2:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800035f4:	0001b517          	auipc	a0,0x1b
    800035f8:	bdc50513          	addi	a0,a0,-1060 # 8001e1d0 <itable>
    800035fc:	eb6fd0ef          	jal	80000cb2 <acquire>
  if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    80003600:	4498                	lw	a4,8(s1)
    80003602:	4785                	li	a5,1
    80003604:	02f70063          	beq	a4,a5,80003624 <iput+0x3c>
  ip->ref--;
    80003608:	449c                	lw	a5,8(s1)
    8000360a:	37fd                	addiw	a5,a5,-1
    8000360c:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000360e:	0001b517          	auipc	a0,0x1b
    80003612:	bc250513          	addi	a0,a0,-1086 # 8001e1d0 <itable>
    80003616:	f20fd0ef          	jal	80000d36 <release>
}
    8000361a:	60e2                	ld	ra,24(sp)
    8000361c:	6442                	ld	s0,16(sp)
    8000361e:	64a2                	ld	s1,8(sp)
    80003620:	6105                	addi	sp,sp,32
    80003622:	8082                	ret
  if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    80003624:	40bc                	lw	a5,64(s1)
    80003626:	d3ed                	beqz	a5,80003608 <iput+0x20>
    80003628:	04a49783          	lh	a5,74(s1)
    8000362c:	fff1                	bnez	a5,80003608 <iput+0x20>
    8000362e:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003630:	01048793          	addi	a5,s1,16
    80003634:	893e                	mv	s2,a5
    80003636:	853e                	mv	a0,a5
    80003638:	371000ef          	jal	800041a8 <acquiresleep>
    release(&itable.lock);
    8000363c:	0001b517          	auipc	a0,0x1b
    80003640:	b9450513          	addi	a0,a0,-1132 # 8001e1d0 <itable>
    80003644:	ef2fd0ef          	jal	80000d36 <release>
    itrunc(ip);
    80003648:	8526                	mv	a0,s1
    8000364a:	f0bff0ef          	jal	80003554 <itrunc>
    ip->type = 0;
    8000364e:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003652:	8526                	mv	a0,s1
    80003654:	d5fff0ef          	jal	800033b2 <iupdate>
    ip->valid = 0;
    80003658:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000365c:	854a                	mv	a0,s2
    8000365e:	39f000ef          	jal	800041fc <releasesleep>
    acquire(&itable.lock);
    80003662:	0001b517          	auipc	a0,0x1b
    80003666:	b6e50513          	addi	a0,a0,-1170 # 8001e1d0 <itable>
    8000366a:	e48fd0ef          	jal	80000cb2 <acquire>
    8000366e:	6902                	ld	s2,0(sp)
    80003670:	bf61                	j	80003608 <iput+0x20>

0000000080003672 <iunlockput>:
{
    80003672:	1101                	addi	sp,sp,-32
    80003674:	ec06                	sd	ra,24(sp)
    80003676:	e822                	sd	s0,16(sp)
    80003678:	e426                	sd	s1,8(sp)
    8000367a:	1000                	addi	s0,sp,32
    8000367c:	84aa                	mv	s1,a0
  iunlock(ip);
    8000367e:	e97ff0ef          	jal	80003514 <iunlock>
  iput(ip);
    80003682:	8526                	mv	a0,s1
    80003684:	f65ff0ef          	jal	800035e8 <iput>
}
    80003688:	60e2                	ld	ra,24(sp)
    8000368a:	6442                	ld	s0,16(sp)
    8000368c:	64a2                	ld	s1,8(sp)
    8000368e:	6105                	addi	sp,sp,32
    80003690:	8082                	ret

0000000080003692 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003692:	0001b717          	auipc	a4,0x1b
    80003696:	b2a72703          	lw	a4,-1238(a4) # 8001e1bc <sb+0xc>
    8000369a:	4785                	li	a5,1
    8000369c:	0ae7fe63          	bgeu	a5,a4,80003758 <ireclaim+0xc6>
{
    800036a0:	7139                	addi	sp,sp,-64
    800036a2:	fc06                	sd	ra,56(sp)
    800036a4:	f822                	sd	s0,48(sp)
    800036a6:	f426                	sd	s1,40(sp)
    800036a8:	f04a                	sd	s2,32(sp)
    800036aa:	ec4e                	sd	s3,24(sp)
    800036ac:	e852                	sd	s4,16(sp)
    800036ae:	e456                	sd	s5,8(sp)
    800036b0:	e05a                	sd	s6,0(sp)
    800036b2:	0080                	addi	s0,sp,64
    800036b4:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800036b6:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800036b8:	0001ba17          	auipc	s4,0x1b
    800036bc:	af8a0a13          	addi	s4,s4,-1288 # 8001e1b0 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    800036c0:	00004b17          	auipc	s6,0x4
    800036c4:	ea8b0b13          	addi	s6,s6,-344 # 80007568 <etext+0x568>
    800036c8:	a099                	j	8000370e <ireclaim+0x7c>
    800036ca:	85ce                	mv	a1,s3
    800036cc:	855a                	mv	a0,s6
    800036ce:	e43fc0ef          	jal	80000510 <printk>
      ip = iget(dev, inum);
    800036d2:	85ce                	mv	a1,s3
    800036d4:	8556                	mv	a0,s5
    800036d6:	b17ff0ef          	jal	800031ec <iget>
    800036da:	89aa                	mv	s3,a0
    brelse(bp);
    800036dc:	854a                	mv	a0,s2
    800036de:	ff0ff0ef          	jal	80002ece <brelse>
    if (ip) {
    800036e2:	00098f63          	beqz	s3,80003700 <ireclaim+0x6e>
      begin_op();
    800036e6:	7aa000ef          	jal	80003e90 <begin_op>
      ilock(ip);
    800036ea:	854e                	mv	a0,s3
    800036ec:	d7bff0ef          	jal	80003466 <ilock>
      iunlock(ip);
    800036f0:	854e                	mv	a0,s3
    800036f2:	e23ff0ef          	jal	80003514 <iunlock>
      iput(ip);
    800036f6:	854e                	mv	a0,s3
    800036f8:	ef1ff0ef          	jal	800035e8 <iput>
      end_op();
    800036fc:	021000ef          	jal	80003f1c <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003700:	0485                	addi	s1,s1,1
    80003702:	00ca2703          	lw	a4,12(s4)
    80003706:	0004879b          	sext.w	a5,s1
    8000370a:	02e7fd63          	bgeu	a5,a4,80003744 <ireclaim+0xb2>
    8000370e:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003712:	0044d593          	srli	a1,s1,0x4
    80003716:	018a2783          	lw	a5,24(s4)
    8000371a:	9dbd                	addw	a1,a1,a5
    8000371c:	8556                	mv	a0,s5
    8000371e:	ea8ff0ef          	jal	80002dc6 <bread>
    80003722:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003724:	05850793          	addi	a5,a0,88
    80003728:	00f9f713          	andi	a4,s3,15
    8000372c:	071a                	slli	a4,a4,0x6
    8000372e:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    80003730:	00079703          	lh	a4,0(a5)
    80003734:	c701                	beqz	a4,8000373c <ireclaim+0xaa>
    80003736:	00679783          	lh	a5,6(a5)
    8000373a:	dbc1                	beqz	a5,800036ca <ireclaim+0x38>
    brelse(bp);
    8000373c:	854a                	mv	a0,s2
    8000373e:	f90ff0ef          	jal	80002ece <brelse>
    if (ip) {
    80003742:	bf7d                	j	80003700 <ireclaim+0x6e>
}
    80003744:	70e2                	ld	ra,56(sp)
    80003746:	7442                	ld	s0,48(sp)
    80003748:	74a2                	ld	s1,40(sp)
    8000374a:	7902                	ld	s2,32(sp)
    8000374c:	69e2                	ld	s3,24(sp)
    8000374e:	6a42                	ld	s4,16(sp)
    80003750:	6aa2                	ld	s5,8(sp)
    80003752:	6b02                	ld	s6,0(sp)
    80003754:	6121                	addi	sp,sp,64
    80003756:	8082                	ret
    80003758:	8082                	ret

000000008000375a <fsinit>:
{
    8000375a:	1101                	addi	sp,sp,-32
    8000375c:	ec06                	sd	ra,24(sp)
    8000375e:	e822                	sd	s0,16(sp)
    80003760:	e426                	sd	s1,8(sp)
    80003762:	e04a                	sd	s2,0(sp)
    80003764:	1000                	addi	s0,sp,32
    80003766:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003768:	4585                	li	a1,1
    8000376a:	e5cff0ef          	jal	80002dc6 <bread>
    8000376e:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003770:	02000613          	li	a2,32
    80003774:	05850593          	addi	a1,a0,88
    80003778:	0001b517          	auipc	a0,0x1b
    8000377c:	a3850513          	addi	a0,a0,-1480 # 8001e1b0 <sb>
    80003780:	e4afd0ef          	jal	80000dca <memmove>
  brelse(bp);
    80003784:	8526                	mv	a0,s1
    80003786:	f48ff0ef          	jal	80002ece <brelse>
  if (sb.magic != FSMAGIC)
    8000378a:	0001b717          	auipc	a4,0x1b
    8000378e:	a2672703          	lw	a4,-1498(a4) # 8001e1b0 <sb>
    80003792:	102037b7          	lui	a5,0x10203
    80003796:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000379a:	02f71263          	bne	a4,a5,800037be <fsinit+0x64>
  initlog(dev, &sb);
    8000379e:	0001b597          	auipc	a1,0x1b
    800037a2:	a1258593          	addi	a1,a1,-1518 # 8001e1b0 <sb>
    800037a6:	854a                	mv	a0,s2
    800037a8:	666000ef          	jal	80003e0e <initlog>
  ireclaim(dev);
    800037ac:	854a                	mv	a0,s2
    800037ae:	ee5ff0ef          	jal	80003692 <ireclaim>
}
    800037b2:	60e2                	ld	ra,24(sp)
    800037b4:	6442                	ld	s0,16(sp)
    800037b6:	64a2                	ld	s1,8(sp)
    800037b8:	6902                	ld	s2,0(sp)
    800037ba:	6105                	addi	sp,sp,32
    800037bc:	8082                	ret
    panic("invalid file system");
    800037be:	00004517          	auipc	a0,0x4
    800037c2:	dca50513          	addi	a0,a0,-566 # 80007588 <etext+0x588>
    800037c6:	882fd0ef          	jal	80000848 <panic>

00000000800037ca <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800037ca:	1141                	addi	sp,sp,-16
    800037cc:	e406                	sd	ra,8(sp)
    800037ce:	e022                	sd	s0,0(sp)
    800037d0:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800037d2:	411c                	lw	a5,0(a0)
    800037d4:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800037d6:	415c                	lw	a5,4(a0)
    800037d8:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800037da:	04451783          	lh	a5,68(a0)
    800037de:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800037e2:	04a51783          	lh	a5,74(a0)
    800037e6:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800037ea:	04c56783          	lwu	a5,76(a0)
    800037ee:	e99c                	sd	a5,16(a1)
}
    800037f0:	60a2                	ld	ra,8(sp)
    800037f2:	6402                	ld	s0,0(sp)
    800037f4:	0141                	addi	sp,sp,16
    800037f6:	8082                	ret

00000000800037f8 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    800037f8:	457c                	lw	a5,76(a0)
    800037fa:	0ed7e663          	bltu	a5,a3,800038e6 <readi+0xee>
{
    800037fe:	7159                	addi	sp,sp,-112
    80003800:	f486                	sd	ra,104(sp)
    80003802:	f0a2                	sd	s0,96(sp)
    80003804:	eca6                	sd	s1,88(sp)
    80003806:	e0d2                	sd	s4,64(sp)
    80003808:	fc56                	sd	s5,56(sp)
    8000380a:	f85a                	sd	s6,48(sp)
    8000380c:	f45e                	sd	s7,40(sp)
    8000380e:	1880                	addi	s0,sp,112
    80003810:	8b2a                	mv	s6,a0
    80003812:	8bae                	mv	s7,a1
    80003814:	8a32                	mv	s4,a2
    80003816:	84b6                	mv	s1,a3
    80003818:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    8000381a:	9f35                	addw	a4,a4,a3
    return 0;
    8000381c:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    8000381e:	0ad76b63          	bltu	a4,a3,800038d4 <readi+0xdc>
    80003822:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    80003824:	00e7f463          	bgeu	a5,a4,8000382c <readi+0x34>
    n = ip->size - off;
    80003828:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    8000382c:	080a8b63          	beqz	s5,800038c2 <readi+0xca>
    80003830:	e8ca                	sd	s2,80(sp)
    80003832:	f062                	sd	s8,32(sp)
    80003834:	ec66                	sd	s9,24(sp)
    80003836:	e86a                	sd	s10,16(sp)
    80003838:	e46e                	sd	s11,8(sp)
    8000383a:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    8000383c:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003840:	5c7d                	li	s8,-1
    80003842:	a80d                	j	80003874 <readi+0x7c>
    80003844:	020d1d93          	slli	s11,s10,0x20
    80003848:	020ddd93          	srli	s11,s11,0x20
    8000384c:	05890613          	addi	a2,s2,88
    80003850:	86ee                	mv	a3,s11
    80003852:	963e                	add	a2,a2,a5
    80003854:	85d2                	mv	a1,s4
    80003856:	855e                	mv	a0,s7
    80003858:	bfdfe0ef          	jal	80002454 <either_copyout>
    8000385c:	05850363          	beq	a0,s8,800038a2 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003860:	854a                	mv	a0,s2
    80003862:	e6cff0ef          	jal	80002ece <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003866:	013d09bb          	addw	s3,s10,s3
    8000386a:	009d04bb          	addw	s1,s10,s1
    8000386e:	9a6e                	add	s4,s4,s11
    80003870:	0559f363          	bgeu	s3,s5,800038b6 <readi+0xbe>
    uint addr = bmap(ip, off / BSIZE);
    80003874:	00a4d59b          	srliw	a1,s1,0xa
    80003878:	855a                	mv	a0,s6
    8000387a:	8b3ff0ef          	jal	8000312c <bmap>
    8000387e:	85aa                	mv	a1,a0
    if (addr == 0)
    80003880:	c139                	beqz	a0,800038c6 <readi+0xce>
    bp = bread(ip->dev, addr);
    80003882:	000b2503          	lw	a0,0(s6)
    80003886:	d40ff0ef          	jal	80002dc6 <bread>
    8000388a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    8000388c:	3ff4f793          	andi	a5,s1,1023
    80003890:	40fc873b          	subw	a4,s9,a5
    80003894:	413a86bb          	subw	a3,s5,s3
    80003898:	8d3a                	mv	s10,a4
    8000389a:	fae6f5e3          	bgeu	a3,a4,80003844 <readi+0x4c>
    8000389e:	8d36                	mv	s10,a3
    800038a0:	b755                	j	80003844 <readi+0x4c>
      brelse(bp);
    800038a2:	854a                	mv	a0,s2
    800038a4:	e2aff0ef          	jal	80002ece <brelse>
      tot = -1;
    800038a8:	59fd                	li	s3,-1
      break;
    800038aa:	6946                	ld	s2,80(sp)
    800038ac:	7c02                	ld	s8,32(sp)
    800038ae:	6ce2                	ld	s9,24(sp)
    800038b0:	6d42                	ld	s10,16(sp)
    800038b2:	6da2                	ld	s11,8(sp)
    800038b4:	a831                	j	800038d0 <readi+0xd8>
    800038b6:	6946                	ld	s2,80(sp)
    800038b8:	7c02                	ld	s8,32(sp)
    800038ba:	6ce2                	ld	s9,24(sp)
    800038bc:	6d42                	ld	s10,16(sp)
    800038be:	6da2                	ld	s11,8(sp)
    800038c0:	a801                	j	800038d0 <readi+0xd8>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800038c2:	89d6                	mv	s3,s5
    800038c4:	a031                	j	800038d0 <readi+0xd8>
    800038c6:	6946                	ld	s2,80(sp)
    800038c8:	7c02                	ld	s8,32(sp)
    800038ca:	6ce2                	ld	s9,24(sp)
    800038cc:	6d42                	ld	s10,16(sp)
    800038ce:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800038d0:	854e                	mv	a0,s3
    800038d2:	69a6                	ld	s3,72(sp)
}
    800038d4:	70a6                	ld	ra,104(sp)
    800038d6:	7406                	ld	s0,96(sp)
    800038d8:	64e6                	ld	s1,88(sp)
    800038da:	6a06                	ld	s4,64(sp)
    800038dc:	7ae2                	ld	s5,56(sp)
    800038de:	7b42                	ld	s6,48(sp)
    800038e0:	7ba2                	ld	s7,40(sp)
    800038e2:	6165                	addi	sp,sp,112
    800038e4:	8082                	ret
    return 0;
    800038e6:	4501                	li	a0,0
}
    800038e8:	8082                	ret

00000000800038ea <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    800038ea:	457c                	lw	a5,76(a0)
    800038ec:	10d7e163          	bltu	a5,a3,800039ee <writei+0x104>
{
    800038f0:	7159                	addi	sp,sp,-112
    800038f2:	f486                	sd	ra,104(sp)
    800038f4:	f0a2                	sd	s0,96(sp)
    800038f6:	e8ca                	sd	s2,80(sp)
    800038f8:	e0d2                	sd	s4,64(sp)
    800038fa:	fc56                	sd	s5,56(sp)
    800038fc:	f85a                	sd	s6,48(sp)
    800038fe:	f45e                	sd	s7,40(sp)
    80003900:	1880                	addi	s0,sp,112
    80003902:	8aaa                	mv	s5,a0
    80003904:	8bae                	mv	s7,a1
    80003906:	8a32                	mv	s4,a2
    80003908:	8936                	mv	s2,a3
    8000390a:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    8000390c:	9f35                	addw	a4,a4,a3
    return -1;
  if (off + n > MAXFILE * BSIZE)
    8000390e:	000437b7          	lui	a5,0x43
    80003912:	00e7b7b3          	sltu	a5,a5,a4
  if (off > ip->size || off + n < off)
    80003916:	00d73733          	sltu	a4,a4,a3
  if (off + n > MAXFILE * BSIZE)
    8000391a:	8fd9                	or	a5,a5,a4
    8000391c:	ef91                	bnez	a5,80003938 <writei+0x4e>
    8000391e:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003920:	0a0b0f63          	beqz	s6,800039de <writei+0xf4>
    80003924:	eca6                	sd	s1,88(sp)
    80003926:	f062                	sd	s8,32(sp)
    80003928:	ec66                	sd	s9,24(sp)
    8000392a:	e86a                	sd	s10,16(sp)
    8000392c:	e46e                	sd	s11,8(sp)
    8000392e:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003930:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003934:	5c7d                	li	s8,-1
    80003936:	a835                	j	80003972 <writei+0x88>
    return -1;
    80003938:	557d                	li	a0,-1
    8000393a:	a849                	j	800039cc <writei+0xe2>
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000393c:	020d1d93          	slli	s11,s10,0x20
    80003940:	020ddd93          	srli	s11,s11,0x20
    80003944:	05848513          	addi	a0,s1,88
    80003948:	86ee                	mv	a3,s11
    8000394a:	8652                	mv	a2,s4
    8000394c:	85de                	mv	a1,s7
    8000394e:	953e                	add	a0,a0,a5
    80003950:	b51fe0ef          	jal	800024a0 <either_copyin>
    80003954:	05850663          	beq	a0,s8,800039a0 <writei+0xb6>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003958:	8526                	mv	a0,s1
    8000395a:	6e4000ef          	jal	8000403e <log_write>
    brelse(bp);
    8000395e:	8526                	mv	a0,s1
    80003960:	d6eff0ef          	jal	80002ece <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003964:	013d09bb          	addw	s3,s10,s3
    80003968:	012d093b          	addw	s2,s10,s2
    8000396c:	9a6e                	add	s4,s4,s11
    8000396e:	0369ff63          	bgeu	s3,s6,800039ac <writei+0xc2>
    uint addr = bmap(ip, off / BSIZE);
    80003972:	00a9559b          	srliw	a1,s2,0xa
    80003976:	8556                	mv	a0,s5
    80003978:	fb4ff0ef          	jal	8000312c <bmap>
    8000397c:	85aa                	mv	a1,a0
    if (addr == 0)
    8000397e:	c51d                	beqz	a0,800039ac <writei+0xc2>
    bp = bread(ip->dev, addr);
    80003980:	000aa503          	lw	a0,0(s5)
    80003984:	c42ff0ef          	jal	80002dc6 <bread>
    80003988:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    8000398a:	3ff97793          	andi	a5,s2,1023
    8000398e:	40fc873b          	subw	a4,s9,a5
    80003992:	413b06bb          	subw	a3,s6,s3
    80003996:	8d3a                	mv	s10,a4
    80003998:	fae6f2e3          	bgeu	a3,a4,8000393c <writei+0x52>
    8000399c:	8d36                	mv	s10,a3
    8000399e:	bf79                	j	8000393c <writei+0x52>
      log_write(bp);
    800039a0:	8526                	mv	a0,s1
    800039a2:	69c000ef          	jal	8000403e <log_write>
      brelse(bp);
    800039a6:	8526                	mv	a0,s1
    800039a8:	d26ff0ef          	jal	80002ece <brelse>
  }

  if (off > ip->size)
    800039ac:	04caa783          	lw	a5,76(s5)
    800039b0:	0327f963          	bgeu	a5,s2,800039e2 <writei+0xf8>
    ip->size = off;
    800039b4:	052aa623          	sw	s2,76(s5)
    800039b8:	64e6                	ld	s1,88(sp)
    800039ba:	7c02                	ld	s8,32(sp)
    800039bc:	6ce2                	ld	s9,24(sp)
    800039be:	6d42                	ld	s10,16(sp)
    800039c0:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800039c2:	8556                	mv	a0,s5
    800039c4:	9efff0ef          	jal	800033b2 <iupdate>

  return tot;
    800039c8:	854e                	mv	a0,s3
    800039ca:	69a6                	ld	s3,72(sp)
}
    800039cc:	70a6                	ld	ra,104(sp)
    800039ce:	7406                	ld	s0,96(sp)
    800039d0:	6946                	ld	s2,80(sp)
    800039d2:	6a06                	ld	s4,64(sp)
    800039d4:	7ae2                	ld	s5,56(sp)
    800039d6:	7b42                	ld	s6,48(sp)
    800039d8:	7ba2                	ld	s7,40(sp)
    800039da:	6165                	addi	sp,sp,112
    800039dc:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    800039de:	89da                	mv	s3,s6
    800039e0:	b7cd                	j	800039c2 <writei+0xd8>
    800039e2:	64e6                	ld	s1,88(sp)
    800039e4:	7c02                	ld	s8,32(sp)
    800039e6:	6ce2                	ld	s9,24(sp)
    800039e8:	6d42                	ld	s10,16(sp)
    800039ea:	6da2                	ld	s11,8(sp)
    800039ec:	bfd9                	j	800039c2 <writei+0xd8>
    return -1;
    800039ee:	557d                	li	a0,-1
}
    800039f0:	8082                	ret

00000000800039f2 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    800039f2:	1141                	addi	sp,sp,-16
    800039f4:	e406                	sd	ra,8(sp)
    800039f6:	e022                	sd	s0,0(sp)
    800039f8:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    800039fa:	4639                	li	a2,14
    800039fc:	c42fd0ef          	jal	80000e3e <strncmp>
}
    80003a00:	60a2                	ld	ra,8(sp)
    80003a02:	6402                	ld	s0,0(sp)
    80003a04:	0141                	addi	sp,sp,16
    80003a06:	8082                	ret

0000000080003a08 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003a08:	711d                	addi	sp,sp,-96
    80003a0a:	ec86                	sd	ra,88(sp)
    80003a0c:	e8a2                	sd	s0,80(sp)
    80003a0e:	e4a6                	sd	s1,72(sp)
    80003a10:	e0ca                	sd	s2,64(sp)
    80003a12:	fc4e                	sd	s3,56(sp)
    80003a14:	f852                	sd	s4,48(sp)
    80003a16:	f456                	sd	s5,40(sp)
    80003a18:	f05a                	sd	s6,32(sp)
    80003a1a:	ec5e                	sd	s7,24(sp)
    80003a1c:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80003a1e:	04451703          	lh	a4,68(a0)
    80003a22:	4785                	li	a5,1
    80003a24:	02f71963          	bne	a4,a5,80003a56 <dirlookup+0x4e>
    80003a28:	892a                	mv	s2,a0
    80003a2a:	8aae                	mv	s5,a1
    80003a2c:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003a2e:	457c                	lw	a5,76(a0)
    80003a30:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a32:	fa040a13          	addi	s4,s0,-96
    80003a36:	49c1                	li	s3,16
      panic("dirlookup read");
    if (de.inum == 0)
      continue;
    if (namecmp(name, de.name) == 0) {
    80003a38:	fa240b13          	addi	s6,s0,-94
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003a3c:	ef95                	bnez	a5,80003a78 <dirlookup+0x70>
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003a3e:	4501                	li	a0,0
}
    80003a40:	60e6                	ld	ra,88(sp)
    80003a42:	6446                	ld	s0,80(sp)
    80003a44:	64a6                	ld	s1,72(sp)
    80003a46:	6906                	ld	s2,64(sp)
    80003a48:	79e2                	ld	s3,56(sp)
    80003a4a:	7a42                	ld	s4,48(sp)
    80003a4c:	7aa2                	ld	s5,40(sp)
    80003a4e:	7b02                	ld	s6,32(sp)
    80003a50:	6be2                	ld	s7,24(sp)
    80003a52:	6125                	addi	sp,sp,96
    80003a54:	8082                	ret
    panic("dirlookup not DIR");
    80003a56:	00004517          	auipc	a0,0x4
    80003a5a:	b4a50513          	addi	a0,a0,-1206 # 800075a0 <etext+0x5a0>
    80003a5e:	debfc0ef          	jal	80000848 <panic>
      panic("dirlookup read");
    80003a62:	00004517          	auipc	a0,0x4
    80003a66:	b5650513          	addi	a0,a0,-1194 # 800075b8 <etext+0x5b8>
    80003a6a:	ddffc0ef          	jal	80000848 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003a6e:	24c1                	addiw	s1,s1,16
    80003a70:	04c92783          	lw	a5,76(s2)
    80003a74:	fcf4f5e3          	bgeu	s1,a5,80003a3e <dirlookup+0x36>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a78:	874e                	mv	a4,s3
    80003a7a:	86a6                	mv	a3,s1
    80003a7c:	8652                	mv	a2,s4
    80003a7e:	4581                	li	a1,0
    80003a80:	854a                	mv	a0,s2
    80003a82:	d77ff0ef          	jal	800037f8 <readi>
    80003a86:	fd351ee3          	bne	a0,s3,80003a62 <dirlookup+0x5a>
    if (de.inum == 0)
    80003a8a:	fa045783          	lhu	a5,-96(s0)
    80003a8e:	d3e5                	beqz	a5,80003a6e <dirlookup+0x66>
    if (namecmp(name, de.name) == 0) {
    80003a90:	85da                	mv	a1,s6
    80003a92:	8556                	mv	a0,s5
    80003a94:	f5fff0ef          	jal	800039f2 <namecmp>
    80003a98:	f979                	bnez	a0,80003a6e <dirlookup+0x66>
      if (poff)
    80003a9a:	000b8463          	beqz	s7,80003aa2 <dirlookup+0x9a>
        *poff = off;
    80003a9e:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003aa2:	fa045583          	lhu	a1,-96(s0)
    80003aa6:	00092503          	lw	a0,0(s2)
    80003aaa:	f42ff0ef          	jal	800031ec <iget>
    80003aae:	bf49                	j	80003a40 <dirlookup+0x38>

0000000080003ab0 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    80003ab0:	711d                	addi	sp,sp,-96
    80003ab2:	ec86                	sd	ra,88(sp)
    80003ab4:	e8a2                	sd	s0,80(sp)
    80003ab6:	e4a6                	sd	s1,72(sp)
    80003ab8:	e0ca                	sd	s2,64(sp)
    80003aba:	fc4e                	sd	s3,56(sp)
    80003abc:	f852                	sd	s4,48(sp)
    80003abe:	f456                	sd	s5,40(sp)
    80003ac0:	f05a                	sd	s6,32(sp)
    80003ac2:	ec5e                	sd	s7,24(sp)
    80003ac4:	e862                	sd	s8,16(sp)
    80003ac6:	e466                	sd	s9,8(sp)
    80003ac8:	e06a                	sd	s10,0(sp)
    80003aca:	1080                	addi	s0,sp,96
    80003acc:	84aa                	mv	s1,a0
    80003ace:	8b2e                	mv	s6,a1
    80003ad0:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    80003ad2:	00054703          	lbu	a4,0(a0)
    80003ad6:	02f00793          	li	a5,47
    80003ada:	00f70f63          	beq	a4,a5,80003af8 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003ade:	fa7fd0ef          	jal	80001a84 <myproc>
    80003ae2:	15053503          	ld	a0,336(a0)
    80003ae6:	94bff0ef          	jal	80003430 <idup>
    80003aea:	8a2a                	mv	s4,a0
  while (*path == '/')
    80003aec:	02f00993          	li	s3,47
  if (len >= DIRSIZ)
    80003af0:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003af2:	4cb9                	li	s9,14

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    80003af4:	4b85                	li	s7,1
    80003af6:	a075                	j	80003ba2 <namex+0xf2>
    ip = iget(ROOTDEV, ROOTINO);
    80003af8:	4585                	li	a1,1
    80003afa:	852e                	mv	a0,a1
    80003afc:	ef0ff0ef          	jal	800031ec <iget>
    80003b00:	8a2a                	mv	s4,a0
    80003b02:	b7ed                	j	80003aec <namex+0x3c>
      iunlockput(ip);
    80003b04:	8552                	mv	a0,s4
    80003b06:	b6dff0ef          	jal	80003672 <iunlockput>
      return 0;
    80003b0a:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003b0c:	8552                	mv	a0,s4
    80003b0e:	60e6                	ld	ra,88(sp)
    80003b10:	6446                	ld	s0,80(sp)
    80003b12:	64a6                	ld	s1,72(sp)
    80003b14:	6906                	ld	s2,64(sp)
    80003b16:	79e2                	ld	s3,56(sp)
    80003b18:	7a42                	ld	s4,48(sp)
    80003b1a:	7aa2                	ld	s5,40(sp)
    80003b1c:	7b02                	ld	s6,32(sp)
    80003b1e:	6be2                	ld	s7,24(sp)
    80003b20:	6c42                	ld	s8,16(sp)
    80003b22:	6ca2                	ld	s9,8(sp)
    80003b24:	6d02                	ld	s10,0(sp)
    80003b26:	6125                	addi	sp,sp,96
    80003b28:	8082                	ret
      iunlockput(ip);
    80003b2a:	8552                	mv	a0,s4
    80003b2c:	b47ff0ef          	jal	80003672 <iunlockput>
      return 0;
    80003b30:	bfe9                	j	80003b0a <namex+0x5a>
      iunlock(ip);
    80003b32:	8552                	mv	a0,s4
    80003b34:	9e1ff0ef          	jal	80003514 <iunlock>
      return ip;
    80003b38:	bfd1                	j	80003b0c <namex+0x5c>
      iunlockput(ip);
    80003b3a:	8552                	mv	a0,s4
    80003b3c:	b37ff0ef          	jal	80003672 <iunlockput>
      return 0;
    80003b40:	8a4a                	mv	s4,s2
    80003b42:	b7e9                	j	80003b0c <namex+0x5c>
  while (*path != '/' && *path != 0)
    80003b44:	8926                	mv	s2,s1
  len = path - s;
    80003b46:	4d01                	li	s10,0
    80003b48:	4601                	li	a2,0
    memmove(name, s, len);
    80003b4a:	2601                	sext.w	a2,a2
    80003b4c:	85a6                	mv	a1,s1
    80003b4e:	8556                	mv	a0,s5
    80003b50:	a7afd0ef          	jal	80000dca <memmove>
    name[len] = 0;
    80003b54:	9d56                	add	s10,s10,s5
    80003b56:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffde148>
    80003b5a:	84ca                	mv	s1,s2
  while (*path == '/')
    80003b5c:	0004c783          	lbu	a5,0(s1)
    80003b60:	01379763          	bne	a5,s3,80003b6e <namex+0xbe>
    path++;
    80003b64:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003b66:	0004c783          	lbu	a5,0(s1)
    80003b6a:	ff378de3          	beq	a5,s3,80003b64 <namex+0xb4>
    ilock(ip);
    80003b6e:	8552                	mv	a0,s4
    80003b70:	8f7ff0ef          	jal	80003466 <ilock>
    if (ip->type != T_DIR) {
    80003b74:	044a1783          	lh	a5,68(s4)
    80003b78:	f97796e3          	bne	a5,s7,80003b04 <namex+0x54>
    if (ip->nlink == 0) {
    80003b7c:	04aa1783          	lh	a5,74(s4)
    80003b80:	d7cd                	beqz	a5,80003b2a <namex+0x7a>
    if (nameiparent && *path == '\0') {
    80003b82:	000b0563          	beqz	s6,80003b8c <namex+0xdc>
    80003b86:	0004c783          	lbu	a5,0(s1)
    80003b8a:	d7c5                	beqz	a5,80003b32 <namex+0x82>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003b8c:	4601                	li	a2,0
    80003b8e:	85d6                	mv	a1,s5
    80003b90:	8552                	mv	a0,s4
    80003b92:	e77ff0ef          	jal	80003a08 <dirlookup>
    80003b96:	892a                	mv	s2,a0
    80003b98:	d14d                	beqz	a0,80003b3a <namex+0x8a>
    iunlockput(ip);
    80003b9a:	8552                	mv	a0,s4
    80003b9c:	ad7ff0ef          	jal	80003672 <iunlockput>
    ip = next;
    80003ba0:	8a4a                	mv	s4,s2
  while (*path == '/')
    80003ba2:	0004c783          	lbu	a5,0(s1)
    80003ba6:	01379763          	bne	a5,s3,80003bb4 <namex+0x104>
    path++;
    80003baa:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003bac:	0004c783          	lbu	a5,0(s1)
    80003bb0:	ff378de3          	beq	a5,s3,80003baa <namex+0xfa>
  if (*path == 0)
    80003bb4:	c7a1                	beqz	a5,80003bfc <namex+0x14c>
  while (*path != '/' && *path != 0)
    80003bb6:	0004c703          	lbu	a4,0(s1)
    80003bba:	fd170793          	addi	a5,a4,-47
    80003bbe:	00f037b3          	snez	a5,a5
    80003bc2:	00e03733          	snez	a4,a4
    80003bc6:	8ff9                	and	a5,a5,a4
    80003bc8:	dfb5                	beqz	a5,80003b44 <namex+0x94>
    80003bca:	8926                	mv	s2,s1
    path++;
    80003bcc:	0905                	addi	s2,s2,1
  while (*path != '/' && *path != 0)
    80003bce:	00094703          	lbu	a4,0(s2)
    80003bd2:	fd170793          	addi	a5,a4,-47
    80003bd6:	00f037b3          	snez	a5,a5
    80003bda:	00e03733          	snez	a4,a4
    80003bde:	8ff9                	and	a5,a5,a4
    80003be0:	f7f5                	bnez	a5,80003bcc <namex+0x11c>
  len = path - s;
    80003be2:	40990633          	sub	a2,s2,s1
    80003be6:	00060d1b          	sext.w	s10,a2
  if (len >= DIRSIZ)
    80003bea:	f7ac50e3          	bge	s8,s10,80003b4a <namex+0x9a>
    memmove(name, s, DIRSIZ);
    80003bee:	8666                	mv	a2,s9
    80003bf0:	85a6                	mv	a1,s1
    80003bf2:	8556                	mv	a0,s5
    80003bf4:	9d6fd0ef          	jal	80000dca <memmove>
    80003bf8:	84ca                	mv	s1,s2
    80003bfa:	b78d                	j	80003b5c <namex+0xac>
  if (nameiparent) {
    80003bfc:	f00b08e3          	beqz	s6,80003b0c <namex+0x5c>
    iput(ip);
    80003c00:	8552                	mv	a0,s4
    80003c02:	9e7ff0ef          	jal	800035e8 <iput>
    return 0;
    80003c06:	b711                	j	80003b0a <namex+0x5a>

0000000080003c08 <dirlink>:
{
    80003c08:	715d                	addi	sp,sp,-80
    80003c0a:	e486                	sd	ra,72(sp)
    80003c0c:	e0a2                	sd	s0,64(sp)
    80003c0e:	f84a                	sd	s2,48(sp)
    80003c10:	ec56                	sd	s5,24(sp)
    80003c12:	e85a                	sd	s6,16(sp)
    80003c14:	0880                	addi	s0,sp,80
    80003c16:	892a                	mv	s2,a0
    80003c18:	8aae                	mv	s5,a1
    80003c1a:	8b32                	mv	s6,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003c1c:	4601                	li	a2,0
    80003c1e:	debff0ef          	jal	80003a08 <dirlookup>
    80003c22:	ed1d                	bnez	a0,80003c60 <dirlink+0x58>
    80003c24:	fc26                	sd	s1,56(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003c26:	04c92483          	lw	s1,76(s2)
    80003c2a:	c4b9                	beqz	s1,80003c78 <dirlink+0x70>
    80003c2c:	f44e                	sd	s3,40(sp)
    80003c2e:	f052                	sd	s4,32(sp)
    80003c30:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c32:	fb040a13          	addi	s4,s0,-80
    80003c36:	49c1                	li	s3,16
    80003c38:	874e                	mv	a4,s3
    80003c3a:	86a6                	mv	a3,s1
    80003c3c:	8652                	mv	a2,s4
    80003c3e:	4581                	li	a1,0
    80003c40:	854a                	mv	a0,s2
    80003c42:	bb7ff0ef          	jal	800037f8 <readi>
    80003c46:	03351163          	bne	a0,s3,80003c68 <dirlink+0x60>
    if (de.inum == 0)
    80003c4a:	fb045783          	lhu	a5,-80(s0)
    80003c4e:	c39d                	beqz	a5,80003c74 <dirlink+0x6c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003c50:	24c1                	addiw	s1,s1,16
    80003c52:	04c92783          	lw	a5,76(s2)
    80003c56:	fef4e1e3          	bltu	s1,a5,80003c38 <dirlink+0x30>
    80003c5a:	79a2                	ld	s3,40(sp)
    80003c5c:	7a02                	ld	s4,32(sp)
    80003c5e:	a829                	j	80003c78 <dirlink+0x70>
    iput(ip);
    80003c60:	989ff0ef          	jal	800035e8 <iput>
    return -1;
    80003c64:	557d                	li	a0,-1
    80003c66:	a83d                	j	80003ca4 <dirlink+0x9c>
      panic("dirlink read");
    80003c68:	00004517          	auipc	a0,0x4
    80003c6c:	96050513          	addi	a0,a0,-1696 # 800075c8 <etext+0x5c8>
    80003c70:	bd9fc0ef          	jal	80000848 <panic>
    80003c74:	79a2                	ld	s3,40(sp)
    80003c76:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003c78:	4639                	li	a2,14
    80003c7a:	85d6                	mv	a1,s5
    80003c7c:	fb240513          	addi	a0,s0,-78
    80003c80:	9f4fd0ef          	jal	80000e74 <strncpy>
  de.inum = inum;
    80003c84:	fb641823          	sh	s6,-80(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c88:	4741                	li	a4,16
    80003c8a:	86a6                	mv	a3,s1
    80003c8c:	fb040613          	addi	a2,s0,-80
    80003c90:	4581                	li	a1,0
    80003c92:	854a                	mv	a0,s2
    80003c94:	c57ff0ef          	jal	800038ea <writei>
    80003c98:	1541                	addi	a0,a0,-16
    80003c9a:	00a03533          	snez	a0,a0
    80003c9e:	40a0053b          	negw	a0,a0
    80003ca2:	74e2                	ld	s1,56(sp)
}
    80003ca4:	60a6                	ld	ra,72(sp)
    80003ca6:	6406                	ld	s0,64(sp)
    80003ca8:	7942                	ld	s2,48(sp)
    80003caa:	6ae2                	ld	s5,24(sp)
    80003cac:	6b42                	ld	s6,16(sp)
    80003cae:	6161                	addi	sp,sp,80
    80003cb0:	8082                	ret

0000000080003cb2 <namei>:

struct inode *
namei(char *path)
{
    80003cb2:	1101                	addi	sp,sp,-32
    80003cb4:	ec06                	sd	ra,24(sp)
    80003cb6:	e822                	sd	s0,16(sp)
    80003cb8:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003cba:	fe040613          	addi	a2,s0,-32
    80003cbe:	4581                	li	a1,0
    80003cc0:	df1ff0ef          	jal	80003ab0 <namex>
}
    80003cc4:	60e2                	ld	ra,24(sp)
    80003cc6:	6442                	ld	s0,16(sp)
    80003cc8:	6105                	addi	sp,sp,32
    80003cca:	8082                	ret

0000000080003ccc <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003ccc:	1141                	addi	sp,sp,-16
    80003cce:	e406                	sd	ra,8(sp)
    80003cd0:	e022                	sd	s0,0(sp)
    80003cd2:	0800                	addi	s0,sp,16
    80003cd4:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003cd6:	4585                	li	a1,1
    80003cd8:	dd9ff0ef          	jal	80003ab0 <namex>
}
    80003cdc:	60a2                	ld	ra,8(sp)
    80003cde:	6402                	ld	s0,0(sp)
    80003ce0:	0141                	addi	sp,sp,16
    80003ce2:	8082                	ret

0000000080003ce4 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003ce4:	1101                	addi	sp,sp,-32
    80003ce6:	ec06                	sd	ra,24(sp)
    80003ce8:	e822                	sd	s0,16(sp)
    80003cea:	e426                	sd	s1,8(sp)
    80003cec:	e04a                	sd	s2,0(sp)
    80003cee:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003cf0:	0001c917          	auipc	s2,0x1c
    80003cf4:	f8890913          	addi	s2,s2,-120 # 8001fc78 <log>
    80003cf8:	01892583          	lw	a1,24(s2)
    80003cfc:	02492503          	lw	a0,36(s2)
    80003d00:	8c6ff0ef          	jal	80002dc6 <bread>
    80003d04:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003d06:	02c92603          	lw	a2,44(s2)
    80003d0a:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003d0c:	00c05f63          	blez	a2,80003d2a <write_head+0x46>
    80003d10:	0001c717          	auipc	a4,0x1c
    80003d14:	f9870713          	addi	a4,a4,-104 # 8001fca8 <log+0x30>
    80003d18:	87aa                	mv	a5,a0
    80003d1a:	060a                	slli	a2,a2,0x2
    80003d1c:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003d1e:	4314                	lw	a3,0(a4)
    80003d20:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003d22:	0711                	addi	a4,a4,4
    80003d24:	0791                	addi	a5,a5,4 # 43004 <_entry-0x7ffbcffc>
    80003d26:	fec79ce3          	bne	a5,a2,80003d1e <write_head+0x3a>
  }
  bwrite(buf);
    80003d2a:	8526                	mv	a0,s1
    80003d2c:	970ff0ef          	jal	80002e9c <bwrite>
  brelse(buf);
    80003d30:	8526                	mv	a0,s1
    80003d32:	99cff0ef          	jal	80002ece <brelse>
}
    80003d36:	60e2                	ld	ra,24(sp)
    80003d38:	6442                	ld	s0,16(sp)
    80003d3a:	64a2                	ld	s1,8(sp)
    80003d3c:	6902                	ld	s2,0(sp)
    80003d3e:	6105                	addi	sp,sp,32
    80003d40:	8082                	ret

0000000080003d42 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d42:	0001c797          	auipc	a5,0x1c
    80003d46:	f627a783          	lw	a5,-158(a5) # 8001fca4 <log+0x2c>
    80003d4a:	0cf05163          	blez	a5,80003e0c <install_trans+0xca>
{
    80003d4e:	715d                	addi	sp,sp,-80
    80003d50:	e486                	sd	ra,72(sp)
    80003d52:	e0a2                	sd	s0,64(sp)
    80003d54:	fc26                	sd	s1,56(sp)
    80003d56:	f84a                	sd	s2,48(sp)
    80003d58:	f44e                	sd	s3,40(sp)
    80003d5a:	f052                	sd	s4,32(sp)
    80003d5c:	ec56                	sd	s5,24(sp)
    80003d5e:	e85a                	sd	s6,16(sp)
    80003d60:	e45e                	sd	s7,8(sp)
    80003d62:	e062                	sd	s8,0(sp)
    80003d64:	0880                	addi	s0,sp,80
    80003d66:	8b2a                	mv	s6,a0
    80003d68:	0001ca97          	auipc	s5,0x1c
    80003d6c:	f40a8a93          	addi	s5,s5,-192 # 8001fca8 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d70:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003d72:	00004c17          	auipc	s8,0x4
    80003d76:	866c0c13          	addi	s8,s8,-1946 # 800075d8 <etext+0x5d8>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003d7a:	0001ca17          	auipc	s4,0x1c
    80003d7e:	efea0a13          	addi	s4,s4,-258 # 8001fc78 <log>
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003d82:	40000b93          	li	s7,1024
    80003d86:	a025                	j	80003dae <install_trans+0x6c>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003d88:	000aa603          	lw	a2,0(s5)
    80003d8c:	85ce                	mv	a1,s3
    80003d8e:	8562                	mv	a0,s8
    80003d90:	f80fc0ef          	jal	80000510 <printk>
    80003d94:	a839                	j	80003db2 <install_trans+0x70>
    brelse(lbuf);
    80003d96:	854a                	mv	a0,s2
    80003d98:	936ff0ef          	jal	80002ece <brelse>
    brelse(dbuf);
    80003d9c:	8526                	mv	a0,s1
    80003d9e:	930ff0ef          	jal	80002ece <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003da2:	2985                	addiw	s3,s3,1
    80003da4:	0a91                	addi	s5,s5,4
    80003da6:	02ca2783          	lw	a5,44(s4)
    80003daa:	04f9d563          	bge	s3,a5,80003df4 <install_trans+0xb2>
    if (recovering) {
    80003dae:	fc0b1de3          	bnez	s6,80003d88 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003db2:	018a2583          	lw	a1,24(s4)
    80003db6:	013585bb          	addw	a1,a1,s3
    80003dba:	2585                	addiw	a1,a1,1
    80003dbc:	024a2503          	lw	a0,36(s4)
    80003dc0:	806ff0ef          	jal	80002dc6 <bread>
    80003dc4:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003dc6:	000aa583          	lw	a1,0(s5)
    80003dca:	024a2503          	lw	a0,36(s4)
    80003dce:	ff9fe0ef          	jal	80002dc6 <bread>
    80003dd2:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003dd4:	865e                	mv	a2,s7
    80003dd6:	05890593          	addi	a1,s2,88
    80003dda:	05850513          	addi	a0,a0,88
    80003dde:	fedfc0ef          	jal	80000dca <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003de2:	8526                	mv	a0,s1
    80003de4:	8b8ff0ef          	jal	80002e9c <bwrite>
    if (recovering == 0)
    80003de8:	fa0b17e3          	bnez	s6,80003d96 <install_trans+0x54>
      bunpin(dbuf);
    80003dec:	8526                	mv	a0,s1
    80003dee:	998ff0ef          	jal	80002f86 <bunpin>
    80003df2:	b755                	j	80003d96 <install_trans+0x54>
}
    80003df4:	60a6                	ld	ra,72(sp)
    80003df6:	6406                	ld	s0,64(sp)
    80003df8:	74e2                	ld	s1,56(sp)
    80003dfa:	7942                	ld	s2,48(sp)
    80003dfc:	79a2                	ld	s3,40(sp)
    80003dfe:	7a02                	ld	s4,32(sp)
    80003e00:	6ae2                	ld	s5,24(sp)
    80003e02:	6b42                	ld	s6,16(sp)
    80003e04:	6ba2                	ld	s7,8(sp)
    80003e06:	6c02                	ld	s8,0(sp)
    80003e08:	6161                	addi	sp,sp,80
    80003e0a:	8082                	ret
    80003e0c:	8082                	ret

0000000080003e0e <initlog>:
{
    80003e0e:	7179                	addi	sp,sp,-48
    80003e10:	f406                	sd	ra,40(sp)
    80003e12:	f022                	sd	s0,32(sp)
    80003e14:	ec26                	sd	s1,24(sp)
    80003e16:	e84a                	sd	s2,16(sp)
    80003e18:	e44e                	sd	s3,8(sp)
    80003e1a:	1800                	addi	s0,sp,48
    80003e1c:	84aa                	mv	s1,a0
    80003e1e:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003e20:	0001c917          	auipc	s2,0x1c
    80003e24:	e5890913          	addi	s2,s2,-424 # 8001fc78 <log>
    80003e28:	00003597          	auipc	a1,0x3
    80003e2c:	7d058593          	addi	a1,a1,2000 # 800075f8 <etext+0x5f8>
    80003e30:	854a                	mv	a0,s2
    80003e32:	e01fc0ef          	jal	80000c32 <initlock>
  log.start = sb->logstart;
    80003e36:	0149a583          	lw	a1,20(s3)
    80003e3a:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003e3e:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003e42:	8526                	mv	a0,s1
    80003e44:	f83fe0ef          	jal	80002dc6 <bread>
  log.lh.n = lh->n;
    80003e48:	4d30                	lw	a2,88(a0)
    80003e4a:	02c92623          	sw	a2,44(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003e4e:	00c05f63          	blez	a2,80003e6c <initlog+0x5e>
    80003e52:	87aa                	mv	a5,a0
    80003e54:	0001c717          	auipc	a4,0x1c
    80003e58:	e5470713          	addi	a4,a4,-428 # 8001fca8 <log+0x30>
    80003e5c:	060a                	slli	a2,a2,0x2
    80003e5e:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003e60:	4ff4                	lw	a3,92(a5)
    80003e62:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003e64:	0791                	addi	a5,a5,4
    80003e66:	0711                	addi	a4,a4,4
    80003e68:	fec79ce3          	bne	a5,a2,80003e60 <initlog+0x52>
  brelse(buf);
    80003e6c:	862ff0ef          	jal	80002ece <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003e70:	4505                	li	a0,1
    80003e72:	ed1ff0ef          	jal	80003d42 <install_trans>
  log.lh.n = 0;
    80003e76:	0001c797          	auipc	a5,0x1c
    80003e7a:	e207a723          	sw	zero,-466(a5) # 8001fca4 <log+0x2c>
  write_head(); // clear the log
    80003e7e:	e67ff0ef          	jal	80003ce4 <write_head>
}
    80003e82:	70a2                	ld	ra,40(sp)
    80003e84:	7402                	ld	s0,32(sp)
    80003e86:	64e2                	ld	s1,24(sp)
    80003e88:	6942                	ld	s2,16(sp)
    80003e8a:	69a2                	ld	s3,8(sp)
    80003e8c:	6145                	addi	sp,sp,48
    80003e8e:	8082                	ret

0000000080003e90 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003e90:	1101                	addi	sp,sp,-32
    80003e92:	ec06                	sd	ra,24(sp)
    80003e94:	e822                	sd	s0,16(sp)
    80003e96:	e426                	sd	s1,8(sp)
    80003e98:	e04a                	sd	s2,0(sp)
    80003e9a:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003e9c:	0001c517          	auipc	a0,0x1c
    80003ea0:	ddc50513          	addi	a0,a0,-548 # 8001fc78 <log>
    80003ea4:	e0ffc0ef          	jal	80000cb2 <acquire>
  while (1) {
    if (log.committing) {
    80003ea8:	0001c497          	auipc	s1,0x1c
    80003eac:	dd048493          	addi	s1,s1,-560 # 8001fc78 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003eb0:	4979                	li	s2,30
    80003eb2:	a821                	j	80003eca <begin_op+0x3a>
      sleep_prepare(&log);
    80003eb4:	8526                	mv	a0,s1
    80003eb6:	a14fe0ef          	jal	800020ca <sleep_prepare>
      release(&log.lock);
    80003eba:	8526                	mv	a0,s1
    80003ebc:	e7bfc0ef          	jal	80000d36 <release>
      sleep();
    80003ec0:	a46fe0ef          	jal	80002106 <sleep>
      acquire(&log.lock);
    80003ec4:	8526                	mv	a0,s1
    80003ec6:	dedfc0ef          	jal	80000cb2 <acquire>
    if (log.committing) {
    80003eca:	509c                	lw	a5,32(s1)
    80003ecc:	f7e5                	bnez	a5,80003eb4 <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003ece:	4cd8                	lw	a4,28(s1)
    80003ed0:	2705                	addiw	a4,a4,1
    80003ed2:	0027179b          	slliw	a5,a4,0x2
    80003ed6:	9fb9                	addw	a5,a5,a4
    80003ed8:	0017979b          	slliw	a5,a5,0x1
    80003edc:	54d4                	lw	a3,44(s1)
    80003ede:	9fb5                	addw	a5,a5,a3
    80003ee0:	00f95e63          	bge	s2,a5,80003efc <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003ee4:	8526                	mv	a0,s1
    80003ee6:	9e4fe0ef          	jal	800020ca <sleep_prepare>
      release(&log.lock);
    80003eea:	8526                	mv	a0,s1
    80003eec:	e4bfc0ef          	jal	80000d36 <release>
      sleep();
    80003ef0:	a16fe0ef          	jal	80002106 <sleep>
      acquire(&log.lock);
    80003ef4:	8526                	mv	a0,s1
    80003ef6:	dbdfc0ef          	jal	80000cb2 <acquire>
    80003efa:	bfc1                	j	80003eca <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80003efc:	0001c797          	auipc	a5,0x1c
    80003f00:	d8e7ac23          	sw	a4,-616(a5) # 8001fc94 <log+0x1c>
      release(&log.lock);
    80003f04:	0001c517          	auipc	a0,0x1c
    80003f08:	d7450513          	addi	a0,a0,-652 # 8001fc78 <log>
    80003f0c:	e2bfc0ef          	jal	80000d36 <release>
      break;
    }
  }
}
    80003f10:	60e2                	ld	ra,24(sp)
    80003f12:	6442                	ld	s0,16(sp)
    80003f14:	64a2                	ld	s1,8(sp)
    80003f16:	6902                	ld	s2,0(sp)
    80003f18:	6105                	addi	sp,sp,32
    80003f1a:	8082                	ret

0000000080003f1c <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003f1c:	7139                	addi	sp,sp,-64
    80003f1e:	fc06                	sd	ra,56(sp)
    80003f20:	f822                	sd	s0,48(sp)
    80003f22:	f426                	sd	s1,40(sp)
    80003f24:	f04a                	sd	s2,32(sp)
    80003f26:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003f28:	0001c497          	auipc	s1,0x1c
    80003f2c:	d5048493          	addi	s1,s1,-688 # 8001fc78 <log>
    80003f30:	8526                	mv	a0,s1
    80003f32:	d81fc0ef          	jal	80000cb2 <acquire>
  log.outstanding -= 1;
    80003f36:	4cdc                	lw	a5,28(s1)
    80003f38:	37fd                	addiw	a5,a5,-1
    80003f3a:	893e                	mv	s2,a5
    80003f3c:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003f3e:	509c                	lw	a5,32(s1)
    80003f40:	e7b9                	bnez	a5,80003f8e <end_op+0x72>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003f42:	04091f63          	bnez	s2,80003fa0 <end_op+0x84>
    do_commit = 1;
    log.committing = 1;
    80003f46:	0001c497          	auipc	s1,0x1c
    80003f4a:	d3248493          	addi	s1,s1,-718 # 8001fc78 <log>
    80003f4e:	4785                	li	a5,1
    80003f50:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003f52:	8526                	mv	a0,s1
    80003f54:	de3fc0ef          	jal	80000d36 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003f58:	54dc                	lw	a5,44(s1)
    80003f5a:	06f04063          	bgtz	a5,80003fba <end_op+0x9e>
    acquire(&log.lock);
    80003f5e:	0001c497          	auipc	s1,0x1c
    80003f62:	d1a48493          	addi	s1,s1,-742 # 8001fc78 <log>
    80003f66:	8526                	mv	a0,s1
    80003f68:	d4bfc0ef          	jal	80000cb2 <acquire>
    log.committing = 0;
    80003f6c:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003f70:	549c                	lw	a5,40(s1)
    80003f72:	2785                	addiw	a5,a5,1
    80003f74:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003f76:	8526                	mv	a0,s1
    80003f78:	9befe0ef          	jal	80002136 <wakeup>
    release(&log.lock);
    80003f7c:	8526                	mv	a0,s1
    80003f7e:	db9fc0ef          	jal	80000d36 <release>
}
    80003f82:	70e2                	ld	ra,56(sp)
    80003f84:	7442                	ld	s0,48(sp)
    80003f86:	74a2                	ld	s1,40(sp)
    80003f88:	7902                	ld	s2,32(sp)
    80003f8a:	6121                	addi	sp,sp,64
    80003f8c:	8082                	ret
    80003f8e:	ec4e                	sd	s3,24(sp)
    80003f90:	e852                	sd	s4,16(sp)
    80003f92:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003f94:	00003517          	auipc	a0,0x3
    80003f98:	66c50513          	addi	a0,a0,1644 # 80007600 <etext+0x600>
    80003f9c:	8adfc0ef          	jal	80000848 <panic>
    wakeup(&log);
    80003fa0:	0001c517          	auipc	a0,0x1c
    80003fa4:	cd850513          	addi	a0,a0,-808 # 8001fc78 <log>
    80003fa8:	98efe0ef          	jal	80002136 <wakeup>
  release(&log.lock);
    80003fac:	0001c517          	auipc	a0,0x1c
    80003fb0:	ccc50513          	addi	a0,a0,-820 # 8001fc78 <log>
    80003fb4:	d83fc0ef          	jal	80000d36 <release>
  if (do_commit) {
    80003fb8:	b7e9                	j	80003f82 <end_op+0x66>
    80003fba:	ec4e                	sd	s3,24(sp)
    80003fbc:	e852                	sd	s4,16(sp)
    80003fbe:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fc0:	0001ca97          	auipc	s5,0x1c
    80003fc4:	ce8a8a93          	addi	s5,s5,-792 # 8001fca8 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003fc8:	0001ca17          	auipc	s4,0x1c
    80003fcc:	cb0a0a13          	addi	s4,s4,-848 # 8001fc78 <log>
    80003fd0:	018a2583          	lw	a1,24(s4)
    80003fd4:	012585bb          	addw	a1,a1,s2
    80003fd8:	2585                	addiw	a1,a1,1
    80003fda:	024a2503          	lw	a0,36(s4)
    80003fde:	de9fe0ef          	jal	80002dc6 <bread>
    80003fe2:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003fe4:	000aa583          	lw	a1,0(s5)
    80003fe8:	024a2503          	lw	a0,36(s4)
    80003fec:	ddbfe0ef          	jal	80002dc6 <bread>
    80003ff0:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003ff2:	40000613          	li	a2,1024
    80003ff6:	05850593          	addi	a1,a0,88
    80003ffa:	05848513          	addi	a0,s1,88
    80003ffe:	dcdfc0ef          	jal	80000dca <memmove>
    bwrite(to); // write the log
    80004002:	8526                	mv	a0,s1
    80004004:	e99fe0ef          	jal	80002e9c <bwrite>
    brelse(from);
    80004008:	854e                	mv	a0,s3
    8000400a:	ec5fe0ef          	jal	80002ece <brelse>
    brelse(to);
    8000400e:	8526                	mv	a0,s1
    80004010:	ebffe0ef          	jal	80002ece <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004014:	2905                	addiw	s2,s2,1
    80004016:	0a91                	addi	s5,s5,4
    80004018:	02ca2783          	lw	a5,44(s4)
    8000401c:	faf94ae3          	blt	s2,a5,80003fd0 <end_op+0xb4>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80004020:	cc5ff0ef          	jal	80003ce4 <write_head>
    install_trans(0); // Now install writes to home locations
    80004024:	4501                	li	a0,0
    80004026:	d1dff0ef          	jal	80003d42 <install_trans>
    log.lh.n = 0;
    8000402a:	0001c797          	auipc	a5,0x1c
    8000402e:	c607ad23          	sw	zero,-902(a5) # 8001fca4 <log+0x2c>
    write_head(); // Erase the transaction from the log
    80004032:	cb3ff0ef          	jal	80003ce4 <write_head>
    80004036:	69e2                	ld	s3,24(sp)
    80004038:	6a42                	ld	s4,16(sp)
    8000403a:	6aa2                	ld	s5,8(sp)
    8000403c:	b70d                	j	80003f5e <end_op+0x42>

000000008000403e <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000403e:	1101                	addi	sp,sp,-32
    80004040:	ec06                	sd	ra,24(sp)
    80004042:	e822                	sd	s0,16(sp)
    80004044:	e426                	sd	s1,8(sp)
    80004046:	1000                	addi	s0,sp,32
    80004048:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    8000404a:	0001c517          	auipc	a0,0x1c
    8000404e:	c2e50513          	addi	a0,a0,-978 # 8001fc78 <log>
    80004052:	c61fc0ef          	jal	80000cb2 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80004056:	0001c617          	auipc	a2,0x1c
    8000405a:	c4e62603          	lw	a2,-946(a2) # 8001fca4 <log+0x2c>
    8000405e:	47f5                	li	a5,29
    80004060:	04c7cc63          	blt	a5,a2,800040b8 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80004064:	0001c797          	auipc	a5,0x1c
    80004068:	c307a783          	lw	a5,-976(a5) # 8001fc94 <log+0x1c>
    8000406c:	04f05c63          	blez	a5,800040c4 <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004070:	4781                	li	a5,0
    80004072:	04c05f63          	blez	a2,800040d0 <log_write+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    80004076:	44cc                	lw	a1,12(s1)
    80004078:	0001c717          	auipc	a4,0x1c
    8000407c:	c3070713          	addi	a4,a4,-976 # 8001fca8 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80004080:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    80004082:	4314                	lw	a3,0(a4)
    80004084:	04b68663          	beq	a3,a1,800040d0 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80004088:	2785                	addiw	a5,a5,1
    8000408a:	0711                	addi	a4,a4,4
    8000408c:	fef61be3          	bne	a2,a5,80004082 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004090:	0621                	addi	a2,a2,8
    80004092:	060a                	slli	a2,a2,0x2
    80004094:	0001c797          	auipc	a5,0x1c
    80004098:	be478793          	addi	a5,a5,-1052 # 8001fc78 <log>
    8000409c:	97b2                	add	a5,a5,a2
    8000409e:	44d8                	lw	a4,12(s1)
    800040a0:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    800040a2:	8526                	mv	a0,s1
    800040a4:	eaffe0ef          	jal	80002f52 <bpin>
    log.lh.n++;
    800040a8:	0001c717          	auipc	a4,0x1c
    800040ac:	bd070713          	addi	a4,a4,-1072 # 8001fc78 <log>
    800040b0:	575c                	lw	a5,44(a4)
    800040b2:	2785                	addiw	a5,a5,1
    800040b4:	d75c                	sw	a5,44(a4)
    800040b6:	a80d                	j	800040e8 <log_write+0xaa>
    panic("too big a transaction");
    800040b8:	00003517          	auipc	a0,0x3
    800040bc:	55850513          	addi	a0,a0,1368 # 80007610 <etext+0x610>
    800040c0:	f88fc0ef          	jal	80000848 <panic>
    panic("log_write outside of trans");
    800040c4:	00003517          	auipc	a0,0x3
    800040c8:	56450513          	addi	a0,a0,1380 # 80007628 <etext+0x628>
    800040cc:	f7cfc0ef          	jal	80000848 <panic>
  log.lh.block[i] = b->blockno;
    800040d0:	00878693          	addi	a3,a5,8
    800040d4:	068a                	slli	a3,a3,0x2
    800040d6:	0001c717          	auipc	a4,0x1c
    800040da:	ba270713          	addi	a4,a4,-1118 # 8001fc78 <log>
    800040de:	9736                	add	a4,a4,a3
    800040e0:	44d4                	lw	a3,12(s1)
    800040e2:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    800040e4:	faf60fe3          	beq	a2,a5,800040a2 <log_write+0x64>
  }
  release(&log.lock);
    800040e8:	0001c517          	auipc	a0,0x1c
    800040ec:	b9050513          	addi	a0,a0,-1136 # 8001fc78 <log>
    800040f0:	c47fc0ef          	jal	80000d36 <release>
}
    800040f4:	60e2                	ld	ra,24(sp)
    800040f6:	6442                	ld	s0,16(sp)
    800040f8:	64a2                	ld	s1,8(sp)
    800040fa:	6105                	addi	sp,sp,32
    800040fc:	8082                	ret

00000000800040fe <sys_sync>:

uint64
sys_sync(void)
{
    800040fe:	1101                	addi	sp,sp,-32
    80004100:	ec06                	sd	ra,24(sp)
    80004102:	e822                	sd	s0,16(sp)
    80004104:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004106:	0001c517          	auipc	a0,0x1c
    8000410a:	b7250513          	addi	a0,a0,-1166 # 8001fc78 <log>
    8000410e:	ba5fc0ef          	jal	80000cb2 <acquire>
  if (log.committing || log.outstanding > 0) {
    80004112:	0001c797          	auipc	a5,0x1c
    80004116:	b867a783          	lw	a5,-1146(a5) # 8001fc98 <log+0x20>
    8000411a:	e799                	bnez	a5,80004128 <sys_sync+0x2a>
    8000411c:	0001c797          	auipc	a5,0x1c
    80004120:	b787a783          	lw	a5,-1160(a5) # 8001fc94 <log+0x1c>
    80004124:	02f05c63          	blez	a5,8000415c <sys_sync+0x5e>
    80004128:	e426                	sd	s1,8(sp)
    8000412a:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    8000412c:	0001c917          	auipc	s2,0x1c
    80004130:	b7492903          	lw	s2,-1164(s2) # 8001fca0 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    80004134:	0001c497          	auipc	s1,0x1c
    80004138:	b4448493          	addi	s1,s1,-1212 # 8001fc78 <log>
    8000413c:	8526                	mv	a0,s1
    8000413e:	f8dfd0ef          	jal	800020ca <sleep_prepare>
      release(&log.lock);
    80004142:	8526                	mv	a0,s1
    80004144:	bf3fc0ef          	jal	80000d36 <release>
      sleep();
    80004148:	fbffd0ef          	jal	80002106 <sleep>
      acquire(&log.lock);
    8000414c:	8526                	mv	a0,s1
    8000414e:	b65fc0ef          	jal	80000cb2 <acquire>
    while (log.ncommit < n) {
    80004152:	549c                	lw	a5,40(s1)
    80004154:	fef954e3          	bge	s2,a5,8000413c <sys_sync+0x3e>
    80004158:	64a2                	ld	s1,8(sp)
    8000415a:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    8000415c:	0001c517          	auipc	a0,0x1c
    80004160:	b1c50513          	addi	a0,a0,-1252 # 8001fc78 <log>
    80004164:	bd3fc0ef          	jal	80000d36 <release>
  return 0;
}
    80004168:	4501                	li	a0,0
    8000416a:	60e2                	ld	ra,24(sp)
    8000416c:	6442                	ld	s0,16(sp)
    8000416e:	6105                	addi	sp,sp,32
    80004170:	8082                	ret

0000000080004172 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80004172:	1101                	addi	sp,sp,-32
    80004174:	ec06                	sd	ra,24(sp)
    80004176:	e822                	sd	s0,16(sp)
    80004178:	e426                	sd	s1,8(sp)
    8000417a:	e04a                	sd	s2,0(sp)
    8000417c:	1000                	addi	s0,sp,32
    8000417e:	84aa                	mv	s1,a0
    80004180:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004182:	00003597          	auipc	a1,0x3
    80004186:	4c658593          	addi	a1,a1,1222 # 80007648 <etext+0x648>
    8000418a:	0521                	addi	a0,a0,8
    8000418c:	aa7fc0ef          	jal	80000c32 <initlock>
  lk->name = name;
    80004190:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004194:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004198:	0204a423          	sw	zero,40(s1)
}
    8000419c:	60e2                	ld	ra,24(sp)
    8000419e:	6442                	ld	s0,16(sp)
    800041a0:	64a2                	ld	s1,8(sp)
    800041a2:	6902                	ld	s2,0(sp)
    800041a4:	6105                	addi	sp,sp,32
    800041a6:	8082                	ret

00000000800041a8 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800041a8:	1101                	addi	sp,sp,-32
    800041aa:	ec06                	sd	ra,24(sp)
    800041ac:	e822                	sd	s0,16(sp)
    800041ae:	e426                	sd	s1,8(sp)
    800041b0:	e04a                	sd	s2,0(sp)
    800041b2:	1000                	addi	s0,sp,32
    800041b4:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800041b6:	00850913          	addi	s2,a0,8
    800041ba:	854a                	mv	a0,s2
    800041bc:	af7fc0ef          	jal	80000cb2 <acquire>
  while (lk->locked) {
    800041c0:	409c                	lw	a5,0(s1)
    800041c2:	cf91                	beqz	a5,800041de <acquiresleep+0x36>
    sleep_prepare(lk);
    800041c4:	8526                	mv	a0,s1
    800041c6:	f05fd0ef          	jal	800020ca <sleep_prepare>
    release(&lk->lk);
    800041ca:	854a                	mv	a0,s2
    800041cc:	b6bfc0ef          	jal	80000d36 <release>
    sleep();
    800041d0:	f37fd0ef          	jal	80002106 <sleep>
    acquire(&lk->lk);
    800041d4:	854a                	mv	a0,s2
    800041d6:	addfc0ef          	jal	80000cb2 <acquire>
  while (lk->locked) {
    800041da:	409c                	lw	a5,0(s1)
    800041dc:	f7e5                	bnez	a5,800041c4 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800041de:	4785                	li	a5,1
    800041e0:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800041e2:	8a3fd0ef          	jal	80001a84 <myproc>
    800041e6:	591c                	lw	a5,48(a0)
    800041e8:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800041ea:	854a                	mv	a0,s2
    800041ec:	b4bfc0ef          	jal	80000d36 <release>
}
    800041f0:	60e2                	ld	ra,24(sp)
    800041f2:	6442                	ld	s0,16(sp)
    800041f4:	64a2                	ld	s1,8(sp)
    800041f6:	6902                	ld	s2,0(sp)
    800041f8:	6105                	addi	sp,sp,32
    800041fa:	8082                	ret

00000000800041fc <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800041fc:	1101                	addi	sp,sp,-32
    800041fe:	ec06                	sd	ra,24(sp)
    80004200:	e822                	sd	s0,16(sp)
    80004202:	e426                	sd	s1,8(sp)
    80004204:	e04a                	sd	s2,0(sp)
    80004206:	1000                	addi	s0,sp,32
    80004208:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000420a:	00850913          	addi	s2,a0,8
    8000420e:	854a                	mv	a0,s2
    80004210:	aa3fc0ef          	jal	80000cb2 <acquire>
  lk->locked = 0;
    80004214:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004218:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000421c:	8526                	mv	a0,s1
    8000421e:	f19fd0ef          	jal	80002136 <wakeup>
  release(&lk->lk);
    80004222:	854a                	mv	a0,s2
    80004224:	b13fc0ef          	jal	80000d36 <release>
}
    80004228:	60e2                	ld	ra,24(sp)
    8000422a:	6442                	ld	s0,16(sp)
    8000422c:	64a2                	ld	s1,8(sp)
    8000422e:	6902                	ld	s2,0(sp)
    80004230:	6105                	addi	sp,sp,32
    80004232:	8082                	ret

0000000080004234 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80004234:	7179                	addi	sp,sp,-48
    80004236:	f406                	sd	ra,40(sp)
    80004238:	f022                	sd	s0,32(sp)
    8000423a:	ec26                	sd	s1,24(sp)
    8000423c:	e84a                	sd	s2,16(sp)
    8000423e:	1800                	addi	s0,sp,48
    80004240:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    80004242:	00850913          	addi	s2,a0,8
    80004246:	854a                	mv	a0,s2
    80004248:	a6bfc0ef          	jal	80000cb2 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000424c:	409c                	lw	a5,0(s1)
    8000424e:	ef81                	bnez	a5,80004266 <holdingsleep+0x32>
    80004250:	4481                	li	s1,0
  release(&lk->lk);
    80004252:	854a                	mv	a0,s2
    80004254:	ae3fc0ef          	jal	80000d36 <release>
  return r;
}
    80004258:	8526                	mv	a0,s1
    8000425a:	70a2                	ld	ra,40(sp)
    8000425c:	7402                	ld	s0,32(sp)
    8000425e:	64e2                	ld	s1,24(sp)
    80004260:	6942                	ld	s2,16(sp)
    80004262:	6145                	addi	sp,sp,48
    80004264:	8082                	ret
    80004266:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80004268:	0284a983          	lw	s3,40(s1)
    8000426c:	819fd0ef          	jal	80001a84 <myproc>
    80004270:	5904                	lw	s1,48(a0)
    80004272:	413484b3          	sub	s1,s1,s3
    80004276:	0014b493          	seqz	s1,s1
    8000427a:	69a2                	ld	s3,8(sp)
    8000427c:	bfd9                	j	80004252 <holdingsleep+0x1e>

000000008000427e <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    8000427e:	1141                	addi	sp,sp,-16
    80004280:	e406                	sd	ra,8(sp)
    80004282:	e022                	sd	s0,0(sp)
    80004284:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80004286:	00003597          	auipc	a1,0x3
    8000428a:	3d258593          	addi	a1,a1,978 # 80007658 <etext+0x658>
    8000428e:	0001c517          	auipc	a0,0x1c
    80004292:	b3250513          	addi	a0,a0,-1230 # 8001fdc0 <ftable>
    80004296:	99dfc0ef          	jal	80000c32 <initlock>
}
    8000429a:	60a2                	ld	ra,8(sp)
    8000429c:	6402                	ld	s0,0(sp)
    8000429e:	0141                	addi	sp,sp,16
    800042a0:	8082                	ret

00000000800042a2 <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    800042a2:	1101                	addi	sp,sp,-32
    800042a4:	ec06                	sd	ra,24(sp)
    800042a6:	e822                	sd	s0,16(sp)
    800042a8:	e426                	sd	s1,8(sp)
    800042aa:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800042ac:	0001c517          	auipc	a0,0x1c
    800042b0:	b1450513          	addi	a0,a0,-1260 # 8001fdc0 <ftable>
    800042b4:	9fffc0ef          	jal	80000cb2 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800042b8:	0001c497          	auipc	s1,0x1c
    800042bc:	b2048493          	addi	s1,s1,-1248 # 8001fdd8 <ftable+0x18>
    800042c0:	0001d717          	auipc	a4,0x1d
    800042c4:	ab870713          	addi	a4,a4,-1352 # 80020d78 <disk>
    if (f->ref == 0) {
    800042c8:	40dc                	lw	a5,4(s1)
    800042ca:	cf89                	beqz	a5,800042e4 <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800042cc:	02848493          	addi	s1,s1,40
    800042d0:	fee49ce3          	bne	s1,a4,800042c8 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800042d4:	0001c517          	auipc	a0,0x1c
    800042d8:	aec50513          	addi	a0,a0,-1300 # 8001fdc0 <ftable>
    800042dc:	a5bfc0ef          	jal	80000d36 <release>
  return 0;
    800042e0:	4481                	li	s1,0
    800042e2:	a809                	j	800042f4 <filealloc+0x52>
      f->ref = 1;
    800042e4:	4785                	li	a5,1
    800042e6:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800042e8:	0001c517          	auipc	a0,0x1c
    800042ec:	ad850513          	addi	a0,a0,-1320 # 8001fdc0 <ftable>
    800042f0:	a47fc0ef          	jal	80000d36 <release>
}
    800042f4:	8526                	mv	a0,s1
    800042f6:	60e2                	ld	ra,24(sp)
    800042f8:	6442                	ld	s0,16(sp)
    800042fa:	64a2                	ld	s1,8(sp)
    800042fc:	6105                	addi	sp,sp,32
    800042fe:	8082                	ret

0000000080004300 <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    80004300:	1101                	addi	sp,sp,-32
    80004302:	ec06                	sd	ra,24(sp)
    80004304:	e822                	sd	s0,16(sp)
    80004306:	e426                	sd	s1,8(sp)
    80004308:	1000                	addi	s0,sp,32
    8000430a:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000430c:	0001c517          	auipc	a0,0x1c
    80004310:	ab450513          	addi	a0,a0,-1356 # 8001fdc0 <ftable>
    80004314:	99ffc0ef          	jal	80000cb2 <acquire>
  if (f->ref < 1)
    80004318:	40dc                	lw	a5,4(s1)
    8000431a:	02f05063          	blez	a5,8000433a <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000431e:	2785                	addiw	a5,a5,1
    80004320:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004322:	0001c517          	auipc	a0,0x1c
    80004326:	a9e50513          	addi	a0,a0,-1378 # 8001fdc0 <ftable>
    8000432a:	a0dfc0ef          	jal	80000d36 <release>
  return f;
}
    8000432e:	8526                	mv	a0,s1
    80004330:	60e2                	ld	ra,24(sp)
    80004332:	6442                	ld	s0,16(sp)
    80004334:	64a2                	ld	s1,8(sp)
    80004336:	6105                	addi	sp,sp,32
    80004338:	8082                	ret
    panic("filedup");
    8000433a:	00003517          	auipc	a0,0x3
    8000433e:	32650513          	addi	a0,a0,806 # 80007660 <etext+0x660>
    80004342:	d06fc0ef          	jal	80000848 <panic>

0000000080004346 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004346:	7139                	addi	sp,sp,-64
    80004348:	fc06                	sd	ra,56(sp)
    8000434a:	f822                	sd	s0,48(sp)
    8000434c:	f426                	sd	s1,40(sp)
    8000434e:	0080                	addi	s0,sp,64
    80004350:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004352:	0001c517          	auipc	a0,0x1c
    80004356:	a6e50513          	addi	a0,a0,-1426 # 8001fdc0 <ftable>
    8000435a:	959fc0ef          	jal	80000cb2 <acquire>
  if (f->ref < 1)
    8000435e:	40dc                	lw	a5,4(s1)
    80004360:	04f05a63          	blez	a5,800043b4 <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    80004364:	37fd                	addiw	a5,a5,-1
    80004366:	c0dc                	sw	a5,4(s1)
    80004368:	06f04063          	bgtz	a5,800043c8 <fileclose+0x82>
    8000436c:	f04a                	sd	s2,32(sp)
    8000436e:	ec4e                	sd	s3,24(sp)
    80004370:	e852                	sd	s4,16(sp)
    80004372:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004374:	0004a903          	lw	s2,0(s1)
    80004378:	0094c783          	lbu	a5,9(s1)
    8000437c:	89be                	mv	s3,a5
    8000437e:	689c                	ld	a5,16(s1)
    80004380:	8a3e                	mv	s4,a5
    80004382:	6c9c                	ld	a5,24(s1)
    80004384:	8abe                	mv	s5,a5
  f->ref = 0;
    80004386:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000438a:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000438e:	0001c517          	auipc	a0,0x1c
    80004392:	a3250513          	addi	a0,a0,-1486 # 8001fdc0 <ftable>
    80004396:	9a1fc0ef          	jal	80000d36 <release>

  if (ff.type == FD_PIPE) {
    8000439a:	4785                	li	a5,1
    8000439c:	04f90163          	beq	s2,a5,800043de <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    800043a0:	ffe9079b          	addiw	a5,s2,-2
    800043a4:	4705                	li	a4,1
    800043a6:	04f77563          	bgeu	a4,a5,800043f0 <fileclose+0xaa>
    800043aa:	7902                	ld	s2,32(sp)
    800043ac:	69e2                	ld	s3,24(sp)
    800043ae:	6a42                	ld	s4,16(sp)
    800043b0:	6aa2                	ld	s5,8(sp)
    800043b2:	a00d                	j	800043d4 <fileclose+0x8e>
    800043b4:	f04a                	sd	s2,32(sp)
    800043b6:	ec4e                	sd	s3,24(sp)
    800043b8:	e852                	sd	s4,16(sp)
    800043ba:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800043bc:	00003517          	auipc	a0,0x3
    800043c0:	2ac50513          	addi	a0,a0,684 # 80007668 <etext+0x668>
    800043c4:	c84fc0ef          	jal	80000848 <panic>
    release(&ftable.lock);
    800043c8:	0001c517          	auipc	a0,0x1c
    800043cc:	9f850513          	addi	a0,a0,-1544 # 8001fdc0 <ftable>
    800043d0:	967fc0ef          	jal	80000d36 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800043d4:	70e2                	ld	ra,56(sp)
    800043d6:	7442                	ld	s0,48(sp)
    800043d8:	74a2                	ld	s1,40(sp)
    800043da:	6121                	addi	sp,sp,64
    800043dc:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800043de:	85ce                	mv	a1,s3
    800043e0:	8552                	mv	a0,s4
    800043e2:	336000ef          	jal	80004718 <pipeclose>
    800043e6:	7902                	ld	s2,32(sp)
    800043e8:	69e2                	ld	s3,24(sp)
    800043ea:	6a42                	ld	s4,16(sp)
    800043ec:	6aa2                	ld	s5,8(sp)
    800043ee:	b7dd                	j	800043d4 <fileclose+0x8e>
    begin_op();
    800043f0:	aa1ff0ef          	jal	80003e90 <begin_op>
    iput(ff.ip);
    800043f4:	8556                	mv	a0,s5
    800043f6:	9f2ff0ef          	jal	800035e8 <iput>
    end_op();
    800043fa:	b23ff0ef          	jal	80003f1c <end_op>
    800043fe:	7902                	ld	s2,32(sp)
    80004400:	69e2                	ld	s3,24(sp)
    80004402:	6a42                	ld	s4,16(sp)
    80004404:	6aa2                	ld	s5,8(sp)
    80004406:	b7f9                	j	800043d4 <fileclose+0x8e>

0000000080004408 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004408:	715d                	addi	sp,sp,-80
    8000440a:	e486                	sd	ra,72(sp)
    8000440c:	e0a2                	sd	s0,64(sp)
    8000440e:	fc26                	sd	s1,56(sp)
    80004410:	f052                	sd	s4,32(sp)
    80004412:	0880                	addi	s0,sp,80
    80004414:	84aa                	mv	s1,a0
    80004416:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004418:	e6cfd0ef          	jal	80001a84 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    8000441c:	409c                	lw	a5,0(s1)
    8000441e:	37f9                	addiw	a5,a5,-2
    80004420:	4705                	li	a4,1
    80004422:	04f76463          	bltu	a4,a5,8000446a <filestat+0x62>
    80004426:	f84a                	sd	s2,48(sp)
    80004428:	f44e                	sd	s3,40(sp)
    8000442a:	892a                	mv	s2,a0
    ilock(f->ip);
    8000442c:	6c88                	ld	a0,24(s1)
    8000442e:	838ff0ef          	jal	80003466 <ilock>
    stati(f->ip, &st);
    80004432:	fb840993          	addi	s3,s0,-72
    80004436:	85ce                	mv	a1,s3
    80004438:	6c88                	ld	a0,24(s1)
    8000443a:	b90ff0ef          	jal	800037ca <stati>
    iunlock(f->ip);
    8000443e:	6c88                	ld	a0,24(s1)
    80004440:	8d4ff0ef          	jal	80003514 <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    80004444:	4761                	li	a4,24
    80004446:	86ce                	mv	a3,s3
    80004448:	8652                	mv	a2,s4
    8000444a:	04893583          	ld	a1,72(s2)
    8000444e:	05093503          	ld	a0,80(s2)
    80004452:	994fd0ef          	jal	800015e6 <copyout>
    80004456:	41f5551b          	sraiw	a0,a0,0x1f
    8000445a:	7942                	ld	s2,48(sp)
    8000445c:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    8000445e:	60a6                	ld	ra,72(sp)
    80004460:	6406                	ld	s0,64(sp)
    80004462:	74e2                	ld	s1,56(sp)
    80004464:	7a02                	ld	s4,32(sp)
    80004466:	6161                	addi	sp,sp,80
    80004468:	8082                	ret
  return -1;
    8000446a:	557d                	li	a0,-1
    8000446c:	bfcd                	j	8000445e <filestat+0x56>

000000008000446e <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000446e:	7179                	addi	sp,sp,-48
    80004470:	f406                	sd	ra,40(sp)
    80004472:	f022                	sd	s0,32(sp)
    80004474:	e84a                	sd	s2,16(sp)
    80004476:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0)
    80004478:	00854783          	lbu	a5,8(a0)
    8000447c:	c3c5                	beqz	a5,8000451c <fileread+0xae>
    8000447e:	ec26                	sd	s1,24(sp)
    80004480:	e44e                	sd	s3,8(sp)
    80004482:	84aa                	mv	s1,a0
    80004484:	892e                	mv	s2,a1
    80004486:	89b2                	mv	s3,a2
    return -1;

  if (f->type == FD_PIPE) {
    80004488:	411c                	lw	a5,0(a0)
    8000448a:	4705                	li	a4,1
    8000448c:	04e78363          	beq	a5,a4,800044d2 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004490:	470d                	li	a4,3
    80004492:	04e78763          	beq	a5,a4,800044e0 <fileread+0x72>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004496:	4709                	li	a4,2
    80004498:	06e79a63          	bne	a5,a4,8000450c <fileread+0x9e>
    ilock(f->ip);
    8000449c:	6d08                	ld	a0,24(a0)
    8000449e:	fc9fe0ef          	jal	80003466 <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800044a2:	874e                	mv	a4,s3
    800044a4:	5094                	lw	a3,32(s1)
    800044a6:	864a                	mv	a2,s2
    800044a8:	4585                	li	a1,1
    800044aa:	6c88                	ld	a0,24(s1)
    800044ac:	b4cff0ef          	jal	800037f8 <readi>
    800044b0:	892a                	mv	s2,a0
    800044b2:	00a05563          	blez	a0,800044bc <fileread+0x4e>
      f->off += r;
    800044b6:	509c                	lw	a5,32(s1)
    800044b8:	9fa9                	addw	a5,a5,a0
    800044ba:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800044bc:	6c88                	ld	a0,24(s1)
    800044be:	856ff0ef          	jal	80003514 <iunlock>
    800044c2:	64e2                	ld	s1,24(sp)
    800044c4:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800044c6:	854a                	mv	a0,s2
    800044c8:	70a2                	ld	ra,40(sp)
    800044ca:	7402                	ld	s0,32(sp)
    800044cc:	6942                	ld	s2,16(sp)
    800044ce:	6145                	addi	sp,sp,48
    800044d0:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800044d2:	6908                	ld	a0,16(a0)
    800044d4:	3be000ef          	jal	80004892 <piperead>
    800044d8:	892a                	mv	s2,a0
    800044da:	64e2                	ld	s1,24(sp)
    800044dc:	69a2                	ld	s3,8(sp)
    800044de:	b7e5                	j	800044c6 <fileread+0x58>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800044e0:	02451783          	lh	a5,36(a0)
    800044e4:	03079693          	slli	a3,a5,0x30
    800044e8:	92c1                	srli	a3,a3,0x30
    800044ea:	4725                	li	a4,9
    800044ec:	02d76663          	bltu	a4,a3,80004518 <fileread+0xaa>
    800044f0:	0792                	slli	a5,a5,0x4
    800044f2:	0001c717          	auipc	a4,0x1c
    800044f6:	82e70713          	addi	a4,a4,-2002 # 8001fd20 <devsw>
    800044fa:	97ba                	add	a5,a5,a4
    800044fc:	639c                	ld	a5,0(a5)
    800044fe:	c395                	beqz	a5,80004522 <fileread+0xb4>
    r = devsw[f->major].read(1, addr, n);
    80004500:	4505                	li	a0,1
    80004502:	9782                	jalr	a5
    80004504:	892a                	mv	s2,a0
    80004506:	64e2                	ld	s1,24(sp)
    80004508:	69a2                	ld	s3,8(sp)
    8000450a:	bf75                	j	800044c6 <fileread+0x58>
    panic("fileread");
    8000450c:	00003517          	auipc	a0,0x3
    80004510:	16c50513          	addi	a0,a0,364 # 80007678 <etext+0x678>
    80004514:	b34fc0ef          	jal	80000848 <panic>
    80004518:	64e2                	ld	s1,24(sp)
    8000451a:	69a2                	ld	s3,8(sp)
    return -1;
    8000451c:	57fd                	li	a5,-1
    8000451e:	893e                	mv	s2,a5
    80004520:	b75d                	j	800044c6 <fileread+0x58>
    80004522:	64e2                	ld	s1,24(sp)
    80004524:	69a2                	ld	s3,8(sp)
    80004526:	bfdd                	j	8000451c <fileread+0xae>

0000000080004528 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0)
    80004528:	00954783          	lbu	a5,9(a0)
    8000452c:	12078463          	beqz	a5,80004654 <filewrite+0x12c>
{
    80004530:	711d                	addi	sp,sp,-96
    80004532:	ec86                	sd	ra,88(sp)
    80004534:	e8a2                	sd	s0,80(sp)
    80004536:	e0ca                	sd	s2,64(sp)
    80004538:	f456                	sd	s5,40(sp)
    8000453a:	f05a                	sd	s6,32(sp)
    8000453c:	1080                	addi	s0,sp,96
    8000453e:	892a                	mv	s2,a0
    80004540:	8b2e                	mv	s6,a1
    80004542:	8ab2                	mv	s5,a2
    return -1;

  if (f->type == FD_PIPE) {
    80004544:	411c                	lw	a5,0(a0)
    80004546:	4705                	li	a4,1
    80004548:	02e78a63          	beq	a5,a4,8000457c <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    8000454c:	470d                	li	a4,3
    8000454e:	02e78b63          	beq	a5,a4,80004584 <filewrite+0x5c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004552:	4709                	li	a4,2
    80004554:	0ce79f63          	bne	a5,a4,80004632 <filewrite+0x10a>
    80004558:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    8000455a:	0ac05a63          	blez	a2,8000460e <filewrite+0xe6>
    8000455e:	e4a6                	sd	s1,72(sp)
    80004560:	fc4e                	sd	s3,56(sp)
    80004562:	ec5e                	sd	s7,24(sp)
    80004564:	e862                	sd	s8,16(sp)
    80004566:	e466                	sd	s9,8(sp)
    int i = 0;
    80004568:	4a01                	li	s4,0
      int n1 = n - i;
      if (n1 > max)
    8000456a:	6b85                	lui	s7,0x1
    8000456c:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004570:	6785                	lui	a5,0x1
    80004572:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80004576:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004578:	4c05                	li	s8,1
    8000457a:	a8ad                	j	800045f4 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    8000457c:	6908                	ld	a0,16(a0)
    8000457e:	1f8000ef          	jal	80004776 <pipewrite>
    80004582:	a04d                	j	80004624 <filewrite+0xfc>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004584:	02451783          	lh	a5,36(a0)
    80004588:	03079693          	slli	a3,a5,0x30
    8000458c:	92c1                	srli	a3,a3,0x30
    8000458e:	4725                	li	a4,9
    80004590:	0ad76d63          	bltu	a4,a3,8000464a <filewrite+0x122>
    80004594:	0792                	slli	a5,a5,0x4
    80004596:	0001b717          	auipc	a4,0x1b
    8000459a:	78a70713          	addi	a4,a4,1930 # 8001fd20 <devsw>
    8000459e:	97ba                	add	a5,a5,a4
    800045a0:	679c                	ld	a5,8(a5)
    800045a2:	c7c5                	beqz	a5,8000464a <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    800045a4:	4505                	li	a0,1
    800045a6:	9782                	jalr	a5
    800045a8:	a8b5                	j	80004624 <filewrite+0xfc>
      if (n1 > max)
    800045aa:	2981                	sext.w	s3,s3
      begin_op();
    800045ac:	8e5ff0ef          	jal	80003e90 <begin_op>
      ilock(f->ip);
    800045b0:	01893503          	ld	a0,24(s2)
    800045b4:	eb3fe0ef          	jal	80003466 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800045b8:	874e                	mv	a4,s3
    800045ba:	02092683          	lw	a3,32(s2)
    800045be:	016a0633          	add	a2,s4,s6
    800045c2:	85e2                	mv	a1,s8
    800045c4:	01893503          	ld	a0,24(s2)
    800045c8:	b22ff0ef          	jal	800038ea <writei>
    800045cc:	84aa                	mv	s1,a0
    800045ce:	00a05763          	blez	a0,800045dc <filewrite+0xb4>
        f->off += r;
    800045d2:	02092783          	lw	a5,32(s2)
    800045d6:	9fa9                	addw	a5,a5,a0
    800045d8:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800045dc:	01893503          	ld	a0,24(s2)
    800045e0:	f35fe0ef          	jal	80003514 <iunlock>
      end_op();
    800045e4:	939ff0ef          	jal	80003f1c <end_op>

      if (r != n1) {
    800045e8:	02999563          	bne	s3,s1,80004612 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    800045ec:	01448a3b          	addw	s4,s1,s4
    while (i < n) {
    800045f0:	015a5963          	bge	s4,s5,80004602 <filewrite+0xda>
      int n1 = n - i;
    800045f4:	414a87bb          	subw	a5,s5,s4
    800045f8:	89be                	mv	s3,a5
      if (n1 > max)
    800045fa:	fafbd8e3          	bge	s7,a5,800045aa <filewrite+0x82>
    800045fe:	89e6                	mv	s3,s9
    80004600:	b76d                	j	800045aa <filewrite+0x82>
    80004602:	64a6                	ld	s1,72(sp)
    80004604:	79e2                	ld	s3,56(sp)
    80004606:	6be2                	ld	s7,24(sp)
    80004608:	6c42                	ld	s8,16(sp)
    8000460a:	6ca2                	ld	s9,8(sp)
    8000460c:	a801                	j	8000461c <filewrite+0xf4>
    int i = 0;
    8000460e:	4a01                	li	s4,0
    80004610:	a031                	j	8000461c <filewrite+0xf4>
    80004612:	64a6                	ld	s1,72(sp)
    80004614:	79e2                	ld	s3,56(sp)
    80004616:	6be2                	ld	s7,24(sp)
    80004618:	6c42                	ld	s8,16(sp)
    8000461a:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000461c:	034a9963          	bne	s5,s4,8000464e <filewrite+0x126>
    80004620:	8556                	mv	a0,s5
    80004622:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004624:	60e6                	ld	ra,88(sp)
    80004626:	6446                	ld	s0,80(sp)
    80004628:	6906                	ld	s2,64(sp)
    8000462a:	7aa2                	ld	s5,40(sp)
    8000462c:	7b02                	ld	s6,32(sp)
    8000462e:	6125                	addi	sp,sp,96
    80004630:	8082                	ret
    80004632:	e4a6                	sd	s1,72(sp)
    80004634:	fc4e                	sd	s3,56(sp)
    80004636:	f852                	sd	s4,48(sp)
    80004638:	ec5e                	sd	s7,24(sp)
    8000463a:	e862                	sd	s8,16(sp)
    8000463c:	e466                	sd	s9,8(sp)
    panic("filewrite");
    8000463e:	00003517          	auipc	a0,0x3
    80004642:	04a50513          	addi	a0,a0,74 # 80007688 <etext+0x688>
    80004646:	a02fc0ef          	jal	80000848 <panic>
    return -1;
    8000464a:	557d                	li	a0,-1
    8000464c:	bfe1                	j	80004624 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    8000464e:	557d                	li	a0,-1
    80004650:	7a42                	ld	s4,48(sp)
    80004652:	bfc9                	j	80004624 <filewrite+0xfc>
    return -1;
    80004654:	557d                	li	a0,-1
}
    80004656:	8082                	ret

0000000080004658 <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004658:	7179                	addi	sp,sp,-48
    8000465a:	f406                	sd	ra,40(sp)
    8000465c:	f022                	sd	s0,32(sp)
    8000465e:	ec26                	sd	s1,24(sp)
    80004660:	e052                	sd	s4,0(sp)
    80004662:	1800                	addi	s0,sp,48
    80004664:	84aa                	mv	s1,a0
    80004666:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004668:	0005b023          	sd	zero,0(a1)
    8000466c:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004670:	c33ff0ef          	jal	800042a2 <filealloc>
    80004674:	e088                	sd	a0,0(s1)
    80004676:	c549                	beqz	a0,80004700 <pipealloc+0xa8>
    80004678:	c2bff0ef          	jal	800042a2 <filealloc>
    8000467c:	00aa3023          	sd	a0,0(s4)
    80004680:	cd25                	beqz	a0,800046f8 <pipealloc+0xa0>
    80004682:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    80004684:	cbefc0ef          	jal	80000b42 <kalloc>
    80004688:	892a                	mv	s2,a0
    8000468a:	c12d                	beqz	a0,800046ec <pipealloc+0x94>
    8000468c:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    8000468e:	4985                	li	s3,1
    80004690:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004694:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004698:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000469c:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800046a0:	00003597          	auipc	a1,0x3
    800046a4:	ff858593          	addi	a1,a1,-8 # 80007698 <etext+0x698>
    800046a8:	d8afc0ef          	jal	80000c32 <initlock>
  (*f0)->type = FD_PIPE;
    800046ac:	609c                	ld	a5,0(s1)
    800046ae:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800046b2:	609c                	ld	a5,0(s1)
    800046b4:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800046b8:	609c                	ld	a5,0(s1)
    800046ba:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800046be:	609c                	ld	a5,0(s1)
    800046c0:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800046c4:	000a3783          	ld	a5,0(s4)
    800046c8:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800046cc:	000a3783          	ld	a5,0(s4)
    800046d0:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800046d4:	000a3783          	ld	a5,0(s4)
    800046d8:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800046dc:	000a3783          	ld	a5,0(s4)
    800046e0:	0127b823          	sd	s2,16(a5)
  return 0;
    800046e4:	4501                	li	a0,0
    800046e6:	6942                	ld	s2,16(sp)
    800046e8:	69a2                	ld	s3,8(sp)
    800046ea:	a00d                	j	8000470c <pipealloc+0xb4>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    800046ec:	6088                	ld	a0,0(s1)
    800046ee:	c119                	beqz	a0,800046f4 <pipealloc+0x9c>
    800046f0:	6942                	ld	s2,16(sp)
    800046f2:	a029                	j	800046fc <pipealloc+0xa4>
    800046f4:	6942                	ld	s2,16(sp)
    800046f6:	a029                	j	80004700 <pipealloc+0xa8>
    800046f8:	6088                	ld	a0,0(s1)
    800046fa:	c901                	beqz	a0,8000470a <pipealloc+0xb2>
    fileclose(*f0);
    800046fc:	c4bff0ef          	jal	80004346 <fileclose>
  if (*f1)
    80004700:	000a3503          	ld	a0,0(s4)
    80004704:	c119                	beqz	a0,8000470a <pipealloc+0xb2>
    fileclose(*f1);
    80004706:	c41ff0ef          	jal	80004346 <fileclose>
  return -1;
    8000470a:	557d                	li	a0,-1
}
    8000470c:	70a2                	ld	ra,40(sp)
    8000470e:	7402                	ld	s0,32(sp)
    80004710:	64e2                	ld	s1,24(sp)
    80004712:	6a02                	ld	s4,0(sp)
    80004714:	6145                	addi	sp,sp,48
    80004716:	8082                	ret

0000000080004718 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004718:	1101                	addi	sp,sp,-32
    8000471a:	ec06                	sd	ra,24(sp)
    8000471c:	e822                	sd	s0,16(sp)
    8000471e:	e426                	sd	s1,8(sp)
    80004720:	e04a                	sd	s2,0(sp)
    80004722:	1000                	addi	s0,sp,32
    80004724:	84aa                	mv	s1,a0
    80004726:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004728:	d8afc0ef          	jal	80000cb2 <acquire>
  if (writable) {
    8000472c:	02090763          	beqz	s2,8000475a <pipeclose+0x42>
    pi->writeopen = 0;
    80004730:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004734:	21848513          	addi	a0,s1,536
    80004738:	9fffd0ef          	jal	80002136 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    8000473c:	2204a783          	lw	a5,544(s1)
    80004740:	e781                	bnez	a5,80004748 <pipeclose+0x30>
    80004742:	2244a783          	lw	a5,548(s1)
    80004746:	c38d                	beqz	a5,80004768 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char *)pi);
  } else
    release(&pi->lock);
    80004748:	8526                	mv	a0,s1
    8000474a:	decfc0ef          	jal	80000d36 <release>
}
    8000474e:	60e2                	ld	ra,24(sp)
    80004750:	6442                	ld	s0,16(sp)
    80004752:	64a2                	ld	s1,8(sp)
    80004754:	6902                	ld	s2,0(sp)
    80004756:	6105                	addi	sp,sp,32
    80004758:	8082                	ret
    pi->readopen = 0;
    8000475a:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000475e:	21c48513          	addi	a0,s1,540
    80004762:	9d5fd0ef          	jal	80002136 <wakeup>
    80004766:	bfd9                	j	8000473c <pipeclose+0x24>
    release(&pi->lock);
    80004768:	8526                	mv	a0,s1
    8000476a:	dccfc0ef          	jal	80000d36 <release>
    kfree((char *)pi);
    8000476e:	8526                	mv	a0,s1
    80004770:	ac6fc0ef          	jal	80000a36 <kfree>
    80004774:	bfe9                	j	8000474e <pipeclose+0x36>

0000000080004776 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004776:	7159                	addi	sp,sp,-112
    80004778:	f486                	sd	ra,104(sp)
    8000477a:	f0a2                	sd	s0,96(sp)
    8000477c:	eca6                	sd	s1,88(sp)
    8000477e:	e8ca                	sd	s2,80(sp)
    80004780:	e4ce                	sd	s3,72(sp)
    80004782:	e0d2                	sd	s4,64(sp)
    80004784:	fc56                	sd	s5,56(sp)
    80004786:	1880                	addi	s0,sp,112
    80004788:	84aa                	mv	s1,a0
    8000478a:	8aae                	mv	s5,a1
    8000478c:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000478e:	af6fd0ef          	jal	80001a84 <myproc>
    80004792:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004794:	8526                	mv	a0,s1
    80004796:	d1cfc0ef          	jal	80000cb2 <acquire>
  while (i < n) {
    8000479a:	0f405a63          	blez	s4,8000488e <pipewrite+0x118>
    8000479e:	f85a                	sd	s6,48(sp)
    800047a0:	f45e                	sd	s7,40(sp)
    800047a2:	f062                	sd	s8,32(sp)
    800047a4:	ec66                	sd	s9,24(sp)
    800047a6:	e86a                	sd	s10,16(sp)
  int i = 0;
    800047a8:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    800047aa:	f9f40c13          	addi	s8,s0,-97
    800047ae:	4b85                	li	s7,1
    800047b0:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800047b2:	21848d13          	addi	s10,s1,536
      sleep_prepare(&pi->nwrite);
    800047b6:	21c48c93          	addi	s9,s1,540
    800047ba:	a0a1                	j	80004802 <pipewrite+0x8c>
      release(&pi->lock);
    800047bc:	8526                	mv	a0,s1
    800047be:	d78fc0ef          	jal	80000d36 <release>
      return -1;
    800047c2:	597d                	li	s2,-1
    800047c4:	7b42                	ld	s6,48(sp)
    800047c6:	7ba2                	ld	s7,40(sp)
    800047c8:	7c02                	ld	s8,32(sp)
    800047ca:	6ce2                	ld	s9,24(sp)
    800047cc:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800047ce:	854a                	mv	a0,s2
    800047d0:	70a6                	ld	ra,104(sp)
    800047d2:	7406                	ld	s0,96(sp)
    800047d4:	64e6                	ld	s1,88(sp)
    800047d6:	6946                	ld	s2,80(sp)
    800047d8:	69a6                	ld	s3,72(sp)
    800047da:	6a06                	ld	s4,64(sp)
    800047dc:	7ae2                	ld	s5,56(sp)
    800047de:	6165                	addi	sp,sp,112
    800047e0:	8082                	ret
      wakeup(&pi->nread);
    800047e2:	856a                	mv	a0,s10
    800047e4:	953fd0ef          	jal	80002136 <wakeup>
      sleep_prepare(&pi->nwrite);
    800047e8:	8566                	mv	a0,s9
    800047ea:	8e1fd0ef          	jal	800020ca <sleep_prepare>
      release(&pi->lock);
    800047ee:	8526                	mv	a0,s1
    800047f0:	d46fc0ef          	jal	80000d36 <release>
      sleep();
    800047f4:	913fd0ef          	jal	80002106 <sleep>
      acquire(&pi->lock);
    800047f8:	8526                	mv	a0,s1
    800047fa:	cb8fc0ef          	jal	80000cb2 <acquire>
  while (i < n) {
    800047fe:	07495b63          	bge	s2,s4,80004874 <pipewrite+0xfe>
    if (pi->readopen == 0 || killed(pr)) {
    80004802:	2204a783          	lw	a5,544(s1)
    80004806:	dbdd                	beqz	a5,800047bc <pipewrite+0x46>
    80004808:	854e                	mv	a0,s3
    8000480a:	b19fd0ef          	jal	80002322 <killed>
    8000480e:	f55d                	bnez	a0,800047bc <pipewrite+0x46>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    80004810:	2184a783          	lw	a5,536(s1)
    80004814:	21c4a703          	lw	a4,540(s1)
    80004818:	2007879b          	addiw	a5,a5,512
    8000481c:	fcf703e3          	beq	a4,a5,800047e2 <pipewrite+0x6c>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004820:	875e                	mv	a4,s7
    80004822:	015906b3          	add	a3,s2,s5
    80004826:	8662                	mv	a2,s8
    80004828:	0489b583          	ld	a1,72(s3)
    8000482c:	0509b503          	ld	a0,80(s3)
    80004830:	e77fc0ef          	jal	800016a6 <copyin>
    80004834:	03650163          	beq	a0,s6,80004856 <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004838:	21c4a783          	lw	a5,540(s1)
    8000483c:	0017871b          	addiw	a4,a5,1
    80004840:	20e4ae23          	sw	a4,540(s1)
    80004844:	1ff7f793          	andi	a5,a5,511
    80004848:	97a6                	add	a5,a5,s1
    8000484a:	f9f44703          	lbu	a4,-97(s0)
    8000484e:	00e78c23          	sb	a4,24(a5)
      i++;
    80004852:	2905                	addiw	s2,s2,1
    80004854:	b76d                	j	800047fe <pipewrite+0x88>
        if (i == 0)
    80004856:	00090863          	beqz	s2,80004866 <pipewrite+0xf0>
    8000485a:	7b42                	ld	s6,48(sp)
    8000485c:	7ba2                	ld	s7,40(sp)
    8000485e:	7c02                	ld	s8,32(sp)
    80004860:	6ce2                	ld	s9,24(sp)
    80004862:	6d42                	ld	s10,16(sp)
    80004864:	a829                	j	8000487e <pipewrite+0x108>
          i = -1;
    80004866:	892a                	mv	s2,a0
        break;
    80004868:	7b42                	ld	s6,48(sp)
    8000486a:	7ba2                	ld	s7,40(sp)
    8000486c:	7c02                	ld	s8,32(sp)
    8000486e:	6ce2                	ld	s9,24(sp)
    80004870:	6d42                	ld	s10,16(sp)
    80004872:	a031                	j	8000487e <pipewrite+0x108>
    80004874:	7b42                	ld	s6,48(sp)
    80004876:	7ba2                	ld	s7,40(sp)
    80004878:	7c02                	ld	s8,32(sp)
    8000487a:	6ce2                	ld	s9,24(sp)
    8000487c:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    8000487e:	21848513          	addi	a0,s1,536
    80004882:	8b5fd0ef          	jal	80002136 <wakeup>
  release(&pi->lock);
    80004886:	8526                	mv	a0,s1
    80004888:	caefc0ef          	jal	80000d36 <release>
  return i;
    8000488c:	b789                	j	800047ce <pipewrite+0x58>
  int i = 0;
    8000488e:	4901                	li	s2,0
    80004890:	b7fd                	j	8000487e <pipewrite+0x108>

0000000080004892 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004892:	711d                	addi	sp,sp,-96
    80004894:	ec86                	sd	ra,88(sp)
    80004896:	e8a2                	sd	s0,80(sp)
    80004898:	e4a6                	sd	s1,72(sp)
    8000489a:	e0ca                	sd	s2,64(sp)
    8000489c:	fc4e                	sd	s3,56(sp)
    8000489e:	f852                	sd	s4,48(sp)
    800048a0:	f456                	sd	s5,40(sp)
    800048a2:	1080                	addi	s0,sp,96
    800048a4:	84aa                	mv	s1,a0
    800048a6:	89ae                	mv	s3,a1
    800048a8:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800048aa:	9dafd0ef          	jal	80001a84 <myproc>
    800048ae:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    800048b0:	8526                	mv	a0,s1
    800048b2:	c00fc0ef          	jal	80000cb2 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800048b6:	2184a703          	lw	a4,536(s1)
    800048ba:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800048be:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800048c2:	02f71a63          	bne	a4,a5,800048f6 <piperead+0x64>
    800048c6:	2244a783          	lw	a5,548(s1)
    800048ca:	c795                	beqz	a5,800048f6 <piperead+0x64>
    if (killed(pr)) {
    800048cc:	854a                	mv	a0,s2
    800048ce:	a55fd0ef          	jal	80002322 <killed>
    800048d2:	e149                	bnez	a0,80004954 <piperead+0xc2>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800048d4:	8552                	mv	a0,s4
    800048d6:	ff4fd0ef          	jal	800020ca <sleep_prepare>
    release(&pi->lock);
    800048da:	8526                	mv	a0,s1
    800048dc:	c5afc0ef          	jal	80000d36 <release>
    sleep();
    800048e0:	827fd0ef          	jal	80002106 <sleep>
    acquire(&pi->lock);
    800048e4:	8526                	mv	a0,s1
    800048e6:	bccfc0ef          	jal	80000cb2 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800048ea:	2184a703          	lw	a4,536(s1)
    800048ee:	21c4a783          	lw	a5,540(s1)
    800048f2:	fcf70ae3          	beq	a4,a5,800048c6 <piperead+0x34>
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800048f6:	07505a63          	blez	s5,8000496a <piperead+0xd8>
    800048fa:	f05a                	sd	s6,32(sp)
    800048fc:	ec5e                	sd	s7,24(sp)
    800048fe:	e862                	sd	s8,16(sp)
    80004900:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004902:	faf40c13          	addi	s8,s0,-81
    80004906:	4b85                	li	s7,1
    80004908:	5b7d                	li	s6,-1
    if (pi->nread == pi->nwrite)
    8000490a:	2184a783          	lw	a5,536(s1)
    8000490e:	21c4a703          	lw	a4,540(s1)
    80004912:	06f70363          	beq	a4,a5,80004978 <piperead+0xe6>
    ch = pi->data[pi->nread % PIPESIZE];
    80004916:	1ff7f793          	andi	a5,a5,511
    8000491a:	97a6                	add	a5,a5,s1
    8000491c:	0187c783          	lbu	a5,24(a5)
    80004920:	faf407a3          	sb	a5,-81(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004924:	875e                	mv	a4,s7
    80004926:	86e2                	mv	a3,s8
    80004928:	864e                	mv	a2,s3
    8000492a:	04893583          	ld	a1,72(s2)
    8000492e:	05093503          	ld	a0,80(s2)
    80004932:	cb5fc0ef          	jal	800015e6 <copyout>
    80004936:	03650463          	beq	a0,s6,8000495e <piperead+0xcc>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    8000493a:	2184a783          	lw	a5,536(s1)
    8000493e:	2785                	addiw	a5,a5,1
    80004940:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004944:	2a05                	addiw	s4,s4,1
    80004946:	0985                	addi	s3,s3,1
    80004948:	fd4a91e3          	bne	s5,s4,8000490a <piperead+0x78>
    8000494c:	7b02                	ld	s6,32(sp)
    8000494e:	6be2                	ld	s7,24(sp)
    80004950:	6c42                	ld	s8,16(sp)
    80004952:	a035                	j	8000497e <piperead+0xec>
      release(&pi->lock);
    80004954:	8526                	mv	a0,s1
    80004956:	be0fc0ef          	jal	80000d36 <release>
      return -1;
    8000495a:	5a7d                	li	s4,-1
    8000495c:	a805                	j	8000498c <piperead+0xfa>
      if (i == 0)
    8000495e:	000a0863          	beqz	s4,8000496e <piperead+0xdc>
    80004962:	7b02                	ld	s6,32(sp)
    80004964:	6be2                	ld	s7,24(sp)
    80004966:	6c42                	ld	s8,16(sp)
    80004968:	a819                	j	8000497e <piperead+0xec>
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    8000496a:	4a01                	li	s4,0
    8000496c:	a809                	j	8000497e <piperead+0xec>
        i = -1;
    8000496e:	8a2a                	mv	s4,a0
    80004970:	7b02                	ld	s6,32(sp)
    80004972:	6be2                	ld	s7,24(sp)
    80004974:	6c42                	ld	s8,16(sp)
    80004976:	a021                	j	8000497e <piperead+0xec>
    80004978:	7b02                	ld	s6,32(sp)
    8000497a:	6be2                	ld	s7,24(sp)
    8000497c:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    8000497e:	21c48513          	addi	a0,s1,540
    80004982:	fb4fd0ef          	jal	80002136 <wakeup>
  release(&pi->lock);
    80004986:	8526                	mv	a0,s1
    80004988:	baefc0ef          	jal	80000d36 <release>
  return i;
}
    8000498c:	8552                	mv	a0,s4
    8000498e:	60e6                	ld	ra,88(sp)
    80004990:	6446                	ld	s0,80(sp)
    80004992:	64a6                	ld	s1,72(sp)
    80004994:	6906                	ld	s2,64(sp)
    80004996:	79e2                	ld	s3,56(sp)
    80004998:	7a42                	ld	s4,48(sp)
    8000499a:	7aa2                	ld	s5,40(sp)
    8000499c:	6125                	addi	sp,sp,96
    8000499e:	8082                	ret

00000000800049a0 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    800049a0:	1141                	addi	sp,sp,-16
    800049a2:	e406                	sd	ra,8(sp)
    800049a4:	e022                	sd	s0,0(sp)
    800049a6:	0800                	addi	s0,sp,16
    800049a8:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    800049aa:	0035151b          	slliw	a0,a0,0x3
    800049ae:	8921                	andi	a0,a0,8
    perm = PTE_X;
  if (flags & 0x2)
    800049b0:	8b89                	andi	a5,a5,2
    800049b2:	c399                	beqz	a5,800049b8 <flags2perm+0x18>
    perm |= PTE_W;
    800049b4:	00456513          	ori	a0,a0,4
  return perm;
}
    800049b8:	60a2                	ld	ra,8(sp)
    800049ba:	6402                	ld	s0,0(sp)
    800049bc:	0141                	addi	sp,sp,16
    800049be:	8082                	ret

00000000800049c0 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800049c0:	df010113          	addi	sp,sp,-528
    800049c4:	20113423          	sd	ra,520(sp)
    800049c8:	20813023          	sd	s0,512(sp)
    800049cc:	ffa6                	sd	s1,504(sp)
    800049ce:	fbca                	sd	s2,496(sp)
    800049d0:	0c00                	addi	s0,sp,528
    800049d2:	892a                	mv	s2,a0
    800049d4:	e0a43023          	sd	a0,-512(s0)
    800049d8:	deb43c23          	sd	a1,-520(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800049dc:	8a8fd0ef          	jal	80001a84 <myproc>
    800049e0:	84aa                	mv	s1,a0

  begin_op();
    800049e2:	caeff0ef          	jal	80003e90 <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    800049e6:	854a                	mv	a0,s2
    800049e8:	acaff0ef          	jal	80003cb2 <namei>
    800049ec:	c931                	beqz	a0,80004a40 <kexec+0x80>
    800049ee:	f3d2                	sd	s4,480(sp)
    800049f0:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800049f2:	a75fe0ef          	jal	80003466 <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800049f6:	04000713          	li	a4,64
    800049fa:	4681                	li	a3,0
    800049fc:	e5040613          	addi	a2,s0,-432
    80004a00:	4581                	li	a1,0
    80004a02:	8552                	mv	a0,s4
    80004a04:	df5fe0ef          	jal	800037f8 <readi>
    80004a08:	04000793          	li	a5,64
    80004a0c:	00f51a63          	bne	a0,a5,80004a20 <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    80004a10:	e5042703          	lw	a4,-432(s0)
    80004a14:	464c47b7          	lui	a5,0x464c4
    80004a18:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004a1c:	02f70563          	beq	a4,a5,80004a46 <kexec+0x86>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    80004a20:	8552                	mv	a0,s4
    80004a22:	c51fe0ef          	jal	80003672 <iunlockput>
    end_op();
    80004a26:	cf6ff0ef          	jal	80003f1c <end_op>
    80004a2a:	7a1e                	ld	s4,480(sp)
    return -1;
    80004a2c:	557d                	li	a0,-1
  }
  return -1;
}
    80004a2e:	20813083          	ld	ra,520(sp)
    80004a32:	20013403          	ld	s0,512(sp)
    80004a36:	74fe                	ld	s1,504(sp)
    80004a38:	795e                	ld	s2,496(sp)
    80004a3a:	21010113          	addi	sp,sp,528
    80004a3e:	8082                	ret
    end_op();
    80004a40:	cdcff0ef          	jal	80003f1c <end_op>
    return -1;
    80004a44:	b7e5                	j	80004a2c <kexec+0x6c>
    80004a46:	ebda                	sd	s6,464(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    80004a48:	8526                	mv	a0,s1
    80004a4a:	950fd0ef          	jal	80001b9a <proc_pagetable>
    80004a4e:	8b2a                	mv	s6,a0
    80004a50:	26050263          	beqz	a0,80004cb4 <kexec+0x2f4>
    80004a54:	f7ce                	sd	s3,488(sp)
    80004a56:	efd6                	sd	s5,472(sp)
    80004a58:	e7de                	sd	s7,456(sp)
    80004a5a:	e3e2                	sd	s8,448(sp)
    80004a5c:	ff66                	sd	s9,440(sp)
    80004a5e:	fb6a                	sd	s10,432(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004a60:	e8845783          	lhu	a5,-376(s0)
    80004a64:	12078763          	beqz	a5,80004b92 <kexec+0x1d2>
    80004a68:	f76e                	sd	s11,424(sp)
    80004a6a:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004a6e:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004a70:	4d01                	li	s10,0
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004a72:	03800d93          	li	s11,56

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    80004a76:	6c85                	lui	s9,0x1
    80004a78:	6a85                	lui	s5,0x1
    80004a7a:	a085                	j	80004ada <kexec+0x11a>
      panic("loadseg: address should exist");
    80004a7c:	00003517          	auipc	a0,0x3
    80004a80:	c2450513          	addi	a0,a0,-988 # 800076a0 <etext+0x6a0>
    80004a84:	dc5fb0ef          	jal	80000848 <panic>
    if (sz - i < PGSIZE)
    80004a88:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80004a8a:	874a                	mv	a4,s2
    80004a8c:	009b86bb          	addw	a3,s7,s1
    80004a90:	4581                	li	a1,0
    80004a92:	8552                	mv	a0,s4
    80004a94:	d65fe0ef          	jal	800037f8 <readi>
    80004a98:	22a91263          	bne	s2,a0,80004cbc <kexec+0x2fc>
  for (i = 0; i < sz; i += PGSIZE) {
    80004a9c:	009a84bb          	addw	s1,s5,s1
    80004aa0:	0334f263          	bgeu	s1,s3,80004ac4 <kexec+0x104>
    pa = walkaddr(pagetable, va + i);
    80004aa4:	02049593          	slli	a1,s1,0x20
    80004aa8:	9181                	srli	a1,a1,0x20
    80004aaa:	95e2                	add	a1,a1,s8
    80004aac:	855a                	mv	a0,s6
    80004aae:	de4fc0ef          	jal	80001092 <walkaddr>
    80004ab2:	862a                	mv	a2,a0
    if (pa == 0)
    80004ab4:	d561                	beqz	a0,80004a7c <kexec+0xbc>
    if (sz - i < PGSIZE)
    80004ab6:	409987bb          	subw	a5,s3,s1
    80004aba:	893e                	mv	s2,a5
    80004abc:	fcfcf6e3          	bgeu	s9,a5,80004a88 <kexec+0xc8>
    80004ac0:	8956                	mv	s2,s5
    80004ac2:	b7d9                	j	80004a88 <kexec+0xc8>
    sz = sz1;
    80004ac4:	df043903          	ld	s2,-528(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004ac8:	2d05                	addiw	s10,s10,1
    80004aca:	e0843783          	ld	a5,-504(s0)
    80004ace:	0387869b          	addiw	a3,a5,56
    80004ad2:	e8845783          	lhu	a5,-376(s0)
    80004ad6:	06fd5863          	bge	s10,a5,80004b46 <kexec+0x186>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004ada:	e0d43423          	sd	a3,-504(s0)
    80004ade:	876e                	mv	a4,s11
    80004ae0:	e1840613          	addi	a2,s0,-488
    80004ae4:	4581                	li	a1,0
    80004ae6:	8552                	mv	a0,s4
    80004ae8:	d11fe0ef          	jal	800037f8 <readi>
    80004aec:	1db51663          	bne	a0,s11,80004cb8 <kexec+0x2f8>
    if (ph.type != ELF_PROG_LOAD)
    80004af0:	e1842783          	lw	a5,-488(s0)
    80004af4:	4705                	li	a4,1
    80004af6:	fce799e3          	bne	a5,a4,80004ac8 <kexec+0x108>
    if (ph.memsz < ph.filesz)
    80004afa:	e4043483          	ld	s1,-448(s0)
    80004afe:	e3843783          	ld	a5,-456(s0)
    80004b02:	1af4eb63          	bltu	s1,a5,80004cb8 <kexec+0x2f8>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80004b06:	e2843783          	ld	a5,-472(s0)
    80004b0a:	94be                	add	s1,s1,a5
    80004b0c:	1af4e663          	bltu	s1,a5,80004cb8 <kexec+0x2f8>
    if (ph.vaddr % PGSIZE != 0)
    80004b10:	17d2                	slli	a5,a5,0x34
    80004b12:	1a079363          	bnez	a5,80004cb8 <kexec+0x2f8>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80004b16:	e1c42503          	lw	a0,-484(s0)
    80004b1a:	e87ff0ef          	jal	800049a0 <flags2perm>
    80004b1e:	86aa                	mv	a3,a0
    80004b20:	8626                	mv	a2,s1
    80004b22:	85ca                	mv	a1,s2
    80004b24:	855a                	mv	a0,s6
    80004b26:	83bfc0ef          	jal	80001360 <uvmalloc>
    80004b2a:	dea43823          	sd	a0,-528(s0)
    80004b2e:	18050563          	beqz	a0,80004cb8 <kexec+0x2f8>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004b32:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004b36:	f80987e3          	beqz	s3,80004ac4 <kexec+0x104>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004b3a:	e2843c03          	ld	s8,-472(s0)
    80004b3e:	e2042b83          	lw	s7,-480(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004b42:	4481                	li	s1,0
    80004b44:	b785                	j	80004aa4 <kexec+0xe4>
    80004b46:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004b48:	8552                	mv	a0,s4
    80004b4a:	b29fe0ef          	jal	80003672 <iunlockput>
  end_op();
    80004b4e:	bceff0ef          	jal	80003f1c <end_op>
  p = myproc();
    80004b52:	f33fc0ef          	jal	80001a84 <myproc>
    80004b56:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004b58:	04853a03          	ld	s4,72(a0)
  sz = PGROUNDUP(sz);
    80004b5c:	6485                	lui	s1,0x1
    80004b5e:	14fd                	addi	s1,s1,-1 # fff <_entry-0x7ffff001>
    80004b60:	94ca                	add	s1,s1,s2
    80004b62:	77fd                	lui	a5,0xfffff
    80004b64:	8cfd                	and	s1,s1,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004b66:	4691                	li	a3,4
    80004b68:	6609                	lui	a2,0x2
    80004b6a:	9626                	add	a2,a2,s1
    80004b6c:	85a6                	mv	a1,s1
    80004b6e:	855a                	mv	a0,s6
    80004b70:	ff0fc0ef          	jal	80001360 <uvmalloc>
    80004b74:	8aaa                	mv	s5,a0
    80004b76:	e105                	bnez	a0,80004b96 <kexec+0x1d6>
    proc_freepagetable(pagetable, sz);
    80004b78:	85a6                	mv	a1,s1
    80004b7a:	855a                	mv	a0,s6
    80004b7c:	8a0fd0ef          	jal	80001c1c <proc_freepagetable>
  if (ip) {
    80004b80:	79be                	ld	s3,488(sp)
    80004b82:	7a1e                	ld	s4,480(sp)
    80004b84:	6afe                	ld	s5,472(sp)
    80004b86:	6b5e                	ld	s6,464(sp)
    80004b88:	6bbe                	ld	s7,456(sp)
    80004b8a:	6c1e                	ld	s8,448(sp)
    80004b8c:	7cfa                	ld	s9,440(sp)
    80004b8e:	7d5a                	ld	s10,432(sp)
    80004b90:	bd71                	j	80004a2c <kexec+0x6c>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004b92:	4901                	li	s2,0
    80004b94:	bf55                	j	80004b48 <kexec+0x188>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004b96:	75f9                	lui	a1,0xffffe
    80004b98:	95aa                	add	a1,a1,a0
    80004b9a:	855a                	mv	a0,s6
    80004b9c:	98dfc0ef          	jal	80001528 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004ba0:	7bfd                	lui	s7,0xfffff
    80004ba2:	9bd6                	add	s7,s7,s5
  for (argc = 0; argv[argc]; argc++) {
    80004ba4:	df843783          	ld	a5,-520(s0)
    80004ba8:	6388                	ld	a0,0(a5)
    80004baa:	cd3d                	beqz	a0,80004c28 <kexec+0x268>
  sp = sz;
    80004bac:	8c56                	mv	s8,s5
  for (argc = 0; argv[argc]; argc++) {
    80004bae:	4481                	li	s1,0
    ustack[argc] = sp;
    80004bb0:	e9040913          	addi	s2,s0,-368
    sp -= strlen(argv[argc]) + 1;
    80004bb4:	b3afc0ef          	jal	80000eee <strlen>
    80004bb8:	0015079b          	addiw	a5,a0,1
    80004bbc:	40fc07b3          	sub	a5,s8,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004bc0:	ff07fc13          	andi	s8,a5,-16
    if (sp < stackbase)
    80004bc4:	077c6063          	bltu	s8,s7,80004c24 <kexec+0x264>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004bc8:	df843d03          	ld	s10,-520(s0)
    80004bcc:	000d3c83          	ld	s9,0(s10)
    80004bd0:	8566                	mv	a0,s9
    80004bd2:	b1cfc0ef          	jal	80000eee <strlen>
    80004bd6:	0015071b          	addiw	a4,a0,1
    80004bda:	86e6                	mv	a3,s9
    80004bdc:	8662                	mv	a2,s8
    80004bde:	85d6                	mv	a1,s5
    80004be0:	855a                	mv	a0,s6
    80004be2:	a05fc0ef          	jal	800015e6 <copyout>
    80004be6:	02054f63          	bltz	a0,80004c24 <kexec+0x264>
    ustack[argc] = sp;
    80004bea:	00349793          	slli	a5,s1,0x3
    80004bee:	97ca                	add	a5,a5,s2
    80004bf0:	0187b023          	sd	s8,0(a5) # fffffffffffff000 <end+0xffffffff7ffde148>
  for (argc = 0; argv[argc]; argc++) {
    80004bf4:	0485                	addi	s1,s1,1
    80004bf6:	008d0793          	addi	a5,s10,8
    80004bfa:	def43c23          	sd	a5,-520(s0)
    80004bfe:	008d3503          	ld	a0,8(s10)
    80004c02:	f94d                	bnez	a0,80004bb4 <kexec+0x1f4>
  ustack[argc] = 0;
    80004c04:	00349793          	slli	a5,s1,0x3
    80004c08:	f9040713          	addi	a4,s0,-112
    80004c0c:	97ba                	add	a5,a5,a4
    80004c0e:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004c12:	00148713          	addi	a4,s1,1
    80004c16:	070e                	slli	a4,a4,0x3
    80004c18:	40ec0933          	sub	s2,s8,a4
  sp -= sp % 16;
    80004c1c:	ff097913          	andi	s2,s2,-16
  if (sp < stackbase)
    80004c20:	01797763          	bgeu	s2,s7,80004c2e <kexec+0x26e>
  sz = sz1;
    80004c24:	84d6                	mv	s1,s5
    80004c26:	bf89                	j	80004b78 <kexec+0x1b8>
  sp = sz;
    80004c28:	8c56                	mv	s8,s5
  for (argc = 0; argv[argc]; argc++) {
    80004c2a:	4481                	li	s1,0
    80004c2c:	bfe1                	j	80004c04 <kexec+0x244>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004c2e:	e9040693          	addi	a3,s0,-368
    80004c32:	864a                	mv	a2,s2
    80004c34:	85d6                	mv	a1,s5
    80004c36:	855a                	mv	a0,s6
    80004c38:	9affc0ef          	jal	800015e6 <copyout>
    80004c3c:	fe0544e3          	bltz	a0,80004c24 <kexec+0x264>
  p->trapframe->a1 = sp;
    80004c40:	0589b783          	ld	a5,88(s3)
    80004c44:	0727bc23          	sd	s2,120(a5)
  for (last = s = path; *s; s++)
    80004c48:	e0043783          	ld	a5,-512(s0)
    80004c4c:	0007c703          	lbu	a4,0(a5)
    80004c50:	cf11                	beqz	a4,80004c6c <kexec+0x2ac>
    80004c52:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004c54:	02f00693          	li	a3,47
    80004c58:	a029                	j	80004c62 <kexec+0x2a2>
  for (last = s = path; *s; s++)
    80004c5a:	0785                	addi	a5,a5,1
    80004c5c:	fff7c703          	lbu	a4,-1(a5)
    80004c60:	c711                	beqz	a4,80004c6c <kexec+0x2ac>
    if (*s == '/')
    80004c62:	fed71ce3          	bne	a4,a3,80004c5a <kexec+0x29a>
      last = s + 1;
    80004c66:	e0f43023          	sd	a5,-512(s0)
    80004c6a:	bfc5                	j	80004c5a <kexec+0x29a>
  safestrcpy(p->name, last, sizeof(p->name));
    80004c6c:	4641                	li	a2,16
    80004c6e:	e0043583          	ld	a1,-512(s0)
    80004c72:	15898513          	addi	a0,s3,344
    80004c76:	a42fc0ef          	jal	80000eb8 <safestrcpy>
  oldpagetable = p->pagetable;
    80004c7a:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004c7e:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004c82:	0559b423          	sd	s5,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004c86:	0589b783          	ld	a5,88(s3)
    80004c8a:	e6843703          	ld	a4,-408(s0)
    80004c8e:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004c90:	0589b783          	ld	a5,88(s3)
    80004c94:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004c98:	85d2                	mv	a1,s4
    80004c9a:	f83fc0ef          	jal	80001c1c <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004c9e:	0004851b          	sext.w	a0,s1
    80004ca2:	79be                	ld	s3,488(sp)
    80004ca4:	7a1e                	ld	s4,480(sp)
    80004ca6:	6afe                	ld	s5,472(sp)
    80004ca8:	6b5e                	ld	s6,464(sp)
    80004caa:	6bbe                	ld	s7,456(sp)
    80004cac:	6c1e                	ld	s8,448(sp)
    80004cae:	7cfa                	ld	s9,440(sp)
    80004cb0:	7d5a                	ld	s10,432(sp)
    80004cb2:	bbb5                	j	80004a2e <kexec+0x6e>
    80004cb4:	6b5e                	ld	s6,464(sp)
    80004cb6:	b3ad                	j	80004a20 <kexec+0x60>
    return -1;
    80004cb8:	df243823          	sd	s2,-528(s0)
    proc_freepagetable(pagetable, sz);
    80004cbc:	df043583          	ld	a1,-528(s0)
    80004cc0:	855a                	mv	a0,s6
    80004cc2:	f5bfc0ef          	jal	80001c1c <proc_freepagetable>
  if (ip) {
    80004cc6:	79be                	ld	s3,488(sp)
    80004cc8:	6afe                	ld	s5,472(sp)
    80004cca:	6b5e                	ld	s6,464(sp)
    80004ccc:	6bbe                	ld	s7,456(sp)
    80004cce:	6c1e                	ld	s8,448(sp)
    80004cd0:	7cfa                	ld	s9,440(sp)
    80004cd2:	7d5a                	ld	s10,432(sp)
    80004cd4:	7dba                	ld	s11,424(sp)
    80004cd6:	b3a9                	j	80004a20 <kexec+0x60>

0000000080004cd8 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004cd8:	7179                	addi	sp,sp,-48
    80004cda:	f406                	sd	ra,40(sp)
    80004cdc:	f022                	sd	s0,32(sp)
    80004cde:	ec26                	sd	s1,24(sp)
    80004ce0:	e84a                	sd	s2,16(sp)
    80004ce2:	1800                	addi	s0,sp,48
    80004ce4:	892e                	mv	s2,a1
    80004ce6:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004ce8:	fdc40593          	addi	a1,s0,-36
    80004cec:	d05fd0ef          	jal	800029f0 <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004cf0:	fdc42703          	lw	a4,-36(s0)
    80004cf4:	47bd                	li	a5,15
    80004cf6:	02e7e963          	bltu	a5,a4,80004d28 <argfd+0x50>
    80004cfa:	d8bfc0ef          	jal	80001a84 <myproc>
    80004cfe:	fdc42703          	lw	a4,-36(s0)
    80004d02:	01a70793          	addi	a5,a4,26
    80004d06:	078e                	slli	a5,a5,0x3
    80004d08:	953e                	add	a0,a0,a5
    80004d0a:	611c                	ld	a5,0(a0)
    80004d0c:	cf91                	beqz	a5,80004d28 <argfd+0x50>
    return -1;
  if (pfd)
    80004d0e:	00090463          	beqz	s2,80004d16 <argfd+0x3e>
    *pfd = fd;
    80004d12:	00e92023          	sw	a4,0(s2)
  if (pf)
    80004d16:	c091                	beqz	s1,80004d1a <argfd+0x42>
    *pf = f;
    80004d18:	e09c                	sd	a5,0(s1)
  return 0;
    80004d1a:	4501                	li	a0,0
}
    80004d1c:	70a2                	ld	ra,40(sp)
    80004d1e:	7402                	ld	s0,32(sp)
    80004d20:	64e2                	ld	s1,24(sp)
    80004d22:	6942                	ld	s2,16(sp)
    80004d24:	6145                	addi	sp,sp,48
    80004d26:	8082                	ret
    return -1;
    80004d28:	557d                	li	a0,-1
    80004d2a:	bfcd                	j	80004d1c <argfd+0x44>

0000000080004d2c <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004d2c:	1101                	addi	sp,sp,-32
    80004d2e:	ec06                	sd	ra,24(sp)
    80004d30:	e822                	sd	s0,16(sp)
    80004d32:	e426                	sd	s1,8(sp)
    80004d34:	1000                	addi	s0,sp,32
    80004d36:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004d38:	d4dfc0ef          	jal	80001a84 <myproc>
    80004d3c:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004d3e:	0d050793          	addi	a5,a0,208
    80004d42:	4501                	li	a0,0
    80004d44:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004d46:	6398                	ld	a4,0(a5)
    80004d48:	cb19                	beqz	a4,80004d5e <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004d4a:	2505                	addiw	a0,a0,1
    80004d4c:	07a1                	addi	a5,a5,8
    80004d4e:	fed51ce3          	bne	a0,a3,80004d46 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004d52:	557d                	li	a0,-1
}
    80004d54:	60e2                	ld	ra,24(sp)
    80004d56:	6442                	ld	s0,16(sp)
    80004d58:	64a2                	ld	s1,8(sp)
    80004d5a:	6105                	addi	sp,sp,32
    80004d5c:	8082                	ret
      p->ofile[fd] = f;
    80004d5e:	01a50793          	addi	a5,a0,26
    80004d62:	078e                	slli	a5,a5,0x3
    80004d64:	963e                	add	a2,a2,a5
    80004d66:	e204                	sd	s1,0(a2)
      return fd;
    80004d68:	b7f5                	j	80004d54 <fdalloc+0x28>

0000000080004d6a <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004d6a:	715d                	addi	sp,sp,-80
    80004d6c:	e486                	sd	ra,72(sp)
    80004d6e:	e0a2                	sd	s0,64(sp)
    80004d70:	fc26                	sd	s1,56(sp)
    80004d72:	f44e                	sd	s3,40(sp)
    80004d74:	ec56                	sd	s5,24(sp)
    80004d76:	e85a                	sd	s6,16(sp)
    80004d78:	0880                	addi	s0,sp,80
    80004d7a:	89ae                	mv	s3,a1
    80004d7c:	8ab2                	mv	s5,a2
    80004d7e:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004d80:	fb040593          	addi	a1,s0,-80
    80004d84:	f49fe0ef          	jal	80003ccc <nameiparent>
    80004d88:	84aa                	mv	s1,a0
    80004d8a:	c125                	beqz	a0,80004dea <create+0x80>
    return 0;

  ilock(dp);
    80004d8c:	edafe0ef          	jal	80003466 <ilock>

  if (dp->nlink == 0) {
    80004d90:	04a49783          	lh	a5,74(s1)
    80004d94:	c3a9                	beqz	a5,80004dd6 <create+0x6c>
    80004d96:	f84a                	sd	s2,48(sp)
    80004d98:	f052                	sd	s4,32(sp)
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004d9a:	4601                	li	a2,0
    80004d9c:	fb040593          	addi	a1,s0,-80
    80004da0:	8526                	mv	a0,s1
    80004da2:	c67fe0ef          	jal	80003a08 <dirlookup>
    80004da6:	892a                	mv	s2,a0
    80004da8:	8a2a                	mv	s4,a0
    80004daa:	c929                	beqz	a0,80004dfc <create+0x92>
    iunlockput(dp);
    80004dac:	8526                	mv	a0,s1
    80004dae:	8c5fe0ef          	jal	80003672 <iunlockput>
    ilock(ip);
    80004db2:	854a                	mv	a0,s2
    80004db4:	eb2fe0ef          	jal	80003466 <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004db8:	4789                	li	a5,2
    80004dba:	02f99263          	bne	s3,a5,80004dde <create+0x74>
    80004dbe:	04495783          	lhu	a5,68(s2)
    80004dc2:	37f9                	addiw	a5,a5,-2
    80004dc4:	17c2                	slli	a5,a5,0x30
    80004dc6:	93c1                	srli	a5,a5,0x30
    80004dc8:	4705                	li	a4,1
    80004dca:	00f76a63          	bltu	a4,a5,80004dde <create+0x74>
      return ip;
    80004dce:	84d2                	mv	s1,s4
    80004dd0:	7942                	ld	s2,48(sp)
    80004dd2:	7a02                	ld	s4,32(sp)
    80004dd4:	a819                	j	80004dea <create+0x80>
    iunlockput(dp);
    80004dd6:	8526                	mv	a0,s1
    80004dd8:	89bfe0ef          	jal	80003672 <iunlockput>
    return 0;
    80004ddc:	a031                	j	80004de8 <create+0x7e>
    iunlockput(ip);
    80004dde:	8552                	mv	a0,s4
    80004de0:	893fe0ef          	jal	80003672 <iunlockput>
    return 0;
    80004de4:	7942                	ld	s2,48(sp)
    80004de6:	7a02                	ld	s4,32(sp)
    return 0;
    80004de8:	4481                	li	s1,0
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004dea:	8526                	mv	a0,s1
    80004dec:	60a6                	ld	ra,72(sp)
    80004dee:	6406                	ld	s0,64(sp)
    80004df0:	74e2                	ld	s1,56(sp)
    80004df2:	79a2                	ld	s3,40(sp)
    80004df4:	6ae2                	ld	s5,24(sp)
    80004df6:	6b42                	ld	s6,16(sp)
    80004df8:	6161                	addi	sp,sp,80
    80004dfa:	8082                	ret
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004dfc:	85ce                	mv	a1,s3
    80004dfe:	4088                	lw	a0,0(s1)
    80004e00:	cf6fe0ef          	jal	800032f6 <ialloc>
    80004e04:	892a                	mv	s2,a0
    80004e06:	c121                	beqz	a0,80004e46 <create+0xdc>
  ilock(ip);
    80004e08:	e5efe0ef          	jal	80003466 <ilock>
  ip->major = major;
    80004e0c:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004e10:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004e14:	4705                	li	a4,1
    80004e16:	04e91523          	sh	a4,74(s2)
  iupdate(ip);
    80004e1a:	854a                	mv	a0,s2
    80004e1c:	d96fe0ef          	jal	800033b2 <iupdate>
  if (type == T_DIR) { // Create . and .. entries.
    80004e20:	4705                	li	a4,1
    80004e22:	02e98663          	beq	s3,a4,80004e4e <create+0xe4>
  if (dirlink(dp, name, ip->inum) < 0)
    80004e26:	00492603          	lw	a2,4(s2)
    80004e2a:	fb040593          	addi	a1,s0,-80
    80004e2e:	8526                	mv	a0,s1
    80004e30:	dd9fe0ef          	jal	80003c08 <dirlink>
    80004e34:	06054463          	bltz	a0,80004e9c <create+0x132>
  iunlockput(dp);
    80004e38:	8526                	mv	a0,s1
    80004e3a:	839fe0ef          	jal	80003672 <iunlockput>
    return 0;
    80004e3e:	84ca                	mv	s1,s2
    80004e40:	7942                	ld	s2,48(sp)
    80004e42:	7a02                	ld	s4,32(sp)
    80004e44:	b75d                	j	80004dea <create+0x80>
    iunlockput(dp);
    80004e46:	8526                	mv	a0,s1
    80004e48:	82bfe0ef          	jal	80003672 <iunlockput>
    return 0;
    80004e4c:	bfcd                	j	80004e3e <create+0xd4>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004e4e:	00492603          	lw	a2,4(s2)
    80004e52:	00003597          	auipc	a1,0x3
    80004e56:	86e58593          	addi	a1,a1,-1938 # 800076c0 <etext+0x6c0>
    80004e5a:	854a                	mv	a0,s2
    80004e5c:	dadfe0ef          	jal	80003c08 <dirlink>
    80004e60:	02054e63          	bltz	a0,80004e9c <create+0x132>
    80004e64:	40d0                	lw	a2,4(s1)
    80004e66:	00003597          	auipc	a1,0x3
    80004e6a:	86258593          	addi	a1,a1,-1950 # 800076c8 <etext+0x6c8>
    80004e6e:	854a                	mv	a0,s2
    80004e70:	d99fe0ef          	jal	80003c08 <dirlink>
    80004e74:	02054463          	bltz	a0,80004e9c <create+0x132>
  if (dirlink(dp, name, ip->inum) < 0)
    80004e78:	00492603          	lw	a2,4(s2)
    80004e7c:	fb040593          	addi	a1,s0,-80
    80004e80:	8526                	mv	a0,s1
    80004e82:	d87fe0ef          	jal	80003c08 <dirlink>
    80004e86:	00054b63          	bltz	a0,80004e9c <create+0x132>
    dp->nlink++; // for ".."
    80004e8a:	04a4d783          	lhu	a5,74(s1)
    80004e8e:	2785                	addiw	a5,a5,1
    80004e90:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004e94:	8526                	mv	a0,s1
    80004e96:	d1cfe0ef          	jal	800033b2 <iupdate>
    80004e9a:	bf79                	j	80004e38 <create+0xce>
  ip->nlink = 0;
    80004e9c:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004ea0:	854a                	mv	a0,s2
    80004ea2:	d10fe0ef          	jal	800033b2 <iupdate>
  iunlockput(ip);
    80004ea6:	854a                	mv	a0,s2
    80004ea8:	fcafe0ef          	jal	80003672 <iunlockput>
  iunlockput(dp);
    80004eac:	8526                	mv	a0,s1
    80004eae:	fc4fe0ef          	jal	80003672 <iunlockput>
  return 0;
    80004eb2:	bf31                	j	80004dce <create+0x64>

0000000080004eb4 <sys_dup>:
{
    80004eb4:	7179                	addi	sp,sp,-48
    80004eb6:	f406                	sd	ra,40(sp)
    80004eb8:	f022                	sd	s0,32(sp)
    80004eba:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004ebc:	fd840613          	addi	a2,s0,-40
    80004ec0:	4581                	li	a1,0
    80004ec2:	4501                	li	a0,0
    80004ec4:	e15ff0ef          	jal	80004cd8 <argfd>
    80004ec8:	02054863          	bltz	a0,80004ef8 <sys_dup+0x44>
    80004ecc:	ec26                	sd	s1,24(sp)
    80004ece:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004ed0:	fd843483          	ld	s1,-40(s0)
    80004ed4:	8526                	mv	a0,s1
    80004ed6:	e57ff0ef          	jal	80004d2c <fdalloc>
    80004eda:	892a                	mv	s2,a0
    80004edc:	00054c63          	bltz	a0,80004ef4 <sys_dup+0x40>
  filedup(f);
    80004ee0:	8526                	mv	a0,s1
    80004ee2:	c1eff0ef          	jal	80004300 <filedup>
  return fd;
    80004ee6:	854a                	mv	a0,s2
    80004ee8:	64e2                	ld	s1,24(sp)
    80004eea:	6942                	ld	s2,16(sp)
}
    80004eec:	70a2                	ld	ra,40(sp)
    80004eee:	7402                	ld	s0,32(sp)
    80004ef0:	6145                	addi	sp,sp,48
    80004ef2:	8082                	ret
    80004ef4:	64e2                	ld	s1,24(sp)
    80004ef6:	6942                	ld	s2,16(sp)
    return -1;
    80004ef8:	557d                	li	a0,-1
    80004efa:	bfcd                	j	80004eec <sys_dup+0x38>

0000000080004efc <sys_read>:
{
    80004efc:	7179                	addi	sp,sp,-48
    80004efe:	f406                	sd	ra,40(sp)
    80004f00:	f022                	sd	s0,32(sp)
    80004f02:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004f04:	fd840593          	addi	a1,s0,-40
    80004f08:	4505                	li	a0,1
    80004f0a:	b03fd0ef          	jal	80002a0c <argaddr>
  argint(2, &n);
    80004f0e:	fe440593          	addi	a1,s0,-28
    80004f12:	4509                	li	a0,2
    80004f14:	addfd0ef          	jal	800029f0 <argint>
  if (argfd(0, 0, &f) < 0)
    80004f18:	fe840613          	addi	a2,s0,-24
    80004f1c:	4581                	li	a1,0
    80004f1e:	4501                	li	a0,0
    80004f20:	db9ff0ef          	jal	80004cd8 <argfd>
    80004f24:	87aa                	mv	a5,a0
    return -1;
    80004f26:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004f28:	0007ca63          	bltz	a5,80004f3c <sys_read+0x40>
  return fileread(f, p, n);
    80004f2c:	fe442603          	lw	a2,-28(s0)
    80004f30:	fd843583          	ld	a1,-40(s0)
    80004f34:	fe843503          	ld	a0,-24(s0)
    80004f38:	d36ff0ef          	jal	8000446e <fileread>
}
    80004f3c:	70a2                	ld	ra,40(sp)
    80004f3e:	7402                	ld	s0,32(sp)
    80004f40:	6145                	addi	sp,sp,48
    80004f42:	8082                	ret

0000000080004f44 <sys_write>:
{
    80004f44:	7179                	addi	sp,sp,-48
    80004f46:	f406                	sd	ra,40(sp)
    80004f48:	f022                	sd	s0,32(sp)
    80004f4a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004f4c:	fd840593          	addi	a1,s0,-40
    80004f50:	4505                	li	a0,1
    80004f52:	abbfd0ef          	jal	80002a0c <argaddr>
  argint(2, &n);
    80004f56:	fe440593          	addi	a1,s0,-28
    80004f5a:	4509                	li	a0,2
    80004f5c:	a95fd0ef          	jal	800029f0 <argint>
  if (argfd(0, 0, &f) < 0)
    80004f60:	fe840613          	addi	a2,s0,-24
    80004f64:	4581                	li	a1,0
    80004f66:	4501                	li	a0,0
    80004f68:	d71ff0ef          	jal	80004cd8 <argfd>
    80004f6c:	87aa                	mv	a5,a0
    return -1;
    80004f6e:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004f70:	0007ca63          	bltz	a5,80004f84 <sys_write+0x40>
  return filewrite(f, p, n);
    80004f74:	fe442603          	lw	a2,-28(s0)
    80004f78:	fd843583          	ld	a1,-40(s0)
    80004f7c:	fe843503          	ld	a0,-24(s0)
    80004f80:	da8ff0ef          	jal	80004528 <filewrite>
}
    80004f84:	70a2                	ld	ra,40(sp)
    80004f86:	7402                	ld	s0,32(sp)
    80004f88:	6145                	addi	sp,sp,48
    80004f8a:	8082                	ret

0000000080004f8c <sys_close>:
{
    80004f8c:	1101                	addi	sp,sp,-32
    80004f8e:	ec06                	sd	ra,24(sp)
    80004f90:	e822                	sd	s0,16(sp)
    80004f92:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80004f94:	fe040613          	addi	a2,s0,-32
    80004f98:	fec40593          	addi	a1,s0,-20
    80004f9c:	4501                	li	a0,0
    80004f9e:	d3bff0ef          	jal	80004cd8 <argfd>
    return -1;
    80004fa2:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80004fa4:	02054063          	bltz	a0,80004fc4 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004fa8:	addfc0ef          	jal	80001a84 <myproc>
    80004fac:	fec42783          	lw	a5,-20(s0)
    80004fb0:	07e9                	addi	a5,a5,26
    80004fb2:	078e                	slli	a5,a5,0x3
    80004fb4:	953e                	add	a0,a0,a5
    80004fb6:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004fba:	fe043503          	ld	a0,-32(s0)
    80004fbe:	b88ff0ef          	jal	80004346 <fileclose>
  return 0;
    80004fc2:	4781                	li	a5,0
}
    80004fc4:	853e                	mv	a0,a5
    80004fc6:	60e2                	ld	ra,24(sp)
    80004fc8:	6442                	ld	s0,16(sp)
    80004fca:	6105                	addi	sp,sp,32
    80004fcc:	8082                	ret

0000000080004fce <sys_fstat>:
{
    80004fce:	1101                	addi	sp,sp,-32
    80004fd0:	ec06                	sd	ra,24(sp)
    80004fd2:	e822                	sd	s0,16(sp)
    80004fd4:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004fd6:	fe040593          	addi	a1,s0,-32
    80004fda:	4505                	li	a0,1
    80004fdc:	a31fd0ef          	jal	80002a0c <argaddr>
  if (argfd(0, 0, &f) < 0)
    80004fe0:	fe840613          	addi	a2,s0,-24
    80004fe4:	4581                	li	a1,0
    80004fe6:	4501                	li	a0,0
    80004fe8:	cf1ff0ef          	jal	80004cd8 <argfd>
    80004fec:	87aa                	mv	a5,a0
    return -1;
    80004fee:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004ff0:	0007c863          	bltz	a5,80005000 <sys_fstat+0x32>
  return filestat(f, st);
    80004ff4:	fe043583          	ld	a1,-32(s0)
    80004ff8:	fe843503          	ld	a0,-24(s0)
    80004ffc:	c0cff0ef          	jal	80004408 <filestat>
}
    80005000:	60e2                	ld	ra,24(sp)
    80005002:	6442                	ld	s0,16(sp)
    80005004:	6105                	addi	sp,sp,32
    80005006:	8082                	ret

0000000080005008 <sys_link>:
{
    80005008:	7169                	addi	sp,sp,-304
    8000500a:	f606                	sd	ra,296(sp)
    8000500c:	f222                	sd	s0,288(sp)
    8000500e:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005010:	08000613          	li	a2,128
    80005014:	ed040593          	addi	a1,s0,-304
    80005018:	4501                	li	a0,0
    8000501a:	a0ffd0ef          	jal	80002a28 <argstr>
    8000501e:	0c054a63          	bltz	a0,800050f2 <sys_link+0xea>
    80005022:	08000613          	li	a2,128
    80005026:	f5040593          	addi	a1,s0,-176
    8000502a:	4505                	li	a0,1
    8000502c:	9fdfd0ef          	jal	80002a28 <argstr>
    80005030:	0c054163          	bltz	a0,800050f2 <sys_link+0xea>
    80005034:	ee26                	sd	s1,280(sp)
  begin_op();
    80005036:	e5bfe0ef          	jal	80003e90 <begin_op>
  if ((ip = namei(old)) == 0) {
    8000503a:	ed040513          	addi	a0,s0,-304
    8000503e:	c75fe0ef          	jal	80003cb2 <namei>
    80005042:	84aa                	mv	s1,a0
    80005044:	c53d                	beqz	a0,800050b2 <sys_link+0xaa>
  ilock(ip);
    80005046:	c20fe0ef          	jal	80003466 <ilock>
  if (ip->type == T_DIR) {
    8000504a:	04449703          	lh	a4,68(s1)
    8000504e:	4785                	li	a5,1
    80005050:	06f70563          	beq	a4,a5,800050ba <sys_link+0xb2>
    80005054:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80005056:	04a4d783          	lhu	a5,74(s1)
    8000505a:	2785                	addiw	a5,a5,1
    8000505c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005060:	8526                	mv	a0,s1
    80005062:	b50fe0ef          	jal	800033b2 <iupdate>
  iunlock(ip);
    80005066:	8526                	mv	a0,s1
    80005068:	cacfe0ef          	jal	80003514 <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    8000506c:	fd040593          	addi	a1,s0,-48
    80005070:	f5040513          	addi	a0,s0,-176
    80005074:	c59fe0ef          	jal	80003ccc <nameiparent>
    80005078:	892a                	mv	s2,a0
    8000507a:	c931                	beqz	a0,800050ce <sys_link+0xc6>
  ilock(dp);
    8000507c:	beafe0ef          	jal	80003466 <ilock>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80005080:	854a                	mv	a0,s2
    80005082:	00092703          	lw	a4,0(s2)
    80005086:	409c                	lw	a5,0(s1)
    80005088:	04f71063          	bne	a4,a5,800050c8 <sys_link+0xc0>
    8000508c:	40d0                	lw	a2,4(s1)
    8000508e:	fd040593          	addi	a1,s0,-48
    80005092:	b77fe0ef          	jal	80003c08 <dirlink>
    80005096:	02054963          	bltz	a0,800050c8 <sys_link+0xc0>
  iunlockput(dp);
    8000509a:	854a                	mv	a0,s2
    8000509c:	dd6fe0ef          	jal	80003672 <iunlockput>
  iput(ip);
    800050a0:	8526                	mv	a0,s1
    800050a2:	d46fe0ef          	jal	800035e8 <iput>
  end_op();
    800050a6:	e77fe0ef          	jal	80003f1c <end_op>
  return 0;
    800050aa:	4501                	li	a0,0
    800050ac:	64f2                	ld	s1,280(sp)
    800050ae:	6952                	ld	s2,272(sp)
    800050b0:	a091                	j	800050f4 <sys_link+0xec>
    end_op();
    800050b2:	e6bfe0ef          	jal	80003f1c <end_op>
    return -1;
    800050b6:	64f2                	ld	s1,280(sp)
    800050b8:	a82d                	j	800050f2 <sys_link+0xea>
    iunlockput(ip);
    800050ba:	8526                	mv	a0,s1
    800050bc:	db6fe0ef          	jal	80003672 <iunlockput>
    end_op();
    800050c0:	e5dfe0ef          	jal	80003f1c <end_op>
    return -1;
    800050c4:	64f2                	ld	s1,280(sp)
    800050c6:	a035                	j	800050f2 <sys_link+0xea>
    iunlockput(dp);
    800050c8:	854a                	mv	a0,s2
    800050ca:	da8fe0ef          	jal	80003672 <iunlockput>
  ilock(ip);
    800050ce:	8526                	mv	a0,s1
    800050d0:	b96fe0ef          	jal	80003466 <ilock>
  ip->nlink--;
    800050d4:	04a4d783          	lhu	a5,74(s1)
    800050d8:	37fd                	addiw	a5,a5,-1
    800050da:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800050de:	8526                	mv	a0,s1
    800050e0:	ad2fe0ef          	jal	800033b2 <iupdate>
  iunlockput(ip);
    800050e4:	8526                	mv	a0,s1
    800050e6:	d8cfe0ef          	jal	80003672 <iunlockput>
  end_op();
    800050ea:	e33fe0ef          	jal	80003f1c <end_op>
  return -1;
    800050ee:	64f2                	ld	s1,280(sp)
    800050f0:	6952                	ld	s2,272(sp)
    return -1;
    800050f2:	557d                	li	a0,-1
}
    800050f4:	70b2                	ld	ra,296(sp)
    800050f6:	7412                	ld	s0,288(sp)
    800050f8:	6155                	addi	sp,sp,304
    800050fa:	8082                	ret

00000000800050fc <sys_unlink>:
{
    800050fc:	7151                	addi	sp,sp,-240
    800050fe:	f586                	sd	ra,232(sp)
    80005100:	f1a2                	sd	s0,224(sp)
    80005102:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    80005104:	08000613          	li	a2,128
    80005108:	f3040593          	addi	a1,s0,-208
    8000510c:	4501                	li	a0,0
    8000510e:	91bfd0ef          	jal	80002a28 <argstr>
    80005112:	14054763          	bltz	a0,80005260 <sys_unlink+0x164>
    80005116:	eda6                	sd	s1,216(sp)
  begin_op();
    80005118:	d79fe0ef          	jal	80003e90 <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    8000511c:	fb040593          	addi	a1,s0,-80
    80005120:	f3040513          	addi	a0,s0,-208
    80005124:	ba9fe0ef          	jal	80003ccc <nameiparent>
    80005128:	84aa                	mv	s1,a0
    8000512a:	c955                	beqz	a0,800051de <sys_unlink+0xe2>
  ilock(dp);
    8000512c:	b3afe0ef          	jal	80003466 <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005130:	00002597          	auipc	a1,0x2
    80005134:	59058593          	addi	a1,a1,1424 # 800076c0 <etext+0x6c0>
    80005138:	fb040513          	addi	a0,s0,-80
    8000513c:	8b7fe0ef          	jal	800039f2 <namecmp>
    80005140:	10050a63          	beqz	a0,80005254 <sys_unlink+0x158>
    80005144:	00002597          	auipc	a1,0x2
    80005148:	58458593          	addi	a1,a1,1412 # 800076c8 <etext+0x6c8>
    8000514c:	fb040513          	addi	a0,s0,-80
    80005150:	8a3fe0ef          	jal	800039f2 <namecmp>
    80005154:	10050063          	beqz	a0,80005254 <sys_unlink+0x158>
    80005158:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    8000515a:	f2c40613          	addi	a2,s0,-212
    8000515e:	fb040593          	addi	a1,s0,-80
    80005162:	8526                	mv	a0,s1
    80005164:	8a5fe0ef          	jal	80003a08 <dirlookup>
    80005168:	892a                	mv	s2,a0
    8000516a:	0e050463          	beqz	a0,80005252 <sys_unlink+0x156>
    8000516e:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80005170:	af6fe0ef          	jal	80003466 <ilock>
  if (ip->nlink < 1)
    80005174:	04a91783          	lh	a5,74(s2)
    80005178:	06f05763          	blez	a5,800051e6 <sys_unlink+0xea>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    8000517c:	04491703          	lh	a4,68(s2)
    80005180:	4785                	li	a5,1
    80005182:	06f70863          	beq	a4,a5,800051f2 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80005186:	fc040993          	addi	s3,s0,-64
    8000518a:	4641                	li	a2,16
    8000518c:	4581                	li	a1,0
    8000518e:	854e                	mv	a0,s3
    80005190:	bdffb0ef          	jal	80000d6e <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005194:	4741                	li	a4,16
    80005196:	f2c42683          	lw	a3,-212(s0)
    8000519a:	864e                	mv	a2,s3
    8000519c:	4581                	li	a1,0
    8000519e:	8526                	mv	a0,s1
    800051a0:	f4afe0ef          	jal	800038ea <writei>
    800051a4:	47c1                	li	a5,16
    800051a6:	08f51763          	bne	a0,a5,80005234 <sys_unlink+0x138>
  if (ip->type == T_DIR) {
    800051aa:	04491703          	lh	a4,68(s2)
    800051ae:	4785                	li	a5,1
    800051b0:	08f70863          	beq	a4,a5,80005240 <sys_unlink+0x144>
  iunlockput(dp);
    800051b4:	8526                	mv	a0,s1
    800051b6:	cbcfe0ef          	jal	80003672 <iunlockput>
  ip->nlink--;
    800051ba:	04a95783          	lhu	a5,74(s2)
    800051be:	37fd                	addiw	a5,a5,-1
    800051c0:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800051c4:	854a                	mv	a0,s2
    800051c6:	9ecfe0ef          	jal	800033b2 <iupdate>
  iunlockput(ip);
    800051ca:	854a                	mv	a0,s2
    800051cc:	ca6fe0ef          	jal	80003672 <iunlockput>
  end_op();
    800051d0:	d4dfe0ef          	jal	80003f1c <end_op>
  return 0;
    800051d4:	4501                	li	a0,0
    800051d6:	64ee                	ld	s1,216(sp)
    800051d8:	694e                	ld	s2,208(sp)
    800051da:	69ae                	ld	s3,200(sp)
    800051dc:	a059                	j	80005262 <sys_unlink+0x166>
    end_op();
    800051de:	d3ffe0ef          	jal	80003f1c <end_op>
    return -1;
    800051e2:	64ee                	ld	s1,216(sp)
    800051e4:	a8b5                	j	80005260 <sys_unlink+0x164>
    panic("unlink: nlink < 1");
    800051e6:	00002517          	auipc	a0,0x2
    800051ea:	4ea50513          	addi	a0,a0,1258 # 800076d0 <etext+0x6d0>
    800051ee:	e5afb0ef          	jal	80000848 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800051f2:	04c92703          	lw	a4,76(s2)
    800051f6:	02000793          	li	a5,32
    800051fa:	f8e7f6e3          	bgeu	a5,a4,80005186 <sys_unlink+0x8a>
    800051fe:	89be                	mv	s3,a5
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005200:	4741                	li	a4,16
    80005202:	86ce                	mv	a3,s3
    80005204:	f1840613          	addi	a2,s0,-232
    80005208:	4581                	li	a1,0
    8000520a:	854a                	mv	a0,s2
    8000520c:	decfe0ef          	jal	800037f8 <readi>
    80005210:	47c1                	li	a5,16
    80005212:	00f51b63          	bne	a0,a5,80005228 <sys_unlink+0x12c>
    if (de.inum != 0)
    80005216:	f1845783          	lhu	a5,-232(s0)
    8000521a:	eba1                	bnez	a5,8000526a <sys_unlink+0x16e>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    8000521c:	29c1                	addiw	s3,s3,16
    8000521e:	04c92783          	lw	a5,76(s2)
    80005222:	fcf9efe3          	bltu	s3,a5,80005200 <sys_unlink+0x104>
    80005226:	b785                	j	80005186 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80005228:	00002517          	auipc	a0,0x2
    8000522c:	4c050513          	addi	a0,a0,1216 # 800076e8 <etext+0x6e8>
    80005230:	e18fb0ef          	jal	80000848 <panic>
    panic("unlink: writei");
    80005234:	00002517          	auipc	a0,0x2
    80005238:	4cc50513          	addi	a0,a0,1228 # 80007700 <etext+0x700>
    8000523c:	e0cfb0ef          	jal	80000848 <panic>
    dp->nlink--;
    80005240:	04a4d783          	lhu	a5,74(s1)
    80005244:	37fd                	addiw	a5,a5,-1
    80005246:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000524a:	8526                	mv	a0,s1
    8000524c:	966fe0ef          	jal	800033b2 <iupdate>
    80005250:	b795                	j	800051b4 <sys_unlink+0xb8>
    80005252:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80005254:	8526                	mv	a0,s1
    80005256:	c1cfe0ef          	jal	80003672 <iunlockput>
  end_op();
    8000525a:	cc3fe0ef          	jal	80003f1c <end_op>
  return -1;
    8000525e:	64ee                	ld	s1,216(sp)
    return -1;
    80005260:	557d                	li	a0,-1
}
    80005262:	70ae                	ld	ra,232(sp)
    80005264:	740e                	ld	s0,224(sp)
    80005266:	616d                	addi	sp,sp,240
    80005268:	8082                	ret
    iunlockput(ip);
    8000526a:	854a                	mv	a0,s2
    8000526c:	c06fe0ef          	jal	80003672 <iunlockput>
    goto bad;
    80005270:	694e                	ld	s2,208(sp)
    80005272:	69ae                	ld	s3,200(sp)
    80005274:	b7c5                	j	80005254 <sys_unlink+0x158>

0000000080005276 <sys_open>:

uint64
sys_open(void)
{
    80005276:	7131                	addi	sp,sp,-192
    80005278:	fd06                	sd	ra,184(sp)
    8000527a:	f922                	sd	s0,176(sp)
    8000527c:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000527e:	f4c40593          	addi	a1,s0,-180
    80005282:	4505                	li	a0,1
    80005284:	f6cfd0ef          	jal	800029f0 <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005288:	08000613          	li	a2,128
    8000528c:	f5040593          	addi	a1,s0,-176
    80005290:	4501                	li	a0,0
    80005292:	f96fd0ef          	jal	80002a28 <argstr>
    80005296:	10054563          	bltz	a0,800053a0 <sys_open+0x12a>
    8000529a:	f526                	sd	s1,168(sp)
    return -1;

  begin_op();
    8000529c:	bf5fe0ef          	jal	80003e90 <begin_op>

  if (omode & O_CREATE) {
    800052a0:	f4c42783          	lw	a5,-180(s0)
    800052a4:	2007f793          	andi	a5,a5,512
    800052a8:	cfd9                	beqz	a5,80005346 <sys_open+0xd0>
    ip = create(path, T_FILE, 0, 0);
    800052aa:	4681                	li	a3,0
    800052ac:	4601                	li	a2,0
    800052ae:	4589                	li	a1,2
    800052b0:	f5040513          	addi	a0,s0,-176
    800052b4:	ab7ff0ef          	jal	80004d6a <create>
    800052b8:	84aa                	mv	s1,a0
    if (ip == 0) {
    800052ba:	c151                	beqz	a0,8000533e <sys_open+0xc8>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    800052bc:	04449703          	lh	a4,68(s1)
    800052c0:	478d                	li	a5,3
    800052c2:	00f71763          	bne	a4,a5,800052d0 <sys_open+0x5a>
    800052c6:	0464d703          	lhu	a4,70(s1)
    800052ca:	47a5                	li	a5,9
    800052cc:	0ae7e863          	bltu	a5,a4,8000537c <sys_open+0x106>
    800052d0:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    800052d2:	fd1fe0ef          	jal	800042a2 <filealloc>
    800052d6:	892a                	mv	s2,a0
    800052d8:	cd4d                	beqz	a0,80005392 <sys_open+0x11c>
    800052da:	ed4e                	sd	s3,152(sp)
    800052dc:	a51ff0ef          	jal	80004d2c <fdalloc>
    800052e0:	89aa                	mv	s3,a0
    800052e2:	0a054463          	bltz	a0,8000538a <sys_open+0x114>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    800052e6:	04449703          	lh	a4,68(s1)
    800052ea:	478d                	li	a5,3
    800052ec:	0af70f63          	beq	a4,a5,800053aa <sys_open+0x134>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800052f0:	4789                	li	a5,2
    800052f2:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800052f6:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800052fa:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800052fe:	f4c42783          	lw	a5,-180(s0)
    80005302:	0017f713          	andi	a4,a5,1
    80005306:	00174713          	xori	a4,a4,1
    8000530a:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000530e:	0037f713          	andi	a4,a5,3
    80005312:	00e03733          	snez	a4,a4
    80005316:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    8000531a:	4007f793          	andi	a5,a5,1024
    8000531e:	c791                	beqz	a5,8000532a <sys_open+0xb4>
    80005320:	04449703          	lh	a4,68(s1)
    80005324:	4789                	li	a5,2
    80005326:	08f70963          	beq	a4,a5,800053b8 <sys_open+0x142>
    itrunc(ip);
  }

  iunlock(ip);
    8000532a:	8526                	mv	a0,s1
    8000532c:	9e8fe0ef          	jal	80003514 <iunlock>
  end_op();
    80005330:	bedfe0ef          	jal	80003f1c <end_op>

  return fd;
    80005334:	854e                	mv	a0,s3
    80005336:	74aa                	ld	s1,168(sp)
    80005338:	790a                	ld	s2,160(sp)
    8000533a:	69ea                	ld	s3,152(sp)
    8000533c:	a09d                	j	800053a2 <sys_open+0x12c>
      end_op();
    8000533e:	bdffe0ef          	jal	80003f1c <end_op>
      return -1;
    80005342:	74aa                	ld	s1,168(sp)
    80005344:	a8b1                	j	800053a0 <sys_open+0x12a>
    if ((ip = namei(path)) == 0) {
    80005346:	f5040513          	addi	a0,s0,-176
    8000534a:	969fe0ef          	jal	80003cb2 <namei>
    8000534e:	84aa                	mv	s1,a0
    80005350:	c115                	beqz	a0,80005374 <sys_open+0xfe>
    ilock(ip);
    80005352:	914fe0ef          	jal	80003466 <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    80005356:	04449703          	lh	a4,68(s1)
    8000535a:	4785                	li	a5,1
    8000535c:	f6f710e3          	bne	a4,a5,800052bc <sys_open+0x46>
    80005360:	f4c42783          	lw	a5,-180(s0)
    80005364:	d7b5                	beqz	a5,800052d0 <sys_open+0x5a>
      iunlockput(ip);
    80005366:	8526                	mv	a0,s1
    80005368:	b0afe0ef          	jal	80003672 <iunlockput>
      end_op();
    8000536c:	bb1fe0ef          	jal	80003f1c <end_op>
      return -1;
    80005370:	74aa                	ld	s1,168(sp)
    80005372:	a03d                	j	800053a0 <sys_open+0x12a>
      end_op();
    80005374:	ba9fe0ef          	jal	80003f1c <end_op>
      return -1;
    80005378:	74aa                	ld	s1,168(sp)
    8000537a:	a01d                	j	800053a0 <sys_open+0x12a>
    iunlockput(ip);
    8000537c:	8526                	mv	a0,s1
    8000537e:	af4fe0ef          	jal	80003672 <iunlockput>
    end_op();
    80005382:	b9bfe0ef          	jal	80003f1c <end_op>
    return -1;
    80005386:	74aa                	ld	s1,168(sp)
    80005388:	a821                	j	800053a0 <sys_open+0x12a>
      fileclose(f);
    8000538a:	854a                	mv	a0,s2
    8000538c:	fbbfe0ef          	jal	80004346 <fileclose>
    80005390:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005392:	8526                	mv	a0,s1
    80005394:	adefe0ef          	jal	80003672 <iunlockput>
    end_op();
    80005398:	b85fe0ef          	jal	80003f1c <end_op>
    return -1;
    8000539c:	74aa                	ld	s1,168(sp)
    8000539e:	790a                	ld	s2,160(sp)
    return -1;
    800053a0:	557d                	li	a0,-1
}
    800053a2:	70ea                	ld	ra,184(sp)
    800053a4:	744a                	ld	s0,176(sp)
    800053a6:	6129                	addi	sp,sp,192
    800053a8:	8082                	ret
    f->type = FD_DEVICE;
    800053aa:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800053ae:	04649783          	lh	a5,70(s1)
    800053b2:	02f91223          	sh	a5,36(s2)
    800053b6:	b791                	j	800052fa <sys_open+0x84>
    itrunc(ip);
    800053b8:	8526                	mv	a0,s1
    800053ba:	99afe0ef          	jal	80003554 <itrunc>
    800053be:	b7b5                	j	8000532a <sys_open+0xb4>

00000000800053c0 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800053c0:	7175                	addi	sp,sp,-144
    800053c2:	e506                	sd	ra,136(sp)
    800053c4:	e122                	sd	s0,128(sp)
    800053c6:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800053c8:	ac9fe0ef          	jal	80003e90 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    800053cc:	08000613          	li	a2,128
    800053d0:	f7040593          	addi	a1,s0,-144
    800053d4:	4501                	li	a0,0
    800053d6:	e52fd0ef          	jal	80002a28 <argstr>
    800053da:	02054363          	bltz	a0,80005400 <sys_mkdir+0x40>
    800053de:	4681                	li	a3,0
    800053e0:	4601                	li	a2,0
    800053e2:	4585                	li	a1,1
    800053e4:	f7040513          	addi	a0,s0,-144
    800053e8:	983ff0ef          	jal	80004d6a <create>
    800053ec:	c911                	beqz	a0,80005400 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800053ee:	a84fe0ef          	jal	80003672 <iunlockput>
  end_op();
    800053f2:	b2bfe0ef          	jal	80003f1c <end_op>
  return 0;
    800053f6:	4501                	li	a0,0
}
    800053f8:	60aa                	ld	ra,136(sp)
    800053fa:	640a                	ld	s0,128(sp)
    800053fc:	6149                	addi	sp,sp,144
    800053fe:	8082                	ret
    end_op();
    80005400:	b1dfe0ef          	jal	80003f1c <end_op>
    return -1;
    80005404:	557d                	li	a0,-1
    80005406:	bfcd                	j	800053f8 <sys_mkdir+0x38>

0000000080005408 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005408:	7135                	addi	sp,sp,-160
    8000540a:	ed06                	sd	ra,152(sp)
    8000540c:	e922                	sd	s0,144(sp)
    8000540e:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005410:	a81fe0ef          	jal	80003e90 <begin_op>
  argint(1, &major);
    80005414:	f6c40593          	addi	a1,s0,-148
    80005418:	4505                	li	a0,1
    8000541a:	dd6fd0ef          	jal	800029f0 <argint>
  argint(2, &minor);
    8000541e:	f6840593          	addi	a1,s0,-152
    80005422:	4509                	li	a0,2
    80005424:	dccfd0ef          	jal	800029f0 <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005428:	08000613          	li	a2,128
    8000542c:	f7040593          	addi	a1,s0,-144
    80005430:	4501                	li	a0,0
    80005432:	df6fd0ef          	jal	80002a28 <argstr>
    80005436:	02054563          	bltz	a0,80005460 <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    8000543a:	f6841683          	lh	a3,-152(s0)
    8000543e:	f6c41603          	lh	a2,-148(s0)
    80005442:	458d                	li	a1,3
    80005444:	f7040513          	addi	a0,s0,-144
    80005448:	923ff0ef          	jal	80004d6a <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    8000544c:	c911                	beqz	a0,80005460 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000544e:	a24fe0ef          	jal	80003672 <iunlockput>
  end_op();
    80005452:	acbfe0ef          	jal	80003f1c <end_op>
  return 0;
    80005456:	4501                	li	a0,0
}
    80005458:	60ea                	ld	ra,152(sp)
    8000545a:	644a                	ld	s0,144(sp)
    8000545c:	610d                	addi	sp,sp,160
    8000545e:	8082                	ret
    end_op();
    80005460:	abdfe0ef          	jal	80003f1c <end_op>
    return -1;
    80005464:	557d                	li	a0,-1
    80005466:	bfcd                	j	80005458 <sys_mknod+0x50>

0000000080005468 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005468:	7135                	addi	sp,sp,-160
    8000546a:	ed06                	sd	ra,152(sp)
    8000546c:	e922                	sd	s0,144(sp)
    8000546e:	e14a                	sd	s2,128(sp)
    80005470:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005472:	e12fc0ef          	jal	80001a84 <myproc>
    80005476:	892a                	mv	s2,a0

  begin_op();
    80005478:	a19fe0ef          	jal	80003e90 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    8000547c:	08000613          	li	a2,128
    80005480:	f6040593          	addi	a1,s0,-160
    80005484:	4501                	li	a0,0
    80005486:	da2fd0ef          	jal	80002a28 <argstr>
    8000548a:	02054f63          	bltz	a0,800054c8 <sys_chdir+0x60>
    8000548e:	e526                	sd	s1,136(sp)
    80005490:	f6040513          	addi	a0,s0,-160
    80005494:	81ffe0ef          	jal	80003cb2 <namei>
    80005498:	84aa                	mv	s1,a0
    8000549a:	c515                	beqz	a0,800054c6 <sys_chdir+0x5e>
    end_op();
    return -1;
  }
  ilock(ip);
    8000549c:	fcbfd0ef          	jal	80003466 <ilock>
  if (ip->type != T_DIR) {
    800054a0:	04449703          	lh	a4,68(s1)
    800054a4:	4785                	li	a5,1
    800054a6:	02f71963          	bne	a4,a5,800054d8 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800054aa:	8526                	mv	a0,s1
    800054ac:	868fe0ef          	jal	80003514 <iunlock>
  iput(p->cwd);
    800054b0:	15093503          	ld	a0,336(s2)
    800054b4:	934fe0ef          	jal	800035e8 <iput>
  end_op();
    800054b8:	a65fe0ef          	jal	80003f1c <end_op>
  p->cwd = ip;
    800054bc:	14993823          	sd	s1,336(s2)
  return 0;
    800054c0:	4501                	li	a0,0
    800054c2:	64aa                	ld	s1,136(sp)
    800054c4:	a029                	j	800054ce <sys_chdir+0x66>
    800054c6:	64aa                	ld	s1,136(sp)
    end_op();
    800054c8:	a55fe0ef          	jal	80003f1c <end_op>
    return -1;
    800054cc:	557d                	li	a0,-1
}
    800054ce:	60ea                	ld	ra,152(sp)
    800054d0:	644a                	ld	s0,144(sp)
    800054d2:	690a                	ld	s2,128(sp)
    800054d4:	610d                	addi	sp,sp,160
    800054d6:	8082                	ret
    iunlockput(ip);
    800054d8:	8526                	mv	a0,s1
    800054da:	998fe0ef          	jal	80003672 <iunlockput>
    end_op();
    800054de:	a3ffe0ef          	jal	80003f1c <end_op>
    return -1;
    800054e2:	64aa                	ld	s1,136(sp)
    800054e4:	b7e5                	j	800054cc <sys_chdir+0x64>

00000000800054e6 <sys_exec>:

uint64
sys_exec(void)
{
    800054e6:	7105                	addi	sp,sp,-480
    800054e8:	ef86                	sd	ra,472(sp)
    800054ea:	eba2                	sd	s0,464(sp)
    800054ec:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800054ee:	e2840593          	addi	a1,s0,-472
    800054f2:	4505                	li	a0,1
    800054f4:	d18fd0ef          	jal	80002a0c <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    800054f8:	08000613          	li	a2,128
    800054fc:	f3040593          	addi	a1,s0,-208
    80005500:	4501                	li	a0,0
    80005502:	d26fd0ef          	jal	80002a28 <argstr>
    80005506:	0c054e63          	bltz	a0,800055e2 <sys_exec+0xfc>
    8000550a:	e7a6                	sd	s1,456(sp)
    8000550c:	e3ca                	sd	s2,448(sp)
    8000550e:	ff4e                	sd	s3,440(sp)
    80005510:	fb52                	sd	s4,432(sp)
    80005512:	f756                	sd	s5,424(sp)
    80005514:	f35a                	sd	s6,416(sp)
    80005516:	ef5e                	sd	s7,408(sp)
    return -1;
  }
  memset(argv, 0, sizeof(argv));
    80005518:	e3040a13          	addi	s4,s0,-464
    8000551c:	10000613          	li	a2,256
    80005520:	4581                	li	a1,0
    80005522:	8552                	mv	a0,s4
    80005524:	84bfb0ef          	jal	80000d6e <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    80005528:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000552a:	89d2                	mv	s3,s4
    8000552c:	4901                	li	s2,0
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    8000552e:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if (argv[i] == 0)
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005532:	6b05                	lui	s6,0x1
    if (i >= NELEM(argv)) {
    80005534:	02000b93          	li	s7,32
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    80005538:	00391513          	slli	a0,s2,0x3
    8000553c:	85d6                	mv	a1,s5
    8000553e:	e2843783          	ld	a5,-472(s0)
    80005542:	953e                	add	a0,a0,a5
    80005544:	c24fd0ef          	jal	80002968 <fetchaddr>
    80005548:	02054663          	bltz	a0,80005574 <sys_exec+0x8e>
    if (uarg == 0) {
    8000554c:	e2043783          	ld	a5,-480(s0)
    80005550:	c3b9                	beqz	a5,80005596 <sys_exec+0xb0>
    argv[i] = kalloc();
    80005552:	df0fb0ef          	jal	80000b42 <kalloc>
    80005556:	85aa                	mv	a1,a0
    80005558:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    8000555c:	cd01                	beqz	a0,80005574 <sys_exec+0x8e>
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000555e:	865a                	mv	a2,s6
    80005560:	e2043503          	ld	a0,-480(s0)
    80005564:	c4afd0ef          	jal	800029ae <fetchstr>
    80005568:	00054663          	bltz	a0,80005574 <sys_exec+0x8e>
    if (i >= NELEM(argv)) {
    8000556c:	0905                	addi	s2,s2,1
    8000556e:	09a1                	addi	s3,s3,8
    80005570:	fd7914e3          	bne	s2,s7,80005538 <sys_exec+0x52>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005574:	100a0a13          	addi	s4,s4,256
    80005578:	6088                	ld	a0,0(s1)
    8000557a:	cd29                	beqz	a0,800055d4 <sys_exec+0xee>
    kfree(argv[i]);
    8000557c:	cbafb0ef          	jal	80000a36 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005580:	04a1                	addi	s1,s1,8
    80005582:	ff449be3          	bne	s1,s4,80005578 <sys_exec+0x92>
    80005586:	64be                	ld	s1,456(sp)
    80005588:	691e                	ld	s2,448(sp)
    8000558a:	79fa                	ld	s3,440(sp)
    8000558c:	7a5a                	ld	s4,432(sp)
    8000558e:	7aba                	ld	s5,424(sp)
    80005590:	7b1a                	ld	s6,416(sp)
    80005592:	6bfa                	ld	s7,408(sp)
    80005594:	a0b9                	j	800055e2 <sys_exec+0xfc>
      argv[i] = 0;
    80005596:	0009079b          	sext.w	a5,s2
    8000559a:	e3040593          	addi	a1,s0,-464
    8000559e:	078e                	slli	a5,a5,0x3
    800055a0:	97ae                	add	a5,a5,a1
    800055a2:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    800055a6:	f3040513          	addi	a0,s0,-208
    800055aa:	c16ff0ef          	jal	800049c0 <kexec>
    800055ae:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800055b0:	100a0a13          	addi	s4,s4,256
    800055b4:	6088                	ld	a0,0(s1)
    800055b6:	c511                	beqz	a0,800055c2 <sys_exec+0xdc>
    kfree(argv[i]);
    800055b8:	c7efb0ef          	jal	80000a36 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800055bc:	04a1                	addi	s1,s1,8
    800055be:	ff449be3          	bne	s1,s4,800055b4 <sys_exec+0xce>
  return ret;
    800055c2:	854a                	mv	a0,s2
    800055c4:	64be                	ld	s1,456(sp)
    800055c6:	691e                	ld	s2,448(sp)
    800055c8:	79fa                	ld	s3,440(sp)
    800055ca:	7a5a                	ld	s4,432(sp)
    800055cc:	7aba                	ld	s5,424(sp)
    800055ce:	7b1a                	ld	s6,416(sp)
    800055d0:	6bfa                	ld	s7,408(sp)
    800055d2:	a809                	j	800055e4 <sys_exec+0xfe>
    800055d4:	64be                	ld	s1,456(sp)
    800055d6:	691e                	ld	s2,448(sp)
    800055d8:	79fa                	ld	s3,440(sp)
    800055da:	7a5a                	ld	s4,432(sp)
    800055dc:	7aba                	ld	s5,424(sp)
    800055de:	7b1a                	ld	s6,416(sp)
    800055e0:	6bfa                	ld	s7,408(sp)
    return -1;
    800055e2:	557d                	li	a0,-1
  return -1;
}
    800055e4:	60fe                	ld	ra,472(sp)
    800055e6:	645e                	ld	s0,464(sp)
    800055e8:	613d                	addi	sp,sp,480
    800055ea:	8082                	ret

00000000800055ec <sys_pipe>:

uint64
sys_pipe(void)
{
    800055ec:	7139                	addi	sp,sp,-64
    800055ee:	fc06                	sd	ra,56(sp)
    800055f0:	f822                	sd	s0,48(sp)
    800055f2:	f426                	sd	s1,40(sp)
    800055f4:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800055f6:	c8efc0ef          	jal	80001a84 <myproc>
    800055fa:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800055fc:	fd840593          	addi	a1,s0,-40
    80005600:	4501                	li	a0,0
    80005602:	c0afd0ef          	jal	80002a0c <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    80005606:	fc840593          	addi	a1,s0,-56
    8000560a:	fd040513          	addi	a0,s0,-48
    8000560e:	84aff0ef          	jal	80004658 <pipealloc>
    80005612:	0a054663          	bltz	a0,800056be <sys_pipe+0xd2>
    return -1;
  fd0 = -1;
    80005616:	57fd                	li	a5,-1
    80005618:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    8000561c:	fd043503          	ld	a0,-48(s0)
    80005620:	f0cff0ef          	jal	80004d2c <fdalloc>
    80005624:	fca42223          	sw	a0,-60(s0)
    80005628:	08054363          	bltz	a0,800056ae <sys_pipe+0xc2>
    8000562c:	fc843503          	ld	a0,-56(s0)
    80005630:	efcff0ef          	jal	80004d2c <fdalloc>
    80005634:	fca42023          	sw	a0,-64(s0)
    80005638:	06054263          	bltz	a0,8000569c <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    8000563c:	4711                	li	a4,4
    8000563e:	fc440693          	addi	a3,s0,-60
    80005642:	fd843603          	ld	a2,-40(s0)
    80005646:	64ac                	ld	a1,72(s1)
    80005648:	68a8                	ld	a0,80(s1)
    8000564a:	f9dfb0ef          	jal	800015e6 <copyout>
    8000564e:	02054063          	bltz	a0,8000566e <sys_pipe+0x82>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    80005652:	4711                	li	a4,4
    80005654:	fc040693          	addi	a3,s0,-64
    80005658:	fd843603          	ld	a2,-40(s0)
    8000565c:	963a                	add	a2,a2,a4
    8000565e:	64ac                	ld	a1,72(s1)
    80005660:	68a8                	ld	a0,80(s1)
    80005662:	f85fb0ef          	jal	800015e6 <copyout>
    80005666:	87aa                	mv	a5,a0
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005668:	4501                	li	a0,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    8000566a:	0407db63          	bgez	a5,800056c0 <sys_pipe+0xd4>
    p->ofile[fd0] = 0;
    8000566e:	fc442783          	lw	a5,-60(s0)
    80005672:	07e9                	addi	a5,a5,26
    80005674:	078e                	slli	a5,a5,0x3
    80005676:	97a6                	add	a5,a5,s1
    80005678:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000567c:	fc042783          	lw	a5,-64(s0)
    80005680:	07e9                	addi	a5,a5,26
    80005682:	078e                	slli	a5,a5,0x3
    80005684:	94be                	add	s1,s1,a5
    80005686:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000568a:	fd043503          	ld	a0,-48(s0)
    8000568e:	cb9fe0ef          	jal	80004346 <fileclose>
    fileclose(wf);
    80005692:	fc843503          	ld	a0,-56(s0)
    80005696:	cb1fe0ef          	jal	80004346 <fileclose>
    return -1;
    8000569a:	a015                	j	800056be <sys_pipe+0xd2>
    if (fd0 >= 0)
    8000569c:	fc442783          	lw	a5,-60(s0)
    800056a0:	0007c763          	bltz	a5,800056ae <sys_pipe+0xc2>
      p->ofile[fd0] = 0;
    800056a4:	07e9                	addi	a5,a5,26
    800056a6:	078e                	slli	a5,a5,0x3
    800056a8:	97a6                	add	a5,a5,s1
    800056aa:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800056ae:	fd043503          	ld	a0,-48(s0)
    800056b2:	c95fe0ef          	jal	80004346 <fileclose>
    fileclose(wf);
    800056b6:	fc843503          	ld	a0,-56(s0)
    800056ba:	c8dfe0ef          	jal	80004346 <fileclose>
    return -1;
    800056be:	557d                	li	a0,-1
}
    800056c0:	70e2                	ld	ra,56(sp)
    800056c2:	7442                	ld	s0,48(sp)
    800056c4:	74a2                	ld	s1,40(sp)
    800056c6:	6121                	addi	sp,sp,64
    800056c8:	8082                	ret
    800056ca:	0000                	unimp
    800056cc:	0000                	unimp
	...

00000000800056d0 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    800056d0:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    800056d2:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    800056d4:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    800056d6:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    800056d8:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    800056da:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    800056dc:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    800056de:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    800056e0:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    800056e2:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    800056e4:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    800056e6:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    800056e8:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    800056ea:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    800056ec:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    800056ee:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    800056f0:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    800056f2:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    800056f4:	982fd0ef          	jal	80002876 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    800056f8:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    800056fa:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    800056fc:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800056fe:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005700:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005702:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005704:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005706:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    80005708:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000570a:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000570c:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    8000570e:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005710:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005712:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005714:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005716:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    80005718:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000571a:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000571c:	10200073          	sret
    80005720:	0001                	nop
    80005722:	00000013          	nop
    80005726:	00000013          	nop
    8000572a:	00000013          	nop

000000008000572e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000572e:	1141                	addi	sp,sp,-16
    80005730:	e406                	sd	ra,8(sp)
    80005732:	e022                	sd	s0,0(sp)
    80005734:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    80005736:	0c000737          	lui	a4,0xc000
    8000573a:	4785                	li	a5,1
    8000573c:	d71c                	sw	a5,40(a4)
  *(uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    8000573e:	c35c                	sw	a5,4(a4)
}
    80005740:	60a2                	ld	ra,8(sp)
    80005742:	6402                	ld	s0,0(sp)
    80005744:	0141                	addi	sp,sp,16
    80005746:	8082                	ret

0000000080005748 <plicinithart>:

void
plicinithart(void)
{
    80005748:	1141                	addi	sp,sp,-16
    8000574a:	e406                	sd	ra,8(sp)
    8000574c:	e022                	sd	s0,0(sp)
    8000574e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005750:	b00fc0ef          	jal	80001a50 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32 *)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005754:	0085171b          	slliw	a4,a0,0x8
    80005758:	0c0027b7          	lui	a5,0xc002
    8000575c:	97ba                	add	a5,a5,a4
    8000575e:	40200713          	li	a4,1026
    80005762:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005766:	00d5151b          	slliw	a0,a0,0xd
    8000576a:	0c2017b7          	lui	a5,0xc201
    8000576e:	97aa                	add	a5,a5,a0
    80005770:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005774:	60a2                	ld	ra,8(sp)
    80005776:	6402                	ld	s0,0(sp)
    80005778:	0141                	addi	sp,sp,16
    8000577a:	8082                	ret

000000008000577c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000577c:	1141                	addi	sp,sp,-16
    8000577e:	e406                	sd	ra,8(sp)
    80005780:	e022                	sd	s0,0(sp)
    80005782:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005784:	accfc0ef          	jal	80001a50 <cpuid>
  int irq = *(uint32 *)PLIC_SCLAIM(hart);
    80005788:	00d5151b          	slliw	a0,a0,0xd
    8000578c:	0c2017b7          	lui	a5,0xc201
    80005790:	97aa                	add	a5,a5,a0
  return irq;
}
    80005792:	43c8                	lw	a0,4(a5)
    80005794:	60a2                	ld	ra,8(sp)
    80005796:	6402                	ld	s0,0(sp)
    80005798:	0141                	addi	sp,sp,16
    8000579a:	8082                	ret

000000008000579c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000579c:	1101                	addi	sp,sp,-32
    8000579e:	ec06                	sd	ra,24(sp)
    800057a0:	e822                	sd	s0,16(sp)
    800057a2:	e426                	sd	s1,8(sp)
    800057a4:	1000                	addi	s0,sp,32
    800057a6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800057a8:	aa8fc0ef          	jal	80001a50 <cpuid>
  *(uint32 *)PLIC_SCLAIM(hart) = irq;
    800057ac:	00d5179b          	slliw	a5,a0,0xd
    800057b0:	0c201737          	lui	a4,0xc201
    800057b4:	97ba                	add	a5,a5,a4
    800057b6:	c3c4                	sw	s1,4(a5)
}
    800057b8:	60e2                	ld	ra,24(sp)
    800057ba:	6442                	ld	s0,16(sp)
    800057bc:	64a2                	ld	s1,8(sp)
    800057be:	6105                	addi	sp,sp,32
    800057c0:	8082                	ret

00000000800057c2 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800057c2:	1141                	addi	sp,sp,-16
    800057c4:	e406                	sd	ra,8(sp)
    800057c6:	e022                	sd	s0,0(sp)
    800057c8:	0800                	addi	s0,sp,16
  if (i >= NUM)
    800057ca:	479d                	li	a5,7
    800057cc:	04a7ca63          	blt	a5,a0,80005820 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    800057d0:	0001b797          	auipc	a5,0x1b
    800057d4:	5a878793          	addi	a5,a5,1448 # 80020d78 <disk>
    800057d8:	97aa                	add	a5,a5,a0
    800057da:	0187c783          	lbu	a5,24(a5)
    800057de:	e7b9                	bnez	a5,8000582c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800057e0:	00451693          	slli	a3,a0,0x4
    800057e4:	0001b797          	auipc	a5,0x1b
    800057e8:	59478793          	addi	a5,a5,1428 # 80020d78 <disk>
    800057ec:	6398                	ld	a4,0(a5)
    800057ee:	9736                	add	a4,a4,a3
    800057f0:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    800057f4:	6398                	ld	a4,0(a5)
    800057f6:	9736                	add	a4,a4,a3
    800057f8:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800057fc:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005800:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005804:	97aa                	add	a5,a5,a0
    80005806:	4705                	li	a4,1
    80005808:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000580c:	0001b517          	auipc	a0,0x1b
    80005810:	58450513          	addi	a0,a0,1412 # 80020d90 <disk+0x18>
    80005814:	923fc0ef          	jal	80002136 <wakeup>
}
    80005818:	60a2                	ld	ra,8(sp)
    8000581a:	6402                	ld	s0,0(sp)
    8000581c:	0141                	addi	sp,sp,16
    8000581e:	8082                	ret
    panic("free_desc 1");
    80005820:	00002517          	auipc	a0,0x2
    80005824:	ef050513          	addi	a0,a0,-272 # 80007710 <etext+0x710>
    80005828:	820fb0ef          	jal	80000848 <panic>
    panic("free_desc 2");
    8000582c:	00002517          	auipc	a0,0x2
    80005830:	ef450513          	addi	a0,a0,-268 # 80007720 <etext+0x720>
    80005834:	814fb0ef          	jal	80000848 <panic>

0000000080005838 <virtio_disk_init>:
{
    80005838:	1101                	addi	sp,sp,-32
    8000583a:	ec06                	sd	ra,24(sp)
    8000583c:	e822                	sd	s0,16(sp)
    8000583e:	e426                	sd	s1,8(sp)
    80005840:	e04a                	sd	s2,0(sp)
    80005842:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005844:	00002597          	auipc	a1,0x2
    80005848:	eec58593          	addi	a1,a1,-276 # 80007730 <etext+0x730>
    8000584c:	0001b517          	auipc	a0,0x1b
    80005850:	65450513          	addi	a0,a0,1620 # 80020ea0 <disk+0x128>
    80005854:	bdefb0ef          	jal	80000c32 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005858:	100017b7          	lui	a5,0x10001
    8000585c:	4398                	lw	a4,0(a5)
    8000585e:	747277b7          	lui	a5,0x74727
    80005862:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005866:	14f71263          	bne	a4,a5,800059aa <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000586a:	100017b7          	lui	a5,0x10001
    8000586e:	43d8                	lw	a4,4(a5)
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005870:	4789                	li	a5,2
    80005872:	12f71c63          	bne	a4,a5,800059aa <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005876:	100017b7          	lui	a5,0x10001
    8000587a:	4798                	lw	a4,8(a5)
    8000587c:	4789                	li	a5,2
    8000587e:	12f71663          	bne	a4,a5,800059aa <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005882:	100017b7          	lui	a5,0x10001
    80005886:	47d8                	lw	a4,12(a5)
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005888:	554d47b7          	lui	a5,0x554d4
    8000588c:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005890:	10f71d63          	bne	a4,a5,800059aa <virtio_disk_init+0x172>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005894:	100017b7          	lui	a5,0x10001
    80005898:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000589c:	4705                	li	a4,1
    8000589e:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800058a0:	470d                	li	a4,3
    800058a2:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800058a4:	10001737          	lui	a4,0x10001
    800058a8:	4b18                	lw	a4,16(a4)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800058aa:	c7ffe6b7          	lui	a3,0xc7ffe
    800058ae:	55f68693          	addi	a3,a3,1375 # ffffffffc7ffe55f <end+0xffffffff47fdd6a7>
    800058b2:	8f75                	and	a4,a4,a3
    800058b4:	100016b7          	lui	a3,0x10001
    800058b8:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    800058ba:	472d                	li	a4,11
    800058bc:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800058be:	0707a903          	lw	s2,112(a5)
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800058c2:	00897793          	andi	a5,s2,8
    800058c6:	0e078863          	beqz	a5,800059b6 <virtio_disk_init+0x17e>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800058ca:	100017b7          	lui	a5,0x10001
    800058ce:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    800058d2:	43fc                	lw	a5,68(a5)
    800058d4:	0e079763          	bnez	a5,800059c2 <virtio_disk_init+0x18a>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800058d8:	100017b7          	lui	a5,0x10001
    800058dc:	5bdc                	lw	a5,52(a5)
  if (max == 0)
    800058de:	0e078863          	beqz	a5,800059ce <virtio_disk_init+0x196>
  if (max < NUM)
    800058e2:	471d                	li	a4,7
    800058e4:	0ef77b63          	bgeu	a4,a5,800059da <virtio_disk_init+0x1a2>
  disk.desc = kalloc();
    800058e8:	a5afb0ef          	jal	80000b42 <kalloc>
    800058ec:	0001b497          	auipc	s1,0x1b
    800058f0:	48c48493          	addi	s1,s1,1164 # 80020d78 <disk>
    800058f4:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800058f6:	a4cfb0ef          	jal	80000b42 <kalloc>
    800058fa:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800058fc:	a46fb0ef          	jal	80000b42 <kalloc>
    80005900:	87aa                	mv	a5,a0
    80005902:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    80005904:	6088                	ld	a0,0(s1)
    80005906:	0e050063          	beqz	a0,800059e6 <virtio_disk_init+0x1ae>
    8000590a:	0001b717          	auipc	a4,0x1b
    8000590e:	47673703          	ld	a4,1142(a4) # 80020d80 <disk+0x8>
    80005912:	00173713          	seqz	a4,a4
    80005916:	0017b793          	seqz	a5,a5
    8000591a:	8fd9                	or	a5,a5,a4
    8000591c:	e7e9                	bnez	a5,800059e6 <virtio_disk_init+0x1ae>
  memset(disk.desc, 0, PGSIZE);
    8000591e:	6605                	lui	a2,0x1
    80005920:	4581                	li	a1,0
    80005922:	c4cfb0ef          	jal	80000d6e <memset>
  memset(disk.avail, 0, PGSIZE);
    80005926:	0001b497          	auipc	s1,0x1b
    8000592a:	45248493          	addi	s1,s1,1106 # 80020d78 <disk>
    8000592e:	6605                	lui	a2,0x1
    80005930:	4581                	li	a1,0
    80005932:	6488                	ld	a0,8(s1)
    80005934:	c3afb0ef          	jal	80000d6e <memset>
  memset(disk.used, 0, PGSIZE);
    80005938:	6605                	lui	a2,0x1
    8000593a:	4581                	li	a1,0
    8000593c:	6888                	ld	a0,16(s1)
    8000593e:	c30fb0ef          	jal	80000d6e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005942:	100017b7          	lui	a5,0x10001
    80005946:	4721                	li	a4,8
    80005948:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000594a:	4098                	lw	a4,0(s1)
    8000594c:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005950:	40d8                	lw	a4,4(s1)
    80005952:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005956:	649c                	ld	a5,8(s1)
    80005958:	10001737          	lui	a4,0x10001
    8000595c:	08f72823          	sw	a5,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005960:	9781                	srai	a5,a5,0x20
    80005962:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005966:	689c                	ld	a5,16(s1)
    80005968:	0af72023          	sw	a5,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000596c:	9781                	srai	a5,a5,0x20
    8000596e:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005972:	4785                	li	a5,1
    80005974:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005976:	00f48c23          	sb	a5,24(s1)
    8000597a:	00f48ca3          	sb	a5,25(s1)
    8000597e:	00f48d23          	sb	a5,26(s1)
    80005982:	00f48da3          	sb	a5,27(s1)
    80005986:	00f48e23          	sb	a5,28(s1)
    8000598a:	00f48ea3          	sb	a5,29(s1)
    8000598e:	00f48f23          	sb	a5,30(s1)
    80005992:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005996:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    8000599a:	07272823          	sw	s2,112(a4)
}
    8000599e:	60e2                	ld	ra,24(sp)
    800059a0:	6442                	ld	s0,16(sp)
    800059a2:	64a2                	ld	s1,8(sp)
    800059a4:	6902                	ld	s2,0(sp)
    800059a6:	6105                	addi	sp,sp,32
    800059a8:	8082                	ret
    panic("could not find virtio disk");
    800059aa:	00002517          	auipc	a0,0x2
    800059ae:	d9650513          	addi	a0,a0,-618 # 80007740 <etext+0x740>
    800059b2:	e97fa0ef          	jal	80000848 <panic>
    panic("virtio disk FEATURES_OK unset");
    800059b6:	00002517          	auipc	a0,0x2
    800059ba:	daa50513          	addi	a0,a0,-598 # 80007760 <etext+0x760>
    800059be:	e8bfa0ef          	jal	80000848 <panic>
    panic("virtio disk should not be ready");
    800059c2:	00002517          	auipc	a0,0x2
    800059c6:	dbe50513          	addi	a0,a0,-578 # 80007780 <etext+0x780>
    800059ca:	e7ffa0ef          	jal	80000848 <panic>
    panic("virtio disk has no queue 0");
    800059ce:	00002517          	auipc	a0,0x2
    800059d2:	dd250513          	addi	a0,a0,-558 # 800077a0 <etext+0x7a0>
    800059d6:	e73fa0ef          	jal	80000848 <panic>
    panic("virtio disk max queue too short");
    800059da:	00002517          	auipc	a0,0x2
    800059de:	de650513          	addi	a0,a0,-538 # 800077c0 <etext+0x7c0>
    800059e2:	e67fa0ef          	jal	80000848 <panic>
    panic("virtio disk kalloc");
    800059e6:	00002517          	auipc	a0,0x2
    800059ea:	dfa50513          	addi	a0,a0,-518 # 800077e0 <etext+0x7e0>
    800059ee:	e5bfa0ef          	jal	80000848 <panic>

00000000800059f2 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800059f2:	711d                	addi	sp,sp,-96
    800059f4:	ec86                	sd	ra,88(sp)
    800059f6:	e8a2                	sd	s0,80(sp)
    800059f8:	e4a6                	sd	s1,72(sp)
    800059fa:	e0ca                	sd	s2,64(sp)
    800059fc:	fc4e                	sd	s3,56(sp)
    800059fe:	f852                	sd	s4,48(sp)
    80005a00:	f456                	sd	s5,40(sp)
    80005a02:	f05a                	sd	s6,32(sp)
    80005a04:	ec5e                	sd	s7,24(sp)
    80005a06:	e862                	sd	s8,16(sp)
    80005a08:	1080                	addi	s0,sp,96
    80005a0a:	89aa                	mv	s3,a0
    80005a0c:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005a0e:	00c52b83          	lw	s7,12(a0)
    80005a12:	001b9b9b          	slliw	s7,s7,0x1
    80005a16:	1b82                	slli	s7,s7,0x20
    80005a18:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80005a1c:	0001b517          	auipc	a0,0x1b
    80005a20:	48450513          	addi	a0,a0,1156 # 80020ea0 <disk+0x128>
    80005a24:	a8efb0ef          	jal	80000cb2 <acquire>
  for (int i = 0; i < NUM; i++) {
    80005a28:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005a2a:	0001ba97          	auipc	s5,0x1b
    80005a2e:	34ea8a93          	addi	s5,s5,846 # 80020d78 <disk>
  for (int i = 0; i < 3; i++) {
    80005a32:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80005a34:	5c7d                	li	s8,-1
    80005a36:	a8a5                	j	80005aae <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    80005a38:	00fa8733          	add	a4,s5,a5
    80005a3c:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005a40:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    80005a42:	0207c563          	bltz	a5,80005a6c <virtio_disk_rw+0x7a>
  for (int i = 0; i < 3; i++) {
    80005a46:	2905                	addiw	s2,s2,1
    80005a48:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005a4a:	07490663          	beq	s2,s4,80005ab6 <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    80005a4e:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005a50:	0001b717          	auipc	a4,0x1b
    80005a54:	32870713          	addi	a4,a4,808 # 80020d78 <disk>
    80005a58:	4781                	li	a5,0
    if (disk.free[i]) {
    80005a5a:	01874683          	lbu	a3,24(a4)
    80005a5e:	fee9                	bnez	a3,80005a38 <virtio_disk_rw+0x46>
  for (int i = 0; i < NUM; i++) {
    80005a60:	2785                	addiw	a5,a5,1
    80005a62:	0705                	addi	a4,a4,1
    80005a64:	fe979be3          	bne	a5,s1,80005a5a <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80005a68:	0185a023          	sw	s8,0(a1)
      for (int j = 0; j < i; j++)
    80005a6c:	01205d63          	blez	s2,80005a86 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005a70:	fa042503          	lw	a0,-96(s0)
    80005a74:	d4fff0ef          	jal	800057c2 <free_desc>
      for (int j = 0; j < i; j++)
    80005a78:	4785                	li	a5,1
    80005a7a:	0127d663          	bge	a5,s2,80005a86 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005a7e:	fa442503          	lw	a0,-92(s0)
    80005a82:	d41ff0ef          	jal	800057c2 <free_desc>
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005a86:	0001b517          	auipc	a0,0x1b
    80005a8a:	30a50513          	addi	a0,a0,778 # 80020d90 <disk+0x18>
    80005a8e:	e3cfc0ef          	jal	800020ca <sleep_prepare>
    release(&disk.vdisk_lock);
    80005a92:	0001b517          	auipc	a0,0x1b
    80005a96:	40e50513          	addi	a0,a0,1038 # 80020ea0 <disk+0x128>
    80005a9a:	a9cfb0ef          	jal	80000d36 <release>
    sleep();
    80005a9e:	e68fc0ef          	jal	80002106 <sleep>
    acquire(&disk.vdisk_lock);
    80005aa2:	0001b517          	auipc	a0,0x1b
    80005aa6:	3fe50513          	addi	a0,a0,1022 # 80020ea0 <disk+0x128>
    80005aaa:	a08fb0ef          	jal	80000cb2 <acquire>
  for (int i = 0; i < 3; i++) {
    80005aae:	fa040613          	addi	a2,s0,-96
    80005ab2:	4901                	li	s2,0
    80005ab4:	bf69                	j	80005a4e <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005ab6:	fa042503          	lw	a0,-96(s0)
    80005aba:	00451693          	slli	a3,a0,0x4

  if (write)
    80005abe:	0001b797          	auipc	a5,0x1b
    80005ac2:	2ba78793          	addi	a5,a5,698 # 80020d78 <disk>
    80005ac6:	00451713          	slli	a4,a0,0x4
    80005aca:	0a070713          	addi	a4,a4,160
    80005ace:	973e                	add	a4,a4,a5
    80005ad0:	01603633          	snez	a2,s6
    80005ad4:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005ad6:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005ada:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005ade:	6398                	ld	a4,0(a5)
    80005ae0:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005ae2:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005ae6:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005ae8:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005aea:	6390                	ld	a2,0(a5)
    80005aec:	00d605b3          	add	a1,a2,a3
    80005af0:	4741                	li	a4,16
    80005af2:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005af4:	4805                	li	a6,1
    80005af6:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005afa:	fa442703          	lw	a4,-92(s0)
    80005afe:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005b02:	0712                	slli	a4,a4,0x4
    80005b04:	963a                	add	a2,a2,a4
    80005b06:	05898593          	addi	a1,s3,88
    80005b0a:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005b0c:	0007b883          	ld	a7,0(a5)
    80005b10:	9746                	add	a4,a4,a7
    80005b12:	40000613          	li	a2,1024
    80005b16:	c710                	sw	a2,8(a4)
  if (write)
    80005b18:	001b3613          	seqz	a2,s6
    80005b1c:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005b20:	01066633          	or	a2,a2,a6
    80005b24:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005b28:	fa842583          	lw	a1,-88(s0)
    80005b2c:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005b30:	00250613          	addi	a2,a0,2
    80005b34:	0612                	slli	a2,a2,0x4
    80005b36:	963e                	add	a2,a2,a5
    80005b38:	577d                	li	a4,-1
    80005b3a:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005b3e:	0592                	slli	a1,a1,0x4
    80005b40:	98ae                	add	a7,a7,a1
    80005b42:	03068713          	addi	a4,a3,48
    80005b46:	973e                	add	a4,a4,a5
    80005b48:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005b4c:	6398                	ld	a4,0(a5)
    80005b4e:	972e                	add	a4,a4,a1
    80005b50:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005b54:	4689                	li	a3,2
    80005b56:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005b5a:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005b5e:	0109a223          	sw	a6,4(s3)
  disk.info[idx[0]].b = b;
    80005b62:	01363423          	sd	s3,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005b66:	6794                	ld	a3,8(a5)
    80005b68:	0026d703          	lhu	a4,2(a3)
    80005b6c:	8b1d                	andi	a4,a4,7
    80005b6e:	0706                	slli	a4,a4,0x1
    80005b70:	96ba                	add	a3,a3,a4
    80005b72:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005b76:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005b7a:	6798                	ld	a4,8(a5)
    80005b7c:	00275783          	lhu	a5,2(a4)
    80005b80:	2785                	addiw	a5,a5,1
    80005b82:	00f71123          	sh	a5,2(a4)
    80005b86:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b8a:	100017b7          	lui	a5,0x10001
    80005b8e:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005b92:	0049a783          	lw	a5,4(s3)
    80005b96:	03079663          	bne	a5,a6,80005bc2 <virtio_disk_rw+0x1d0>
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80005b9a:	0001b497          	auipc	s1,0x1b
    80005b9e:	30648493          	addi	s1,s1,774 # 80020ea0 <disk+0x128>
  while (b->disk == 1) {
    80005ba2:	893e                	mv	s2,a5
    sleep_prepare(b);
    80005ba4:	854e                	mv	a0,s3
    80005ba6:	d24fc0ef          	jal	800020ca <sleep_prepare>
    release(&disk.vdisk_lock);
    80005baa:	8526                	mv	a0,s1
    80005bac:	98afb0ef          	jal	80000d36 <release>
    sleep();
    80005bb0:	d56fc0ef          	jal	80002106 <sleep>
    acquire(&disk.vdisk_lock);
    80005bb4:	8526                	mv	a0,s1
    80005bb6:	8fcfb0ef          	jal	80000cb2 <acquire>
  while (b->disk == 1) {
    80005bba:	0049a783          	lw	a5,4(s3)
    80005bbe:	ff2783e3          	beq	a5,s2,80005ba4 <virtio_disk_rw+0x1b2>
  }

  disk.info[idx[0]].b = 0;
    80005bc2:	fa042903          	lw	s2,-96(s0)
    80005bc6:	00290713          	addi	a4,s2,2
    80005bca:	0712                	slli	a4,a4,0x4
    80005bcc:	0001b797          	auipc	a5,0x1b
    80005bd0:	1ac78793          	addi	a5,a5,428 # 80020d78 <disk>
    80005bd4:	97ba                	add	a5,a5,a4
    80005bd6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005bda:	0001b997          	auipc	s3,0x1b
    80005bde:	19e98993          	addi	s3,s3,414 # 80020d78 <disk>
    80005be2:	00491713          	slli	a4,s2,0x4
    80005be6:	0009b783          	ld	a5,0(s3)
    80005bea:	97ba                	add	a5,a5,a4
    80005bec:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005bf0:	854a                	mv	a0,s2
    80005bf2:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005bf6:	bcdff0ef          	jal	800057c2 <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005bfa:	8885                	andi	s1,s1,1
    80005bfc:	f0fd                	bnez	s1,80005be2 <virtio_disk_rw+0x1f0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005bfe:	0001b517          	auipc	a0,0x1b
    80005c02:	2a250513          	addi	a0,a0,674 # 80020ea0 <disk+0x128>
    80005c06:	930fb0ef          	jal	80000d36 <release>
}
    80005c0a:	60e6                	ld	ra,88(sp)
    80005c0c:	6446                	ld	s0,80(sp)
    80005c0e:	64a6                	ld	s1,72(sp)
    80005c10:	6906                	ld	s2,64(sp)
    80005c12:	79e2                	ld	s3,56(sp)
    80005c14:	7a42                	ld	s4,48(sp)
    80005c16:	7aa2                	ld	s5,40(sp)
    80005c18:	7b02                	ld	s6,32(sp)
    80005c1a:	6be2                	ld	s7,24(sp)
    80005c1c:	6c42                	ld	s8,16(sp)
    80005c1e:	6125                	addi	sp,sp,96
    80005c20:	8082                	ret

0000000080005c22 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005c22:	1101                	addi	sp,sp,-32
    80005c24:	ec06                	sd	ra,24(sp)
    80005c26:	e822                	sd	s0,16(sp)
    80005c28:	e426                	sd	s1,8(sp)
    80005c2a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005c2c:	0001b497          	auipc	s1,0x1b
    80005c30:	14c48493          	addi	s1,s1,332 # 80020d78 <disk>
    80005c34:	0001b517          	auipc	a0,0x1b
    80005c38:	26c50513          	addi	a0,a0,620 # 80020ea0 <disk+0x128>
    80005c3c:	876fb0ef          	jal	80000cb2 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005c40:	100017b7          	lui	a5,0x10001
    80005c44:	53bc                	lw	a5,96(a5)
    80005c46:	8b8d                	andi	a5,a5,3
    80005c48:	10001737          	lui	a4,0x10001
    80005c4c:	d37c                	sw	a5,100(a4)
    80005c4e:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005c52:	689c                	ld	a5,16(s1)
    80005c54:	0204d703          	lhu	a4,32(s1)
    80005c58:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005c5c:	04f70663          	beq	a4,a5,80005ca8 <virtio_disk_intr+0x86>
    80005c60:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005c64:	6898                	ld	a4,16(s1)
    80005c66:	0204d783          	lhu	a5,32(s1)
    80005c6a:	8b9d                	andi	a5,a5,7
    80005c6c:	078e                	slli	a5,a5,0x3
    80005c6e:	97ba                	add	a5,a5,a4
    80005c70:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005c72:	00278713          	addi	a4,a5,2
    80005c76:	0712                	slli	a4,a4,0x4
    80005c78:	9726                	add	a4,a4,s1
    80005c7a:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80005c7e:	e321                	bnez	a4,80005cbe <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005c80:	0789                	addi	a5,a5,2
    80005c82:	0792                	slli	a5,a5,0x4
    80005c84:	97a6                	add	a5,a5,s1
    80005c86:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005c88:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c8c:	caafc0ef          	jal	80002136 <wakeup>

    disk.used_idx += 1;
    80005c90:	0204d783          	lhu	a5,32(s1)
    80005c94:	2785                	addiw	a5,a5,1
    80005c96:	17c2                	slli	a5,a5,0x30
    80005c98:	93c1                	srli	a5,a5,0x30
    80005c9a:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005c9e:	6898                	ld	a4,16(s1)
    80005ca0:	00275703          	lhu	a4,2(a4)
    80005ca4:	faf71ee3          	bne	a4,a5,80005c60 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005ca8:	0001b517          	auipc	a0,0x1b
    80005cac:	1f850513          	addi	a0,a0,504 # 80020ea0 <disk+0x128>
    80005cb0:	886fb0ef          	jal	80000d36 <release>
}
    80005cb4:	60e2                	ld	ra,24(sp)
    80005cb6:	6442                	ld	s0,16(sp)
    80005cb8:	64a2                	ld	s1,8(sp)
    80005cba:	6105                	addi	sp,sp,32
    80005cbc:	8082                	ret
      panic("virtio_disk_intr status");
    80005cbe:	00002517          	auipc	a0,0x2
    80005cc2:	b3a50513          	addi	a0,a0,-1222 # 800077f8 <etext+0x7f8>
    80005cc6:	b83fa0ef          	jal	80000848 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	0000100f          	fence.i
    800060a0:	12000073          	sfence.vma
    800060a4:	18051073          	csrw	satp,a0
    800060a8:	12000073          	sfence.vma
    800060ac:	02000537          	lui	a0,0x2000
    800060b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060b2:	0536                	slli	a0,a0,0xd
    800060b4:	02853083          	ld	ra,40(a0)
    800060b8:	03053103          	ld	sp,48(a0)
    800060bc:	03853183          	ld	gp,56(a0)
    800060c0:	04053203          	ld	tp,64(a0)
    800060c4:	04853283          	ld	t0,72(a0)
    800060c8:	05053303          	ld	t1,80(a0)
    800060cc:	05853383          	ld	t2,88(a0)
    800060d0:	7120                	ld	s0,96(a0)
    800060d2:	7524                	ld	s1,104(a0)
    800060d4:	7d2c                	ld	a1,120(a0)
    800060d6:	6150                	ld	a2,128(a0)
    800060d8:	6554                	ld	a3,136(a0)
    800060da:	6958                	ld	a4,144(a0)
    800060dc:	6d5c                	ld	a5,152(a0)
    800060de:	0a053803          	ld	a6,160(a0)
    800060e2:	0a853883          	ld	a7,168(a0)
    800060e6:	0b053903          	ld	s2,176(a0)
    800060ea:	0b853983          	ld	s3,184(a0)
    800060ee:	0c053a03          	ld	s4,192(a0)
    800060f2:	0c853a83          	ld	s5,200(a0)
    800060f6:	0d053b03          	ld	s6,208(a0)
    800060fa:	0d853b83          	ld	s7,216(a0)
    800060fe:	0e053c03          	ld	s8,224(a0)
    80006102:	0e853c83          	ld	s9,232(a0)
    80006106:	0f053d03          	ld	s10,240(a0)
    8000610a:	0f853d83          	ld	s11,248(a0)
    8000610e:	10053e03          	ld	t3,256(a0)
    80006112:	10853e83          	ld	t4,264(a0)
    80006116:	11053f03          	ld	t5,272(a0)
    8000611a:	11853f83          	ld	t6,280(a0)
    8000611e:	7928                	ld	a0,112(a0)
    80006120:	10200073          	sret
	...
